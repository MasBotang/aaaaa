import foundersAsset from "@/assets/founders.png.asset.json";
import originalAsset from "@/assets/original-mayo.png.asset.json";

export function Story() {
  return (
    <section id="story" aria-label="Cerita De Salut" className="relative overflow-hidden bg-cream-deep py-20 lg:py-28">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 top-10 h-[520px] w-[520px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--gold) 40%, transparent), transparent)" }}
      />

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-start gap-12 px-5 sm:px-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)] lg:gap-16 lg:px-12">
        {/* Visual */}
        <div className="relative">
          <div className="relative overflow-hidden rounded-[2rem] border border-border/50 bg-card shadow-[var(--shadow-product)]">
            <div className="relative aspect-[4/5] bg-gradient-to-br from-cream to-cream-deep">
              <div
                aria-hidden
                className="absolute inset-0"
                style={{ background: "radial-gradient(55% 50% at 50% 45%, color-mix(in oklab, var(--gold) 45%, transparent), transparent 72%)" }}
              />
              <img
                src={originalAsset.url}
                alt="Proses lipat kulit risol tipis krispi De Salut"
                className="absolute inset-0 m-auto h-[88%] w-auto max-w-[88%] object-contain drop-shadow-[0_30px_50px_rgba(70,25,10,0.30)]"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>

          {/* Founders small overlay */}
          <div className="absolute -bottom-6 -right-4 hidden w-40 overflow-hidden rounded-2xl border border-border/60 bg-card p-2 shadow-[var(--shadow-badge)] sm:block">
            <img src={foundersAsset.url} alt="Founder De Salut" className="h-full w-full object-contain" loading="lazy" />
          </div>
        </div>

        {/* Copy */}
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-terracotta/30 bg-terracotta/10 px-3 py-1.5 text-[0.72rem] font-semibold uppercase tracking-[0.14em] text-terracotta-deep">
            Our Story
          </span>
          <h2 className="mt-5 font-display text-[2.1rem] font-semibold leading-[1.05] tracking-[-0.02em] text-ink sm:text-[2.6rem] lg:text-[3rem]">
            Berawal dari Berburu Risol <br className="hidden sm:block" />
            di Kota Orang… <span aria-hidden>🚗💨</span>
          </h2>

          <div className="mt-6 space-y-4 text-[1.02rem] leading-relaxed text-ink-soft">
            <p>
              Kami berdua suka banget kulineran dan nemuin brand-brand risol
              legendaris di Jogja & Bandung. Tapi tiap kali balik ke Bekasi,
              selalu nanya:
            </p>
            <blockquote className="border-l-2 border-terracotta bg-cream/60 px-5 py-3 font-display text-lg italic text-ink">
              “Kenapa di Bekasi belum ada risol kulit tipis krispi yang isinya
              melimpah kayak gini?”
            </blockquote>
            <p>
              Akhirnya, kami putusin buat bikin sendiri! Berbulan-bulan bongkar
              pasang resep di dapur demi dapetin krispi kulit yang pas dan isian
              yang <span className="font-semibold text-terracotta-deep">nggak pelit</span>.
            </p>
            <p>
              Kami mau buktikan kalau Bekasi juga punya risol{" "}
              <span className="font-semibold text-terracotta-deep">local pride</span>{" "}
              yang nggak kalah jempolan!
            </p>
          </div>

          <p className="mt-6 font-display text-base italic text-terracotta-deep">
            — Tim Risol Mayo De Salut ❤️
          </p>
        </div>
      </div>
    </section>
  );
}
