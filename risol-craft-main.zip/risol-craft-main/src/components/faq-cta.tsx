import { useState } from "react";
import { ChevronDown, Zap, MessageCircle } from "lucide-react";

const faqs = [
  {
    q: "Hari apa aja operasional Risol De Salut?",
    a: "Kami buka Selasa–Minggu, produksi fresh setiap hari. Libur produksi setiap hari Senin ya!",
  },
  {
    q: "Gimana cara pengiriman untuk luar kota?",
    a: "Untuk pengiriman luar kota / jarak jauh, kamu bisa pilih varian Frozen Pack yang aman dikirim pakai layanan Paxel Sameday/Nextday!",
  },
  {
    q: "Boleh gak kalau mau Pickup / ambil sendiri?",
    a: "Boleh banget! Kamu bisa pickup di dapur kami di Bekasi. DM admin dulu buat konfirmasi jam ambil ya.",
  },
  {
    q: "Minimal order berapa pcs?",
    a: "Minimal order 10 pcs untuk area Bekasi. Untuk Frozen Pack minimal 1 pack isi 10.",
  },
];

export function FaqCta() {
  const [open, setOpen] = useState<number | null>(1);

  return (
    <section id="order" aria-label="FAQ dan Order" className="relative overflow-hidden bg-cream-deep py-20 lg:py-28">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-40 bottom-0 h-[500px] w-[500px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--terracotta) 25%, transparent), transparent)" }}
      />

      <div className="relative z-10 mx-auto w-full max-w-3xl px-5 sm:px-8 lg:px-12">
        <div className="text-center">
          <h2 className="font-display text-[2rem] font-semibold leading-[1.05] tracking-[-0.02em] text-ink sm:text-[2.4rem]">
            Ada Pertanyaan? 💬
          </h2>
        </div>

        <div className="mt-8 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div
                key={f.q}
                className={`overflow-hidden rounded-2xl border bg-card transition-all duration-200 ${
                  isOpen ? "border-terracotta/40 shadow-[var(--shadow-badge)]" : "border-border/60"
                }`}
              >
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-medium text-ink">{f.q}</span>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-terracotta transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                    aria-hidden
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ease-out ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-[0.95rem] leading-relaxed text-ink-soft">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <hr className="my-12 border-border/60" />

        {/* Final CTA */}
        <div className="text-center">
          <h3 className="font-display text-[1.9rem] font-semibold leading-[1.05] tracking-[-0.02em] text-ink sm:text-[2.3rem]">
            Siap Nyobain Risol Kulit <span className="italic text-terracotta">Tipis Krispi</span>? 🚀
          </h3>
          <p className="mt-3 text-sm italic text-ink-soft">
            *Dibuat fresh setiap hari. Libur produksi setiap hari Senin.
          </p>

          <div className="mt-8 flex w-full flex-col items-stretch justify-center gap-3 sm:flex-row">
            <a
              href="#quick-order"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-terracotta px-8 py-4 text-[0.98rem] font-semibold text-cream shadow-[var(--shadow-cta)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-terracotta-deep"
            >
              <Zap className="h-4 w-4" aria-hidden />
              Form Quick Order (Web)
            </a>
            <a
              href="https://wa.me/6281234567890"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-terracotta/30 bg-card px-8 py-4 text-[0.98rem] font-semibold text-terracotta-deep transition-all duration-200 hover:border-terracotta hover:bg-terracotta/5"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Chat Admin via WA
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
