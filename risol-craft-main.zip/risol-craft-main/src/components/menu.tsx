import { useState } from "react";
import { Plus, Flame, Snowflake, Package, Sparkles } from "lucide-react";
import mayoSpesialAsset from "@/assets/mayo-spesial.png.asset.json";
import chocoAsset from "@/assets/choco-crunchy.png.asset.json";
import originalAsset from "@/assets/original-mayo.png.asset.json";
import ayamAsset from "@/assets/ayam-suwir.png.asset.json";

type Category = "all" | "best" | "frozen" | "paket";

type Item = {
  name: string;
  desc: string;
  price: string;
  tag?: { label: string; tone: "fire" | "sweet" | "spicy" | "pack" };
  image: string;
  categories: Category[];
};

const items: Item[] = [
  {
    name: "Mayo Special",
    desc: "Secret Mayo, Double Cheese, Smoked Beef, Telur",
    price: "5K",
    tag: { label: "Most Popular", tone: "fire" },
    image: mayoSpesialAsset.url,
    categories: ["all", "best"],
  },
  {
    name: "Choco Crunchy",
    desc: "Choco Crunchy, Rice Crispy",
    price: "5K",
    tag: { label: "Best Sweet", tone: "sweet" },
    image: chocoAsset.url,
    categories: ["all", "best"],
  },
  {
    name: "Original Mayo",
    desc: "Secret Mayo, Smoked Beef, Telur",
    price: "4K",
    image: originalAsset.url,
    categories: ["all"],
  },
  {
    name: "Ayam Suwir Pedas",
    desc: "Ayam suwir bumbu pedas, mayo lembut",
    price: "5K",
    tag: { label: "Spicy Pick", tone: "spicy" },
    image: ayamAsset.url,
    categories: ["all"],
  },
  {
    name: "Paket Asin",
    desc: "2 Original, 2 Nori Spicy, 1 Mayo Special",
    price: "21K",
    tag: { label: "Hemat", tone: "pack" },
    image: originalAsset.url,
    categories: ["all", "paket"],
  },
  {
    name: "Frozen Pack (isi 10)",
    desc: "Aman dikirim luar kota via Paxel",
    price: "40K",
    tag: { label: "Frozen", tone: "pack" },
    image: mayoSpesialAsset.url,
    categories: ["all", "frozen"],
  },
];

const tabs: { id: Category; label: string; icon: React.ReactNode }[] = [
  { id: "all", label: "All", icon: <Sparkles className="h-3.5 w-3.5" aria-hidden /> },
  { id: "best", label: "Best Seller", icon: <Flame className="h-3.5 w-3.5" aria-hidden /> },
  { id: "frozen", label: "Frozen", icon: <Snowflake className="h-3.5 w-3.5" aria-hidden /> },
  { id: "paket", label: "Paket", icon: <Package className="h-3.5 w-3.5" aria-hidden /> },
];

const toneStyles: Record<NonNullable<Item["tag"]>["tone"], string> = {
  fire: "bg-terracotta text-cream",
  sweet: "bg-gold/90 text-ink",
  spicy: "bg-terracotta-deep text-cream",
  pack: "bg-cream-deep text-terracotta-deep border border-terracotta/30",
};

export function Menu() {
  const [active, setActive] = useState<Category>("all");
  const filtered = items.filter((i) => i.categories.includes(active));

  return (
    <section id="menu" aria-label="Menu De Salut" className="relative overflow-hidden bg-grain py-20 lg:py-28">
      <div className="mx-auto w-full max-w-6xl px-5 sm:px-8 lg:px-12">
        <div className="text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-terracotta/30 bg-terracotta/10 px-3 py-1.5 text-[0.72rem] font-semibold uppercase tracking-[0.14em] text-terracotta-deep">
            Menu De Salut
          </span>
          <h2 className="mt-5 font-display text-[2.1rem] font-semibold leading-[1.05] tracking-[-0.02em] text-ink sm:text-[2.6rem] lg:text-[3rem]">
            Pilih Varian <span className="italic text-terracotta">Favoritmu</span> 🤤
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-ink-soft">
            Semua dibuat fresh setiap hari. Kulit tipis krispi, isian melimpah.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="mt-8 flex flex-wrap justify-center gap-2">
          {tabs.map((t) => {
            const isActive = active === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActive(t.id)}
                className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "border-terracotta bg-terracotta text-cream shadow-[var(--shadow-cta)]"
                    : "border-border bg-card/70 text-ink hover:border-terracotta/40 hover:bg-card"
                }`}
                aria-pressed={isActive}
              >
                {t.icon}
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Grid */}
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (
            <article
              key={item.name}
              className="group relative flex flex-col overflow-hidden rounded-3xl border border-border/60 bg-card shadow-[var(--shadow-badge)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-product)]"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-cream-deep to-cream">
                <div
                  aria-hidden
                  className="absolute inset-0"
                  style={{ background: "radial-gradient(55% 50% at 50% 55%, color-mix(in oklab, var(--gold) 40%, transparent), transparent 72%)" }}
                />
                <img
                  src={item.image}
                  alt={item.name}
                  className="absolute inset-0 m-auto h-[90%] w-auto max-w-[90%] object-contain drop-shadow-[0_20px_30px_rgba(70,25,10,0.28)] transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                  decoding="async"
                />
                {item.tag && (
                  <span
                    className={`absolute left-3 top-3 inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider shadow-[var(--shadow-badge)] ${toneStyles[item.tag.tone]}`}
                  >
                    {item.tag.label}
                  </span>
                )}
                <span className="absolute right-3 top-3 inline-flex items-center rounded-full bg-ink px-3 py-1 text-sm font-semibold text-cream">
                  Rp {item.price}
                </span>
              </div>
              <div className="flex flex-1 flex-col gap-3 p-5">
                <div>
                  <h3 className="font-display text-xl font-semibold tracking-tight text-ink">{item.name}</h3>
                  <p className="mt-1 text-sm text-ink-soft">{item.desc}</p>
                </div>
                <button
                  type="button"
                  className="mt-auto inline-flex items-center justify-center gap-1.5 rounded-full border border-terracotta/30 bg-transparent px-4 py-2.5 text-sm font-semibold text-terracotta-deep transition-all duration-200 hover:border-terracotta hover:bg-terracotta hover:text-cream"
                >
                  <Plus className="h-4 w-4" aria-hidden />
                  Tambah ke Order
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a
            href="#order"
            className="inline-flex items-center gap-2 text-sm font-semibold text-terracotta-deep underline decoration-terracotta/40 decoration-2 underline-offset-4 hover:text-terracotta"
          >
            Lihat Semua Menu Frozen & Paket
          </a>
        </div>
      </div>
    </section>
  );
}
