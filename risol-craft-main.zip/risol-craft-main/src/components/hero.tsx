import { MapPin, ShoppingBag, MessageCircle, ChevronDown, Flame, Star } from "lucide-react";
import logoAsset from "@/assets/logo.png.asset.json";
import foundersAsset from "@/assets/founders.png.asset.json";

export function Hero() {
  return (
    <section aria-label="Risol Mayo De Salut" className="relative isolate overflow-hidden bg-grain">
      {/* Sticky header */}
      <header className="sticky top-0 z-40 border-b border-border/50 bg-cream/85 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8 lg:px-12">
          <a href="/" aria-label="De Salut home" className="flex items-center">
            <img src={logoAsset.url} alt="De Salut" width={140} height={44} className="h-9 w-auto sm:h-10" />
          </a>
          <a
            href="#order"
            className="group inline-flex items-center gap-2 rounded-full bg-terracotta px-4 py-2 text-[0.82rem] font-semibold text-cream shadow-[var(--shadow-cta)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-terracotta-deep sm:px-5 sm:py-2.5 sm:text-sm"
          >
            <ShoppingBag className="h-3.5 w-3.5 sm:h-4 sm:w-4" aria-hidden />
            Quick Order
          </a>
        </div>
      </header>

      {/* Ambient warm glows */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -left-32 h-[520px] w-[520px] rounded-full opacity-60 blur-3xl"
        style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--gold) 35%, transparent), transparent)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 -right-24 h-[560px] w-[560px] rounded-full opacity-50 blur-3xl"
        style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--terracotta) 22%, transparent), transparent)" }}
      />

      <div className="relative z-10 mx-auto flex w-full max-w-4xl flex-col items-center px-5 pb-16 pt-10 text-center sm:px-8 md:pt-14 lg:pb-24 lg:pt-16">
        {/* Media card */}
        <div className="animate-hero-in relative w-full max-w-2xl">
          <div className="relative overflow-hidden rounded-[2rem] border border-border/50 bg-card/70 shadow-[var(--shadow-product)]">
            <div className="relative aspect-[4/3] w-full bg-gradient-to-br from-cream-deep to-cream">
              <div
                aria-hidden
                className="absolute inset-0"
                style={{
                  background:
                    "radial-gradient(60% 55% at 50% 55%, color-mix(in oklab, var(--gold) 40%, var(--cream)) 0%, transparent 70%)",
                }}
              />
              <img
                src={foundersAsset.url}
                alt="Founder Risol Mayo De Salut membawa box risol krispi"
                className="absolute inset-x-0 bottom-0 mx-auto h-[92%] w-auto max-w-[86%] object-contain drop-shadow-[0_30px_45px_rgba(70,25,10,0.28)]"
                loading="eager"
                decoding="async"
              />
            </div>

            {/* Floating location badge */}
            <div className="absolute left-4 top-4 sm:left-5 sm:top-5">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card/90 px-3 py-1.5 text-[0.72rem] font-medium text-ink shadow-[var(--shadow-badge)] backdrop-blur">
                <MapPin className="h-3.5 w-3.5 text-terracotta" aria-hidden />
                Handcrafted in Bekasi
              </span>
            </div>

            {/* Fresh chip */}
            <div className="absolute right-4 top-4 sm:right-5 sm:top-5">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-card/90 px-3 py-1.5 text-[0.72rem] font-medium text-ink shadow-[var(--shadow-badge)] backdrop-blur">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-terracotta/50" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-terracotta" />
                </span>
                Fresh Daily
              </span>
            </div>
          </div>
        </div>

        {/* Headline */}
        <h1 className="animate-hero-in mt-10 font-display text-[2.4rem] font-semibold leading-[1.03] tracking-[-0.02em] text-ink sm:text-[3rem] md:text-[3.4rem] lg:text-[3.9rem] [animation-delay:80ms]">
          Risol Kulit Tipis <span className="italic text-terracotta">Krispi</span>
          <br className="hidden sm:block" /> Kesukaan Warga <span className="italic text-terracotta">Bekasi</span> ✨
        </h1>

        <p className="animate-hero-in mt-6 max-w-2xl text-[1.02rem] leading-relaxed text-ink-soft sm:text-lg [animation-delay:160ms]">
          “Eksperimen berdua demi nyiptain risol kulit super tipis dengan isian
          mayo lumer yang pas buat lidah anak Bekasi.”
        </p>

        {/* Social proof strip */}
        <div className="animate-hero-in mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 rounded-full border border-border/60 bg-card/70 px-6 py-3 shadow-[var(--shadow-badge)] backdrop-blur [animation-delay:240ms]">
          <span className="inline-flex items-center gap-2 text-sm font-semibold text-ink">
            <Flame className="h-4 w-4 text-terracotta" aria-hidden />
            10.000+ Pcs Terjual
          </span>
          <span aria-hidden className="hidden h-4 w-px bg-border sm:block" />
          <span className="inline-flex items-center gap-2 text-sm font-semibold text-ink">
            <Star className="h-4 w-4 fill-gold text-gold" aria-hidden />
            5.0 Google Review · Bekasi
          </span>
        </div>

        {/* CTAs */}
        <div className="animate-hero-in mt-8 flex w-full flex-col items-stretch justify-center gap-3 sm:w-auto sm:flex-row [animation-delay:320ms]">
          <a
            href="#order"
            className="group inline-flex items-center justify-center gap-2 rounded-full bg-terracotta px-8 py-4 text-[0.98rem] font-semibold text-cream shadow-[var(--shadow-cta)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-terracotta-deep"
          >
            <ShoppingBag className="h-4 w-4" aria-hidden />
            Pesan Sekarang
          </a>
          <a
            href="https://wa.me/6281234567890"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-terracotta/30 bg-card/60 px-8 py-4 text-[0.98rem] font-semibold text-terracotta-deep transition-all duration-200 hover:border-terracotta hover:bg-terracotta/5"
          >
            <MessageCircle className="h-4 w-4" aria-hidden />
            Tanya Mimin De Salut
          </a>
        </div>

        <a
          href="#story"
          className="animate-hero-in mt-10 inline-flex items-center gap-1.5 text-sm text-ink-soft transition-colors hover:text-terracotta [animation-delay:400ms]"
        >
          Scroll ke cerita kami
          <ChevronDown className="h-4 w-4 animate-bounce" aria-hidden />
        </a>
      </div>
    </section>
  );
}
