import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/hero";
import { Story } from "@/components/story";
import { Menu } from "@/components/menu";
import { FaqCta } from "@/components/faq-cta";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Risol Mayo De Salut — Risol Kulit Tipis Krispi Kesukaan Warga Bekasi" },
      {
        name: "description",
        content:
          "Risol kulit tipis krispi handcrafted di Bekasi. Mayo lumer, isian melimpah, dibuat fresh setiap hari. Pesan sekarang atau chat mimin De Salut.",
      },
      { property: "og:title", content: "Risol Mayo De Salut — Kulit Tipis Krispi, Handcrafted di Bekasi" },
      {
        property: "og:description",
        content:
          "Risol kulit tipis krispi dengan mayo lumer, dibuat fresh setiap hari di Bekasi. 10.000+ pcs terjual · 5.0 Google Review.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Index() {
  return (
    <main>
      <Hero />
      <Story />
      <Menu />
      <FaqCta />
    </main>
  );
}
