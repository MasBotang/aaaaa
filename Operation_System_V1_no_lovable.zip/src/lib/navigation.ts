import {
  ShoppingCart,
  WalletCards,
  BarChart3,
  UsersRound,
  Settings,
  ListChecks,
  Package,
  Home,
  Clock,
  type LucideIcon,

} from "lucide-react";
import type { Role } from "@/services/types";

export interface NavChild {
  title: string;
  to: string;
  comingVersion?: number;
}

export interface NavItem {
  id: string;
  title: string;
  icon: LucideIcon;
  to?: string;
  children?: NavChild[];
  comingVersion?: number;
}

// ---------- Per-role navigation ----------
// Build ini (Desalut Operational System) cuma berisi 5 modul:
// Analytics, Sales, Finance, Accounts, Settings.
// Production, Inventory, Attendance, Payroll TIDAK dibawa ke build ini.
// ⚠️ Modul Keuangan disembunyikan sementara (2026-07-21): finance.service.ts
// dkk (finance-analytics/report/projection/budget) masih baca/tulis lewat
// localStorage ("./storage"), BELUM dimigrasi ke Supabase — beda dengan
// Sales/Inventory/Accounts/Settings yang sudah full Supabase. Kalau
// ditampilkan, data Finance jadi per-device (tidak sinkron, bisa hilang
// kalau cache di-clear) dan laporan yang menggabungkan Sales (Supabase) +
// Finance (localStorage) bisa tidak konsisten antar perangkat.
// Munculkan lagi setelah migrasi Finance selesai (lihat DEPLOY.md).
const adminNav: NavItem[] = [
  {
    id: "analytics",
    title: "Analytics",
    icon: BarChart3,
    children: [
      { title: "Sales", to: "/analytics/sales" },
      // { title: "Finance", to: "/analytics/finance" }, // lihat catatan di atas — belum Supabase
    ],
  },
  {
    id: "sales",
    title: "Penjualan",
    icon: ShoppingCart,
    children: [
      { title: "Home", to: "/sales/home" },
      { title: "POS", to: "/sales/pos" },
      { title: "Pesanan", to: "/sales/pesanan" },
      { title: "Produk", to: "/sales/products" },
      { title: "Shift", to: "/sales/shifts" },
    ],
  },
  // Modul "Keuangan" disembunyikan sementara — lihat catatan di atas.
  // {
  //   id: "finance",
  //   title: "Keuangan",
  //   icon: WalletCards,
  //   children: [
  //     { title: "Overview", to: "/finance" },
  //     { title: "Ledger", to: "/finance/ledger" },
  //     { title: "Pengeluaran", to: "/finance/expenses" },
  //     { title: "Hutang", to: "/finance/debt" },
  //     { title: "Owner Fund", to: "/finance/owner-fund" },
  //     { title: "Development Fund", to: "/finance/development-fund" },
  //     { title: "Operational Fund", to: "/finance/operational-fund" },
  //     { title: "Budget", to: "/finance/budget" },
  //   ],
  // },
  {
    id: "accounts",
    title: "Akun",
    icon: UsersRound,
    children: [
      { title: "Daftar Akun", to: "/accounts" },
    ],
  },
  { id: "settings", title: "Pengaturan", icon: Settings, to: "/settings" },
];

// Owner sidebar mirrors admin, but the Sales section drops the operational pages
// (POS, Pesanan, Shift) that MATRIX in `permissions.ts` denies to owner. This
// prevents the "clickable but blocked" dead links that Audit Finding A flagged
// — navigation and permission matrix must agree.
const ownerNav: NavItem[] = adminNav.map((item) => {
  if (item.id !== "sales" || !item.children) return item;
  const deniedPaths = new Set(["/sales/pos", "/sales/pesanan", "/sales/shifts"]);
  return {
    ...item,
    children: item.children.filter((child) => !deniedPaths.has(child.to ?? "")),
  };
});

const cashierNav: NavItem[] = [
  { id: "sales-home", title: "Home", icon: Home, to: "/sales/home" },
  { id: "pos", title: "POS", icon: ShoppingCart, to: "/sales/pos" },
  { id: "pesanan", title: "Pesanan", icon: ListChecks, to: "/sales/pesanan" },
  { id: "products", title: "Produk", icon: Package, to: "/sales/products" },
  { id: "shifts", title: "Shift", icon: Clock, to: "/sales/shifts" },
];

// ⚠️ KEPUTUSAN BISNIS BELUM DIAMBIL:
// Role "production" di project asal didesain khusus utk modul Production +
// Inventory ("scoped to Production & Inventory only" — lihat permissions.ts),
// dan semua permission-nya `false` di modul lain (Sales/Finance/dst).
// Karena Production & Inventory TIDAK dibawa ke build ini, role ini sekarang
// tidak py akses ke modul apa pun — nav-nya sengaja dikosongkan biar app
// tidak crash, TAPI user dgn role ini akan mendarat di halaman kosong.
// Perlu diputuskan: hapus role ini dari sistem, gabung ke role lain, atau
// biarkan (kalau memang tidak ada staff dengan role ini)?
const productionNav: NavItem[] = [];

const NAV_BY_ROLE: Record<Role, NavItem[]> = {
  admin: adminNav,
  owner: ownerNav,
  cashier: cashierNav,
  production: productionNav,
};

// Kept for compatibility with anything still importing NAV_TREE
export const NAV_TREE: NavItem[] = adminNav;

export function navForRole(role: Role): NavItem[] {
  return NAV_BY_ROLE[role] ?? [];
}

export const ROLE_LANDING: Record<Role, string> = {
  admin: "/analytics/sales",
  owner: "/analytics/sales",
  cashier: "/sales/home",
  // Lihat catatan role "production" di atas — belum ada modul yang cocok
  // dijadikan landing utk role ini di build sekarang.
  production: "/settings",
};

/** Collect all path prefixes a role may visit. */
function allowedPaths(role: Role): string[] {
  const paths: string[] = [];
  for (const item of navForRole(role)) {
    if (item.to) paths.push(item.to);
    if (item.children) for (const c of item.children) paths.push(c.to);
  }
  return paths;
}

/** True if the path is reachable for this role. */
export function canAccess(role: Role, path: string): boolean {
  const paths = allowedPaths(role);
  return paths.some((p) => path === p || path.startsWith(p + "/"));
}
