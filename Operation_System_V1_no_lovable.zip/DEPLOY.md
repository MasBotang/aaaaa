# Deploying to Cloudflare Workers

This app is built with TanStack Start + Nitro (`preset: cloudflare_module`,
configured directly in `vite.config.ts`). `npm run build` produces:

- `.output/server/index.mjs` — the Worker entrypoint
- `.output/public/` — static assets

`wrangler.toml` at the project root points at those paths, so a plain
`wrangler deploy` from the repo root works without extra flags.

> Nitro also auto-generates its own `wrangler.json` inside `.output/server/`
> on every build (that's normal, zero-config nitro behavior). The root
> `wrangler.toml` is what `wrangler deploy` actually uses when run from the
> repo root — if a future nitro/vite upgrade changes the output layout,
> compare the two and update the root file's `main` / `assets.directory`.

---

# Deploying the Supabase backend (migrations & seed)

This is a separate, one-time-per-environment step from the Cloudflare Worker
deploy above — it provisions the Postgres schema and reference data on the
live Supabase project. An operator with the Supabase CLI and access to the
project must run it; it is not automated as part of `npm run deploy`.

## 1. Migration execution order

Migrations must be applied in ascending timestamp order (this is also the
order `supabase db push` applies them in automatically, since it sorts by
filename — listed here for verification purposes):

1. `20260716164012_f0fe33f0-2512-4b9a-b6c7-6528cea6e4f5.sql` — creates
   `public.profiles`, the `handle_new_user()` trigger, and related RLS.
2. `20260716164034_d422bbdb-bcdd-4784-87d9-65a4b4ac818d.sql` — revokes
   direct EXECUTE on `handle_new_user()` / `tg_set_updated_at()` from
   `PUBLIC`, `anon`, `authenticated`.
3. `20260717080000_sales_pos_init.sql` — Sales/POS-first schema (Tahap 1).
4. `20260717090000_db_audit_hardening.sql` — audit hardening pass over
   migrations #1–#3.
5. `20260718100000_reference_data_rpc.sql` — reference-data migration
   (Produk, Inventory Items, Recipes, Price Groups, Settings) + RPCs.
6. `20260720000000_order_queue_cashier_delete.sql` — Sales Domain Tahap 3
   (Order Queue), adds cashier DELETE on `public.order_queue`.
7. `20260721000000_profiles_account_fields.sql` — extends `public.profiles`
   with the account-management fields used by `accounts-page.tsx`.
8. `20260722000000_stock_movements_cashier_insert.sql` — adds a cashier
   INSERT policy on `public.stock_movements` (additive; needed now that
   `stock-movement.service.ts` writes real rows via Supabase instead of
   localStorage — see comments in that migration and in the service file).

Do not reorder or skip any of these — later migrations assume the objects
created by earlier ones exist.

## 2. Seed idempotency check

All three seed scripts in `supabase/seed/` were reviewed and are already
safe to run more than once:

- **`bootstrap-admin.sql`** — uses `insert ... on conflict (id) do update`,
  so re-running it just re-verifies/re-promotes the same profile to
  `role='admin'` instead of erroring or duplicating.
- **`price-groups.sql`** — the `insert ... select ... where not exists
  (select 1 from public.price_groups)` guard means it only seeds once, on
  an empty table.
- **`products-and-inventory.sql`** — same `where not exists (select 1 from
  public.<table>)` guard applied separately to `products` and to
  `inventory_items`.

No changes were needed to any seed file.

## 3. Commands (operator only, requires live Supabase access)

```bash
supabase link --project-ref <project-id-dari-.env>
supabase db push
# lalu jalankan seed lewat SQL editor dashboard atau psql, DALAM URUTAN INI:
#   1. supabase/seed/bootstrap-admin.sql
#        (WAJIB: buat dulu auth.users untuk email admin lewat Dashboard >
#        Authentication > Users > Add user, SEBELUM menjalankan script ini —
#        lihat komentar di dalam file & docs/auth-migration.md)
#   2. supabase/seed/price-groups.sql
#   3. supabase/seed/products-and-inventory.sql   (opsional, data starter)
```

`<project-id-dari-.env>` is the value of `SUPABASE_PROJECT_ID` in the
project's `.env` file.

## 4. Post-deploy: Auth URL configuration (mandatory)

After `supabase db push` (and before real users log in against the
production domain), the operator **must** update, in the Supabase
Dashboard → **Authentication → URL Configuration**:

- **Site URL** → set to the production domain.
- **Redirect URLs** → add the production domain (and any additional
  redirect URLs the app uses, e.g. password-reset or magic-link callback
  paths).

Skipping this step means auth email links (confirmation, magic link,
password reset) will point at the wrong (e.g. localhost or preview) URL in
production.

## One-time setup (operator only)

These steps need a Cloudflare account and can't be done by an AI assistant —
an operator with access must run them:

1. **Log in to Cloudflare:**

   ```bash
   npx wrangler login
   ```

2. **Set the secret** (never put this in `wrangler.toml` or any file that
   gets committed):

   ```bash
   npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
   ```

3. **Set the non-secret variables.** These are safe to expose (they're
   already public-facing: the Supabase URL and the `sb_publishable_...`
   key), but for the same reason it's fine to manage them either way:

   - **Cloudflare dashboard** (Workers & Pages → your Worker → Settings →
     Variables) — recommended, no repo changes needed, or
   - **`wrangler.toml` `[vars]`** — uncomment and fill in the `[vars]` block
     at the bottom of `wrangler.toml`:
     - `SUPABASE_URL`
     - `VITE_SUPABASE_URL`
     - `VITE_SUPABASE_PUBLISHABLE_KEY`
     - `SUPABASE_PUBLISHABLE_KEY`

   Either way, `SUPABASE_SERVICE_ROLE_KEY` stays out of both the dashboard's
   "plaintext" vars and `wrangler.toml` — it only ever goes in via
   `wrangler secret put` (step 2).

## Every deploy after that

```bash
npm run deploy
```

This runs `npm run build && wrangler deploy`.

---

## Security check performed

Per the task's instruction, I checked for `SUPABASE_SERVICE_ROLE_KEY` /
`client.server.ts` leaking into the client bundle:

- `src/integrations/supabase/client.server.ts` is the only file in `src/`
  that references `client.server` or `SUPABASE_SERVICE_ROLE_KEY` — nothing
  else imports it, top-level or otherwise. **No leak found**, this is clean.
- No `VITE_`-prefixed service-role key exists anywhere in the codebase.
- `wrangler.toml` contains no hardcoded secrets.

**Minor (non-critical) observation, not part of what was asked:** the
project's root `.env` (containing the Supabase project ref, `SUPABASE_URL`,
and the publishable key — no secret) is not excluded by `.gitignore`. These
values aren't sensitive, but it's worth adding `.env` to `.gitignore` as a
general hygiene practice so a real secret never accidentally ends up there
later.
