import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { nitro } from "nitro/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Plain Vite config (no Lovable wrapper). This wires up, explicitly, what
// @lovable.dev/vite-tanstack-config used to provide implicitly:
//   - tanstackStart(): TanStack Start SSR integration, pointed at our
//     custom server entry (src/server.ts) so the h3 error-swallowing
//     workaround in that file stays in effect.
//   - nitro(): build-time server bundling, targeting Cloudflare Workers
//     via the "cloudflare_module" preset (see wrangler.toml / DEPLOY.md).
//   - viteReact(): the standard React plugin.
//   - tailwindcss(): Tailwind v4's first-party Vite plugin.
//   - tsConfigPaths(): resolves the "@/*" -> "./src/*" alias from tsconfig.json.
//
// Not carried over from the Lovable wrapper (safe to add back if needed):
//   - TanStack Router/Query devtools panel in dev mode.
//   - Lovable's in-browser error-reporting bridge (see src/lib/error-reporting.ts,
//     which now just logs to the console instead).
//   - Lovable's sandbox/dev-server bridge plugins (only relevant inside the
//     Lovable editor's preview iframe).
export default defineConfig({
  plugins: [
    tanstackStart({
      server: { entry: "server" },
    }),
    nitro({ preset: "cloudflare_module" }),
    viteReact(),
    tailwindcss(),
    tsConfigPaths(),
  ],
});
