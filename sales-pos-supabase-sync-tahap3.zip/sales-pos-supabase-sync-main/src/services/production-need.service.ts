import { storage, StorageKeys } from "./storage";
import type {
  PreOrder,
  ProductionNeedAddition,
  ProductionNeedReleaseReason,
} from "./types";

function uid() {
  return `pna_${crypto.randomUUID()}`;
}
function nowIso() {
  return new Date().toISOString();
}

/**
 * Production Need Ledger
 * -----------------------
 * Mencatat kebutuhan produksi TAMBAHAN yang lahir dari Pre Order (PO),
 * TERPISAH dari perhitungan kebutuhan produksi normal (forecast /
 * avgSameDay di `production-planning.service.ts` &
 * `production-recommendation.service.ts`).
 *
 * Latar belakang bisnis: ready stock outlet TIDAK boleh dipakai untuk
 * memenuhi PO — PO dianggap "pasti keluar", sehingga produksi harus
 * menyiapkan porsi tambahan di luar stok normal yang dijual ke walk-in
 * customer. Ledger ini adalah representasi eksplisit & persisten dari
 * porsi tambahan tersebut, satu baris per (PO × productId), supaya:
 *   1. Bisa dilacak asalnya (PO mana) — bukan cuma angka agregat.
 *   2. Bisa di-rollback (status → "released") saat PO dibatalkan/selesai,
 *      tanpa perlu menyentuh perhitungan kebutuhan produksi normal.
 *
 * PENTING — status konsumen:
 * `production-recommendation.service.ts` SEKARANG membaca `activeTotals()`
 * dari ledger ini untuk kebutuhan PO (menggantikan scan langsung
 * `preorderService.list()` yang dipakai sebelumnya), dan menambahkannya
 * secara aditif — tidak dikurangi ReadyStock (lihat header file tsb.
 * untuk penjelasan kenapa). `shopping-list.service.ts` SENGAJA TIDAK
 * disambungkan ke ledger ini — sudah dikonfirmasi formula lamanya
 * (kebutuhan bahan baku dari PO, dieksplode dari resep, tidak dikurangi
 * ready stock produk jadi) tidak punya gap yang sama.
 *
 * Service ini TIDAK memotong/menyentuh ready stock (`product.stock`) —
 * murni buku catatan (ledger) kebutuhan.
 */
export const productionNeedService = {
  list(): ProductionNeedAddition[] {
    return storage.get<ProductionNeedAddition[]>(StorageKeys.productionNeedAdditions) ?? [];
  },
  save(rows: ProductionNeedAddition[]) {
    storage.set(StorageKeys.productionNeedAdditions, rows);
  },

  /**
   * Baris ledger milik satu PO (semua status — termasuk yang sudah
   * released). Berguna untuk audit/debugging per PO.
   */
  byPreorderId(preorderId: string): ProductionNeedAddition[] {
    return productionNeedService.list().filter((r) => r.preorderId === preorderId);
  },

  /**
   * Dipanggil saat PO dibuat (`preorderService.create`). Menambahkan satu
   * baris ledger `status: "active"` per item PO. Idempotent secara
   * praktis: dipanggil sekali per PO baru (id PO selalu baru dari
   * `uid()`), jadi tidak mungkin dobel kecuali dipanggil manual berulang.
   */
  addForPreorder(po: PreOrder): ProductionNeedAddition[] {
    if (!po.items || po.items.length === 0) return [];
    const t = nowIso();
    const rows: ProductionNeedAddition[] = po.items
      .filter((it) => (Number(it.qty) || 0) > 0)
      .map((it) => ({
        id: uid(),
        preorderId: po.id,
        productId: it.productId,
        productName: it.name,
        qty: Number(it.qty) || 0,
        date: po.date,
        status: "active",
        createdAt: t,
      }));
    if (rows.length === 0) return [];
    const list = productionNeedService.list();
    list.push(...rows);
    productionNeedService.save(list);
    return rows;
  },

  /**
   * Dipanggil saat PO batal/expire/selesai. Melepas (status → "released")
   * seluruh baris `active` milik PO tersebut — TIDAK menghapus baris
   * (histori tetap ada untuk audit). Idempotent: baris yang sudah
   * "released" dilewati, jadi aman dipanggil berkali-kali (mis. dari
   * `remove()` setelah `update()` sudah melepasnya lebih dulu).
   */
  releaseForPreorder(preorderId: string, reason: ProductionNeedReleaseReason): ProductionNeedAddition[] {
    const list = productionNeedService.list();
    let changed = false;
    const t = nowIso();
    const released: ProductionNeedAddition[] = [];
    for (let i = 0; i < list.length; i++) {
      const row = list[i];
      if (row.preorderId !== preorderId || row.status !== "active") continue;
      const next: ProductionNeedAddition = {
        ...row,
        status: "released",
        releasedAt: t,
        releaseReason: reason,
      };
      list[i] = next;
      released.push(next);
      changed = true;
    }
    if (changed) productionNeedService.save(list);
    return released;
  },

  /**
   * Total kebutuhan tambahan yang masih AKTIF, per productId — gabungan
   * seluruh PO aktif (tidak difilter tanggal — lihat KNOWN LIMITATION di
   * `production-recommendation.service.ts`). Dipakai oleh
   * `productionRecommendationService.preorderDemand()` sebagai pengganti
   * scan langsung `preorderService.list()`.
   */
  activeTotals(): Map<string, number> {
    const out = new Map<string, number>();
    for (const row of productionNeedService.list()) {
      if (row.status !== "active") continue;
      out.set(row.productId, (out.get(row.productId) ?? 0) + row.qty);
    }
    return out;
  },

  /**
   * Setara `preorderService.productionNeedFor(dates)`, tapi bersumber dari
   * ledger (bukan scan live PO by status), difilter ke `dates` tertentu.
   */
  activeByDate(dates: string[]): { productId: string; name: string; qty: number }[] {
    const map = new Map<string, { productId: string; name: string; qty: number }>();
    for (const row of productionNeedService.list()) {
      if (row.status !== "active") continue;
      if (!dates.includes(row.date)) continue;
      const cur = map.get(row.productId);
      if (cur) cur.qty += row.qty;
      else map.set(row.productId, { productId: row.productId, name: row.productName, qty: row.qty });
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty);
  },
};
