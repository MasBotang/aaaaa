import { storage, StorageKeys } from "./storage";
import { salesService } from "./sales.service";
import { auditService } from "./audit.service";
import type { Role } from "./types";

export type RefundStatus = "pending" | "approved" | "rejected";

export const REFUND_STATUS_LABEL: Record<RefundStatus, string> = {
  pending: "Menunggu Approval",
  approved: "Disetujui (Refund)",
  rejected: "Ditolak",
};

export interface RefundRequest {
  id: string;
  saleId: string;
  requestedBy: string;
  requestedByRole?: Role;
  requestedAt: string;
  reason: string;
  status: RefundStatus;
  decidedBy?: string;
  decidedByRole?: Role;
  decidedAt?: string;
  decisionNote?: string;
}

function uid() {
  return `rf_${crypto.randomUUID()}`;
}

export const refundService = {
  list(): RefundRequest[] {
    return storage.get<RefundRequest[]>(StorageKeys.refundRequests) ?? [];
  },
  save(rows: RefundRequest[]) {
    storage.set(StorageKeys.refundRequests, rows);
  },
  bySale(saleId: string): RefundRequest | undefined {
    return refundService.list().find((r) => r.saleId === saleId && r.status !== "rejected");
  },
  request(input: {
    saleId: string;
    reason: string;
    actor: string;
    actorRole?: Role;
  }): RefundRequest {
    const existing = refundService.bySale(input.saleId);
    if (existing) return existing;
    const rec: RefundRequest = {
      id: uid(),
      saleId: input.saleId,
      reason: input.reason,
      requestedBy: input.actor,
      requestedByRole: input.actorRole,
      requestedAt: new Date().toISOString(),
      status: "pending",
    };
    const list = refundService.list();
    list.unshift(rec);
    refundService.save(list);
    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "refund_requested",
      entity: "sale",
      entityId: input.saleId,
      reason: input.reason,
    });
    return rec;
  },
  // TODO(prompt berikutnya): refund.service.ts SENDIRI (tabel
  // `refund_requests`) tetap localStorage. approve() diubah async HANYA
  // karena salesService.void() sekarang async (memanggil productService),
  // sesuai izin eksplisit di scope Prompt 2.
  async approve(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): Promise<{ ok: true; request: RefundRequest } | { ok: false; reason: string }> {
    const list = refundService.list();
    const i = list.findIndex((r) => r.id === id);
    if (i < 0) return { ok: false, reason: "Pengajuan refund tidak ditemukan" };
    const cur = list[i];
    if (cur.status !== "pending") {
      return { ok: false, reason: "Pengajuan refund sudah diputuskan" };
    }
    // Guard: pesanan yang sudah masuk produksi tidak boleh direfund.
    // Async sekarang: canRefund() mem-fetch Sale langsung dari Supabase.
    const guard = await salesService.canRefund(cur.saleId);
    if (!guard.ok) {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "refund_approve_blocked",
        entity: "sale",
        entityId: cur.saleId,
        reason: guard.reason,
      });
      return { ok: false, reason: guard.reason };
    }
    const now = new Date().toISOString();
    const updated: RefundRequest = {
      ...cur,
      status: "approved",
      decidedAt: now,
      decidedBy: opts.actor,
      decidedByRole: opts.actorRole,
      decisionNote: opts.note,
    };
    list[i] = updated;
    refundService.save(list);
    // Approve refund = rollback penuh transaksi (ready stock, queue,
    // packaging, ringkasan penjualan, payment & marketplace breakdown).
    await salesService.void(cur.saleId, {
      reason: `Refund: ${cur.reason}${opts.note ? ` · ${opts.note}` : ""}`,
      actor: opts.actor,
      actorRole: opts.actorRole,
    });
    auditService.log({
      actor: opts.actor,
      actorRole: opts.actorRole,
      action: "refund_approved",
      entity: "sale",
      entityId: cur.saleId,
      reason: opts.note,
    });
    return { ok: true, request: updated };
  },
  reject(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): RefundRequest | null {
    const list = refundService.list();
    const i = list.findIndex((r) => r.id === id);
    if (i < 0) return null;
    const cur = list[i];
    if (cur.status !== "pending") return cur;
    const now = new Date().toISOString();
    const updated: RefundRequest = {
      ...cur,
      status: "rejected",
      decidedAt: now,
      decidedBy: opts.actor,
      decidedByRole: opts.actorRole,
      decisionNote: opts.note,
    };
    list[i] = updated;
    refundService.save(list);
    auditService.log({
      actor: opts.actor,
      actorRole: opts.actorRole,
      action: "refund_rejected",
      entity: "sale",
      entityId: cur.saleId,
      reason: opts.note,
    });
    return updated;
  },
  pendingCount(): number {
    return refundService.list().filter((r) => r.status === "pending").length;
  },
};