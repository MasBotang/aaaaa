import { storage, StorageKeys } from "./storage";
import { preorderService } from "./preorder.service";
import { auditService } from "./audit.service";
import type { PreOrder, Role } from "./types";

export type PreOrderCancelStatus = "pending" | "approved" | "rejected";

export const PREORDER_CANCEL_STATUS_LABEL: Record<PreOrderCancelStatus, string> = {
  pending: "Menunggu Approval",
  approved: "Disetujui (Dibatalkan)",
  rejected: "Ditolak",
};

/**
 * Pengajuan pembatalan Pre Order yang sudah menerima DP. Dibuat sebagai
 * service terpisah (bukan menumpang refundService) karena entitasnya beda:
 * refundService selalu butuh Sale yang sudah tercipta (dipanggil
 * salesService.void di dalamnya), sedangkan Pre Order yang mau dibatalkan
 * belum tentu — dan biasanya belum — pernah jadi Sale. Pola request→
 * approve/reject, shape, dan semantik permission-nya sengaja disamakan
 * dengan refundService supaya konsisten dengan alur Void di pesanan-page.tsx.
 */
export interface PreOrderCancelRequest {
  id: string;
  preorderId: string;
  requestedBy: string;
  requestedByRole?: Role;
  requestedAt: string;
  reason: string;
  status: PreOrderCancelStatus;
  decidedBy?: string;
  decidedByRole?: Role;
  decidedAt?: string;
  decisionNote?: string;
  /** Snapshot DP saat pengajuan dibuat — DP yang akan hangus bila disetujui. */
  downPaymentAtRequest: number;
}

function uid() {
  return `poc_${crypto.randomUUID()}`;
}

export const preorderCancelService = {
  list(): PreOrderCancelRequest[] {
    return storage.get<PreOrderCancelRequest[]>(StorageKeys.preorderCancelRequests) ?? [];
  },
  save(rows: PreOrderCancelRequest[]) {
    storage.set(StorageKeys.preorderCancelRequests, rows);
  },
  /** Pengajuan pending untuk satu Pre Order, kalau ada. */
  byPreorder(preorderId: string): PreOrderCancelRequest | undefined {
    return preorderCancelService
      .list()
      .find((r) => r.preorderId === preorderId && r.status === "pending");
  },
  request(input: {
    preorderId: string;
    reason: string;
    actor: string;
    actorRole?: Role;
  }): PreOrderCancelRequest {
    const existing = preorderCancelService.byPreorder(input.preorderId);
    if (existing) return existing;
    const po = preorderService.byId(input.preorderId);
    const rec: PreOrderCancelRequest = {
      id: uid(),
      preorderId: input.preorderId,
      reason: input.reason,
      requestedBy: input.actor,
      requestedByRole: input.actorRole,
      requestedAt: new Date().toISOString(),
      status: "pending",
      downPaymentAtRequest: po?.downPayment ?? 0,
    };
    const list = preorderCancelService.list();
    list.unshift(rec);
    preorderCancelService.save(list);
    // Best-effort — pengajuan sudah tersimpan; jangan sampai logging gagal
    // bikin fungsi ini throw dan membuat caller (UI) mengira pengajuan
    // gagal terkirim padahal sudah tersimpan.
    try {
      auditService.log({
        actor: input.actor,
        actorRole: input.actorRole,
        action: "preorder_cancel_requested",
        entity: "preorder",
        entityId: input.preorderId,
        reason: input.reason,
        metadata: { downPayment: rec.downPaymentAtRequest },
      });
    } catch (err) {
      console.error("[preorder-cancel] request: audit log failed", err);
    }
    return rec;
  },
  approve(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): { ok: true; request: PreOrderCancelRequest } | { ok: false; reason: string } {
    const list = preorderCancelService.list();
    const i = list.findIndex((r) => r.id === id);
    if (i < 0) return { ok: false, reason: "Pengajuan pembatalan tidak ditemukan" };
    const cur = list[i];
    if (cur.status !== "pending") {
      return { ok: false, reason: "Pengajuan pembatalan sudah diputuskan" };
    }
    const po = preorderService.byId(cur.preorderId);
    if (!po) return { ok: false, reason: "Pre Order tidak ditemukan" };
    if (po.status === "completed" || po.status === "cancelled") {
      return { ok: false, reason: `Pre Order sudah berstatus ${po.status} — tidak bisa diproses lagi` };
    }
    // Bug fix (pola sama seperti H-2 — mutasi storage bertahap tanpa
    // rollback eksplisit): sebelumnya urutannya TERBALIK — pengajuan
    // ditandai "approved" & disimpan dulu, baru PO dibatalkan setelahnya.
    // Kalau mutasi PO gagal di tengah jalan (mis. storage penuh), pengajuan
    // nyangkut permanen berstatus "approved" padahal PO-nya sendiri tidak
    // pernah benar-benar batal — state setengah jalan yang tersembunyi dari
    // admin (DP dianggap hangus di UI tapi order masih aktif). Sekarang PO
    // dibatalkan LEBIH DULU; kalau gagal, pengajuan TETAP "pending" supaya
    // admin bisa coba approve lagi tanpa ada jejak yang salah.
    //
    // Pakai preorderService.cancel() (bukan setStatus mentah) supaya entri
    // Queue placeholder ikut dibersihkan bila PO ini sempat auto-promote —
    // mencegah PO batal nyangkut sebagai antrean produksi "hantu".
    let cancelledPo: PreOrder | null;
    try {
      cancelledPo = preorderService.cancel(cur.preorderId);
    } catch (err) {
      console.error("[preorder-cancel] approve: gagal membatalkan PO", err);
      return { ok: false, reason: "Gagal membatalkan Pre Order — coba lagi" };
    }
    if (!cancelledPo) {
      return { ok: false, reason: "Pre Order tidak ditemukan / gagal diupdate" };
    }
    const now = new Date().toISOString();
    const updated: PreOrderCancelRequest = {
      ...cur,
      status: "approved",
      decidedAt: now,
      decidedBy: opts.actor,
      decidedByRole: opts.actorRole,
      decisionNote: opts.note,
    };
    try {
      list[i] = updated;
      preorderCancelService.save(list);
    } catch (err) {
      // PO sudah kadung batal tapi record pengajuan gagal disimpan — coba
      // rollback PO ke status semula supaya tidak ada PO "cancelled" tanpa
      // pengajuan yang tercatat approved (DP hangus tanpa jejak approval).
      console.error(
        "[preorder-cancel] approve: gagal simpan status approval, rollback PO",
        err,
      );
      try {
        preorderService.update(cur.preorderId, { status: po.status, queueId: po.queueId });
      } catch (rollbackErr) {
        console.error("[preorder-cancel] approve: rollback PO juga gagal", rollbackErr);
      }
      return { ok: false, reason: "Gagal menyimpan status approval — coba lagi" };
    }
    // Best-effort — mutasi bisnis (PO batal + pengajuan approved) sudah
    // sukses; jangan sampai logging gagal bikin fungsi ini throw dan
    // membuat handler UI crash sebelum sempat toast/refresh/onChanged().
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "preorder_cancel_approved",
        entity: "preorder",
        entityId: cur.preorderId,
        reason: opts.note,
        metadata: { downPaymentForfeited: po.downPayment ?? 0 },
      });
    } catch (err) {
      console.error("[preorder-cancel] approve: audit log failed", err);
    }
    return { ok: true, request: updated };
  },
  reject(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): PreOrderCancelRequest | null {
    const list = preorderCancelService.list();
    const i = list.findIndex((r) => r.id === id);
    if (i < 0) return null;
    const cur = list[i];
    if (cur.status !== "pending") return cur;
    const now = new Date().toISOString();
    const updated: PreOrderCancelRequest = {
      ...cur,
      status: "rejected",
      decidedAt: now,
      decidedBy: opts.actor,
      decidedByRole: opts.actorRole,
      decisionNote: opts.note,
    };
    list[i] = updated;
    preorderCancelService.save(list);
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "preorder_cancel_rejected",
        entity: "preorder",
        entityId: cur.preorderId,
        reason: opts.note,
      });
    } catch (err) {
      console.error("[preorder-cancel] reject: audit log failed", err);
    }
    return updated;
  },
  pendingCount(): number {
    return preorderCancelService.list().filter((r) => r.status === "pending").length;
  },
};
