import { saleAmountByMethod } from "@/lib/payment";
import { salesService } from "./sales.service";
import { queueService } from "./queue.service";
import { storage, StorageKeys } from "./storage";
import {
  MARKETPLACE_SOURCES,
  type MarketplaceSource,
  type PaymentBucket,
  type Sale,
} from "./types";

/**
 * Single Source of Truth untuk ringkasan penjualan.
 * Dipakai oleh Home Sales, POS summary, Shift audit, dan (persiapan) Reports/Finance.
 * JANGAN duplikasi logika perhitungan revenue / total order / breakdown pembayaran
 * di tempat lain — pakai service ini.
 */

export interface DailySummary {
  date: string; // YYYY-MM-DD
  totalOrders: number; // exclude voided
  totalRevenue: number; // exclude voided
  targetRevenue: number;
  progress: number; // 0..1
  newOrders: number;
  inProgressOrders: number;
  completedOrders: number;
  refundedOrders: number;
}

export interface PaymentBreakdown {
  cash: number;
  qris: number;
  transfer: number;
  marketplace: number;
}

export interface MarketplaceBreakdown {
  marketplace: MarketplaceSource;
  total: number;
  orders: number;
}

export interface ShiftSummary {
  shiftId: string;
  totalOrders: number;
  totalRevenue: number;
  payments: PaymentBreakdown;
  marketplaces: MarketplaceBreakdown[];
  sales: Sale[];
}

function dayKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function isMarketplaceSale(s: Sale): boolean {
  return !!s.sourceOrder && (MARKETPLACE_SOURCES as string[]).includes(s.sourceOrder);
}

/**
 * Aggregasi pembayaran per bucket. Sprint 7: mendukung Split Payment —
 * satu sale bisa berkontribusi ke >1 bucket. Marketplace sale tetap
 * dialokasikan penuh ke bucket `marketplace` (settlement dari platform).
 */
function aggregatePayments(active: Sale[]): PaymentBreakdown {
  const acc: PaymentBreakdown = { cash: 0, qris: 0, transfer: 0, marketplace: 0 };
  for (const s of active) {
    if (isMarketplaceSale(s)) {
      acc.marketplace += s.total ?? 0;
      continue;
    }
    const parts = saleAmountByMethod(s);
    acc.cash += parts.cash + parts.card; // card fallback → cash bucket
    acc.qris += parts.qris;
    acc.transfer += parts.transfer;
  }
  return acc;
}

function aggregateMarketplaces(active: Sale[]): MarketplaceBreakdown[] {
  return MARKETPLACE_SOURCES.map((m) => {
    const rows = active.filter((s) => s.sourceOrder === m);
    return {
      marketplace: m,
      total: rows.reduce((a, s) => a + (s.total ?? 0), 0),
      orders: rows.length,
    };
  });
}

export const salesTargetService = {
  get(dateKey: string): number {
    const all = storage.get<Record<string, number>>(StorageKeys.salesTargets) ?? {};
    return all[dateKey] ?? all.__default ?? 0;
  },
  setDefault(target: number) {
    const all = storage.get<Record<string, number>>(StorageKeys.salesTargets) ?? {};
    all.__default = target;
    storage.set(StorageKeys.salesTargets, all);
  },
  setForDate(dateKey: string, target: number) {
    const all = storage.get<Record<string, number>>(StorageKeys.salesTargets) ?? {};
    all[dateKey] = target;
    storage.set(StorageKeys.salesTargets, all);
  },
};

export const salesSummaryService = {
  today(now: Date = new Date()): DailySummary {
    const key = dayKey(now);
    // Pakai cache in-memory (dipopulasikan `useSalesData()` di halaman
    // konsumen) supaya today() tetap sinkron — sama pola dengan forShift().
    const startMs = new Date(now).setHours(0, 0, 0, 0);
    const endMs = new Date(now).setHours(23, 59, 59, 999);
    const sales: Sale[] = salesService.listCached().filter((s) => {
      const t = new Date(s.createdAt).getTime();
      return t >= startMs && t <= endMs;
    });
    const active: Sale[] = sales.filter((s) => !s.voided);
    const refunded = sales.filter((s) => s.voided).length;
    const totalRevenue = active.reduce((a, s) => a + (s.total ?? 0), 0);
    const totalOrders = active.length;

    // Live queue status counts (belum completed) untuk pesanan hari ini.
    const queueRows = queueService.listCached();
    const activeSaleIds = new Set(active.map((s) => s.id));
    const todaysQueue = queueRows.filter((q) => activeSaleIds.has(q.saleId));
    const newOrders = todaysQueue.filter((q) => q.status === "waiting").length;
    const inProgressOrders = todaysQueue.filter(
      (q) => q.status === "cooking" || q.status === "packing" || q.status === "ready",
    ).length;
    const completedOrders = active.length - newOrders - inProgressOrders;

    const targetRevenue = salesTargetService.get(key);
    const progress = targetRevenue > 0 ? Math.min(1, totalRevenue / targetRevenue) : 0;

    return {
      date: key,
      totalOrders,
      totalRevenue,
      targetRevenue,
      progress,
      newOrders,
      inProgressOrders,
      completedOrders: Math.max(0, completedOrders),
      refundedOrders: refunded,
    };
  },

  /**
   * Ringkasan penjualan 1 shift — SSoT untuk halaman Shift dan audit.
   */
  forShift(shiftId: string): ShiftSummary {
    const active = salesService.listCached().filter((s) => s.shiftId === shiftId && !s.voided);
    const payments = aggregatePayments(active);
    const marketplaces = aggregateMarketplaces(active);
    const totalRevenue = active.reduce((a, s) => a + (s.total ?? 0), 0);
    return {
      shiftId,
      totalOrders: active.length,
      totalRevenue,
      payments,
      marketplaces,
      sales: active,
    };
  },
};
