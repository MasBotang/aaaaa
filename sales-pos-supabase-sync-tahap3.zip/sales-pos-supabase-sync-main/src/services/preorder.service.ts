import { storage, StorageKeys } from "./storage";
import type { PaymentMethod, PreOrder, PreOrderStatus, SaleItem, SalePacking, SaleType, SourceOrder } from "./types";
import { queueService } from "./queue.service";
import { auditService } from "./audit.service";
import { productionNeedService } from "./production-need.service";

function uid() {
  return `po_${crypto.randomUUID()}`;
}
function nowIso() {
  return new Date().toISOString();
}

function totalOf(items: SaleItem[]) {
  return items.reduce((a, i) => a + i.price * i.qty, 0);
}

/**
 * Buffer minimum (menit) antara waktu saat ini dengan jam pickup untuk PO
 * yang dibuat hari ini. Menghindari kasir memilih slot yang terlalu dekat
 * sehingga customer tidak realistis mengambil pesanan.
 */
export const PREORDER_MIN_LEAD_MINUTES = 30;

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

/** Tanggal hari ini dalam format YYYY-MM-DD (tz lokal). */
export function todayYmd(now: Date = new Date()): string {
  return ymd(now);
}

/**
 * Batas jam paling awal (HH:mm) untuk pickup pada `date` tertentu, mengikuti
 * aturan buffer PREORDER_MIN_LEAD_MINUTES. Return "00:00" bila `date` di
 * masa depan.
 */
export function minPickupTimeFor(date: string, now: Date = new Date()): string {
  if (!date) return "00:00";
  if (date > todayYmd(now)) return "00:00";
  if (date < todayYmd(now)) return "23:59"; // efektif menolak tanggal lampau
  const t = new Date(now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000);
  return `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}`;
}

/**
 * Validasi kombinasi tanggal + jam pickup Pre Order. Return pesan error bila
 * tidak valid; null bila valid. Dipakai baik oleh UI (POS) maupun service
 * layer (fail-safe agar tidak bisa diakali DevTools).
 */
export function validatePickup(
  date: string,
  time: string,
  now: Date = new Date(),
): string | null {
  if (!date) return "Tanggal pengambilan wajib diisi";
  if (!time) return "Jam pengambilan wajib diisi";
  const today = todayYmd(now);
  if (date < today) return "Tanggal pengambilan tidak boleh di masa lalu";
  const dt = new Date(`${date}T${time}:00`);
  if (Number.isNaN(dt.getTime())) return "Format tanggal/jam tidak valid";
  const minMs = now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000;
  if (dt.getTime() < minMs) {
    return `Jam pengambilan minimal ${PREORDER_MIN_LEAD_MINUTES} menit dari sekarang`;
  }
  return null;
}

export const preorderService = {
  list(): PreOrder[] {
    return storage.get<PreOrder[]>(StorageKeys.preorders) ?? [];
  },
  save(rows: PreOrder[]) {
    // Cap supaya array tidak tumbuh tanpa batas di localStorage (quota
    // ~5-10MB) — pola sama seperti auditService (lihat audit.service.ts).
    // Baris baru selalu di-unshift ke depan (lihat create() di bawah), jadi
    // memotong ekor array = membuang PO terlama. 5.000 PO ≈ buffer lama
    // untuk volume Pre Order (jauh lebih jarang dari transaksi POS).
    if (rows.length > 5000) rows.length = 5000;
    storage.set(StorageKeys.preorders, rows);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("desalut:preorders-changed"));
    }
  },
  byId(id: string): PreOrder | undefined {
    return preorderService.list().find((p) => p.id === id);
  },
  create(input: {
    customerName: string;
    customerPhone?: string;
    date: string;
    time: string;
    items: SaleItem[];
    notes?: string;
    sourceOrder: SourceOrder;
    priceGroupId?: string;
    saleType?: SaleType;
    createdBy: string;
    outletId?: string;
    downPayment?: number;
    dpMethod?: PaymentMethod;
    /**
     * Gap #5 (Packaging Fix): rencana Packing (auto atau custom/split) yang
     * sudah diatur kasir di POS saat Pre Order ini dibuat. Optional —
     * caller lama yang tidak mengirim field ini tetap berfungsi seperti
     * sebelumnya (fallback ke "1 Packing gabungan" nanti di titik finalize,
     * lihat preorder-page.tsx → finalizeComplete).
     */
    packings?: SalePacking[];
  }): PreOrder {
    // Fail-safe: validasi pickup di service layer supaya tidak bisa diakali
    // via DevTools bila UI validasi di-bypass.
    const err = validatePickup(input.date, input.time);
    if (err) throw new Error(err);
    const t = nowIso();
    const total = totalOf(input.items);
    const dp = Math.max(0, Math.min(input.downPayment ?? 0, total));
    const rec: PreOrder = {
      id: uid(),
      status: "scheduled",
      total,
      createdAt: t,
      updatedAt: t,
      ...input,
      downPayment: dp,
      remainingBalance: total - dp,
      dpPaidAt: dp > 0 ? t : undefined,
      dpMethod: dp > 0 ? input.dpMethod : undefined,
    };
    const list = preorderService.list();
    list.unshift(rec);
    preorderService.save(list);
    // Production Need Ledger: PO dianggap "pasti keluar" → tambahkan porsi
    // produksi TAMBAHAN (terpisah dari kebutuhan produksi normal), supaya
    // ready stock outlet tidak dipakai memenuhi PO ini. Best-effort — gagal
    // catat ledger tidak boleh menggagalkan pembuatan PO itu sendiri.
    try {
      productionNeedService.addForPreorder(rec);
    } catch (err) {
      console.error("[preorder] production-need addForPreorder failed", err);
    }
    if (dp > 0) {
      try {
        auditService.log({
          actor: input.createdBy,
          action: "preorder_dp_paid",
          entity: "preorder",
          entityId: rec.id,
          metadata: {
            total,
            downPayment: dp,
            remainingBalance: total - dp,
            method: input.dpMethod,
          },
        });
      } catch (err) {
        console.error("[preorder] audit dp failed", err);
      }
    }
    return rec;
  },
  update(id: string, patch: Partial<PreOrder>): PreOrder | null {
    const list = preorderService.list();
    const i = list.findIndex((p) => p.id === id);
    if (i < 0) return null;
    const prevStatus = list[i].status;
    const merged: PreOrder = {
      ...list[i],
      ...patch,
      updatedAt: nowIso(),
    };
    if (patch.items) merged.total = totalOf(patch.items);
    // Sinkronkan remainingBalance saat total atau DP berubah.
    const dp = Math.max(0, Math.min(merged.downPayment ?? 0, merged.total));
    merged.downPayment = dp;
    merged.remainingBalance = merged.total - dp;
    list[i] = merged;
    preorderService.save(list);
    // Production Need Ledger: lepas porsi tambahan begitu PO masuk status
    // akhir (batal ATAU selesai) — bukan cuma "cancel". Saat "completed",
    // porsi tambahan sudah terpakai/tidak relevan lagi sebagai kebutuhan
    // ke depan (pemotongan ready stock itu sendiri TETAP hanya terjadi di
    // titik Complete seperti sebelumnya — baris ini murni melepas catatan
    // ledger, tidak menyentuh stok). Guard `prevStatus !== merged.status`
    // supaya idempotent bila update() dipanggil ulang dengan status sama.
    if (
      patch.status &&
      patch.status !== prevStatus &&
      (patch.status === "cancelled" || patch.status === "completed")
    ) {
      try {
        productionNeedService.releaseForPreorder(id, patch.status);
      } catch (err) {
        console.error("[preorder] production-need releaseForPreorder failed", err);
      }
    }
    return merged;
  },
  /**
   * Sprint 1 (C-3): catat pembayaran DP terpisah (mis. customer bayar DP
   * setelah PO dibuat). Audit `preorder_dp_paid`.
   */
  payDp(
    id: string,
    amount: number,
    ctx: { actor: string; method?: PaymentMethod },
  ): PreOrder | null {
    const cur = preorderService.byId(id);
    if (!cur) return null;
    const dp = Math.max(0, Math.min((cur.downPayment ?? 0) + amount, cur.total));
    const next = preorderService.update(id, {
      downPayment: dp,
      dpPaidAt: nowIso(),
      dpMethod: ctx.method ?? cur.dpMethod,
    });
    try {
      auditService.log({
        actor: ctx.actor,
        action: "preorder_dp_paid",
        entity: "preorder",
        entityId: id,
        metadata: {
          added: amount,
          total: cur.total,
          downPayment: dp,
          remainingBalance: cur.total - dp,
          method: ctx.method ?? cur.dpMethod,
        },
      });
    } catch (err) {
      console.error("[preorder] audit payDp failed", err);
    }
    return next;
  },
  setStatus(id: string, status: PreOrderStatus): PreOrder | null {
    return preorderService.update(id, { status });
  },
  /**
   * Batalkan PO — dipakai baik oleh jalur batal langsung (DP=0, lihat
   * preorder-page.tsx → cancel()) maupun jalur approval pembatalan (DP>0,
   * lihat preorder-cancel.service.ts → approve()). Disatukan di sini
   * (bukan preorderService.setStatus(id, "cancelled") mentah) karena kedua
   * jalur itu sebelumnya TIDAK membersihkan entri Queue placeholder bila PO
   * ini sempat auto-promote lewat promoteDue() (punya `queueId`) sebelum
   * dibatalkan — PO batal jadi nyangkut selamanya sebagai antrean produksi
   * "hantu" (bug yang sama seperti yang sudah pernah diperbaiki utk undo
   * Mark Ready — lihat undoMarkReady di bawah — tapi belum diterapkan juga
   * di jalur Cancel).
   */
  cancel(id: string): PreOrder | null {
    const po = preorderService.byId(id);
    if (!po) return null;
    if (po.queueId) {
      try {
        queueService.removeBySale(po.id);
      } catch (err) {
        console.error("[preorder] cancel: gagal hapus entri queue", err);
      }
    }
    return preorderService.update(id, { status: "cancelled", queueId: undefined });
  },
  /**
   * Undo untuk "Siap Diproses" yang salah klik — kembalikan PO ke
   * `scheduled`. Bug fix (Sprint 1 M-3): sebelumnya markReady() sekali klik
   * tidak bisa dibatalkan, admin harus lewat siklus penuh (Selesaikan/Batal)
   * cuma buat benerin salah klik.
   *
   * Hanya diizinkan dari status `ready_to_process` — begitu PO sudah
   * completed/cancelled, undo lewat jalur ini tidak relevan lagi (ada alur
   * sendiri: request pembatalan / hapus).
   *
   * Kalau PO ini sempat auto-promote lewat `promoteDue()` (sudah lewat jam
   * pickup) sehingga punya `queueId`, entri Queue placeholder-nya (dibuat
   * dengan `saleId = po.id`) ikut dihapus juga — supaya tidak nyangkut jadi
   * antrean produksi "hantu" buat PO yang balik ke `scheduled`.
   */
  undoMarkReady(
    id: string,
    ctx: { actor: string; actorRole?: string },
  ): { ok: true; preorder: PreOrder } | { ok: false; reason: string } {
    const po = preorderService.byId(id);
    if (!po) return { ok: false, reason: "Pre Order tidak ditemukan" };
    if (po.status !== "ready_to_process") {
      return { ok: false, reason: "Hanya bisa diurungkan dari status Siap Diproses" };
    }
    if (po.queueId) {
      try {
        queueService.removeBySale(po.id);
      } catch (err) {
        console.error("[preorder] undoMarkReady: gagal hapus entri queue", err);
      }
    }
    const next = preorderService.update(id, { status: "scheduled", queueId: undefined });
    if (!next) return { ok: false, reason: "Pre Order tidak ditemukan" };
    try {
      auditService.log({
        actor: ctx.actor,
        actorRole: ctx.actorRole,
        action: "preorder_mark_ready_undo",
        entity: "preorder",
        entityId: id,
      });
    } catch {
      // best-effort, jangan gagalkan undo hanya karena audit log error
    }
    return { ok: true, preorder: next };
  },
  remove(id: string) {
    preorderService.save(preorderService.list().filter((p) => p.id !== id));
    // Jaring pengaman: remove() di UI hanya dipanggil untuk PO yang statusnya
    // sudah cancelled/completed (ledger sudah dilepas via update() di atas),
    // tapi releaseForPreorder idempotent — aman dipanggil lagi untuk
    // menutup kemungkinan PO lama/dari jalur lain yang belum sempat dilepas.
    try {
      productionNeedService.releaseForPreorder(id, "manual");
    } catch (err) {
      console.error("[preorder] production-need release on remove failed", err);
    }
  },
  byDate(date: string): PreOrder[] {
    return preorderService.list().filter((p) => p.date === date);
  },
  /**
   * Promote PO scheduled yang sudah jatuh tempo (date+time <= now) menjadi
   * ready_to_process dan buat entri Queue. Tidak membuat Sale.
   */
  promoteDue(now = new Date()): { promoted: PreOrder[] } {
    const promoted: PreOrder[] = [];
    const list = preorderService.list();
    let changed = false;
    for (let i = 0; i < list.length; i++) {
      const po = list[i];
      if (po.status !== "scheduled") continue;
      const dt = new Date(`${po.date}T${po.time || "00:00"}:00`);
      if (Number.isNaN(dt.getTime())) continue;
      if (dt.getTime() > now.getTime()) continue;
      // Buat queue entry — sekali saja.
      let queueId = po.queueId;
      if (!queueId) {
        try {
          const q = queueService.create({
            saleId: po.id, // pakai id PO sebagai "saleId" placeholder hingga PO di-Complete
            saleCode: po.id,
            saleType: po.saleType ?? "frozen",
            customerName: po.customerName,
            customerPhone: po.customerPhone,
            pickupAt: dt.toISOString(),
            isPreorder: true,
            itemCount: po.items.reduce((a, c) => a + c.qty, 0),
            itemsSummary: po.items.map((i) => `${i.qty}× ${i.name}`).join(", "),
            sourceOrder: po.sourceOrder,
          });
          queueId = q.id;
        } catch (err) {
          console.error("[preorder] promote → queue.create failed", err);
        }
      }
      const updated: PreOrder = {
        ...po,
        status: "ready_to_process",
        queueId,
        updatedAt: nowIso(),
      };
      list[i] = updated;
      promoted.push(updated);
      changed = true;
    }
    if (changed) preorderService.save(list);
    return { promoted };
  },
  countByDate(date: string): number {
    return preorderService
      .list()
      .filter((p) => p.date === date && p.status !== "cancelled" && p.status !== "completed")
      .length;
  },
  /** Semua PO yang masih aktif (scheduled / ready_to_process). */
  countActive(): number {
    return preorderService
      .list()
      .filter((p) => p.status !== "cancelled" && p.status !== "completed")
      .length;
  },
  productionNeedFor(dates: string[]): { productId: string; name: string; qty: number }[] {
    const map = new Map<string, { productId: string; name: string; qty: number }>();
    for (const p of preorderService.list()) {
      if (!dates.includes(p.date)) continue;
      if (p.status === "cancelled" || p.status === "completed") continue;
      for (const it of p.items) {
        const cur = map.get(it.productId);
        if (cur) cur.qty += it.qty;
        else map.set(it.productId, { productId: it.productId, name: it.name, qty: it.qty });
      }
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty);
  },
};
