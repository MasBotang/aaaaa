import { storage, StorageKeys } from "./storage";
import { auditService } from "./audit.service";
import type { MarketplaceSettlement, MarketplaceSource, Sale } from "./types";

function uid() {
  return `ms_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

export type SettlementStatus = "settled" | "unsettled";

export const marketplaceSettlementService = {
  list(): MarketplaceSettlement[] {
    return storage.get<MarketplaceSettlement[]>(StorageKeys.marketplaceSettlements) ?? [];
  },
  save(rows: MarketplaceSettlement[]) {
    storage.set(StorageKeys.marketplaceSettlements, rows);
  },
  find(date: string, marketplace: MarketplaceSource): MarketplaceSettlement | undefined {
    return marketplaceSettlementService
      .list()
      .find((r) => r.date === date && r.marketplace === marketplace);
  },
  upsert(
    input: Omit<MarketplaceSettlement, "id" | "createdAt"> & { actor?: string; actorRole?: string },
  ): MarketplaceSettlement {
    const { actor, actorRole, ...payload } = input;
    const list = marketplaceSettlementService.list();
    const idx = list.findIndex(
      (r) => r.date === payload.date && r.marketplace === payload.marketplace,
    );
    let result: MarketplaceSettlement;
    let before: MarketplaceSettlement | undefined;
    if (idx >= 0) {
      before = list[idx];
      result = { ...list[idx], ...payload };
      list[idx] = result;
      marketplaceSettlementService.save(list);
    } else {
      result = {
        ...payload,
        id: uid(),
        createdAt: new Date().toISOString(),
      };
      list.unshift(result);
      marketplaceSettlementService.save(list);
    }
    // Sprint 2: audit setiap posting settlement (idempotent by date × marketplace).
    try {
      auditService.log({
        actor: actor ?? "system",
        actorRole,
        action: "settlement_posted",
        entity: "marketplace_settlement",
        entityId: result.id,
        metadata: {
          date: result.date,
          marketplace: result.marketplace,
          grossSales: result.grossSales,
          marketplaceFee: result.marketplaceFee,
          netReceived: result.netReceived,
          before,
        },
      });
    } catch (err) {
      console.error("[settlement] audit failed", err);
    }
    return result;
  },
  remove(id: string) {
    marketplaceSettlementService.save(
      marketplaceSettlementService.list().filter((r) => r.id !== id),
    );
  },
  /** Status settlement untuk (tanggal × marketplace). */
  statusFor(date: string, marketplace: MarketplaceSource): SettlementStatus {
    return marketplaceSettlementService.find(date, marketplace) ? "settled" : "unsettled";
  },
  /** Extract (date, marketplace) pasangan dari sales yang masuk marketplace. */
  outstandingPairs(sales: Sale[]): { date: string; marketplace: MarketplaceSource }[] {
    const set = new Map<string, { date: string; marketplace: MarketplaceSource }>();
    for (const s of sales) {
      if (s.voided) continue;
      const src = s.sourceOrder;
      if (src !== "shopeefood" && src !== "gofood" && src !== "grabfood") continue;
      const d = new Date(s.createdAt);
      if (Number.isNaN(d.getTime())) continue;
      const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
        d.getDate(),
      ).padStart(2, "0")}`;
      const key = `${dateStr}|${src}`;
      if (!set.has(key)) set.set(key, { date: dateStr, marketplace: src });
    }
    return Array.from(set.values()).sort((a, b) => (a.date < b.date ? 1 : -1));
  },
};
