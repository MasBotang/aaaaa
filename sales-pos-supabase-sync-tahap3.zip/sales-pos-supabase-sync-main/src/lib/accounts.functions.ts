/**
 * Account Management — data layer.
 *
 * LocalStorage-backed store. Owns User/Role/Status/Permission.
 * Explicitly NOT: attendance, payroll, activity log, analytics.
 *
 * Other modules must go through the public API (bottom of this file) —
 * never poke the storage key directly.
 */

import { storage, StorageKeys } from "@/services/storage";
import type { Role } from "@/services/types";

export type AccountStatus = "active" | "inactive";

export interface Account {
  id: string;
  fullName: string;
  username: string;
  email: string;
  /** Plain — localStorage only, MVP. Never returned by public list. */
  password: string;
  role: Role;
  status: AccountStatus;
  /** ISO. Optional future-ready fields — hidden in UI when empty. */
  employeeCode?: string;
  phone?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

/** Public projection — password stripped. */
export interface AccountView {
  id: string;
  fullName: string;
  username: string;
  email: string;
  role: Role;
  status: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

const STORAGE_KEY = "desalut:v1:accounts";

const DEFAULT_ADMIN: Account = {
  id: "admin-default",
  fullName: "Daria Bang",
  username: "dariabang",
  email: "dariabang@desalut.id",
  password: "Alyacantik08",
  role: "admin",
  status: "active",
  createdAt: new Date("2026-01-01T00:00:00Z").toISOString(),
  updatedAt: new Date("2026-01-01T00:00:00Z").toISOString(),
};

// ---------- Legacy migration (from `desalut_accounts` array) ----------
interface LegacyAccount {
  id: string;
  email: string;
  password: string;
  full_name: string;
  roles: Role[];
  created_at: string;
}

function isBrowser() {
  return typeof window !== "undefined" && !!window.localStorage;
}

function migrateLegacy(): Account[] | null {
  if (!isBrowser()) return null;
  try {
    const raw = window.localStorage.getItem("desalut_accounts");
    if (!raw) return null;
    const list = JSON.parse(raw) as LegacyAccount[];
    if (!Array.isArray(list)) return null;
    const migrated: Account[] = list.map((a) => ({
      id: a.id,
      fullName: a.full_name,
      username: a.email.split("@")[0] ?? a.email,
      email: a.email,
      password: a.password,
      role: a.roles[0] ?? "cashier",
      status: "active",
      createdAt: a.created_at,
      updatedAt: a.created_at,
    }));
    return migrated;
  } catch {
    return null;
  }
}

function read(): Account[] {
  const existing = storage.get<Account[]>(STORAGE_KEY);
  if (existing && Array.isArray(existing) && existing.length > 0) {
    if (!existing.some((a) => a.role === "admin")) {
      const next = [DEFAULT_ADMIN, ...existing];
      storage.set(STORAGE_KEY, next);
      return next;
    }
    return existing;
  }
  const legacy = migrateLegacy();
  if (legacy && legacy.length > 0) {
    const withAdmin = legacy.some((a) => a.role === "admin")
      ? legacy
      : [DEFAULT_ADMIN, ...legacy];
    storage.set(STORAGE_KEY, withAdmin);
    return withAdmin;
  }
  storage.set(STORAGE_KEY, [DEFAULT_ADMIN]);
  return [DEFAULT_ADMIN];
}

function write(list: Account[]) {
  storage.set(STORAGE_KEY, list);
}

function toView(a: Account): AccountView {
  const { password: _pw, ...view } = a;
  return view;
}

function now() {
  return new Date().toISOString();
}

// ---------- Transaction guard ----------
interface CreatedByRow {
  createdBy?: string;
}

/**
 * Sudah punya transaksi = akun ini pernah tercatat sebagai `createdBy` di
 * Sales / PreOrder / Purchase (baseline modul yang men-stamp aktor). Dipakai
 * untuk memilih hard-delete vs deactivate.
 */
export function accountHasTransactions(acc: Pick<Account, "id" | "fullName" | "username" | "email">): boolean {
  const needles = [acc.id, acc.fullName, acc.username, acc.email]
    .filter(Boolean)
    .map((s) => s.toLowerCase());
  const keys: string[] = [
    StorageKeys.sales,
    StorageKeys.preorders,
    StorageKeys.purchases,
    StorageKeys.marketplaceSettlements,
    StorageKeys.shifts,
  ];
  for (const key of keys) {
    const rows = storage.get<CreatedByRow[]>(key) ?? [];
    if (!Array.isArray(rows)) continue;
    if (rows.some((r) => r?.createdBy && needles.includes(String(r.createdBy).toLowerCase()))) {
      return true;
    }
  }
  return false;
}

// ---------- Public API ----------
export function ensureDefaultAdmin() {
  read();
}

export async function findByEmail(email: string): Promise<Account | null> {
  const list = read();
  const q = email.trim().toLowerCase();
  return (
    list.find((a) => a.email.toLowerCase() === q || a.username.toLowerCase() === q) ?? null
  );
}

export async function signInWithPassword(
  emailOrUsername: string,
  password: string,
): Promise<Account> {
  const acc = await findByEmail(emailOrUsername);
  if (!acc || acc.password !== password) {
    throw new Error("Email/username atau kata sandi salah.");
  }
  if (acc.status === "inactive") {
    throw new Error("Akun nonaktif. Hubungi admin.");
  }
  // stamp last login
  const list = read();
  const next = list.map((a) => (a.id === acc.id ? { ...a, lastLogin: now() } : a));
  write(next);
  return { ...acc, lastLogin: now() };
}

export async function adminExists(): Promise<{ exists: boolean }> {
  return { exists: read().some((a) => a.role === "admin" && a.status === "active") };
}

export async function bootstrapAdmin(input: {
  data: { email: string; password: string; full_name: string };
}): Promise<{ id: string }> {
  const list = read();
  if (list.some((a) => a.role === "admin")) {
    throw new Error("Admin sudah ada. Bootstrap tidak diizinkan.");
  }
  const email = input.data.email.trim();
  const fullName = input.data.full_name.trim();
  const acc: Account = {
    id: crypto.randomUUID(),
    fullName,
    username: email.split("@")[0] ?? email,
    email,
    password: input.data.password,
    role: "admin",
    status: "active",
    createdAt: now(),
    updatedAt: now(),
  };
  write([...list, acc]);
  return { id: acc.id };
}

export async function listAccounts(): Promise<AccountView[]> {
  return read().map(toView);
}

export interface CreateAccountInput {
  fullName: string;
  username: string;
  email?: string;
  password: string;
  role: Role;
  status?: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
}

function validateUsername(username: string) {
  const u = username.trim();
  if (u.length < 3) throw new Error("Username minimal 3 karakter.");
  if (!/^[a-zA-Z0-9._-]+$/.test(u)) {
    throw new Error("Username hanya boleh huruf, angka, titik, garis bawah, atau strip.");
  }
  return u;
}

function validatePassword(pw: string) {
  if (pw.length < 8) throw new Error("Password minimal 8 karakter.");
}

export async function createAccount(input: CreateAccountInput): Promise<AccountView> {
  const list = read();
  const username = validateUsername(input.username);
  validatePassword(input.password);
  const email = (input.email ?? "").trim();
  if (list.some((a) => a.username.toLowerCase() === username.toLowerCase())) {
    throw new Error("Username sudah dipakai.");
  }
  if (email && list.some((a) => a.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("Email sudah terdaftar.");
  }
  const acc: Account = {
    id: crypto.randomUUID(),
    fullName: input.fullName.trim(),
    username,
    email,
    password: input.password,
    role: input.role,
    status: input.status ?? "active",
    employeeCode: input.employeeCode?.trim() || undefined,
    phone: input.phone?.trim() || undefined,
    notes: input.notes?.trim() || undefined,
    createdAt: now(),
    updatedAt: now(),
  };
  write([...list, acc]);
  return toView(acc);
}

export interface UpdateAccountInput {
  fullName?: string;
  email?: string;
  role?: Role;
  status?: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
}

export async function updateAccount(id: string, patch: UpdateAccountInput): Promise<AccountView> {
  const list = read();
  const idx = list.findIndex((a) => a.id === id);
  if (idx === -1) throw new Error("Akun tidak ditemukan.");
  const current = list[idx];
  const email = patch.email !== undefined ? patch.email.trim() : current.email;
  if (
    email &&
    email !== current.email &&
    list.some((a) => a.id !== id && a.email.toLowerCase() === email.toLowerCase())
  ) {
    throw new Error("Email sudah terdaftar.");
  }
  // Prevent demoting/disabling the last active admin.
  const willBeAdmin = (patch.role ?? current.role) === "admin";
  const willBeActive = (patch.status ?? current.status) === "active";
  const activeAdmins = list.filter(
    (a) => a.role === "admin" && a.status === "active" && a.id !== id,
  ).length;
  if (current.role === "admin" && current.status === "active" && !(willBeAdmin && willBeActive) && activeAdmins === 0) {
    throw new Error("Harus tersisa minimal 1 admin aktif.");
  }
  const next: Account = {
    ...current,
    fullName: patch.fullName?.trim() ?? current.fullName,
    email,
    role: patch.role ?? current.role,
    status: patch.status ?? current.status,
    employeeCode: patch.employeeCode !== undefined ? (patch.employeeCode.trim() || undefined) : current.employeeCode,
    phone: patch.phone !== undefined ? (patch.phone.trim() || undefined) : current.phone,
    notes: patch.notes !== undefined ? (patch.notes.trim() || undefined) : current.notes,
    updatedAt: now(),
  };
  const nextList = [...list];
  nextList[idx] = next;
  write(nextList);
  return toView(next);
}

export async function setAccountStatus(id: string, status: AccountStatus): Promise<AccountView> {
  return updateAccount(id, { status });
}

export async function resetAccountPassword(id: string, newPassword: string): Promise<void> {
  validatePassword(newPassword);
  const list = read();
  const idx = list.findIndex((a) => a.id === id);
  if (idx === -1) throw new Error("Akun tidak ditemukan.");
  const next = [...list];
  next[idx] = { ...next[idx], password: newPassword, updatedAt: now() };
  write(next);
}

/**
 * Hard-delete jika belum ada transaksi. Kalau sudah ada → dilempar error
 * — pemanggil harus menawarkan Deactivate.
 */
export async function deleteAccount(id: string): Promise<{ deactivated: boolean }> {
  const list = read();
  const acc = list.find((a) => a.id === id);
  if (!acc) throw new Error("Akun tidak ditemukan.");
  if (acc.role === "admin") {
    const activeAdmins = list.filter((a) => a.role === "admin" && a.status === "active" && a.id !== id).length;
    if (activeAdmins === 0) throw new Error("Harus tersisa minimal 1 admin aktif.");
  }
  if (accountHasTransactions(acc)) {
    await setAccountStatus(id, "inactive");
    return { deactivated: true };
  }
  write(list.filter((a) => a.id !== id));
  return { deactivated: false };
}

// ---------- Read helpers for other modules (read-only) ----------
export function countAccountsByRole(): Record<Role, number> {
  const base: Record<Role, number> = { admin: 0, owner: 0, cashier: 0, production: 0 };
  for (const a of read()) base[a.role] = (base[a.role] ?? 0) + 1;
  return base;
}
