/**
 * Operational Sales Analytics — read-only, additive.
 *
 * Menambah agregasi BI operasional (Cashier, Shift, Peak, Void, Packaging,
 * Operational Expense, KPI panel) TANPA mengubah service canonical apa pun.
 * Semua data dibaca dari service yang sudah ada:
 *   salesService, refundService, shiftService, inventoryService,
 *   productService. (packagingAnalytics dihitung dari Sale.packings/
 *   Sale.plastic/Sale.extraPackaging via packing.ts, bukan StockMovement —
 *   lihat Gap #3 di packing.ts.)
 *
 * TIDAK menulis storage. TIDAK memutasi entity. TIDAK mengubah business flow.
 */

import { saleAmountByMethod } from "@/lib/payment";
import { type DateRange, aggregateSalesRange } from "@/services/finance-aggregation";
import { salesService } from "@/services/sales.service";
import { refundService } from "@/services/refund.service";
// shiftService bukan lagi diimpor di sini — daftar Shift diteruskan
// sebagai parameter oleh sales-analytics-page (fetch via react-query).
import { aggregatePackagingUsageFromSales, totalPackagingQtyForSale } from "@/services/packing";
import type { InventoryItem, Product, Sale, Shift } from "@/services/types";
import { customerStats, type Period } from "./data";

/* ---------------------- Shared helpers ---------------------- */

function inRange(iso: string | undefined, r: DateRange): boolean {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function activeSalesInRange(range: DateRange): Sale[] {
  return salesService.listCached().filter((s) => !s.voided && inRange(s.createdAt, range));
}

function saleProfit(s: Sale): number {
  let hpp = 0;
  for (const it of s.items) hpp += (it.cost ?? 0) * it.qty;
  return (s.total ?? 0) - hpp;
}

/** Set saleId yang refund-nya disetujui (untuk memisahkan Refund vs Void). */
function approvedRefundSaleIds(): Set<string> {
  const set = new Set<string>();
  for (const r of refundService.list()) {
    if (r.status === "approved") set.add(r.saleId);
  }
  return set;
}

/* ---------------------- Cashier Performance ---------------------- */

export interface CashierRow {
  rank: number;
  cashier: string;
  totalSales: number; // total qty item terjual
  revenue: number;
  profit: number;
  avgOrder: number;
  transactions: number;
  refundCount: number;
  voidCount: number;
  /** voidCount ÷ (transactions + voidCount) — supaya bisa dibandingkan antar kasir walau volume beda. */
  voidRate: number;
  /** refundCount ÷ (transactions + refundCount). */
  refundRate: number;
}

export function cashierPerformance(range: DateRange): CashierRow[] {
  const active = activeSalesInRange(range);
  const refundIds = approvedRefundSaleIds();
  const map = new Map<
    string,
    Omit<CashierRow, "rank" | "avgOrder" | "voidRate" | "refundRate">
  >();
  const ensure = (cashier: string) => {
    const key = cashier || "-";
    let cur = map.get(key);
    if (!cur) {
      cur = {
        cashier: key,
        totalSales: 0,
        revenue: 0,
        profit: 0,
        transactions: 0,
        refundCount: 0,
        voidCount: 0,
      };
      map.set(key, cur);
    }
    return cur;
  };

  for (const s of active) {
    const cur = ensure(s.cashier);
    cur.revenue += s.total ?? 0;
    cur.profit += saleProfit(s);
    cur.transactions += 1;
    for (const it of s.items) cur.totalSales += it.qty;
  }

  // Refund & Void di-attribute ke kasir asal transaksi.
  for (const s of salesService.listCached()) {
    if (!s.voided || !inRange(s.voidedAt, range)) continue;
    const cur = ensure(s.cashier);
    if (refundIds.has(s.id)) cur.refundCount += 1;
    else cur.voidCount += 1;
  }

  return Array.from(map.values())
    .map((r) => ({
      ...r,
      avgOrder: r.transactions > 0 ? r.revenue / r.transactions : 0,
      voidRate: r.transactions + r.voidCount > 0 ? r.voidCount / (r.transactions + r.voidCount) : 0,
      refundRate:
        r.transactions + r.refundCount > 0 ? r.refundCount / (r.transactions + r.refundCount) : 0,
    }))
    .sort((a, b) => b.revenue - a.revenue)
    .map((r, i) => ({ rank: i + 1, ...r }));
}

/* ---------------------- Shift Performance ---------------------- */

export type ShiftKasStatus = "NORMAL" | "WARNING" | "LOSS";

export interface ShiftRow {
  id: string;
  cashier: string;
  openedAt: string;
  closedAt?: string;
  openingCash: number;
  closingCash: number;
  cashSales: number;
  qrisSales: number;
  transferSales: number;
  cardSales: number;
  marketplaceSales: number;
  operationalExpense: number;
  expectedCash: number;
  actualCash: number;
  selisihKas: number;
  status: ShiftKasStatus;
}

function shiftCardSales(s: Shift): number {
  // Sprint 7: split payment — jumlahkan porsi "card" per sale, bukan filter
  // sale-by-payment saja (sale bisa punya cash + card sekaligus).
  return salesService.listCached()
    .filter((x) => !x.voided && x.shiftId === s.id)
    .reduce((a, x) => a + saleAmountByMethod(x).card, 0);
}

export function shiftPerformance(range: DateRange, allShifts: Shift[]): ShiftRow[] {
  const shifts = allShifts.filter((s) => inRange(s.openedAt, range));
  return shifts
    .map((s): ShiftRow => {
      const openingCash = s.openingCash ?? 0;
      const cashSales = s.cashSales ?? 0;
      const opex = s.totalOperationalExpense ?? 0;
      const expected = s.expectedCash ?? openingCash + cashSales - opex;
      const actual = s.closingCash ?? 0;
      const selisih = s.closedAt ? actual - expected : 0;
      let status: ShiftKasStatus = "NORMAL";
      if (s.closedAt) {
        if (selisih < 0) status = "LOSS";
        else if (selisih > 0) status = "WARNING";
      }
      return {
        id: s.id,
        cashier: s.cashier,
        openedAt: s.openedAt,
        closedAt: s.closedAt,
        openingCash,
        closingCash: actual,
        cashSales,
        qrisSales: s.qrisSales ?? 0,
        transferSales: s.transferSales ?? 0,
        cardSales: shiftCardSales(s),
        marketplaceSales: s.marketplaceSales ?? 0,
        operationalExpense: opex,
        expectedCash: expected,
        actualCash: actual,
        selisihKas: selisih,
        status,
      };
    })
    .sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime());
}

/* ---------------------- Peak Day / Peak Month ---------------------- */

export interface PeakRow {
  key: string;
  label: string;
  revenue: number;
  transactions: number;
  profit: number;
}

const WEEKDAY_LABEL = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

export function peakDay(range: DateRange): { rows: PeakRow[]; best: PeakRow | null } {
  const rows: PeakRow[] = WEEKDAY_LABEL.map((label, i) => ({
    key: String(i),
    label,
    revenue: 0,
    transactions: 0,
    profit: 0,
  }));
  for (const s of activeSalesInRange(range)) {
    const d = new Date(s.createdAt).getDay();
    rows[d].revenue += s.total ?? 0;
    rows[d].transactions += 1;
    rows[d].profit += saleProfit(s);
  }
  // Reorder Senin..Minggu untuk tampilan.
  const ordered = [1, 2, 3, 4, 5, 6, 0].map((i) => rows[i]);
  const best = ordered.reduce<PeakRow | null>(
    (acc, r) => (acc == null || r.revenue > acc.revenue ? r : acc),
    null,
  );
  return { rows: ordered, best: best && best.revenue > 0 ? best : null };
}

const MONTH_LABEL = [
  "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
  "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
];

export function peakMonth(range: DateRange): { rows: PeakRow[]; best: PeakRow | null } {
  const map = new Map<string, PeakRow>();
  for (const s of activeSalesInRange(range)) {
    const d = new Date(s.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = `${MONTH_LABEL[d.getMonth()]} ${d.getFullYear()}`;
    const cur = map.get(key) ?? { key, label, revenue: 0, transactions: 0, profit: 0 };
    cur.revenue += s.total ?? 0;
    cur.transactions += 1;
    cur.profit += saleProfit(s);
    map.set(key, cur);
  }
  const rows = Array.from(map.values()).sort((a, b) => a.key.localeCompare(b.key));
  const best = rows.reduce<PeakRow | null>(
    (acc, r) => (acc == null || r.revenue > acc.revenue ? r : acc),
    null,
  );
  return { rows, best: best && best.revenue > 0 ? best : null };
}

/* ---------------------- Weekly / Monthly Trend ---------------------- */

export interface TrendPoint {
  key: string;
  label: string;
  revenue: number;
  transactions: number;
  profit: number;
}

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const day = x.getDay(); // 0 Sun
  const diff = (day + 6) % 7; // Monday start
  x.setDate(x.getDate() - diff);
  return x;
}

/** Tren mingguan (default 12 minggu terakhir). */
export function weeklyTrend(weeks = 12, ref = new Date()): TrendPoint[] {
  const thisWeek = startOfWeek(ref);
  const buckets: TrendPoint[] = [];
  const idx = new Map<string, number>();
  for (let i = weeks - 1; i >= 0; i--) {
    const from = new Date(thisWeek);
    from.setDate(from.getDate() - i * 7);
    const key = ymd(from);
    buckets.push({
      key,
      label: from.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      revenue: 0,
      transactions: 0,
      profit: 0,
    });
    idx.set(key, buckets.length - 1);
  }
  const earliest = new Date(thisWeek);
  earliest.setDate(earliest.getDate() - (weeks - 1) * 7);
  for (const s of salesService.listCached()) {
    if (s.voided) continue;
    const t = new Date(s.createdAt);
    if (t.getTime() < earliest.getTime()) continue;
    const key = ymd(startOfWeek(t));
    const i = idx.get(key);
    if (i == null) continue;
    buckets[i].revenue += s.total ?? 0;
    buckets[i].transactions += 1;
    buckets[i].profit += saleProfit(s);
  }
  return buckets;
}

/** Tren bulanan (default 12 bulan terakhir). */
export function monthlyTrend(months = 12, ref = new Date()): TrendPoint[] {
  const buckets: TrendPoint[] = [];
  const idx = new Map<string, number>();
  const base = new Date(ref.getFullYear(), ref.getMonth(), 1);
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(base.getFullYear(), base.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    buckets.push({
      key,
      label: `${MONTH_LABEL[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`,
      revenue: 0,
      transactions: 0,
      profit: 0,
    });
    idx.set(key, buckets.length - 1);
  }
  for (const s of salesService.listCached()) {
    if (s.voided) continue;
    const d = new Date(s.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const i = idx.get(key);
    if (i == null) continue;
    buckets[i].revenue += s.total ?? 0;
    buckets[i].transactions += 1;
    buckets[i].profit += saleProfit(s);
  }
  return buckets;
}

/* ---------------------- Void Analytics (terpisah dari Refund) ---------------------- */

export interface VoidAnalytics {
  totalVoid: number;
  totalAmount: number;
  voidRate: number;
  topReasons: { reason: string; count: number; amount: number }[];
  perCashier: { cashier: string; count: number; amount: number }[];
  trend: { date: string; label: string; count: number; amount: number }[];
}

export function voidAnalytics(range: DateRange): VoidAnalytics {
  const refundIds = approvedRefundSaleIds();
  const voided = salesService.listCached()
    .filter((s) => s.voided && inRange(s.voidedAt, range) && !refundIds.has(s.id));
  const totalAmount = voided.reduce((a, s) => a + (s.total ?? 0), 0);

  const activeAgg = aggregateSalesRange(range);
  const activeCount = activeAgg.orders;
  const voidRate = activeCount + voided.length > 0 ? voided.length / (activeCount + voided.length) : 0;

  const reasonMap = new Map<string, { reason: string; count: number; amount: number }>();
  const cashierMap = new Map<string, { cashier: string; count: number; amount: number }>();
  for (const s of voided) {
    const reason = (s.voidReason || "Tanpa alasan").trim();
    const rc = reasonMap.get(reason) ?? { reason, count: 0, amount: 0 };
    rc.count += 1;
    rc.amount += s.total ?? 0;
    reasonMap.set(reason, rc);

    const c = s.cashier || "-";
    const cc = cashierMap.get(c) ?? { cashier: c, count: 0, amount: 0 };
    cc.count += 1;
    cc.amount += s.total ?? 0;
    cashierMap.set(c, cc);
  }

  // Trend harian void.
  const trend: { date: string; label: string; count: number; amount: number }[] = [];
  const idx = new Map<string, number>();
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    const key = ymd(cursor);
    trend.push({
      date: key,
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      count: 0,
      amount: 0,
    });
    idx.set(key, trend.length - 1);
    cursor.setDate(cursor.getDate() + 1);
  }
  for (const s of voided) {
    const i = idx.get(ymd(new Date(s.voidedAt!)));
    if (i == null) continue;
    trend[i].count += 1;
    trend[i].amount += s.total ?? 0;
  }

  return {
    totalVoid: voided.length,
    totalAmount,
    voidRate,
    topReasons: Array.from(reasonMap.values()).sort((a, b) => b.count - a.count).slice(0, 10),
    perCashier: Array.from(cashierMap.values()).sort((a, b) => b.count - a.count),
    trend,
  };
}

/* ---------------------- Packaging Analytics ---------------------- */

export interface PackagingAnalytics {
  totalUsedQty: number;
  totalCost: number;
  top: { itemId: string; name: string; qty: number; cost: number }[];
  extraPackaging: { name: string; qty: number }[];
  perShiftAvg: number;
  trend: { date: string; label: string; qty: number }[];
}

// Diubah menerima `inventoryItems` (react-query, sudah di-fetch pemanggil)
// alih-alih fetch sendiri lewat inventoryService.list() — inventoryService
// sekarang Supabase (async), sementara fungsi ini murni komputasi sinkron.
// Pemanggil teratas (sales-analytics-page.tsx) yang bertanggung jawab fetch
// inventory items sekali lalu meneruskannya lewat computeOperationalAnalytics().
export function packagingAnalytics(range: DateRange, inventoryItems: InventoryItem[], allShifts: Shift[]): PackagingAnalytics {
  const costOf = new Map(inventoryItems.map((i) => [i.id, i.costPerUnit ?? 0]));

  // Gap #3 (Packaging Fix): totalUsedQty/totalCost/top dihitung LANGSUNG
  // dari Sale.packings / Sale.plastic / Sale.extraPackaging (sumber
  // kebenaran transaksi — cross-check sesuai rekomendasi audit), BUKAN dari
  // StockMovement seperti sebelumnya. Alasan: StockMovement bertipe
  // "sales_packaging_usage" dicatat baik saat checkout (sales.service.ts)
  // MAUPUN saat koreksi Shift Closing (shift.service.ts →
  // savePackagingUsage), sehingga menjumlah SELURUH movement tsb tanpa
  // membedakan sumbernya bisa menghitung pemakaian fisik yang sama dua
  // kali begitu ada koreksi di Shift Closing. Beralih ke Sale sebagai
  // sumber kebenaran juga otomatis mengeluarkan Sale yang sudah di-void
  // (activeSalesInRange() sudah memfilter `!voided`), tanpa perlu logic
  // tambahan.
  const salesInRange = activeSalesInRange(range);
  const agg = aggregatePackagingUsageFromSales(salesInRange);

  let totalUsedQty = 0;
  let totalCost = 0;
  const map = new Map<string, { itemId: string; name: string; qty: number; cost: number }>();
  for (const entry of agg.values()) {
    const cost = entry.qty * (costOf.get(entry.itemId) ?? 0);
    totalUsedQty += entry.qty;
    totalCost += cost;
    map.set(entry.itemId, { itemId: entry.itemId, name: entry.itemName, qty: entry.qty, cost });
  }

  // Tren harian pemakaian packaging — dijumlah per Sale (box + plastik +
  // extras yang benar-benar dipotong, lihat totalPackagingQtyForSale),
  // dibucket berdasarkan tanggal Sale dibuat.
  const trend: { date: string; label: string; qty: number }[] = [];
  const idx = new Map<string, number>();
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    const key = ymd(cursor);
    trend.push({
      date: key,
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      qty: 0,
    });
    idx.set(key, trend.length - 1);
    cursor.setDate(cursor.getDate() + 1);
  }
  for (const s of salesInRange) {
    const i = idx.get(ymd(new Date(s.createdAt)));
    if (i == null) continue;
    trend[i].qty += totalPackagingQtyForSale(s);
  }

  // Extra packaging dari sales (permintaan customer, Rp 0).
  const extraMap = new Map<string, number>();
  for (const s of salesInRange) {
    for (const ex of s.extraPackaging ?? []) {
      extraMap.set(ex.itemName, (extraMap.get(ex.itemName) ?? 0) + ex.qty);
    }
  }

  // Packaging per shift (rata-rata) dari shift.totalPackagingQty.
  const shiftsInRange = allShifts.filter((s) => inRange(s.openedAt, range));
  const totalShiftPackaging = shiftsInRange.reduce((a, s) => a + (s.totalPackagingQty ?? 0), 0);
  const perShiftAvg = shiftsInRange.length > 0 ? totalShiftPackaging / shiftsInRange.length : 0;

  return {
    totalUsedQty,
    totalCost,
    top: Array.from(map.values()).sort((a, b) => b.qty - a.qty).slice(0, 10),
    extraPackaging: Array.from(extraMap.entries())
      .map(([name, qty]) => ({ name, qty }))
      .sort((a, b) => b.qty - a.qty),
    perShiftAvg,
    trend,
  };
}

/* ---------------------- Operational Expense Analytics ---------------------- */

export interface OpexAnalytics {
  totalExpense: number;
  byCategory: { name: string; amount: number; count: number }[];
  perShiftAvg: number;
  expenseVsRevenue: number;
  expenseVsProfit: number;
  trend: { date: string; label: string; amount: number }[];
}

export function opexAnalytics(range: DateRange, allShifts: Shift[]): OpexAnalytics {
  const shifts = allShifts.filter((s) => inRange(s.openedAt, range));

  const catMap = new Map<string, { name: string; amount: number; count: number }>();
  let totalExpense = 0;

  const trend: { date: string; label: string; amount: number }[] = [];
  const idx = new Map<string, number>();
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    const key = ymd(cursor);
    trend.push({
      date: key,
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      amount: 0,
    });
    idx.set(key, trend.length - 1);
    cursor.setDate(cursor.getDate() + 1);
  }

  for (const s of shifts) {
    for (const e of s.operationalExpenses ?? []) {
      totalExpense += e.total ?? 0;
      const cur = catMap.get(e.itemName) ?? { name: e.itemName, amount: 0, count: 0 };
      cur.amount += e.total ?? 0;
      cur.count += 1;
      catMap.set(e.itemName, cur);
      const i = idx.get(ymd(new Date(e.at)));
      if (i != null) trend[i].amount += e.total ?? 0;
    }
  }

  const agg = aggregateSalesRange(range);
  return {
    totalExpense,
    byCategory: Array.from(catMap.values()).sort((a, b) => b.amount - a.amount),
    perShiftAvg: shifts.length > 0 ? totalExpense / shifts.length : 0,
    expenseVsRevenue: agg.revenue > 0 ? totalExpense / agg.revenue : 0,
    expenseVsProfit: agg.grossProfit > 0 ? totalExpense / agg.grossProfit : 0,
    trend,
  };
}

/* ---------------------- KPI Panel ---------------------- */

export interface KpiPanel {
  readyStockAlert: number;
  packagingDifference: number;
  opexPct: number;
  voidPct: number;
  refundPct: number;
  repeatCustomerPct: number;
  avgItemPerTrx: number;
  avgPackagingPerTrx: number;
  topCashier: string;
  topShift: string;
}

export function kpiPanel(period: Period, products: Product[], inventoryItems: InventoryItem[], allShifts: Shift[]): KpiPanel {
  const range = period.range;
  const active = activeSalesInRange(range);
  const transactions = active.length;
  const refundIds = approvedRefundSaleIds();

  const voidedInRange = salesService.listCached()
    .filter((s) => s.voided && inRange(s.voidedAt, range));
  const voidCount = voidedInRange.filter((s) => !refundIds.has(s.id)).length;
  const refundCount = voidedInRange.filter((s) => refundIds.has(s.id)).length;

  const agg = aggregateSalesRange(range);
  const opex = opexAnalytics(range, allShifts).totalExpense;
  const pkg = packagingAnalytics(range, inventoryItems, allShifts);

  // Ready Stock Alert: produk ready-stock di/di bawah minStock.
  const readyStockAlert = products.filter(
    (p) => p.active !== false && typeof p.stock === "number" && p.stock <= (p.minStock ?? 0),
  ).length;

  const totalItems = active.reduce((a, s) => a + s.items.reduce((x, it) => x + it.qty, 0), 0);

  const cashiers = cashierPerformance(range);
  const shifts = shiftPerformance(range, allShifts);
  const topShift = shifts.reduce<ShiftRow | null>(
    (acc, s) => (acc == null || s.actualCash + s.cashSales > acc.actualCash + acc.cashSales ? s : acc),
    null,
  );

  const repeat = customerStats(range);
  const totalShiftPackaging = allShifts
    .filter((s) => inRange(s.openedAt, range))
    .reduce((a, s) => a + (s.totalPackagingQty ?? 0), 0);

  return {
    readyStockAlert,
    packagingDifference: pkg.extraPackaging.reduce((a, e) => a + e.qty, 0),
    opexPct: agg.revenue > 0 ? opex / agg.revenue : 0,
    voidPct: transactions + voidCount > 0 ? voidCount / (transactions + voidCount) : 0,
    refundPct: transactions + refundCount > 0 ? refundCount / (transactions + refundCount) : 0,
    repeatCustomerPct: repeat.available ? repeat.repeatRate : 0,
    avgItemPerTrx: transactions > 0 ? totalItems / transactions : 0,
    avgPackagingPerTrx: transactions > 0 ? totalShiftPackaging / transactions : 0,
    topCashier: cashiers[0]?.cashier ?? "-",
    topShift: topShift ? `${topShift.cashier} · ${new Date(topShift.openedAt).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}` : "-",
  };
}

/* ---------------------- Compound ---------------------- */

export interface OperationalAnalyticsData {
  cashiers: CashierRow[];
  shifts: ShiftRow[];
  peakDay: { rows: PeakRow[]; best: PeakRow | null };
  peakMonth: { rows: PeakRow[]; best: PeakRow | null };
  weekly: TrendPoint[];
  monthly: TrendPoint[];
  voids: VoidAnalytics;
  packaging: PackagingAnalytics;
  opex: OpexAnalytics;
  kpiPanel: KpiPanel;
}

export function computeOperationalAnalytics(
  period: Period,
  products: Product[],
  inventoryItems: InventoryItem[],
  shifts: Shift[],
): OperationalAnalyticsData {
  return {
    cashiers: cashierPerformance(period.range),
    shifts: shiftPerformance(period.range, shifts),
    peakDay: peakDay(period.range),
    peakMonth: peakMonth(period.range),
    weekly: weeklyTrend(),
    monthly: monthlyTrend(),
    voids: voidAnalytics(period.range),
    packaging: packagingAnalytics(period.range, inventoryItems, shifts),
    opex: opexAnalytics(period.range, shifts),
    kpiPanel: kpiPanel(period, products, inventoryItems, shifts),
  };
}
