import { useEffect, useMemo, useState } from "react";
import { addMonths, format, isSameDay, isSameMonth, startOfMonth, startOfWeek, endOfMonth, endOfWeek, addDays } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { NumberInput } from "@/components/ui/number-input";
import { ChevronLeft, ChevronRight, Trash2, CheckCircle2, PlayCircle, XCircle, AlertTriangle, RotateCcw, Search, X } from "lucide-react";
import { toast } from "sonner";
import { preorderService } from "@/services/preorder.service";
import {
  preorderCancelService,
  PREORDER_CANCEL_STATUS_LABEL,
  type PreOrderCancelRequest,
} from "@/services/preorder-cancel.service";
import { salesService } from "@/services/sales.service";
import { shiftService } from "@/services/shift.service";
import { queueService } from "@/services/queue.service";
import {
  PREORDER_STATUS_LABEL,
  SOURCE_ORDER_LABEL,
  type PreOrder,
  type PreOrderStatus,
  type PaymentMethod,
  type PaymentEntry,
  type Role,
} from "@/services/types";
import { formatIDR } from "@/lib/format";
import { IMPORTANT_TOAST_DURATION } from "@/lib/toast";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";
import { useRole } from "@/lib/role-context";
import { usePermission } from "@/lib/permissions";

function toKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const STATUS_TONE: Record<PreOrderStatus, string> = {
  scheduled: "bg-slate-500/10 text-slate-700 border-slate-500/20",
  ready_to_process: "bg-blue-500/10 text-blue-700 border-blue-500/20",
  completed: "bg-emerald-500/10 text-emerald-700 border-emerald-500/20",
  cancelled: "bg-muted text-muted-foreground border-transparent",
};

/**
 * Panel Pre Order — dirender sebagai tab di dalam halaman Pesanan.
 * Tetap menggunakan preorderService dan lifecycle yang sudah ada; tidak
 * ada perubahan business logic. Untuk kompatibilitas import lama, alias
 * `PreorderPage` diekspor sebagai komponen yang sama.
 */
export function PreorderPanel() {
  const { profile, user, role } = useRole();
  const { can } = usePermission();
  const actor = profile?.full_name ?? user?.email ?? "User";
  // Alur pembatalan PO yang sudah menerima DP disamakan dengan alur Void di
  // pesanan-page.tsx: siapa pun yang bisa mengajukan refund juga bisa
  // mengajukan pembatalan (kasir/admin), tapi hanya yang bisa approve
  // refund yang bisa menyetujui pembatalan (admin).
  const canRequestCancel = can("action.requestRefund");
  const canApproveCancel = can("action.approveRefund");
  const [cursor, setCursor] = useState<Date>(startOfMonth(new Date()));
  // Bug fix (UX Sedang — audit "loading skeleton"): lazy-init langsung dari
  // preorderService.list() (bukan array kosong + isi di useEffect) supaya
  // gak ada sekejap render "Belum ada PO" sebelum data yang sebenarnya
  // sudah tersedia (localStorage itu sinkron, jadi gap-nya murni artifisial).
  const [rows, setRows] = useState<PreOrder[]>(() => preorderService.list());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  // Bug fix (UX Sedang): sebelumnya satu-satunya cara nemuin PO tertentu
  // adalah klik tanggal satu-satu di kalender. Search ini nyari lintas
  // SEMUA bulan (bukan cuma bulan yang lagi ditampilkan) — beda dari filter
  // per-hari di Pesanan — karena tujuannya justru buat nemuin PO yang
  // tanggalnya gak keliatan di layar.
  const [poQuery, setPoQuery] = useState("");

  function refresh() {
    setRows(preorderService.list());
  }
  useEffect(refresh, []);
  useEffect(() => {
    const onChanged = () => refresh();
    window.addEventListener("desalut:preorders-changed", onChanged);
    return () => window.removeEventListener("desalut:preorders-changed", onChanged);
  }, []);
  // `desalut:preorders-changed` hanya nyala di tab yang sama. Untuk sinkron
  // lintas-tab (mis. admin tandai PO "Siap" di tab lain, device sama),
  // ikutkan juga tick dari useSalesRefresh (native `storage` event).
  const salesTick = useSalesRefresh();
  useEffect(refresh, [salesTick]);

  const monthStart = startOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const gridEnd = endOfWeek(endOfMonth(monthStart), { weekStartsOn: 1 });
  const days: Date[] = [];
  for (let d = gridStart; d <= gridEnd; d = addDays(d, 1)) days.push(d);

  const byDate = useMemo(() => {
    const m = new Map<string, PreOrder[]>();
    for (const p of rows) {
      const arr = m.get(p.date) ?? [];
      arr.push(p);
      m.set(p.date, arr);
    }
    return m;
  }, [rows]);

  const searchResults = useMemo(() => {
    const q = poQuery.trim().toLowerCase();
    if (!q) return [];
    return rows
      .filter((p) => {
        const hay = [p.id, p.customerName, p.customerPhone, ...p.items.map((i) => i.name)]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return hay.includes(q);
      })
      .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
      .slice(0, 20);
  }, [rows, poQuery]);

  function jumpToResult(p: PreOrder) {
    const d = new Date(`${p.date}T00:00:00`);
    if (!Number.isNaN(d.getTime())) {
      setCursor(startOfMonth(d));
      setSelectedDate(d);
    }
    setPoQuery("");
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Monitoring pesanan mendatang. Pembuatan Pre Order baru dilakukan melalui POS (Kasir).
        </p>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            aria-label="Bulan sebelumnya"
            onClick={() => setCursor(addMonths(cursor, -1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-[140px] text-center text-sm font-semibold">
            {format(cursor, "MMMM yyyy")}
          </div>
          <Button
            variant="outline"
            size="sm"
            aria-label="Bulan berikutnya"
            onClick={() => setCursor(addMonths(cursor, 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={poQuery}
          onChange={(e) => setPoQuery(e.target.value)}
          placeholder="Cari nama/HP customer atau produk — cari lintas semua bulan"
          className="h-10 rounded-xl pl-9 pr-9"
        />
        {poQuery && (
          <button
            type="button"
            aria-label="Bersihkan pencarian"
            onClick={() => setPoQuery("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
        {poQuery && (
          <div className="absolute z-10 mt-1 w-full overflow-hidden rounded-xl border bg-popover shadow-lg">
            {searchResults.length === 0 ? (
              <div className="px-3 py-3 text-sm text-muted-foreground">
                Tidak ada Pre Order yang cocok dengan "{poQuery}"
              </div>
            ) : (
              <div className="max-h-72 overflow-y-auto">
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => jumpToResult(p)}
                    className="flex w-full items-center justify-between gap-3 border-b px-3 py-2 text-left text-sm last:border-b-0 hover:bg-muted/50"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{p.customerName}</div>
                      <div className="truncate text-xs text-muted-foreground">
                        {format(new Date(`${p.date}T00:00:00`), "d MMM yyyy")} · {p.time}
                        {p.customerPhone ? ` · ${p.customerPhone}` : ""}
                      </div>
                    </div>
                    <Badge variant="outline" className={`shrink-0 text-[10px] ${STATUS_TONE[p.status]}`}>
                      {PREORDER_STATUS_LABEL[p.status]}
                    </Badge>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-7 gap-1 text-xs">
            {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map((d) => (
              <div key={d} className="py-2 text-center font-medium text-muted-foreground">
                {d}
              </div>
            ))}
            {days.map((d) => {
              const key = toKey(d);
              const list = byDate.get(key) ?? [];
              const inMonth = isSameMonth(d, monthStart);
              const isToday = isSameDay(d, new Date());
              const active = list.filter((p) => p.status !== "cancelled" && p.status !== "completed").length;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelectedDate(d)}
                  className={`flex min-h-[60px] min-[720px]:min-h-[80px] flex-col items-start gap-1 rounded-md border p-1 min-[720px]:p-2 text-left transition hover:border-primary/40 ${
                    inMonth ? "bg-card" : "bg-muted/30 text-muted-foreground"
                  } ${isToday ? "border-primary" : ""}`}
                >
                  <span className="text-xs font-semibold">{d.getDate()}</span>
                  {active > 0 && (
                    <Badge variant="secondary" className="text-[10px]">
                      {active} PO
                    </Badge>
                  )}
                  {list.slice(0, 2).map((p) => (
                    <span key={p.id} className="line-clamp-1 w-full text-[10px] text-muted-foreground">
                      {p.time} · {p.customerName}
                    </span>
                  ))}
                  {list.length > 2 && (
                    <span className="text-[10px] text-muted-foreground">
                      +{list.length - 2} lagi
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Sheet open={!!selectedDate} onOpenChange={(o) => !o && setSelectedDate(null)}>
        <SheetContent className="flex flex-col gap-4 sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>
              Pre Order · {selectedDate ? format(selectedDate, "d MMMM yyyy") : ""}
            </SheetTitle>
          </SheetHeader>
          {selectedDate && (
            <DayList
              date={selectedDate}
              items={byDate.get(toKey(selectedDate)) ?? []}
              actor={actor}
              actorRole={role ?? undefined}
              canRequestCancel={canRequestCancel}
              canApproveCancel={canApproveCancel}
              onChanged={refresh}
            />
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

/** @deprecated Route lama; halaman ini kini dilebur ke tab di /sales/pesanan. */
export const PreorderPage = PreorderPanel;

function DayList({
  date,
  items,
  actor,
  actorRole,
  canRequestCancel,
  canApproveCancel,
  onChanged,
}: {
  date: Date;
  items: PreOrder[];
  actor: string;
  actorRole?: Role;
  canRequestCancel: boolean;
  canApproveCancel: boolean;
  onChanged: () => void;
}) {
  const ordered = [...items].sort((a, b) => a.time.localeCompare(b.time));
  const numberOf = new Map<string, number>();
  ordered.forEach((p, i) => numberOf.set(p.id, i + 1));
  // Sprint 5: dialog pelunasan.
  const [settlePo, setSettlePo] = useState<PreOrder | null>(null);
  const [settleMethod, setSettleMethod] = useState<PaymentMethod>("cash");
  const [settleTendered, setSettleTendered] = useState<number>(0);
  const [settleBusy, setSettleBusy] = useState(false);
  // Bug fix: jalur "Selesaikan" langsung (PO yang sudah lunas via DP, tanpa
  // dialog pelunasan) sebelumnya tidak punya guard sama sekali — beda
  // dengan completeSale() di POS (pos-page.tsx) yang selalu di-guard pakai
  // `isCompleting` meski operasinya sama-sama sinkron. Disamakan di sini
  // supaya tombol tidak bisa dipicu dobel selama proses berjalan (mis. dari
  // event click ganda di beberapa browser/touch device), yang kalau lolos
  // bisa bikin Sale duplikat + potong stok dua kali untuk PO yang sama.
  const [completingId, setCompletingId] = useState<string | null>(null);
  // Bug fix: "Hapus" Pre Order sebelumnya menghapus permanen tanpa
  // konfirmasi apa pun — beda dengan pola hapus permanen di tempat lain
  // (mis. Hapus produk di products-page.tsx) yang selalu lewat AlertDialog
  // konfirmasi. Disamakan di sini.
  const [confirmRemove, setConfirmRemove] = useState<PreOrder | null>(null);
  // Alur pembatalan PO yang sudah menerima DP: request → approve/reject,
  // disamakan dengan alur Void di pesanan-page.tsx. DP dinyatakan hangus
  // saat pengajuan disetujui (lihat preorder-cancel.service.ts).
  const [cancelRequests, setCancelRequests] = useState<PreOrderCancelRequest[]>(() =>
    preorderCancelService.list(),
  );
  function refreshCancelRequests() {
    setCancelRequests(preorderCancelService.list());
  }
  useEffect(refreshCancelRequests, []);
  const salesTick = useSalesRefresh();
  useEffect(refreshCancelRequests, [salesTick]);
  const pendingCancelByPo = useMemo(() => {
    const m = new Map<string, PreOrderCancelRequest>();
    for (const r of cancelRequests) if (r.status === "pending") m.set(r.preorderId, r);
    return m;
  }, [cancelRequests]);
  const [cancelReqTarget, setCancelReqTarget] = useState<PreOrder | null>(null);
  const [cancelReqReason, setCancelReqReason] = useState("");
  const [cancelReviewTarget, setCancelReviewTarget] = useState<PreOrderCancelRequest | null>(null);
  const [cancelReviewNote, setCancelReviewNote] = useState("");
  function markReady(id: string) {
    preorderService.setStatus(id, "ready_to_process");
    toast.success("Ditandai siap diproses");
    onChanged();
  }
  function undoMarkReady(id: string) {
    const result = preorderService.undoMarkReady(id, { actor, actorRole });
    if (!result.ok) {
      toast.error(result.reason);
      return;
    }
    toast.success("Diurungkan — PO kembali ke status Terjadwal");
    onChanged();
  }
  function cancel(po: PreOrder) {
    if ((po.downPayment ?? 0) > 0) {
      if (!canRequestCancel) {
        toast.error("Anda tidak punya izin mengajukan pembatalan PO ini");
        return;
      }
      // DP sudah masuk — tidak boleh batal langsung, harus lewat approval
      // karena DP akan dinyatakan hangus.
      setCancelReqReason("");
      setCancelReqTarget(po);
      return;
    }
    preorderService.cancel(po.id);
    toast.success("Pre Order dibatalkan");
    onChanged();
  }
  function submitCancelRequest() {
    if (!cancelReqTarget) return;
    if (!cancelReqReason.trim()) {
      toast.error("Isi alasan pembatalan");
      return;
    }
    preorderCancelService.request({
      preorderId: cancelReqTarget.id,
      reason: cancelReqReason.trim(),
      actor,
      actorRole,
    });
    toast.success("Pengajuan pembatalan dikirim, menunggu approval Admin");
    setCancelReqTarget(null);
    setCancelReqReason("");
    refreshCancelRequests();
  }
  function approveCancelRequest() {
    if (!cancelReviewTarget) return;
    const result = preorderCancelService.approve(cancelReviewTarget.id, {
      actor,
      actorRole,
      note: cancelReviewNote.trim() || undefined,
    });
    if (!result.ok) {
      toast.error(result.reason, { duration: IMPORTANT_TOAST_DURATION });
    } else {
      toast.success("Pembatalan disetujui — DP dinyatakan hangus");
    }
    setCancelReviewTarget(null);
    setCancelReviewNote("");
    refreshCancelRequests();
    onChanged();
  }
  function rejectCancelRequest() {
    if (!cancelReviewTarget) return;
    preorderCancelService.reject(cancelReviewTarget.id, {
      actor,
      actorRole,
      note: cancelReviewNote.trim() || undefined,
    });
    toast.success("Pengajuan pembatalan ditolak");
    setCancelReviewTarget(null);
    setCancelReviewNote("");
    refreshCancelRequests();
  }

  // Keyboard shortcuts — sama seperti dialog Refund di pesanan-page.tsx
  // (Ctrl/Cmd+Enter = konfirmasi, Esc = tutup). Review pembatalan PO juga
  // alur high-frequency buat admin.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const isConfirm = (e.ctrlKey || e.metaKey) && e.key === "Enter";
      if (e.key === "Escape") {
        if (cancelReqTarget) setCancelReqTarget(null);
        else if (cancelReviewTarget) setCancelReviewTarget(null);
        return;
      }
      if (cancelReqTarget && isConfirm) {
        e.preventDefault();
        submitCancelRequest();
        return;
      }
      if (cancelReviewTarget) {
        if (isConfirm) {
          e.preventDefault();
          approveCancelRequest();
        } else if ((e.ctrlKey || e.metaKey) && e.key === "Backspace") {
          e.preventDefault();
          rejectCancelRequest();
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cancelReqTarget, cancelReviewTarget, cancelReqReason, cancelReviewNote]);
  function remove(id: string) {
    preorderService.remove(id);
    toast.success("Pre Order dihapus");
    setConfirmRemove(null);
    onChanged();
  }
  // TODO(prompt berikutnya): preorder-page.tsx SENDIRI (halaman domain
  // Preorder) tidak dimigrasikan tahap ini — requestComplete/
  // finalizeComplete/confirmSettle di bawah diubah jadi async HANYA karena
  // memanggil salesService.create() yang sekarang async (memanggil
  // productService, sekarang Supabase), sesuai izin eksplisit di scope
  // Prompt 2 ("boleh tetap memanggil productService yang sudah async").
  async function requestComplete(po: PreOrder) {
    if (completingId) return;
    const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
    const remaining = po.remainingBalance ?? subtotal;
    if (remaining > 0) {
      setSettleMethod(po.dpMethod ?? "cash");
      setSettleTendered(remaining);
      setSettlePo(po);
      return;
    }
    // Sudah lunas via DP → lanjut Complete tanpa dialog. Seluruh subtotal
    // sudah tercakup di DP; kirim satu entry DP dengan amount = subtotal.
    const dpMethod = po.dpMethod ?? "cash";
    setCompletingId(po.id);
    try {
      await finalizeComplete(po, [{ method: dpMethod, amount: subtotal }]);
    } finally {
      setCompletingId(null);
    }
  }
  async function finalizeComplete(po: PreOrder, payment: PaymentEntry[]) {
    const shift = await shiftService.current();
    if (!shift) {
      toast.error("Buka shift dulu untuk menyelesaikan Pre Order");
      return null;
    }
    const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
    // Sprint 8: Sale.total SELALU = subtotal penuh order (bukan
    // remainingBalance, yang sudah 0 setelah payDp()). Payment breakdown
    // dipasok eksplisit oleh caller (requestComplete / confirmSettle) supaya
    // mencerminkan kapan/bagaimana uang benar-benar diterima.
    const paidSum = payment.reduce((a, e) => a + (e.amount || 0), 0);
    if (paidSum !== subtotal) {
      console.error("[preorder] finalizeComplete: payment sum mismatch", {
        preorderId: po.id,
        subtotal,
        paidSum,
        payment,
      });
      toast.error("Data pembayaran tidak konsisten — batal menyimpan");
      return null;
    }
    // Gap #5 (Packaging Fix): bawa rencana Packing asli PO (bila ada) ke
    // Sale hasil finalize, alih-alih selalu fallback ke "1 Packing gabungan
    // berisi seluruh item". PO lama (dibuat sebelum sprint ini) tidak
    // punya `po.packings` sama sekali → tetap fallback ke auto-packing di
    // sales.service.ts, PERSIS seperti perilaku sebelumnya (disengaja,
    // bukan regresi). Sanity check jumlah pcs sebagai pengaman terhadap
    // data PO yang tidak konsisten (mis. dari versi lama/migrasi) — bila
    // tidak cocok, jangan kirim `packings` sama sekali dan biarkan
    // sales.service.ts fallback ke auto-packing (lebih aman daripada
    // memotong stok box berdasarkan rencana yang sudah tidak valid).
    const poItemQty = po.items.reduce((a, i) => a + i.qty, 0);
    const poPackingQty = (po.packings ?? []).reduce((a, p) => a + p.totalQty, 0);
    const packingsForSale =
      po.packings && po.packings.length > 0 && poPackingQty === poItemQty
        ? po.packings
        : undefined;
    let sale;
    try {
      sale = await salesService.create({
        cashier: actor,
        customerName: po.customerName,
        shiftId: shift.id,
        items: po.items,
        subtotal,
        total: subtotal,
        payment,
        saleType: po.saleType ?? "frozen",
        customerType: po.sourceOrder === "reseller" ? "reseller" : "end_user",
        isPreorder: true,
        customerPhone: po.customerPhone,
        pickupAt: new Date(`${po.date}T${po.time}:00`).toISOString(),
        sourceOrder: po.sourceOrder,
        priceGroupId: po.priceGroupId,
        preorderId: po.id,
        packings: packingsForSale,
      });
    } catch (err) {
      // Complete PO gagal (ready stock / packaging kurang saat pickup) —
      // pesan spesifik dari service memuat nama item + kekurangannya. PO
      // tetap dalam status semula supaya kasir bisa perbaiki stok lalu retry.
      const msg = err instanceof Error ? err.message : "Gagal menyelesaikan Pre Order";
      console.error("[preorder] finalizeComplete failed", err);
      toast.error(
        `Complete PO gagal — stok berubah sejak PO dibuat: ${msg}`,
        { duration: IMPORTANT_TOAST_DURATION },
      );
      return null;
    }

    // Sprint 3 (Finding #3B): relink Queue yang dibuat di promoteDue() dari
    // placeholder saleId=po.id ke sale.id yang baru. Wajib dilakukan SEBELUM
    // proses Complete dianggap selesai supaya deriveStatus() & canRefund()
    // menemukan Queue yang benar. Queue tidak dibuat ulang — hanya di-update.
    if (po.queueId) {
      try {
        const relinked = await queueService.relinkSale(po.queueId, sale.id);
        if (!relinked) {
          console.warn("[preorder] complete → queue not found for relink", {
            preorderId: po.id,
            queueId: po.queueId,
            saleId: sale.id,
          });
        }
      } catch (err) {
        console.error("[preorder] complete → queue relink failed", err);
      }
    }
    preorderService.update(po.id, { status: "completed", saleId: sale.id });
    toast.success("Pre Order selesai & tercatat sebagai Sale");
    onChanged();
    return sale;
  }
  async function confirmSettle() {
    if (!settlePo) return;
    const subtotal = settlePo.items.reduce((a, i) => a + i.price * i.qty, 0);
    // Tangkap sisa pelunasan SEBELUM payDp() memutasinya jadi 0.
    const remaining = settlePo.remainingBalance ?? subtotal;
    if (settleMethod === "cash" && (settleTendered || 0) < remaining) {
      toast.error("Uang tunai kurang dari sisa pelunasan");
      return;
    }
    setSettleBusy(true);
    try {
      const dpAmount = settlePo.downPayment ?? 0;
      const dpMethod = settlePo.dpMethod ?? "cash";
      // Bangun payment breakdown dari nilai PO SEBELUM payDp() dipanggil:
      // entry DP (kalau ada) + entry pelunasan saat ini. Jumlahnya harus
      // pas dengan subtotal (divalidasi di finalizeComplete).
      const payment: PaymentEntry[] =
        dpAmount > 0
          ? [
              { method: dpMethod, amount: dpAmount },
              { method: settleMethod, amount: remaining },
            ]
          : [{ method: settleMethod, amount: subtotal }];
      // H-2 fix: buat Sale-nya (finalizeComplete → salesService.create())
      // LEBIH DULU. Hanya catat pelunasan (payDp — yang menulis
      // downPayment/remainingBalance=0 permanen + audit log
      // "preorder_dp_paid") KALAU Sale-nya sukses terbentuk. Kalau
      // finalizeComplete gagal (mis. stok berubah sejak PO dibuat),
      // payDp() sama sekali tidak dipanggil — jadi tidak ada state yang
      // perlu di-rollback: PO tetap dalam kondisi belum-lunas yang benar,
      // dan kasir bisa retry Complete setelah stok diperbaiki.
      const sale = await finalizeComplete(settlePo, payment);
      if (sale) {
        preorderService.payDp(settlePo.id, remaining, {
          actor,
          method: settleMethod,
        });
        setSettlePo(null);
      }
    } finally {
      setSettleBusy(false);
    }
  }

  void date;
  const settleRemaining = settlePo ? settlePo.remainingBalance ?? settlePo.total : 0;
  const settleDp = settlePo?.downPayment ?? 0;
  return (
    <div className="flex flex-col gap-3 px-4">
      {items.length === 0 && (
        <p className="py-10 text-center text-sm text-muted-foreground">
          Belum ada Pre Order. Buat melalui POS (Kasir).
        </p>
      )}
      {ordered.map((p) => (
        <div key={p.id} className="flex flex-col gap-2 rounded-lg border p-3 text-sm">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex h-6 min-w-[2rem] items-center justify-center rounded-md bg-primary/10 px-1.5 font-mono text-xs font-bold text-primary">
                  #{String(numberOf.get(p.id) ?? 0).padStart(3, "0")}
                </span>
                <span className="font-medium">{p.time} · {p.customerName}</span>
                {(p.downPayment ?? 0) > 0 && (
                  <Badge
                    variant="outline"
                    className="border-amber-500/30 bg-amber-500/10 text-[10px] font-semibold text-amber-700"
                  >
                    DP {formatIDR(p.downPayment ?? 0)}
                  </Badge>
                )}
              </div>
              {p.customerPhone && (
                <div className="text-xs text-muted-foreground">{p.customerPhone}</div>
              )}
            </div>
            <Badge variant="outline" className={STATUS_TONE[p.status]}>
              {PREORDER_STATUS_LABEL[p.status]}
            </Badge>
          </div>
          <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
            {p.items.map((i) => (
              <div key={i.productId} className="flex justify-between">
                <span>{i.qty}× {i.name}</span>
                <span className="tabular-nums">{formatIDR(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{SOURCE_ORDER_LABEL[p.sourceOrder]}</span>
            <span className="font-semibold tabular-nums">{formatIDR(p.total)}</span>
          </div>
          {(p.downPayment ?? 0) > 0 && (
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">Sisa Pelunasan</span>
              <span className="font-semibold tabular-nums text-amber-700">
                {formatIDR(p.remainingBalance ?? p.total)}
              </span>
            </div>
          )}
          {p.notes && <div className="text-xs italic text-muted-foreground">"{p.notes}"</div>}
          {(() => {
            const pendingCancel = pendingCancelByPo.get(p.id);
            // Bug fix (UX Sedang): sebelumnya PO lunas-via-DP (klik Selesaikan
            // = langsung proses) dan PO belum lunas (klik Selesaikan = buka
            // dialog pelunasan dulu) berbeda jumlah langkah tanpa penjelasan
            // apa pun — kasir baru bisa bingung kenapa kadang ada dialog
            // kadang enggak. Micro-copy di bawah tombol menjelaskan di muka.
            const poSubtotal = p.items.reduce((a, i) => a + i.price * i.qty, 0);
            const poRemaining = p.remainingBalance ?? poSubtotal;
            return (
              <>
                {pendingCancel && (
                  <div className="flex items-center gap-1.5 rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-1.5 text-[11px] text-amber-700">
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                    <span className="flex-1">
                      Pengajuan pembatalan {PREORDER_CANCEL_STATUS_LABEL[pendingCancel.status].toLowerCase()}
                      {(p.downPayment ?? 0) > 0 && <> · DP {formatIDR(p.downPayment ?? 0)} akan hangus</>}
                    </span>
                    {canApproveCancel && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 shrink-0 border-amber-600/40 px-2 text-[11px] text-amber-800 hover:bg-amber-500/20"
                        onClick={() => {
                          setCancelReviewNote("");
                          setCancelReviewTarget(pendingCancel);
                        }}
                      >
                        Tinjau
                      </Button>
                    )}
                  </div>
                )}
                {p.status !== "completed" && p.status !== "cancelled" && (
                  <div className="flex flex-wrap gap-1.5">
                    {p.status === "scheduled" && (
                      <Button size="sm" variant="outline" onClick={() => markReady(p.id)}>
                        <PlayCircle className="h-3.5 w-3.5" /> Siap Diproses
                      </Button>
                    )}
                    {p.status === "ready_to_process" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-muted-foreground hover:text-foreground"
                        onClick={() => undoMarkReady(p.id)}
                      >
                        <RotateCcw className="h-3.5 w-3.5" /> Urungkan
                      </Button>
                    )}
                    <Button
                      size="sm"
                      onClick={() => requestComplete(p)}
                      disabled={completingId === p.id || !!pendingCancel}
                      title={
                        poRemaining > 0
                          ? `Akan diminta pelunasan sisa ${formatIDR(poRemaining)} dulu`
                          : "Sudah lunas via DP — langsung diproses tanpa dialog pembayaran"
                      }
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {completingId === p.id ? "Memproses…" : "Selesaikan"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => cancel(p)}
                      disabled={!!pendingCancel}
                    >
                      <XCircle className="h-3.5 w-3.5" /> Batal
                    </Button>
                  </div>
                )}
                {(p.status === "cancelled" || p.status === "completed") && (
                  <Button size="sm" variant="ghost" onClick={() => setConfirmRemove(p)} className="w-fit">
                    <Trash2 className="h-3.5 w-3.5 text-destructive" /> Hapus
                  </Button>
                )}
              </>
            );
          })()}
        </div>
      ))}

      <Dialog open={!!settlePo} onOpenChange={(o) => !o && !settleBusy && setSettlePo(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pelunasan Pre Order</DialogTitle>
          </DialogHeader>
          {settlePo && (
            <div className="flex flex-col gap-4">
              <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-center">
                <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Sisa Pelunasan
                </div>
                <div className="mt-0.5 text-3xl font-bold tabular-nums text-primary">
                  {formatIDR(settleRemaining)}
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-y-1 text-sm">
                <dt className="text-muted-foreground">Total Order</dt>
                <dd className="text-right tabular-nums">{formatIDR(settlePo.total)}</dd>
                <dt className="text-muted-foreground">DP Terbayar</dt>
                <dd className="text-right tabular-nums text-emerald-600">
                  {formatIDR(settleDp)}
                </dd>
                <dt className="font-medium">Harus Dibayar</dt>
                <dd className="text-right font-semibold tabular-nums">
                  {formatIDR(settleRemaining)}
                </dd>
              </dl>
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Metode Pelunasan
                </Label>
                <div className="grid grid-cols-2 min-[380px]:grid-cols-4 gap-2">
                  {(["cash", "qris", "card", "transfer"] as PaymentMethod[]).map((m) => {
                    const active = settleMethod === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setSettleMethod(m)}
                        className={`rounded-lg border px-2 py-2 text-xs font-semibold uppercase transition ${
                          active
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border/70 bg-card text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {m}
                      </button>
                    );
                  })}
                </div>
              </div>
              {settleMethod === "cash" && (
                <div className="flex flex-col gap-2">
                  <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                    Uang Diterima
                  </Label>
                  <NumberInput
                    min={0}
                    value={settleTendered}
                    onChange={setSettleTendered}
                    className="h-11 text-lg font-bold tabular-nums"
                  />
                  <div className="flex justify-between rounded-md border px-3 py-2 text-sm">
                    <span className="text-muted-foreground">
                      {(settleTendered || 0) < settleRemaining ? "Kekurangan" : "Kembalian"}
                    </span>
                    <span className="font-semibold tabular-nums">
                      {formatIDR(Math.abs((settleTendered || 0) - settleRemaining))}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="gap-2 sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setSettlePo(null)}
              disabled={settleBusy}
            >
              Batal
            </Button>
            <Button
              onClick={confirmSettle}
              disabled={
                settleBusy ||
                (settleMethod === "cash" && (settleTendered || 0) < settleRemaining)
              }
              className="min-w-[10rem]"
            >
              {settleBusy ? "Memproses…" : `Bayar · ${formatIDR(settleRemaining)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmRemove} onOpenChange={(o) => !o && setConfirmRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pre Order?</AlertDialogTitle>
            <AlertDialogDescription>
              Pre Order "{confirmRemove?.customerName}" ({confirmRemove ? formatIDR(confirmRemove.total) : ""})
              akan dihapus permanen dari riwayat.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => confirmRemove && remove(confirmRemove.id)}>
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!cancelReqTarget} onOpenChange={(o) => !o && setCancelReqTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajukan Pembatalan Pre Order</DialogTitle>
          </DialogHeader>
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-800">
            DP <span className="font-semibold">{formatIDR(cancelReqTarget?.downPayment ?? 0)}</span> yang
            sudah dibayar customer akan <span className="font-semibold">hangus</span> bila pengajuan ini
            disetujui. Pengajuan akan ditinjau dan disetujui oleh Admin sebelum PO benar-benar dibatalkan.
          </div>
          <div className="flex flex-col gap-2">
            <Label>Alasan</Label>
            <Textarea
              value={cancelReqReason}
              onChange={(e) => setCancelReqReason(e.target.value)}
              placeholder="Contoh: Customer tidak jadi ambil pesanan"
              rows={4}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelReqTarget(null)}>
              Tutup <span className="ml-1.5 text-[10px] opacity-60">Esc</span>
            </Button>
            <Button onClick={submitCancelRequest}>
              Kirim Pengajuan <span className="ml-1.5 text-[10px] opacity-70">Ctrl+Enter</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!cancelReviewTarget} onOpenChange={(o) => !o && setCancelReviewTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Review Pengajuan Pembatalan</DialogTitle>
            <DialogDescription>
              Alasan: {cancelReviewTarget?.reason} · DP hangus:{" "}
              {formatIDR(cancelReviewTarget?.downPaymentAtRequest ?? 0)}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            <Label>Catatan (opsional)</Label>
            <Textarea
              value={cancelReviewNote}
              onChange={(e) => setCancelReviewNote(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCancelReviewTarget(null)}>
              Tutup <span className="ml-1.5 text-[10px] opacity-60">Esc</span>
            </Button>
            <Button variant="destructive" onClick={rejectCancelRequest}>
              <XCircle className="mr-1 h-4 w-4" /> Tolak
              <span className="ml-1.5 text-[10px] opacity-70">Ctrl+⌫</span>
            </Button>
            <Button onClick={approveCancelRequest}>
              <CheckCircle2 className="mr-1 h-4 w-4" /> Setujui Pembatalan
              <span className="ml-1.5 text-[10px] opacity-70">Ctrl+Enter</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
