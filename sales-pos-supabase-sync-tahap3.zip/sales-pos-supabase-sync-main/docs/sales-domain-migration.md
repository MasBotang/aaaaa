# Sales Domain Migration (localStorage → Supabase)

Dokumen ini melacak migrasi service Sales/POS dari `localStorage` ke
Supabase. Format & konvensinya sama seperti `docs/reference-data-migration.md`
(tahap sebelumnya untuk Product, Inventory, Recipe, Price Group, Settings).
Setiap section berisi: tabel yang dipakai, alasan bila perlu SQL tambahan,
daftar file yang diubah, dan checklist acceptance test.

Rencana tahap:

1. **Shift** — selesai (dokumen ini)
2. Sales
3. Order Queue
4. Pre Order
5. Refund

Yang **belum** dimigrasikan (masih localStorage) dan sengaja tidak disentuh
di tahap 1:

- `salesService`, `queueService`, `preorderService`, `refundService`
- `auditService`, `holdService`, `marketplaceSettlementService`
- `salesSummaryService` (agregasi turunan)

---

## 1. Shift

### Tabel Supabase

`public.shifts` — didefinisikan di
`supabase/migrations/20260717080000_sales_pos_init.sql`. Tidak ada schema
tambahan yang dibutuhkan; kolom yang dipakai kode sudah cocok 1-1 dengan
domain `Shift`:

| Kolom DB                          | Domain                            | Catatan |
| --------------------------------- | --------------------------------- | ------- |
| `id uuid PK`                      | `Shift.id`                        | `crypto.randomUUID()` |
| `cashier text NOT NULL`           | `Shift.cashier`                   | Nama aktor (bukan FK, konsisten dengan pola "Identitas Aktor" di schema-mapping.md) |
| `opened_at timestamptz NOT NULL`  | `Shift.openedAt`                  | |
| `closed_at timestamptz NULL`      | `Shift.closedAt`                  | `NULL` = shift aktif |
| `opening_cash numeric`            | `Shift.openingCash`               | |
| `closing_cash / expected_cash / cash_difference_reason` | closing snapshot | |
| `total_orders / total_revenue / cash_sales / qris_sales / transfer_sales / marketplace_sales` | closing summary | Diisi saat `close()` |
| `operational_expenses jsonb`      | `Shift.operationalExpenses[]`     | 1 unit per shift (tidak dinormalisasi) |
| `total_operational_expense numeric` | derived                         | Direcalc di service tiap mutasi |
| `packaging_usage jsonb`           | `Shift.packagingUsage[]`          | Idem |
| `total_packaging_qty numeric`     | derived                           | |
| `packaging_usage_saved_at / packaging_usage_saved_by` | metadata packaging | |
| `marketplace_reconciliations jsonb` | `Shift.marketplaceReconciliations[]` | |
| `payment_reconciliations jsonb`   | `Shift.paymentReconciliations[]`  | |

**Kolom JSONB (`operational_expenses`, `packaging_usage`,
`marketplace_reconciliations`, `payment_reconciliations`) dibaca dan
ditulis sebagai satu unit per shift.** Ini keputusan sadar (lihat komentar
di migration SQL): jumlah entri per shift kecil, kebutuhan query per-entri
tidak ada, dan menormalisasi jadi tabel terpisah malah menambah round-trip
tanpa manfaat query.

### Kenapa TIDAK perlu SQL tambahan

- Schema sudah lengkap — tidak ada field domain yang tidak punya kolom.
- `shifts_only_one_open_idx` (unique partial index
  `ON shifts (true) WHERE closed_at IS NULL`) sudah ada di migration awal
  dan menjamin invariant "cuma 1 shift aktif" di level DB. Percobaan
  `open()` kedua ditolak dengan Postgres error `23505` (unique_violation);
  `shiftService.open()` menerjemahkannya jadi hasil
  `{ ok: false, reason: "Shift lain masih aktif atas nama <cashier>" }`.
- RLS policy `shifts` di migration awal: `USING (true) WITH CHECK (true)`
  untuk role `authenticated` — semua kasir/admin/owner yang sudah login
  dapat SELECT/INSERT/UPDATE/DELETE. Enforcement per-role tetap dilakukan
  di UI (mis. tombol edit/hapus disembunyikan untuk kasir jika shift
  sudah ditutup) DAN di service (`assertCanMutateShift` yang sengaja
  dipertahankan sinkron karena murni memeriksa objek Shift yang sudah
  di-fetch).

### File yang diubah

- **`src/services/shift.service.ts`** — ditulis ulang jadi async/Supabase.
  API tetap: `list()`, `current()`, `get(id)`, `open()`, `close()`,
  `addOperationalExpense()`, `updateOperationalExpense()`,
  `deleteOperationalExpense()`, `savePackagingUsage()`. `isShiftLocked()`,
  `canMutateShift()`, `assertCanMutateShift()` tetap **sinkron** — mereka
  hanya membaca properti objek Shift yang sudah di-fetch, dipakai di JSX
  yang tidak boleh async.
- **`src/features/sales/shifts-page.tsx`** — dikonversi ke react-query
  (`useQuery(["shifts"])` sebagai satu-satunya sumber; `current` diturunkan
  dari `shifts.find(s => !s.closedAt)`). `openShift()`/`doCloseShift()`
  jadi async dengan try/catch — error diterjemahkan ke toast. `refresh()`
  sekarang jadi `qc.invalidateQueries({ queryKey: ["shifts"] })`.
- **`src/features/analytics/sales/operational-data.ts`** —
  `shiftPerformance`, `packagingAnalytics`, `opexAnalytics`, `kpiPanel`,
  `computeOperationalAnalytics` menerima `shifts: Shift[]` sebagai
  parameter (sebelumnya panggil `shiftService.list()` sinkron). Ini pola
  yang sama seperti `computeSalesAnalytics(products)` di migrasi
  Reference Data — komputasi tetap murni sinkron, fetch dilakukan di layer
  page/component.
- **`src/features/analytics/sales/sales-analytics-page.tsx`** — fetch
  shifts via `useQuery(["shifts"])` dan meneruskannya ke
  `computeOperationalAnalytics`.
- **`src/features/sales/home-page.tsx`** — shift dibaca via
  `useQuery(["shifts", "current"])`, di-`refetch()` saat `useSalesRefresh`
  tick.
- **`src/features/pos/pos-page.tsx`** — `openPayment()` dan `complete()`
  jadi async; `sync()` di mount handler membungkus panggilan async
  dengan `.then()`.
- **`src/features/sales/preorder-page.tsx`** — `finalizeComplete()`
  await `shiftService.current()`.
- **`src/lib/supabase-client.ts`** — ekspor client dengan tipe longgar
  (`SupabaseClient<any, any, any>`) karena `src/integrations/supabase/
  types.ts` (auto-generate) belum berisi definisi tabel aplikasi. Tipe
  domain tetap dienforce di service layer (interface `ShiftRow` +
  mapper `fromRow`).

### Utang teknis yang tersisa

- `savePackagingUsage()` masih memanggil `salesService.list()` sinkron
  (localStorage) untuk menghitung baseline packaging saat penyimpanan
  pertama. Akan diperbaiki di **Tahap 2 (Sales)** — baseline harus
  di-`await` dari Supabase setelah `salesService` pindah.
- `auditService.log()` masih localStorage — bukan bagian scope 5 tahap
  Sales/POS; akan dipindahkan terpisah.

### Acceptance test checklist

Test manual dengan role Admin dulu (semua permission), lalu ulang dengan
role Kasir dan Owner untuk memastikan RLS/permission UI berfungsi.

- [ ] **Buka shift**: login sebagai kasir → `/sales/shifts` → input kas
  pembuka → "Buka Shift" → toast "Shift dibuka", panel shift aktif tampil.
- [ ] **Coba buka shift kedua** (invariant `shifts_only_one_open_idx`):
  buka tab baru, login kasir kedua → `/sales/shifts` → coba "Buka Shift"
  → toast error **spesifik** ("Shift lain masih aktif atas nama <nama
  kasir pertama>"), bukan "database error" generic; opening cash kasir
  kedua **tidak** tercatat.
- [ ] **Tambah operational expense**: pada shift aktif → dialog "Tambah
  Pengeluaran" → pilih item operasional, qty, harga → simpan → entri
  muncul di panel, total operational bertambah, stok inventory item
  berkurang (`stock_movements` bertambah 1 baris tipe `operational_usage`).
- [ ] **Edit operational expense**: klik entri yang ada → ubah qty/harga
  → simpan → total operational terupdate, stok inventory ter-reverse
  lalu deduct ulang (`stock_movements` bertambah 2 baris — reverse +
  adjustment baru).
- [ ] **Hapus operational expense**: hapus entri → stok inventory
  dikembalikan (`stock_movements` bertambah 1 baris `adjustment` +).
- [ ] **Simpan packaging usage**: input qty per packaging item → simpan
  → total packaging terupdate, `packaging_usage_saved_at`/`_by` terisi,
  stok packaging berkurang sesuai delta terhadap baseline (agregasi dari
  sales checkout shift ini).
- [ ] **Ubah packaging usage**: ubah qty → simpan lagi → delta terhadap
  data tersimpan sebelumnya diaplikasikan ke stok (tidak double-deduct).
- [ ] **Shortage guard**: coba simpan packaging usage dengan qty melebihi
  stok → error jelas "Stok packaging tidak mencukupi: <nama> (tersedia X,
  butuh Y)"; tidak ada mutasi stok terjadi.
- [ ] **Tutup shift**: input actual cash, alasan jika beda dari expected
  → "Tutup Shift" → toast "Shift ditutup", `closed_at` terisi di DB,
  shift pindah ke daftar riwayat.
- [ ] **Shift lock (kasir)**: setelah shift ditutup, login sebagai kasir
  → tombol edit/hapus operational expense **tidak tersedia** di UI;
  panggilan langsung `shiftService.updateOperationalExpense()` dari
  konsol menolak dengan error "Shift sudah ditutup — hanya Admin/Owner
  yang dapat mengubah data shift ini."
- [ ] **Shift unlock (admin/owner)**: login sebagai admin → edit/hapus
  operational expense pada shift yang sudah ditutup **berhasil**.
- [ ] **POS integration**: shift belum dibuka → POS menolak checkout
  ("Buka shift terlebih dahulu sebelum transaksi"); setelah shift dibuka
  di tab lain, POS mendeteksi shift aktif saat focus/blur tanpa reload.
- [ ] **Sales Analytics**: buka `/analytics/sales` — panel Operational
  (shift performance, packaging, opex, KPI) menampilkan data yang sama
  seperti sebelum migrasi.
- [ ] **Grep sinkron**: `grep -rn "shiftService\." src` — pastikan
  semua pemanggilan di luar `src/services/shift.service.ts` sudah
  `await`, `useQuery`, atau di dalam handler async lainnya (tidak ada
  `!shiftService.current()` bertelanjang atau `shiftService.list().filter(...)`).

---

## 2. Sales / POS

### Tabel Supabase

`public.sales` & `public.hold_orders` — sudah didefinisikan di
`supabase/migrations/20260717080000_sales_pos_init.sql`. Tidak ada migration
tambahan yang dibuat di tahap ini; semua kolom yang dipakai kode sudah
ada 1-1. RPC atomik `next_daily_counter` yang ada di komentar init
migration TIDAK dibuat di tahap ini karena tooling migration belum
tersedia untuk agent — nomor invoice & nomor antrean sementara
diturunkan dari `MAX(legacy_id)`/`MAX(order_number)` hari ini + retry
pada `unique_violation` (lihat "Keputusan Transaksi Checkout" di
bawah). RPC atomik akan disusulkan di prompt berikutnya jika perlu.

Kolom penting `sales`:

| Kolom DB                             | Domain                                  | Catatan |
| ------------------------------------ | --------------------------------------- | ------- |
| `id uuid PK`                         | (internal DB id)                        | `crypto.randomUUID()` |
| `legacy_id text UNIQUE`              | `Sale.id` (`INV-YYYYMMDD-NNNN`)         | ID yang dilihat kasir & tampil di receipt |
| `shift_id uuid FK -> shifts(id)`     | `Sale.shiftId`                          | Wajib terisi; checkout tanpa shift ditolak `create()` |
| `items/payment/packings/plastic/extra_packaging jsonb` | dst.                | Array-per-row, tidak dinormalisasi (sama pola dengan Shift) |
| `voided bool + void_reason/voided_by/voided_at` | soft-void                    | `delete()` fisik tidak dipakai UI |
| `order_number text`                  | `Sale.orderNumber` (`#NNN`)             | Bukan PK; collision toleran, sekadar display |

`hold_orders` mengikuti bentuk `HoldOrder` di `src/services/types.ts` —
`items` JSONB (SaleItem[]).

### Yang berubah

- **Baru**: `src/hooks/use-sales-data.ts` — hook `useSalesData()` yang
  memanggil `useQuery(["sales","list"], salesService.list)` DAN ikut
  `useSalesRefresh()` supaya cache in-memory `salesService.listCached()`
  selalu segar. Halaman yang mengonsumsi compute pipeline sinkron
  (`sales-summary`, `finance-analytics`, `finance-aggregation`,
  `production-planning`, `analytics/sales/*`, `analytics/finance/*`,
  `shift.savePackagingUsage` baseline, `pesanan-page`) memasang hook ini
  di komponen root-nya.
- **Rewrite**: `src/services/sales.service.ts` — `list()` / `create()` /
  `void()` / `byDateRange()` / `canRefund()` sekarang async terhadap
  Supabase. `listCached()` sinkron menjadi permukaan untuk pipeline lama
  (populated by `list()`/`create()`/`void()`). Setiap mutasi memancarkan
  `desalut:storage-write` dengan key `sales` supaya `useSalesRefresh`
  ikut re-tick — pola sama dengan Tahap 1.
- **Rewrite**: `src/services/hold.service.ts` — async terhadap tabel
  `hold_orders`. POS memakai `useQuery(["hold-orders"])` + `invalidateHolds()`.
- **Patch**: `src/features/pos/pos-page.tsx` — checkout memanggil
  `salesService.create()` (sudah async), hold/resume/drop pakai
  `useQuery` + `invalidateHolds()`. Semua toast/reset state dipertahankan
  identik.
- **Patch**: `src/services/refund.service.ts` — `canRefund` sekarang async;
  `approve()` yang sudah async ikut `await`.
- **Patch**: `src/services/audit.service.ts` — action baru
  `sales_rollback_partial_failure` untuk mencatat kegagalan rollback
  parsial saat deduct stock gagal setelah insert Sale.
- **Sed replace**: `salesService.list()` → `salesService.listCached()`
  di `finance-analytics.service`, `finance-aggregation`,
  `sales-summary.service`, `production-planning.service`, `shift.service`
  (`savePackagingUsage` baseline), `pesanan-page`, `analytics/sales/data`,
  `analytics/sales/operational-data`, dan `finance-projection.service` /
  `shifts-page` yang punya panggilan multi-line.

### Keputusan Transaksi Checkout

1. Validasi ready stock + packaging (fail-fast, sama seperti versi
   localStorage).
2. Ambil nomor invoice via `MAX(legacy_id)` hari ini + 1, order_number
   via `MAX(order_number)` hari ini + 1. Belum atomik — retry hingga 5x
   pada collision `legacy_id` (23505).
3. Insert baris `sales`.
4. Loop `productService.deduct()` (RPC atomik dari Tahap Reference).
   Kegagalan di tengah loop → rollback manual: `addStock()` balik untuk
   item yang sudah terpotong + `DELETE` baris sales, lalu throw ulang.
   Kegagalan sub-step rollback dicatat via audit
   `sales_rollback_partial_failure` untuk rekonsiliasi manual.
5. Setelah deduct sukses: catat stock movement packaging + audit +
   insert queue. Kegagalan di sini TIDAK membatalkan Sale (behavior
   existing dipertahankan, tercatat sebagai audit anomaly).

Kenapa bukan satu RPC monolit `checkout_sale()`? Supaya tetap memakai
`productService.deduct` / `addStock` yang sudah audit-friendly (Sprint 1
H-4) dan tidak perlu menduplikasi rule audit di SQL. Kelemahannya:
rollback manual bisa gagal parsial — mitigasi via audit event.

### Yang belum dimigrasikan (masih localStorage)

Sengaja tidak disentuh di tahap ini, konsisten dengan scope Prompt 2:

- `auditService`, `queueService`, `preorderService`, `refundService`,
  `preorderCancelService`, `marketplaceSettlementService`
- `salesTargetService`, `settingsService` (target harian, packaging rule),
  `stockMovementService` / `inventoryService` sudah pindah di tahap
  Reference — mereka konsumen, bukan target migrasi Sales.

### Acceptance test

- [ ] **Checkout normal**: buka shift → tambah item ke cart → Bayar →
  toast "Transaksi berhasil"; row baru di `public.sales` dengan
  `legacy_id INV-...`, `order_number #...`, `voided=false`; stok produk
  berkurang; stok packaging (box + plastik + extras) berkurang.
- [ ] **Checkout tanpa shift**: tutup semua shift → coba Bayar dari POS
  → toast "Buka shift terlebih dahulu"; tidak ada row baru di `sales`.
- [ ] **Checkout dengan stok kurang**: kurangi stok produk manual via
  Reference sampai < qty cart → Bayar → toast "Ready stock tidak
  mencukupi: ..." atau "Stok packaging tidak mencukupi: ..."; **row
  `sales` tidak dibuat**, stok produk tidak berkurang, cart tetap ada.
- [ ] **Rollback deduct** (simulasi race): dua tab buka shift sama,
  kedua-duanya menambahkan produk X qty > stock/2 ke cart → Bayar
  bersamaan. Salah satu Bayar gagal dengan pesan "Ready stock ..."
  ATAU "Rollback checkout tidak sempurna" (kalau race sampai ke deduct);
  bila terjadi rollback: audit log berisi entry
  `sales_rollback_partial_failure`, dan baris sales yang gagal sudah
  ter-hapus.
- [ ] **Void sale**: dari Pesanan, klik Refund pada Sale → approve →
  `voided=true`, stok produk balik, entri queue hilang, stok packaging
  balik (movement `restock`); audit log `sale_voided` tercatat.
- [ ] **Hold + Resume**: cart isi → "Tahan Pesanan" → row baru di
  `hold_orders`; klik hold di sidebar → cart terisi ulang; checkout → hold
  terhapus dari `hold_orders`.
- [ ] **Hold + Drop**: hold pesanan → klik ikon hapus → row hilang dari
  `hold_orders`, sidebar update.
- [ ] **RLS cashier**: login sebagai cashier → checkout & void berjalan.
- [ ] **RLS non-cashier** (owner/production): DB menolak INSERT ke
  `sales` (bukan dari UI karena tombol tidak tampil, tapi coba lewat
  console) dengan error RLS.
- [ ] **Grep sinkron**: `grep -rn "salesService\.\(list\|byDateRange\|
  canRefund\|create\|void\)\b" src` — hanya menunjukkan `.list()` di
  hook `useSalesData`, `.create()` di POS/preorder, `.canRefund()` &
  `.void()` di refund.service, semuanya awaited/di useQuery. Tidak ada
  panggilan sinkron `.list().filter()` yang tersisa (yang lain sudah
  `.listCached()`).

---

## 3. Order Queue

### Tabel Supabase

`public.order_queue` — sudah didefinisikan di
`supabase/migrations/20260717080000_sales_pos_init.sql`. Schema kolom
sudah cocok 1-1 dengan domain `QueueOrder`; **tidak ada perubahan
struktur** yang dibuat di tahap ini. Kolom penting:

| Kolom DB                          | Domain                          | Catatan |
| --------------------------------- | ------------------------------- | ------- |
| `id uuid PK`                      | `QueueOrder.id`                 | `crypto.randomUUID()` di client — supaya `create()` bisa mengembalikan id sync (lihat "Keputusan Sync create" di bawah). |
| `sale_id uuid NOT NULL`           | `QueueOrder.saleId`             | **TIDAK ada FK** ke `sales.id`. Sengaja — `preorder.service.promoteDue()` menulis `preorder.id` ke kolom ini sebagai PLACEHOLDER hingga PO di-Complete, baru di-relink via `relinkSale()`. Layer aplikasi juga tidak boleh mem-validasi kolom ini sebagai FK. |
| `sale_code text NOT NULL`         | `QueueOrder.saleCode`           | Kode display (mengikuti `sale.id` legacy). |
| `status text CHECK (...)`         | `QueueOrder.status`             | `waiting|cooking|packing|ready|completed` — sama dgn versi lama. |
| `sale_type text CHECK (...)`      | `QueueOrder.saleType`           | `frozen|matang` — dipakai `nextStatus()` untuk tentukan transisi. |
| `timeline jsonb`                  | `QueueOrder.timeline`           | `{status, at, by}[]`. Append satu unit per baris tiap perubahan status. Sama pola dgn kolom JSONB di `sales`/`shifts`. |
| `last_actor text`                 | `QueueOrder.lastActor`          | Kasir/production yg terakhir memajukan status. |
| `preorder_id uuid FK -> preorders(id)` | `QueueOrder.preorderId`    | FK ke `preorders` (bukan `sales`) — aman karena PO selalu ada dulu sebelum queue placeholder. |
| `packings jsonb`                  | `QueueOrder.packings`           | `SalePacking[]` untuk display split-packing di antrean. |

### Migration SQL tambahan

**`supabase/migrations/20260720000000_order_queue_cashier_delete.sql`**
— additive (bukan alter struktur). Menambahkan policy DELETE untuk
`cashier` pada `order_queue`:

```sql
create policy order_queue_delete_cashier on public.order_queue
  for delete to authenticated
  using (public.current_role() in ('admin','cashier'));
```

Alasannya: `salesService.void()` (tahap 2) memanggil
`queueService.removeBySale()` sebagai bagian dari rollback refund. Bila
kasir yang men-trigger void, DELETE ke `order_queue` gagal RLS pada
policy generic (`order_queue_delete_admin_only` — admin-only) dan Sale
jadi voided tapi antrean produksi tetap muncul. Policy baru bersifat
permissive (additive) — admin/owner/production tidak terpengaruh.

### File yang diubah

- **`src/services/queue.service.ts`** — ditulis ulang, back-end pindah
  ke Supabase.
  - Async: `list()`, `active()`, `bySale()`, `advance()`, `setStatus()`,
    `removeBySale()`, `relinkSale()`.
  - **Sync (sengaja dipertahankan)**: `create()`, `nextStatus()`,
    `listCached()`. `create()` men-generate `id` di client dan
    mengirim INSERT ke Supabase fire-and-forget (`void (async ...)`) —
    lihat "Keputusan Sync create" di bawah. `nextStatus()` murni fungsi
    transisi state, tidak perlu I/O. `listCached()` = permukaan sync
    untuk compute pipeline lama.
  - Mutasi memancarkan `desalut:storage-write` dengan key
    `StorageKeys.orderQueue` supaya `useSalesRefresh` re-tick (event
    lama `desalut:queue-changed` juga tetap dipancarkan untuk backward
    compat listener yang belum diporting).
- **Baru: `src/hooks/use-queue-data.ts`** — hook `useQueueData()`,
  `useQuery(["order-queue","list"], queueService.list)` + ikut
  `useSalesRefresh()`. Halaman yang mengiterasi `queueService.listCached()`
  dari compute sync (`sales-summary`, `pesanan-page`) memasang hook ini
  supaya cache in-memory selalu segar. Pola identik dengan
  `useSalesData` (tahap 2).
- **`src/features/sales/pesanan-page.tsx`** — memasang `useQueueData()`,
  membaca dari `queueService.listCached()`, `advanceQueue()` jadi async
  dengan try/catch → toast error. Semua path lain (auto-select, filter,
  WA link, refund UI) tidak berubah.
- **`src/features/sales/home-page.tsx`** &
  **`src/features/sales/shifts-page.tsx`** — memasang `useQueueData()`
  supaya `salesSummaryService.today()` / `.forShift()` (yang membaca
  `queueService.listCached()`) mendapatkan data queue yang sudah primed.
- **`src/features/sales/preorder-page.tsx`** — `finalizeComplete()`
  meng-`await queueService.relinkSale(...)` (sebelumnya sinkron, hasilnya
  Promise yang selalu truthy → cek `!relinked` selalu false).
- **`src/services/sales.service.ts`** — `void()` meng-`await
  queueService.removeBySale(...)` di jalur rollback refund.
- **`src/services/sales-summary.service.ts`** — `queueService.list()` di
  compute today() → `queueService.listCached()` (compute tetap sync).

### Keputusan Sync `create()`

Kandidat awal: ubah `create()` menjadi async seperti fungsi lain. Ditolak
karena:

1. `preorder.service.promoteDue()` (out-of-scope, migrasi ke Supabase
   di prompt 4) memanggil `queueService.create({...})` dari kode sync
   dan menyimpan `q.id` ke `preorder.queueId`. Konversi async akan
   membuat `q` jadi Promise dan `q.id` `undefined` — merusak alur
   promote yang belum sempat direfactor.
2. `sales.service.create()` (tahap 2) memanggil ini di dalam
   try/catch tanpa `await` (fire-and-forget) — sudah oke tanpa
   perubahan.

Implementasi: `id` di-generate `crypto.randomUUID()`, `create()`
mengembalikan `QueueOrder` sync, INSERT ke Supabase dijalankan lewat
`void (async () => ...)`. Kegagalan insert di-log ke console + row
di-rollback dari cache in-memory + emit event supaya UI ikut re-fetch.
Trade-off yang dicatat: window kecil di mana row muncul di cache tapi
belum di DB (< 1 network round-trip).

### RLS

Efektif setelah migration additive:

| Aksi        | Role yang diizinkan                        | Sumber                                       |
| ----------- | ------------------------------------------ | -------------------------------------------- |
| SELECT      | authenticated (semua role)                 | init migration §Section 7 generic read       |
| INSERT      | admin, cashier                             | init migration §Sales/POS block              |
| UPDATE      | admin, cashier, production                 | init block + `order_queue_write_production_upd` |
| DELETE      | admin, cashier                             | init `_delete_admin_only` + `order_queue_delete_cashier` |

Catatan: prompt menyebut "hanya production yang bisa advance status".
Policy aktual lebih permisif (admin, cashier, production semua bisa
UPDATE). Enforcement per-tombol tetap dilakukan di UI via
`permissions.ts` matrix — RLS di sini adalah lapisan pertahanan kedua.

### Utang teknis yang tersisa

- `src/services/preorder.service.ts` (`cancel`, `undoMarkReady`,
  `promoteDue`) masih memanggil `queueService.removeBySale()` /
  `queueService.create()` dari kode sync — dua yang pertama sekarang
  return Promise yang tidak di-await (floating). Sengaja tidak
  disentuh — migrasi penuh preorder.service ada di **prompt 4**.
  Selama itu tetap berfungsi karena removeBySale idempoten dan
  create() sync signature dipertahankan.
- Test relink penuh (PO scheduled → auto-promote → complete → sale
  asli terhubung) akan dilakukan di prompt 4 setelah preorderService
  juga pindah ke Supabase.

### Acceptance test checklist

Test manual dengan role Admin dulu, ulang dengan Kasir dan Production.

- [ ] **Checkout POS langsung muncul di queue**: buka shift → cart isi
  → Bayar → `/sales/pesanan` di tab lain langsung memunculkan entri
  baru (status "Menunggu") tanpa reload — event `desalut:storage-write`
  memicu `useSalesRefresh` → `useQueueData` invalidate.
- [ ] **Advance status Frozen** (kasir): klik ▶ pada pesanan frozen →
  status `waiting → packing → ready → completed`. Setiap klik: toast
  transisi, `updated_at` DB berubah, `timeline` bertambah 1 entri
  `{status,at,by}` dengan `by = actor`, `last_actor` terupdate, audit
  log `queue_status_change` bertambah.
- [ ] **Advance status Matang** (kasir/production): pesanan matang →
  `waiting → cooking → packing → ready → completed` (satu langkah
  lebih panjang).
- [ ] **Nomor transisi ditolak DB tidak diblokir client**: sebelum
  klik, `nextStatus()` tetap dipakai untuk menentukan langkah — tidak
  ada cara UI untuk melompat/mundur status.
- [ ] **`setStatus()` invalid transition**: dari console, panggil
  `queueService.setStatus(id, 'completed', actor)` pada entri
  `waiting` → hasil `{ok:false, reason:"Transisi status tidak valid:
  waiting → completed"}`; tidak ada UPDATE di DB.
- [ ] **RLS production advance**: login sebagai production → advance
  status berhasil (policy `order_queue_write_production_upd`).
- [ ] **RLS owner tidak bisa advance**: login sebagai owner (UI tidak
  menampilkan tombol) → panggilan langsung dari console dengan
  `queueService.advance(id, ...)` → error RLS (owner tidak masuk
  role admin/cashier/production).
- [ ] **RLS cashier bisa DELETE (via void)**: login sebagai kasir →
  refund pesanan sendiri via `/sales/pesanan` → toast sukses, baris
  `order_queue` untuk `sale.id` tersebut hilang (policy
  `order_queue_delete_cashier`). Sebelum migration 20260720000000 ini
  akan gagal RLS.
- [ ] **RLS owner/production tidak bisa DELETE**: login sebagai
  production → panggil `queueService.removeBySale(id)` dari console →
  error RLS (bukan admin/cashier).
- [ ] **Placeholder saleId (preorder) tidak dicegah aplikasi**:
  panggil dari console
  `queueService.create({saleId: '<uuid preorder>', saleCode: 'PO-...', ...})`
  → insert sukses, baris muncul di list dengan `sale_id` = uuid PO
  meskipun `sales` belum punya baris tersebut. `order_queue.sale_id`
  DB tidak punya FK → aplikasi juga tidak melempar validasi.
- [ ] **`relinkSale()` mengubah `sale_id` tanpa menyentuh field
  lain**: panggil `queueService.relinkSale(queueId, newSaleId)` pada
  entri hasil poin sebelumnya → `sale_id` berubah, `status`/`timeline`
  tetap. Idempoten — panggil lagi dengan `newSaleId` yang sama
  mengembalikan row apa adanya. **Uji penuh (PO scheduled →
  auto-promote → complete → sale asli) akan dilakukan di prompt 4
  setelah `preorderService` juga di Supabase.**
- [ ] **`removeBySale()` idempoten**: panggil dua kali berturut-turut
  → panggilan pertama `true`, kedua `false`, tidak error.
- [ ] **Cross-tab refresh**: dua tab buka `/sales/pesanan`. Tab A
  advance status → tab B ikut update dalam ≤ 1 detik (native `storage`
  event + `useSalesRefresh`).
- [ ] **Grep sinkron**:
  `grep -rn "queueService\." src --include="*.ts" --include="*.tsx"`.
  Yang legal:
  - `queueService.listCached()` (pesanan-page, sales-summary)
  - `queueService.list()` di `use-queue-data.ts` (di dalam useQuery)
  - `queueService.advance()` / `.relinkSale()` / `.removeBySale()`
    yang di-`await`
  - `queueService.create({...})` (sync signature — sengaja) di
    `sales.service.ts` (di dalam async, try/catch) dan
    `preorder.service.ts` (out-of-scope, dibetulkan penuh di prompt 4)
  - `preorder.service.ts` `removeBySale()` **tanpa await** (floating
    promise) — sengaja tidak disentuh, dituntaskan di prompt 4.

