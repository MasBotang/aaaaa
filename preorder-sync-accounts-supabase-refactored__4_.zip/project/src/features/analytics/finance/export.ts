/**
 * Export helper Finance Analytics — memakai canonical downloadCSV /
 * downloadXLSX dari finance-report.service. Tidak menghitung ulang apapun.
 */
import { downloadCSV, downloadXLSX } from "@/services/finance-report.service";
import type { FinanceAnalyticsData } from "./data";

function slugPeriod(label: string): string {
  return label.replace(/[^0-9a-zA-Z]+/g, "-").toLowerCase();
}

function buildSheets(data: FinanceAnalyticsData) {
  const { kpi, daily, expense, budget, debt, fund, cash, ratios, projection, monthlyCompare } = data;
  return [
    {
      name: "KPI",
      rows: [
        { Metric: "Revenue", Value: kpi.revenue },
        { Metric: "Gross Profit", Value: kpi.grossProfit },
        { Metric: "Net Profit", Value: kpi.netProfit },
        { Metric: "Total Expense", Value: kpi.expenses },
        { Metric: "Cash Position", Value: kpi.cashPosition },
        { Metric: "Debt Outstanding", Value: kpi.debtOutstanding },
        { Metric: "Budget Usage", Value: kpi.budgetUsage },
        { Metric: "Runway Days", Value: kpi.runwayDays ?? "" },
      ],
    },
    {
      name: "Daily",
      rows: daily.map((d) => ({
        Tanggal: d.date,
        Revenue: d.revenue,
        Expense: d.expense,
        Profit: d.profit,
        "Cash In": d.cashIn,
        "Cash Out": d.cashOut,
        "Net Cash": d.netCash,
        "Running Balance": d.running,
      })),
    },
    {
      name: "ExpenseByCategory",
      rows: expense.byCategory.map((e) => ({
        Kategori: e.label,
        Nominal: e.amount,
        Share: e.share,
      })),
    },
    {
      name: "ExpenseByPot",
      rows: expense.byPot.map((e) => ({
        Pot: e.label,
        Nominal: e.amount,
        Share: e.share,
      })),
    },
    {
      name: "TopExpense",
      rows: expense.top.map((e, i) => ({
        Rank: i + 1,
        Tanggal: e.at,
        Deskripsi: e.description,
        Kategori: e.category,
        Pot: e.pot,
        Nominal: e.amount,
      })),
    },
    {
      name: "Budget",
      rows: budget.rows.map((b) => ({
        Kategori: b.label,
        Budget: b.budget,
        Realisasi: b.actual,
        Sisa: b.remaining,
        Persen: b.percent,
        Status: b.status,
      })),
    },
    {
      name: "Debt",
      rows: debt.rows.map((d) => ({
        Nama: d.name,
        Principal: d.principal,
        Terbayar: d.paid,
        Sisa: d.remaining,
        Progress: d.progress,
        Aktif: d.active ? "Ya" : "Tidak",
        JatuhTempo: d.targetDate ?? "",
        HariKeJatuhTempo: d.daysToDue ?? "",
      })),
    },
    {
      name: "Fund",
      rows: fund.map((f) => ({
        Pot: f.label,
        Saldo: f.balance,
        Alokasi: f.allocationPct,
        "Withdraw Total": f.withdrawnTotal,
        "Withdraw Periode": f.withdrawnPeriod,
        "Share Outflow": f.shareOfOutflow,
      })),
    },
    {
      name: "Cash",
      rows: cash.channels.map((c) => ({
        Channel: c.label,
        Saldo: c.balance,
        Share: c.share,
      })),
    },
    {
      name: "Ratios",
      rows: [
        { Metric: "Gross Margin", Value: ratios.grossMargin },
        { Metric: "Net Margin", Value: ratios.netMargin },
        { Metric: "Expense Ratio", Value: ratios.expenseRatio },
        { Metric: "Operating Ratio", Value: ratios.operatingRatio },
        { Metric: "Debt Ratio", Value: ratios.debtRatio },
      ],
    },
    {
      name: "Projection",
      rows: projection.horizons.map((h) => ({
        Horizon: `${h.horizonDays}d`,
        "Projected Revenue": h.projectedRevenue,
        "Projected Outflow": h.projectedOutflow,
        "Projected Gross Profit": h.projectedGrossProfit,
        "Projected Cash": h.projectedCashBalance,
        Runway: h.runwayDays ?? "",
      })),
    },
    {
      name: "MonthlyCompare",
      rows: monthlyCompare.map((m) => ({
        Metric: m.metric,
        Bulan_Ini: m.current,
        Bulan_Lalu: m.previous,
        Delta: m.delta ?? "",
      })),
    },
  ];
}

export function exportFinanceAnalyticsXLSX(data: FinanceAnalyticsData) {
  downloadXLSX(buildSheets(data), `finance-analytics-${slugPeriod(data.period.label)}.xlsx`);
}

export function exportFinanceAnalyticsCSV(data: FinanceAnalyticsData) {
  const sheets = buildSheets(data);
  for (const s of sheets) {
    downloadCSV(s.rows, `finance-analytics-${slugPeriod(data.period.label)}-${s.name}.csv`);
  }
}
