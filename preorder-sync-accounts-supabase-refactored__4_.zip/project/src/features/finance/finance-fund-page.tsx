import { useMemo, useState } from "react";
import { Landmark, PiggyBank, Plus, Sparkles, Trash2, Wrench } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { financeAnalytics, financeFundWithdraws } from "@/services/finance.service";
import {
  FINANCE_PAYMENT_LABEL,
  FUND_POT_LABEL,
  type FinancePayment,
  type FundPot,
} from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import { FinanceEmptyState, FinanceKpiCard, FinancePageHeader } from "./_shared";
import { useSalesData } from "@/hooks/use-sales-data";

const PAYMENTS = Object.keys(FINANCE_PAYMENT_LABEL) as FinancePayment[];

const POT_ICON: Record<FundPot, typeof PiggyBank> = {
  owner: PiggyBank,
  development: Sparkles,
  operational: Wrench,
  debt: Landmark,
};

export function FinanceFundPage({ pot }: { pot: FundPot }) {
  useSalesData();
  const [tick, setTick] = useState(0);
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [pay, setPay] = useState<FinancePayment>("bank");

  const stats = useMemo(() => financeAnalytics.potBalance(pot), [pot, tick]);
  const rows = useMemo(
    () => financeFundWithdraws.list().filter((f) => f.pot === pot),
    [pot, tick],
  );

  function save() {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) return;
    financeFundWithdraws.create({
      at: new Date().toISOString(),
      pot,
      amount: amt,
      description: desc.trim() || FUND_POT_LABEL[pot],
      payment: pay,
    });
    setAmount("");
    setDesc("");
    setOpen(false);
    setTick((t) => t + 1);
  }

  function remove(id: string) {
    financeFundWithdraws.remove(id);
    setTick((t) => t + 1);
  }

  const label = FUND_POT_LABEL[pot];
  const Icon = POT_ICON[pot];
  const totalWithdrawn = rows.reduce((a, r) => a + r.amount, 0);

  // TODO(analytics): Runway estimation dan progress bar "Alokasi Saldo vs
  // Cair Bulan Ini" dipindahkan ke Analytics Module pada Phase berikutnya.

  return (
    <div className="space-y-6">
      <FinancePageHeader
        title={label}
        description={`Saldo dan riwayat pencairan ${label.toLowerCase()}.`}
        meta={
          <>
            <span className="tabular-nums">{rows.length} pencairan</span>
            <span aria-hidden>·</span>
            <span className="tabular-nums">Total {formatIDR(totalWithdrawn)}</span>
          </>
        }
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-1 h-4 w-4" aria-hidden /> Catat Pencairan
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Pencairan {label}</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Jumlah</Label>
                  <Input
                    inputMode="numeric"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Deskripsi</Label>
                  <Input value={desc} onChange={(e) => setDesc(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Payment</Label>
                  <Select value={pay} onValueChange={(v) => setPay(v as FinancePayment)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAYMENTS.map((p) => (
                        <SelectItem key={p} value={p}>
                          {FINANCE_PAYMENT_LABEL[p]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Batal
                </Button>
                <Button onClick={save}>Simpan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <FinanceKpiCard
          label="Saldo"
          value={formatIDR(stats.balance)}
          tone={stats.balance < 0 ? "warning" : "positive"}
          icon={Icon}
        />
        <FinanceKpiCard
          label="Cair Hari Ini"
          value={formatIDR(stats.today)}
          tone="muted"
        />
        <FinanceKpiCard label="Cair Bulan Ini" value={formatIDR(stats.month)} />
      </div>


      <Card className="overflow-hidden rounded-xl">
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <FinanceEmptyState
              icon={Icon}
              title={`Belum ada pencairan ${label.toLowerCase()}`}
              description="Semua pencairan akan tampil di sini beserta metode pembayarannya."
              action={
                <Button size="sm" onClick={() => setOpen(true)}>
                  <Plus className="mr-1 h-4 w-4" aria-hidden /> Catat pencairan pertama
                </Button>
              }
            />
          ) : (
            <TooltipProvider delayDuration={200}>
              <div className="max-h-[70dvh] overflow-auto">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
                    <TableRow>
                      <TableHead className="w-[160px]">Waktu</TableHead>
                      <TableHead>Deskripsi</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Jumlah</TableHead>
                      <TableHead className="w-[50px]" aria-label="Aksi" />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow
                        key={r.id}
                        className="transition-colors hover:bg-muted/40 focus-within:bg-muted/40"
                      >
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground tabular-nums">
                          {formatDateTime(r.at)}
                        </TableCell>
                        <TableCell className="font-medium">{r.description}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {FINANCE_PAYMENT_LABEL[r.payment]}
                        </TableCell>
                        <TableCell className="text-right font-semibold tabular-nums">
                          {formatIDR(r.amount)}
                        </TableCell>
                        <TableCell>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => remove(r.id)}
                                aria-label={`Hapus pencairan ${r.description}`}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" aria-hidden />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Hapus</TooltipContent>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
