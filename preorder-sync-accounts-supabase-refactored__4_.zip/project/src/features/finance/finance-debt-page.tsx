import { useMemo, useState } from "react";
import { CheckCircle2, Landmark, Plus, Trash2, Wallet } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { financeDebts } from "@/services/finance.service";
import { FINANCE_PAYMENT_LABEL, type FinancePayment } from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import { FinanceEmptyState, FinanceKpiCard, FinancePageHeader } from "./_shared";
import { useSalesData } from "@/hooks/use-sales-data";

const PAYMENTS = Object.keys(FINANCE_PAYMENT_LABEL) as FinancePayment[];

export function FinanceDebtPage() {
  useSalesData();
  const [tick, setTick] = useState(0);
  const [openDebt, setOpenDebt] = useState(false);
  const [openPay, setOpenPay] = useState<string | null>(null);

  // debt form
  const [name, setName] = useState("");
  const [principal, setPrincipal] = useState("");
  const [targetDate, setTargetDate] = useState("");

  // payment form
  const [amount, setAmount] = useState("");
  const [pay, setPay] = useState<FinancePayment>("bank");
  const [notes, setNotes] = useState("");

  const debts = useMemo(() => financeDebts.list(), [tick]);
  const payments = useMemo(() => financeDebts.payments(), [tick]);
  const totals = useMemo(() => financeDebts.totals(), [tick]);

  function saveDebt() {
    const p = Number(principal);
    if (!name.trim() || !Number.isFinite(p) || p <= 0) return;
    financeDebts.create({
      name: name.trim(),
      principal: p,
      targetDate: targetDate || undefined,
    });
    setName("");
    setPrincipal("");
    setTargetDate("");
    setOpenDebt(false);
    setTick((t) => t + 1);
  }

  function savePayment() {
    const amt = Number(amount);
    if (!openPay || !Number.isFinite(amt) || amt <= 0) return;
    financeDebts.addPayment({
      debtId: openPay,
      at: new Date().toISOString(),
      amount: amt,
      payment: pay,
      notes: notes.trim() || undefined,
    });
    setAmount("");
    setNotes("");
    setOpenPay(null);
    setTick((t) => t + 1);
  }

  function removeDebt(id: string) {
    financeDebts.remove(id);
    setTick((t) => t + 1);
  }

  // TODO(analytics): "Estimasi Lunas (bulan)" berbasis pace 30 hari terakhir
  // dipindahkan ke Analytics Module pada Phase berikutnya. Progress bar
  // pelunasan tetap dipertahankan sebagai indikator operasional.
  const progressPct = Math.min(100, Math.max(0, totals.progress * 100));


  const activeDebt = debts.find((d) => d.id === openPay) ?? null;
  const activePaid =
    activeDebt !== null
      ? payments
          .filter((p) => p.debtId === activeDebt.id)
          .reduce((a, p) => a + p.amount, 0)
      : 0;

  return (
    <div className="space-y-6">
      <FinancePageHeader
        title="Debt Progress"
        description="Kelola & monitor pelunasan seluruh hutang bisnis."
        meta={
          <>
            <span className="tabular-nums">{debts.length} hutang</span>
            <span aria-hidden>·</span>
            <span className="tabular-nums">Sisa {formatIDR(totals.remaining)}</span>
          </>
        }
        actions={
          <Dialog open={openDebt} onOpenChange={setOpenDebt}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-1 h-4 w-4" aria-hidden /> Tambah Hutang
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Hutang Baru</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Nama</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Nominal</Label>
                  <Input
                    inputMode="numeric"
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value.replace(/[^\d]/g, ""))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Target Lunas (opsional)</Label>
                  <Input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpenDebt(false)}>
                  Batal
                </Button>
                <Button onClick={saveDebt}>Simpan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <FinanceKpiCard label="Target" value={formatIDR(totals.principal)} icon={Landmark} />
        <FinanceKpiCard
          label="Sudah Dibayar"
          value={formatIDR(totals.paid)}
          tone="positive"
          icon={CheckCircle2}
        />
        <FinanceKpiCard
          label="Sisa"
          value={formatIDR(totals.remaining)}
          tone={totals.remaining > 0 ? "warning" : "positive"}
          icon={Wallet}
        />
      </div>


      <Card className="rounded-xl">
        <CardContent className="space-y-2 p-5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              Progress Keseluruhan
            </span>
            <span className="font-semibold tabular-nums text-foreground">
              {progressPct.toFixed(0)}%
            </span>
          </div>
          <div
            className="h-3 w-full overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-valuenow={Math.round(progressPct)}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Progress pelunasan hutang"
          >
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400 transition-[width] duration-700 ease-out"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-muted-foreground tabular-nums">
            <span>{formatIDR(totals.paid)} dibayar</span>
            <span>{formatIDR(totals.remaining)} tersisa</span>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden rounded-xl">
        <CardContent className="p-0">
          {debts.length === 0 ? (
            <FinanceEmptyState
              icon={Landmark}
              title="Belum ada hutang tercatat"
              description="Tambahkan hutang untuk mulai memantau progres pelunasan."
              action={
                <Button size="sm" onClick={() => setOpenDebt(true)}>
                  <Plus className="mr-1 h-4 w-4" aria-hidden /> Tambah hutang pertama
                </Button>
              }
            />
          ) : (
            <TooltipProvider delayDuration={200}>
              <div className="max-h-[70dvh] overflow-auto">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
                    <TableRow>
                      <TableHead>Hutang</TableHead>
                      <TableHead className="w-[200px]">Progress</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead className="text-right">Dibayar</TableHead>
                      <TableHead className="text-right">Sisa</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {debts.map((d) => {
                      const paid = payments
                        .filter((p) => p.debtId === d.id)
                        .reduce((a, p) => a + p.amount, 0);
                      const remaining = Math.max(0, d.principal - paid);
                      const pct =
                        d.principal > 0 ? Math.min(100, (paid / d.principal) * 100) : 0;
                      const done = remaining === 0;
                      const overdue =
                        !done && d.targetDate && new Date(d.targetDate) < new Date();
                      return (
                        <TableRow
                          key={d.id}
                          className="transition-colors hover:bg-muted/40 focus-within:bg-muted/40"
                        >
                          <TableCell>
                            <div className="font-medium text-foreground">{d.name}</div>
                            <div className="text-xs text-muted-foreground tabular-nums">
                              {formatDateTime(d.createdAt)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="h-2 w-full overflow-hidden rounded-full bg-muted"
                                role="progressbar"
                                aria-valuenow={Math.round(pct)}
                                aria-valuemin={0}
                                aria-valuemax={100}
                                aria-label={`Progress ${d.name}`}
                              >
                                <div
                                  className={`h-full rounded-full transition-[width] duration-500 ease-out ${
                                    done
                                      ? "bg-emerald-500"
                                      : "bg-gradient-to-r from-emerald-500 to-emerald-400"
                                  }`}
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                              <span className="w-10 text-right text-[11px] font-medium tabular-nums text-muted-foreground">
                                {pct.toFixed(0)}%
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right font-medium tabular-nums">
                            {formatIDR(d.principal)}
                          </TableCell>
                          <TableCell className="text-right font-medium tabular-nums text-emerald-600 dark:text-emerald-400">
                            {formatIDR(paid)}
                          </TableCell>
                          <TableCell className="text-right font-medium tabular-nums">
                            {formatIDR(remaining)}
                          </TableCell>
                          <TableCell>
                            {done ? (
                              <Badge className="bg-emerald-500/15 text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-400">
                                Lunas
                              </Badge>
                            ) : overdue ? (
                              <Badge variant="destructive">Lewat target</Badge>
                            ) : d.targetDate ? (
                              <Badge
                                variant="secondary"
                                className="bg-amber-500/15 text-amber-700 hover:bg-amber-500/20 dark:text-amber-400"
                              >
                                Jatuh {d.targetDate}
                              </Badge>
                            ) : (
                              <Badge variant="outline">Outstanding</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setOpenPay(d.id)}
                                disabled={done}
                              >
                                Bayar
                              </Button>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => removeDebt(d.id)}
                                    aria-label={`Hapus ${d.name}`}
                                  >
                                    <Trash2
                                      className="h-4 w-4 text-muted-foreground"
                                      aria-hidden
                                    />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Hapus</TooltipContent>
                              </Tooltip>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>

      <Dialog open={openPay !== null} onOpenChange={(o) => !o && setOpenPay(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Bayar Hutang{activeDebt ? ` — ${activeDebt.name}` : ""}
            </DialogTitle>
          </DialogHeader>
          {activeDebt ? (
            <div className="mb-2 rounded-lg border bg-muted/40 p-3 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Sisa</span>
                <span className="font-semibold tabular-nums text-foreground">
                  {formatIDR(Math.max(0, activeDebt.principal - activePaid))}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Total dibayar</span>
                <span className="tabular-nums">{formatIDR(activePaid)}</span>
              </div>
            </div>
          ) : null}
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Jumlah</Label>
              <Input
                inputMode="numeric"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Payment</Label>
              <Select value={pay} onValueChange={(v) => setPay(v as FinancePayment)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENTS.map((p) => (
                    <SelectItem key={p} value={p}>
                      {FINANCE_PAYMENT_LABEL[p]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Catatan</Label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
          </div>
          {activeDebt ? (
            <div className="mt-2 space-y-1.5">
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Riwayat Pembayaran
              </div>
              <div className="max-h-[180px] space-y-1 overflow-auto rounded-md border p-2">
                {payments.filter((p) => p.debtId === activeDebt.id).length === 0 ? (
                  <p className="py-3 text-center text-xs text-muted-foreground">
                    Belum ada pembayaran.
                  </p>
                ) : (
                  payments
                    .filter((p) => p.debtId === activeDebt.id)
                    .map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between rounded-sm px-2 py-1 text-xs hover:bg-muted/40"
                      >
                        <span className="truncate text-muted-foreground">
                          {formatDateTime(p.at)} · {FINANCE_PAYMENT_LABEL[p.payment]}
                        </span>
                        <span className="font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
                          {formatIDR(p.amount)}
                        </span>
                      </div>
                    ))
                )}
              </div>
            </div>
          ) : null}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpenPay(null)}>
              Batal
            </Button>
            <Button onClick={savePayment}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
