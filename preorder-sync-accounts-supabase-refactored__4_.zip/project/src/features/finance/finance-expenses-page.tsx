import { useMemo, useState } from "react";
import { Plus, Receipt, Search, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { financeExpenses } from "@/services/finance.service";
import {
  EXPENSE_CATEGORY_LABEL,
  FINANCE_PAYMENT_LABEL,
  FUND_POT_LABEL,
  type ExpenseCategory,
  type FinancePayment,
  type FundPot,
} from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import { FinanceEmptyState, FinancePageHeader, FinanceKpiCard } from "./_shared";
import { useSalesData } from "@/hooks/use-sales-data";

const CATEGORIES = Object.keys(EXPENSE_CATEGORY_LABEL) as ExpenseCategory[];
const POTS = Object.keys(FUND_POT_LABEL) as FundPot[];
const PAYMENTS = Object.keys(FINANCE_PAYMENT_LABEL) as FinancePayment[];

export function FinanceExpensesPage() {
  useSalesData();
  const [tick, setTick] = useState(0);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<"all" | ExpenseCategory>("all");
  const [pot, setPot] = useState<"all" | FundPot>("all");
  const [open, setOpen] = useState(false);

  // Form state
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [fCat, setFCat] = useState<ExpenseCategory>("operational");
  const [fPot, setFPot] = useState<FundPot>("operational");
  const [fPay, setFPay] = useState<FinancePayment>("cash");

  const rows = useMemo(() => {
    const list = financeExpenses.list();
    return list.filter((e) => {
      if (cat !== "all" && e.category !== cat) return false;
      if (pot !== "all" && e.pot !== pot) return false;
      if (q && !e.description.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, cat, pot, tick]);

  const total = rows.reduce((a, e) => a + e.amount, 0);

  // TODO(analytics): "Rata-rata pengeluaran", "Terbesar", dan breakdown
  // "Top Pengeluaran per Kategori" (progress bar) dipindahkan ke Analytics
  // Module pada Phase berikutnya. Halaman ini hanya untuk CRUD + list.


  function save() {
    const amt = Number(amount);
    if (!desc.trim() || !Number.isFinite(amt) || amt <= 0) return;
    financeExpenses.create({
      at: new Date().toISOString(),
      description: desc.trim(),
      category: fCat,
      pot: fPot,
      payment: fPay,
      amount: amt,
    });
    setDesc("");
    setAmount("");
    setOpen(false);
    setTick((t) => t + 1);
  }

  function remove(id: string) {
    financeExpenses.remove(id);
    setTick((t) => t + 1);
  }

  return (
    <div className="space-y-6">
      <FinancePageHeader
        title="Pengeluaran"
        description="Catat & pantau semua pengeluaran operasional."
        meta={
          <>
            <span className="tabular-nums">{rows.length} entri</span>
            <span aria-hidden>·</span>
            <span className="tabular-nums">Total {formatIDR(total)}</span>
          </>
        }
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-1 h-4 w-4" aria-hidden /> Catat Pengeluaran
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Pengeluaran Baru</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Deskripsi</Label>
                  <Input value={desc} onChange={(e) => setDesc(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Jumlah</Label>
                    <Input
                      inputMode="numeric"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Payment</Label>
                    <Select value={fPay} onValueChange={(v) => setFPay(v as FinancePayment)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PAYMENTS.map((p) => (
                          <SelectItem key={p} value={p}>
                            {FINANCE_PAYMENT_LABEL[p]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Kategori</Label>
                    <Select value={fCat} onValueChange={(v) => setFCat(v as ExpenseCategory)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CATEGORIES.map((c) => (
                          <SelectItem key={c} value={c}>
                            {EXPENSE_CATEGORY_LABEL[c]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Pos Dana</Label>
                    <Select value={fPot} onValueChange={(v) => setFPot(v as FundPot)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {POTS.map((p) => (
                          <SelectItem key={p} value={p}>
                            {FUND_POT_LABEL[p]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Batal
                </Button>
                <Button onClick={save}>Simpan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-4 sm:grid-cols-1">
        <FinanceKpiCard label="Total Pengeluaran (filter aktif)" value={formatIDR(total)} tone="warning" />
      </div>


      <Card className="sticky top-0 z-20 rounded-xl border-border/70 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/70">
        <CardContent className="flex flex-wrap items-center gap-2 p-3 sm:p-4">
          <div className="relative min-w-[220px] flex-1">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <Input
              className="pl-9"
              placeholder="Cari deskripsi…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Cari pengeluaran"
            />
          </div>
          <Select value={cat} onValueChange={(v) => setCat(v as typeof cat)}>
            <SelectTrigger className="w-[180px]" aria-label="Filter kategori">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kategori</SelectItem>
              {CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {EXPENSE_CATEGORY_LABEL[c]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={pot} onValueChange={(v) => setPot(v as typeof pot)}>
            <SelectTrigger className="w-[180px]" aria-label="Filter pos dana">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Pos Dana</SelectItem>
              {POTS.map((p) => (
                <SelectItem key={p} value={p}>
                  {FUND_POT_LABEL[p]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card className="overflow-hidden rounded-xl">
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <FinanceEmptyState
              icon={Receipt}
              title="Belum ada pengeluaran"
              description="Semua pencatatan pengeluaran akan tampil di sini."
              action={
                <Button size="sm" onClick={() => setOpen(true)}>
                  <Plus className="mr-1 h-4 w-4" aria-hidden /> Catat pengeluaran pertama
                </Button>
              }
            />
          ) : (
            <TooltipProvider delayDuration={200}>
              <div className="max-h-[70dvh] overflow-auto">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
                    <TableRow>
                      <TableHead className="w-[160px]">Waktu</TableHead>
                      <TableHead>Deskripsi</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Pos Dana</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Jumlah</TableHead>
                      <TableHead className="w-[50px]" aria-label="Aksi" />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow
                        key={r.id}
                        className="transition-colors hover:bg-muted/40 focus-within:bg-muted/40"
                      >
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground tabular-nums">
                          {formatDateTime(r.at)}
                        </TableCell>
                        <TableCell className="max-w-[260px] font-medium">
                          <span className="block truncate">{r.description}</span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="font-normal">
                            {EXPENSE_CATEGORY_LABEL[r.category]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {FUND_POT_LABEL[r.pot]}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {FINANCE_PAYMENT_LABEL[r.payment]}
                        </TableCell>
                        <TableCell className="text-right font-semibold tabular-nums">
                          {formatIDR(r.amount)}
                        </TableCell>
                        <TableCell className="text-right">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => remove(r.id)}
                                aria-label={`Hapus ${r.description}`}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" aria-hidden />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Hapus</TooltipContent>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
