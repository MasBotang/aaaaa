import type { ComponentType, ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

/**
 * Shared UI primitives for the Finance module.
 *
 * These are pure presentational helpers used across Dashboard, Ledger,
 * Expenses, Debt and Fund pages so that spacing, hover states, radii,
 * typography and empty/loading states are visually identical.
 *
 * NO business logic lives here — polish layer only.
 */

/* -------------------------------- Header -------------------------------- */

export function FinancePageHeader({
  title,
  description,
  meta,
  actions,
}: {
  title: string;
  description?: string;
  meta?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-end sm:justify-between">
      <div className="min-w-0 flex flex-col gap-1">
        <h1 className="font-display truncate text-2xl font-semibold tracking-tight text-foreground">
          {title}
        </h1>
        {description ? (
          <p className="text-sm text-muted-foreground">{description}</p>
        ) : null}
        {meta ? (
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {meta}
          </div>
        ) : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}

/* -------------------------------- KPI Card ------------------------------ */

export type KpiTone = "default" | "positive" | "warning" | "muted" | "destructive";

const TONE_CLASSES: Record<KpiTone, string> = {
  default: "text-foreground",
  positive: "text-emerald-600 dark:text-emerald-400",
  warning: "text-amber-600 dark:text-amber-400",
  destructive: "text-destructive",
  muted: "text-muted-foreground",
};

export function FinanceKpiCard({
  label,
  value,
  hint,
  tone = "default",
  icon: Icon,
  delta,
  interactive = false,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: KpiTone;
  icon?: ComponentType<{ className?: string; strokeWidth?: number; "aria-hidden"?: boolean }>;
  delta?: ReactNode;
  interactive?: boolean;
}) {
  const hoverCls = interactive
    ? "transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
    : "transition-shadow duration-200 hover:shadow-sm";

  return (
    <Card className={`h-full rounded-xl ${hoverCls}`}>
      <CardContent className="flex h-full flex-col gap-2 p-5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {Icon ? (
              <Icon className="h-3.5 w-3.5 shrink-0" strokeWidth={1.75} aria-hidden />
            ) : null}
            <span className="truncate">{label}</span>
          </div>
          {delta}
        </div>
        <div
          className={`font-display text-2xl font-semibold tabular-nums leading-tight ${TONE_CLASSES[tone]}`}
        >
          {value}
        </div>
        {hint ? (
          <div className="mt-auto truncate text-xs text-muted-foreground">{hint}</div>
        ) : null}
      </CardContent>
    </Card>
  );
}

/* -------------------------------- Empty State --------------------------- */

export function FinanceEmptyState({
  icon: Icon,
  title,
  description,
  action,
  compact = false,
}: {
  icon: ComponentType<{ className?: string; strokeWidth?: number; "aria-hidden"?: boolean }>;
  title: string;
  description?: string;
  action?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      className={`animate-fade-in flex flex-col items-center justify-center gap-3 text-center ${
        compact ? "px-4 py-10" : "px-4 py-14"
      }`}
      role="status"
      aria-live="polite"
    >
      <div className="grid h-12 w-12 place-items-center rounded-full border border-dashed border-border bg-muted/40 text-muted-foreground">
        <Icon className="h-5 w-5" strokeWidth={1.75} aria-hidden />
      </div>
      <div className="space-y-1">
        <p className="text-sm font-semibold text-foreground">{title}</p>
        {description ? (
          <p className="max-w-sm text-xs text-muted-foreground">{description}</p>
        ) : null}
      </div>
      {action ? <div className="pt-1">{action}</div> : null}
    </div>
  );
}

/* -------------------------------- Skeletons ----------------------------- */

export function FinanceKpiSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div
      className={`grid gap-4 sm:grid-cols-2 ${
        count >= 5 ? "lg:grid-cols-5" : count === 4 ? "lg:grid-cols-4" : "lg:grid-cols-3"
      }`}
      aria-hidden
    >
      {Array.from({ length: count }).map((_, i) => (
        <Card key={i} className="rounded-xl">
          <CardContent className="flex flex-col gap-3 p-5">
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-7 w-3/4" />
            <Skeleton className="h-3 w-1/3" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function FinanceTableSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <div className="space-y-2 p-4" aria-hidden>
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  );
}

export function FinanceChartSkeleton({ height = 240 }: { height?: number }) {
  return (
    <div style={{ height }} className="flex items-end gap-1.5 p-3" aria-hidden>
      {Array.from({ length: 18 }).map((_, i) => (
        <Skeleton
          key={i}
          className="flex-1 rounded-sm"
          style={{ height: `${30 + ((i * 37) % 60)}%` }}
        />
      ))}
    </div>
  );
}

/* -------------------------------- Sticky Filter Bar --------------------- */

export function FinanceFilterBar({ children }: { children: ReactNode }) {
  return (
    <Card className="sticky top-0 z-10 rounded-xl border-border/70 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <CardContent className="flex flex-wrap items-center gap-2 p-3 sm:p-4">
        {children}
      </CardContent>
    </Card>
  );
}

/* -------------------------------- Section title ------------------------- */

export function SectionTitle({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
      <div className="min-w-0">
        <h2 className="font-display text-lg font-semibold tracking-tight text-foreground">
          {title}
        </h2>
        {subtitle ? (
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      {action}
    </div>
  );
}

/* -------------------------------- Delta badge --------------------------- */

export function DeltaBadge({
  value,
  suffix = "",
  invert = false,
}: {
  value: number;
  suffix?: string;
  invert?: boolean;
}) {
  if (!Number.isFinite(value) || value === 0) {
    return (
      <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium tabular-nums text-muted-foreground">
        0{suffix}
      </span>
    );
  }
  const positive = invert ? value < 0 : value > 0;
  const cls = positive
    ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
    : "bg-amber-500/15 text-amber-700 dark:text-amber-400";
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-[10px] font-medium tabular-nums ${cls}`}
    >
      {value > 0 ? "+" : ""}
      {value.toFixed(1)}
      {suffix}
    </span>
  );
}

/* -------------------------------- Retry button -------------------------- */

export function EmptyStateAction({
  label,
  onClick,
  variant = "outline",
}: {
  label: string;
  onClick?: () => void;
  variant?: "default" | "outline" | "ghost";
}) {
  return (
    <Button size="sm" variant={variant} onClick={onClick}>
      {label}
    </Button>
  );
}
