/**
 * Canonical receipt/invoice renderer — Source of Truth untuk struk POS.
 *
 * Digunakan oleh checkout POS, Cetak Invoice, Reprint Invoice, dan Print
 * dari halaman Pesanan sehingga seluruh hasil cetak identik. Renderer murni
 * presentasi — tidak memutasi data / storage.
 */

import { formatDateTime, formatIDR, formatSalesId } from "@/lib/format";
import { formatPaymentSummary, normalizeSalePayment, PAYMENT_METHOD_LABEL } from "@/lib/payment";
import { settingsService } from "@/services/settings.service";
import { SOURCE_ORDER_LABEL, type PreOrder, type Sale } from "@/services/types";

function esc(str: string) {
  return String(str).replace(/[&<>"']/g, (c) =>
    c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;",
  );
}

function fmtPickup(iso?: string): { d: string; t: string } | null {
  if (!iso) return null;
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return null;
  const d = dt.toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const t = `${String(dt.getHours()).padStart(2, "0")}:${String(dt.getMinutes()).padStart(2, "0")}`;
  return { d, t };
}

export function buildReceiptHtml(s: Sale, isReprint = false): string {
  // settingsService.get() sekarang async — fungsi ini dipakai sinkron dari
  // checkout POS maupun halaman Pesanan (di luar scope migrasi tahap ini),
  // jadi pakai cache sinkron (lihat catatan di settings.service.ts).
  const biz = settingsService.getCached().businessName;
  const subtotal = s.items.reduce((a, i) => a + i.price * i.qty, 0);
  const pickup = fmtPickup(s.pickupAt);

  const itemsHtml = s.items
    .map((i) => {
      const line = i.price * i.qty;
      return `
<div class="ln">
  <div class="ln-name">${esc(i.name)}</div>
  <div class="ln-row">
    <span class="muted">${i.qty} × ${formatIDR(i.price)}</span>
    <span class="tab">${formatIDR(line)}</span>
  </div>
</div>`;
    })
    .join("");

  const packingsHtml =
    s.packings && s.packings.length > 0
      ? s.packings
          .map(
            (p, i) => `
<div class="pk">
  <div class="pk-h">Packing ${i + 1}${p.label ? ` · ${esc(p.label)}` : ""}</div>
  ${p.items.map((it) => `<div class="sub">› ${it.qty}× ${esc(it.name)}</div>`).join("")}
  <div class="muted sub">↳ ${esc(p.boxItemName)}${p.boxQty > 1 ? ` × ${p.boxQty}` : ""}</div>
</div>`,
          )
          .join("")
      : "";

  const extrasHtml =
    (s.plastic && s.plastic.qty > 0) || (s.extraPackaging && s.extraPackaging.length > 0)
      ? `<div class="section-h">Packaging Tambahan</div>${
          s.plastic && s.plastic.qty > 0
            ? `<div class="sub">› ${s.plastic.qty}× ${esc(s.plastic.itemName)}</div>`
            : ""
        }${(s.extraPackaging ?? [])
          .map((e) => `<div class="sub">› ${e.qty}× ${esc(e.itemName)}</div>`)
          .join("")}`
      : "";

  const notesHtml =
    s.customerNotes && s.customerNotes.trim().length > 0
      ? `<div class="section-h">Catatan</div><div class="note">"${esc(s.customerNotes.trim())}"</div>`
      : "";

  const pickupHtml = pickup
    ? `<div class="pickup">
  <div class="pickup-h">🕒 Pengambilan Pre Order</div>
  <div>${esc(pickup.d)}</div>
  <div>Pukul <strong>${pickup.t}</strong></div>
</div>`
    : "";

  const waHtml =
    s.customerPhone && s.customerPhone.trim().length > 0
      ? `<div class="muted center small">📱 Notifikasi WhatsApp akan dikirim ke nomor Anda</div>`
      : "";

  return `<!doctype html><html><head><meta charset="utf-8"><title>Struk ${formatSalesId(s.id)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:ui-monospace,"SF Mono",Menlo,Consolas,monospace;font-size:12px;padding:14px;max-width:320px;margin:0 auto;color:#111;line-height:1.5}
  .brand{text-align:center;margin-bottom:4px}
  .brand h1{font-size:16px;margin:0;letter-spacing:1px;text-transform:uppercase;font-weight:800}
  .brand .tag{font-size:10px;color:#666;letter-spacing:2px;text-transform:uppercase}
  .order-tag{margin:8px 0;padding:6px 0;border:1px dashed #333;text-align:center;font-weight:700;font-size:14px;letter-spacing:2px}
  .copy-badge{margin:6px auto 4px;padding:4px 10px;display:inline-block;border:1.5px dashed #b91c1c;color:#b91c1c;font-weight:800;font-size:11px;letter-spacing:3px;border-radius:4px;text-transform:uppercase}
  .copy-wrap{text-align:center}
  .meta{display:grid;grid-template-columns:auto 1fr;gap:2px 8px;font-size:11px}
  .meta .lbl{color:#666}
  .meta .val{text-align:right;word-break:break-word}
  .sep{border:none;border-top:1px dashed #999;margin:8px 0}
  .sep-solid{border:none;border-top:1px solid #333;margin:8px 0}
  .section-h{font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin:6px 0 4px}
  .ln{margin:4px 0}
  .ln-name{font-weight:600}
  .ln-row{display:flex;justify-content:space-between;gap:8px;font-size:11px}
  .pk{margin:4px 0 6px;padding-top:4px;border-top:1px dotted #ccc}
  .pk:first-of-type{border-top:none;padding-top:0}
  .pk-h{font-weight:600;font-size:11px}
  .sub{padding-left:10px;font-size:11px}
  .muted{color:#666}
  .small{font-size:10px}
  .center{text-align:center}
  .tab{font-variant-numeric:tabular-nums}
  .totals{margin-top:4px}
  .row{display:flex;justify-content:space-between;gap:12px;font-size:11px;padding:1px 0}
  .row .tab{font-variant-numeric:tabular-nums}
  .grand{font-size:14px;font-weight:800;padding:6px 0;border-top:1px solid #111;border-bottom:1px solid #111;margin:4px 0}
  .pickup{margin:10px 0;padding:8px;border:1px dashed #333;text-align:center;font-size:11px}
  .pickup-h{font-weight:700;margin-bottom:2px}
  .note{font-style:italic;color:#333;font-size:11px}
  .footer{margin-top:12px;text-align:center;font-size:11px;color:#333;line-height:1.6}
  .footer .thanks{font-weight:700;font-size:12px}
  @media print{body{padding:6px}}
</style></head><body>
<div class="brand">
  <h1>${esc(biz)}</h1>
  <div class="tag">— Struk Pembelian —</div>
</div>
${s.orderNumber ? `<div class="order-tag">ORDER ${esc(s.orderNumber)}</div>` : ""}
${isReprint ? `<div class="copy-wrap"><span class="copy-badge">★ Salinan ★</span></div>` : ""}
<div class="meta">
  <span class="lbl">No. Invoice</span><span class="val">${formatSalesId(s.id)}</span>
  <span class="lbl">Waktu</span><span class="val">${formatDateTime(s.createdAt)}</span>
  <span class="lbl">Kasir</span><span class="val">${esc(s.cashier)}</span>
  <span class="lbl">Customer</span><span class="val">${esc(s.customerName ?? "—")}</span>
  ${s.customerPhone ? `<span class="lbl">Telepon</span><span class="val">${esc(s.customerPhone)}</span>` : ""}
  <span class="lbl">Source</span><span class="val">${esc(SOURCE_ORDER_LABEL[s.sourceOrder ?? "outlet"])}</span>
  <span class="lbl">Pembayaran</span><span class="val">${esc(formatPaymentSummary(s))}</span>
</div>
<hr class="sep-solid"/>
<div class="section-h">Detail Pesanan</div>
${itemsHtml}
${packingsHtml ? `<hr class="sep"/><div class="section-h">Detail Packing</div>${packingsHtml}` : ""}
${extrasHtml ? `<hr class="sep"/>${extrasHtml}` : ""}
${notesHtml ? `<hr class="sep"/>${notesHtml}` : ""}
<hr class="sep-solid"/>
<div class="totals">
  <div class="row"><span class="muted">Subtotal</span><span class="tab">${formatIDR(subtotal)}</span></div>
  <div class="row grand"><span>TOTAL</span><span class="tab">${formatIDR(s.total)}</span></div>
  ${s.tendered != null ? `<div class="row"><span class="muted">Tunai</span><span class="tab">${formatIDR(s.tendered)}</span></div>` : ""}
  ${s.change != null ? `<div class="row"><span class="muted">Kembalian</span><span class="tab">${formatIDR(s.change)}</span></div>` : ""}
</div>
${pickupHtml}
<div class="footer">
  <div class="thanks">Terima kasih atas kunjungan Anda 🙏</div>
  <div>Sampai bertemu kembali,<br/>semoga harimu menyenangkan 😊</div>
  ${waHtml}
</div>
<script>window.onload=()=>{window.print();setTimeout(()=>window.close(),300)}<\/script>
</body></html>`;
}

/** Buka jendela cetak dengan renderer canonical. Return false bila popup diblokir. */
export function printSaleReceipt(s: Sale, isReprint = false): boolean {
  const w = window.open("", "_blank", "width=380,height=720");
  if (!w) return false;
  w.document.open();
  w.document.write(buildReceiptHtml(s, isReprint));
  w.document.close();
  return true;
}

/**
 * Bukti Pembayaran DP untuk Pre Order (Sprint 9).
 * Pure presentasi — TIDAK menulis storage / membuat Sale / mengubah stok.
 * Judul & label sengaja dibuat jelas berbeda dari struk Sale reguler supaya
 * dokumen ini tidak bisa dibaca sebagai bukti pelunasan penuh.
 */
export function buildPreorderDpProofHtml(po: PreOrder): string {
  // settingsService.get() sekarang async — fungsi ini dipakai sinkron dari
  // checkout POS maupun halaman Pesanan (di luar scope migrasi tahap ini),
  // jadi pakai cache sinkron (lihat catatan di settings.service.ts).
  const biz = settingsService.getCached().businessName;
  const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
  const dp = Math.max(0, po.downPayment ?? 0);
  const remaining = Math.max(0, po.remainingBalance ?? subtotal - dp);
  const pickup = fmtPickup(new Date(`${po.date}T${po.time}:00`).toISOString());
  const dpMethodLabel = po.dpMethod ? PAYMENT_METHOD_LABEL[po.dpMethod] ?? po.dpMethod : "—";

  const itemsHtml = po.items
    .map((i) => {
      const line = i.price * i.qty;
      return `
<div class="ln">
  <div class="ln-name">${esc(i.name)}</div>
  <div class="ln-row">
    <span class="muted">${i.qty} × ${formatIDR(i.price)}</span>
    <span class="tab">${formatIDR(line)}</span>
  </div>
</div>`;
    })
    .join("");

  return `<!doctype html><html><head><meta charset="utf-8"><title>Bukti DP ${esc(po.id)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:ui-monospace,"SF Mono",Menlo,Consolas,monospace;font-size:12px;padding:14px;max-width:320px;margin:0 auto;color:#111;line-height:1.5}
  .brand{text-align:center;margin-bottom:4px}
  .brand h1{font-size:16px;margin:0;letter-spacing:1px;text-transform:uppercase;font-weight:800}
  .brand .tag{font-size:11px;color:#b45309;letter-spacing:2px;text-transform:uppercase;font-weight:700}
  .warn-badge{margin:8px auto 4px;padding:6px 10px;display:block;text-align:center;border:1.5px dashed #b45309;color:#b45309;background:#fffbeb;font-weight:800;font-size:12px;letter-spacing:2px;border-radius:4px;text-transform:uppercase}
  .meta{display:grid;grid-template-columns:auto 1fr;gap:2px 8px;font-size:11px}
  .meta .lbl{color:#666}
  .meta .val{text-align:right;word-break:break-word}
  .sep{border:none;border-top:1px dashed #999;margin:8px 0}
  .sep-solid{border:none;border-top:1px solid #333;margin:8px 0}
  .section-h{font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin:6px 0 4px}
  .ln{margin:4px 0}
  .ln-name{font-weight:600}
  .ln-row{display:flex;justify-content:space-between;gap:8px;font-size:11px}
  .muted{color:#666}
  .small{font-size:10px}
  .center{text-align:center}
  .tab{font-variant-numeric:tabular-nums}
  .row{display:flex;justify-content:space-between;gap:12px;font-size:11px;padding:1px 0}
  .row .tab{font-variant-numeric:tabular-nums}
  .dp-line{font-size:13px;font-weight:700;padding:4px 0;border-top:1px solid #333;margin-top:4px}
  .remaining{font-size:14px;font-weight:800;padding:6px 0;border-top:1px solid #b45309;border-bottom:1px solid #b45309;margin:4px 0;color:#b45309}
  .pickup{margin:10px 0;padding:8px;border:1px dashed #333;text-align:center;font-size:11px}
  .pickup-h{font-weight:700;margin-bottom:2px}
  .footer{margin-top:12px;text-align:center;font-size:11px;color:#333;line-height:1.6}
  @media print{body{padding:6px}}
</style></head><body>
<div class="brand">
  <h1>${esc(biz)}</h1>
  <div class="tag">— Bukti Pembayaran DP —</div>
</div>
<div class="warn-badge">★ BUKTI PEMBAYARAN DP ★<br/><span style="font-size:10px;letter-spacing:1px">BELUM LUNAS · SIMPAN UNTUK PELUNASAN</span></div>
<div class="meta">
  <span class="lbl">No. Pre Order</span><span class="val">${esc(po.id)}</span>
  <span class="lbl">Dibuat</span><span class="val">${formatDateTime(po.createdAt)}</span>
  <span class="lbl">Kasir</span><span class="val">${esc(po.createdBy)}</span>
  <span class="lbl">Customer</span><span class="val">${esc(po.customerName)}</span>
  ${po.customerPhone ? `<span class="lbl">Telepon</span><span class="val">${esc(po.customerPhone)}</span>` : ""}
  <span class="lbl">Source</span><span class="val">${esc(SOURCE_ORDER_LABEL[po.sourceOrder ?? "outlet"])}</span>
  <span class="lbl">Metode DP</span><span class="val">${esc(dpMethodLabel)}</span>
</div>
${pickup ? `<div class="pickup">
  <div class="pickup-h">🕒 Pengambilan Pre Order</div>
  <div>${esc(pickup.d)}</div>
  <div>Pukul <strong>${pickup.t}</strong></div>
</div>` : ""}
<hr class="sep-solid"/>
<div class="section-h">Detail Pesanan</div>
${itemsHtml}
<hr class="sep-solid"/>
<div class="row"><span class="muted">Subtotal Pesanan</span><span class="tab">${formatIDR(subtotal)}</span></div>
<div class="row dp-line"><span>DP Diterima</span><span class="tab">${formatIDR(dp)}</span></div>
<div class="row remaining"><span>SISA PELUNASAN</span><span class="tab">${formatIDR(remaining)}</span></div>
<div class="footer">
  <div class="small muted">Dokumen ini adalah bukti pembayaran DP saja.<br/>Pelunasan wajib dilakukan saat pengambilan pesanan.</div>
</div>
<script>window.onload=()=>{window.print();setTimeout(()=>window.close(),300)}<\/script>
</body></html>`;
}

/** Buka jendela cetak Bukti Pembayaran DP. Return false bila popup diblokir. */
export function printPreorderDpProof(po: PreOrder): boolean {
  const w = window.open("", "_blank", "width=380,height=720");
  if (!w) return false;
  w.document.open();
  w.document.write(buildPreorderDpProofHtml(po));
  w.document.close();
  return true;
}

// normalizeSalePayment kept as re-import for consumers of this module.
void normalizeSalePayment;
