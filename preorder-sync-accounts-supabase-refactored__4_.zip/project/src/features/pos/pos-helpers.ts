/**
 * Helper murni (pure functions & constants) yang dipakai POSPage.
 *
 * Langkah pertama pemecahan `pos-page.tsx` (2.617 baris — lihat audit
 * Sprint 1, "UI Rendah": file tunggal terlalu besar, rawan konflik saat
 * di-edit rame-rame). Bagian ini dipindah lebih dulu karena PALING AMAN:
 * murni fungsi/konstanta tanpa closure ke state komponen, tanpa efek
 * samping — jadi mustahil mengubah perilaku checkout hanya dengan
 * memindahkannya ke file lain. Dipindah verbatim (copy-paste, tanpa
 * modifikasi logika sama sekali).
 *
 * Bagian yang BELUM dipecah (cart panel, payment dialog, product grid)
 * sengaja belum disentuh — itu semua nested function/JSX yang closure
 * berat ke state POSPage (cart, hold order, payment, dst). Baca lebih
 * detail di komentar penutup pos-page.tsx.
 */
import type { LucideIcon } from "lucide-react";
import {
  LayoutGrid,
  Beef,
  Fish,
  Utensils,
  Salad,
  Cake,
  IceCream2,
  Coffee,
  Wine,
  ShoppingBag,
  Soup,
  Cookie,
  Sandwich,
  Pizza,
  Banknote,
  CreditCard,
  QrCode,
  Wallet,
} from "lucide-react";
import { priceGroupService } from "@/services/price-group.service";
import type { CustomerType, PaymentMethod, Product, SaleItem } from "@/services/types";

export interface CartLine extends SaleItem {}

export function priceFor(
  p: Product,
  priceGroupId: string | undefined,
  _customerType: CustomerType,
): number {
  return priceGroupService.priceFor(p, priceGroupId);
}

/** Practical Indonesian cash denominations, ordered low → high. */
export const QUICK_CASH = [500, 1000, 5000, 10000, 50000];

export const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  cash: "Tunai",
  qris: "QRIS",
  card: "Kartu",
  transfer: "Transfer",
};

export const PAYMENT_ICONS: Record<PaymentMethod, LucideIcon> = {
  cash: Banknote,
  qris: QrCode,
  card: CreditCard,
  transfer: Wallet,
};

/** Map category names to a matching Lucide icon. Falls back to LayoutGrid. */
export function iconForCategory(name: string): LucideIcon {
  const n = name.toLowerCase();
  if (n === "semua" || n === "all") return LayoutGrid;
  if (/(daging|beef|sapi|ayam|chicken|meat)/.test(n)) return Beef;
  if (/(ikan|fish|seafood|udang|cumi)/.test(n)) return Fish;
  if (/(sayur|salad|veg|greens)/.test(n)) return Salad;
  if (/(sup|soup|kuah)/.test(n)) return Soup;
  if (/(nasi|rice|main|utama|paket)/.test(n)) return Utensils;
  if (/(kue|cake|dessert|manis|pastry)/.test(n)) return Cake;
  if (/(cookie|biskuit|snack|cemilan)/.test(n)) return Cookie;
  if (/(es|ice|dingin|frozen)/.test(n)) return IceCream2;
  if (/(kopi|coffee|teh|tea|drink|minum|jus|juice)/.test(n)) return Coffee;
  if (/(wine|bir|beer|alkohol)/.test(n)) return Wine;
  if (/(burger|sandwich|roti|bread)/.test(n)) return Sandwich;
  if (/(pizza)/.test(n)) return Pizza;
  if (/(paket|bundle|hampers)/.test(n)) return ShoppingBag;
  return LayoutGrid;
}

// Catatan: firstNameOf & formatTodayLong di bawah ternyata sudah tidak
// dipanggil di mana pun sebelum pemindahan ini juga (dead code lama) —
// tetap disertakan verbatim, tidak dihapus, karena bukan bagian dari
// scope "pemecahan file" ini untuk memutuskan.
export function firstNameOf(full?: string | null): string {
  const src = (full || "").toString();
  const stripped = src.includes("@") ? src.split("@")[0] : src;
  const clean = stripped.replace(/[._-]+/g, " ").trim();
  if (!clean) return "kembali";
  const w = clean.split(/\s+/)[0];
  return w.charAt(0).toUpperCase() + w.slice(1);
}

export function formatTodayLong(): string {
  return new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
