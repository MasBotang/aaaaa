import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import {
  Minus,
  Plus,
  Trash2,
  AlertTriangle,
  ImageIcon,
  CheckCircle2,
  Printer,
  PauseCircle,
  X,
  Snowflake,
  Flame,
  CalendarClock,
  Package,
  ArrowRight,
  User,
  Phone,
  StickyNote,
  Store,
  Receipt,
  CreditCard,
  Wallet,
  Keyboard,
  Bell,
  Sparkles,
  ShoppingBasket,
  ShoppingCart,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { productService } from "@/services/product.service";
import { salesService } from "@/services/sales.service";
import { shiftService } from "@/services/shift.service";
import { settingsService } from "@/services/settings.service";
import { holdService } from "@/services/hold.service";
import { priceGroupService } from "@/services/price-group.service";
import { preorderService, validatePickup, minPickupTimeFor, todayYmd } from "@/services/preorder.service";
import type {
  CustomerType,
  HoldOrder,
  PaymentEntry,
  PaymentMethod,
  PreOrder,
  Product,
  Sale,
  SaleType,
  SourceOrder,
  PriceGroup,
  SalePacking,
  SaleExtraPackaging,
  InventoryItem,
} from "@/services/types";
import { SOURCE_ORDER_LABEL, SOURCE_ORDER_LIST } from "@/services/types";
import { useRole } from "@/lib/role-context";
import { usePermission } from "@/lib/permissions";
import { AccessDenied } from "@/components/app/access-denied";
import { formatIDR, formatDateTime, formatSalesId } from "@/lib/format";
import { formatPaymentSummary, sumPaymentEntries } from "@/lib/payment";
import { IMPORTANT_TOAST_DURATION } from "@/lib/toast";
import { printSaleReceipt, printPreorderDpProof } from "./invoice-receipt";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { inventoryService } from "@/services/inventory.service";
import { buildManualPacking, newPackingId, recomputePacking } from "@/services/packing";
// Helper murni (fungsi/konstanta tanpa closure ke state komponen) sudah
// dipindah ke pos-helpers.ts — langkah pertama pemecahan file ini
// (audit Sprint 1, "UI Rendah": pos-page.tsx terlalu besar). Lihat komentar
// di pos-helpers.ts untuk kenapa cuma bagian ini yang dipindah dulu.
import {
  priceFor,
  QUICK_CASH,
  PAYMENT_LABELS,
  PAYMENT_ICONS,
  iconForCategory,
  type CartLine,
} from "./pos-helpers";
import { ProductGrid } from "./product-grid";

export function POSPage() {
  const qc = useQueryClient();
  const productsQ = useQuery({ queryKey: ["products"], queryFn: () => productService.list() });
  const priceGroupsQ = useQuery({
    queryKey: ["price-groups"],
    queryFn: () => priceGroupService.list(),
  });
  const packagingItemsQ = useQuery({
    queryKey: ["inventory-items", "packaging"],
    queryFn: () => inventoryService.byCategory("packaging"),
  });
  const settingsQ = useQuery({ queryKey: ["settings"], queryFn: () => settingsService.get() });
  const products = useMemo(
    () => (productsQ.data ?? []).filter((p) => p.active),
    [productsQ.data],
  );
  const priceGroups = priceGroupsQ.data ?? [];
  const packagingItems = packagingItemsQ.data ?? [];
  const invalidateProducts = () => qc.invalidateQueries({ queryKey: ["products"] });
  const invalidatePackaging = () =>
    qc.invalidateQueries({ queryKey: ["inventory-items", "packaging"] });

  const [cart, setCart] = useState<CartLine[]>([]);
  const [category, setCategory] = useState<string>("Semua");
  const [query, setQuery] = useState("");
  const [paymentOpen, setPaymentOpen] = useState(false);
  // Sprint 7 (Split Payment, Opsi B): satu transaksi bisa memakai >1
  // metode. Cash boleh melebihi total (kelebihan = kembalian). Non-cash
  // (qris/card/transfer) TIDAK boleh melebihi total (tidak ada kembalian
  // non-tunai).
  const [paymentEntries, setPaymentEntries] = useState<PaymentEntry[]>([
    { method: "cash", amount: 0 },
  ]);
  // Sprint 5: DP (Down Payment) untuk Pre Order. Opsional.
  const [dpAmount, setDpAmount] = useState<number>(0);
  const [dpMethod, setDpMethod] = useState<PaymentMethod>("cash");
  const [customerName, setCustomerName] = useState("");
  const [customerNotes, setCustomerNotes] = useState("");
  const [hasShift, setHasShift] = useState(false);
  const [lastSale, setLastSale] = useState<Sale | null>(null);
  // Sprint 9: dialog sukses untuk PO dengan DP > 0 (tanpa Sale).
  const [lastPreorderDp, setLastPreorderDp] = useState<PreOrder | null>(null);
  // Hold orders — react-query (Supabase-backed). Tidak lagi useState +
  // sync .list() sejak Tahap 2 (hold_orders pindah ke Supabase).
  const holdsQ = useQuery({ queryKey: ["hold-orders"], queryFn: () => holdService.list() });
  const holds = holdsQ.data ?? [];
  const invalidateHolds = () => qc.invalidateQueries({ queryKey: ["hold-orders"] });
  const [activeHoldId, setActiveHoldId] = useState<string | null>(null);
  const [saleType, setSaleType] = useState<SaleType>("frozen");
  const [customerType, setCustomerType] = useState<CustomerType>("end_user");
  const [isPreorder, setIsPreorder] = useState(false);
  const [customerPhone, setCustomerPhone] = useState("");
  const [pickupDate, setPickupDate] = useState("");
  const [pickupTime, setPickupTime] = useState("");
  const [sourceOrder, setSourceOrder] = useState<SourceOrder>("outlet");
  // Packing / Packaging state
  const [packingOpen, setPackingOpen] = useState(false);
  const [packings, setPackings] = useState<SalePacking[]>([]);
  const [packingCustom, setPackingCustom] = useState(false);
  const [extras, setExtras] = useState<SaleExtraPackaging[]>([]);
  const { profile, user } = useRole();
  const cashierName = profile?.full_name ?? user?.email ?? "Kasir";
  const { can } = usePermission();
  const canAccessPos = can("page.pos");
  const defaultCustomerName = settingsQ.data?.defaultCustomerName || "Pelanggan Umum";
  const searchRef = useRef<HTMLInputElement | null>(null);
  // Guard terhadap double-submit (double click / double Enter) saat checkout.
  const isCompletingRef = useRef(false);
  const [isCompleting, setIsCompleting] = useState(false);
  // Sprint 6 (Finding #6): lacak sale yang sudah pernah dicetak agar cetak
  // ulang mendapat badge SALINAN.
  const printedSaleIdsRef = useRef<Set<string>>(new Set());
  // Sprint 6 (Finding #7): auto-save cart ke localStorage supaya tidak
  // hilang saat browser di-refresh.
  const CART_DRAFT_KEY = "desalut_pos_cart_draft";
  const cartRestoredRef = useRef(false);

  useEffect(() => {
    // hold_orders sekarang di-fetch oleh holdsQ (useQuery) — tidak perlu
    // sync manual di mount lagi.
    // Restore draft cart (Finding #7). Dilakukan sekali di mount.
    try {
      const raw = localStorage.getItem(CART_DRAFT_KEY);
      if (raw) {
        const draft = JSON.parse(raw) as {
          cart?: CartLine[];
          saleType?: SaleType;
          customerNotes?: string;
        };
        if (Array.isArray(draft.cart) && draft.cart.length > 0) {
          setCart(draft.cart);
          if (draft.saleType) setSaleType(draft.saleType);
          if (typeof draft.customerNotes === "string") {
            setCustomerNotes(draft.customerNotes);
          }
          toast.success("Cart sebelumnya berhasil dipulihkan");
        }
      }
    } catch (err) {
      console.warn("[pos] restore cart draft failed", err);
    } finally {
      cartRestoredRef.current = true;
    }
    const sync = () => { void shiftService.current().then((s) => setHasShift(!!s)); };
    sync();
    window.addEventListener("focus", sync);
    document.addEventListener("visibilitychange", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("focus", sync);
      document.removeEventListener("visibilitychange", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  // Resolve price group aktif dari source order + auto-sync harga cart & customer type.
  const activePriceGroup = useMemo(
    () => (priceGroups.length ? priceGroupService.forSource(priceGroups, sourceOrder) : undefined),
    [priceGroups, sourceOrder],
  );
  const activePriceGroupId = activePriceGroup?.id;

  // Sinkronkan customerType berdasarkan sumber (reseller → reseller, lainnya → end_user).
  useEffect(() => {
    setCustomerType(sourceOrder === "reseller" ? "reseller" : "end_user");
  }, [sourceOrder]);

  // Saat price group / customer type berubah, sinkronkan harga item yang sudah masuk cart.
  useEffect(() => {
    setCart((prev) =>
      prev.map((line) => {
        const p = products.find((x) => x.id === line.productId);
        if (!p) return line;
        return { ...line, price: priceFor(p, activePriceGroupId, customerType) };
      }),
    );
  }, [activePriceGroupId, customerType, products]);

  // Kelola Packing. Mode manual: box & plastik diisi sendiri oleh kasir
  // (lihat Sheet "Atur Packing") — effect ini HANYA menyinkronkan
  // items/totalQty tiap Packing dengan cart, dan TIDAK PERNAH menimpa
  // box/plastik yang sudah diisi kasir.
  // Non-split: 1 Packing mengikuti seluruh isi cart apa adanya.
  // Split mode: JANGAN auto-tambah alokasi. Hanya cap ke bawah bila cart
  // qty berkurang dan hapus item yang sudah tidak ada di cart. Kasir
  // bertanggung jawab mengalokasikan sisa.
  useEffect(() => {
    if (cart.length === 0) {
      setPackings([]);
      setPackingCustom(false);
      return;
    }
    if (!packingCustom) {
      setPackings((prev) => {
        const items = cart.map((c) => ({ productId: c.productId, name: c.name, qty: c.qty }));
        const totalQty = items.reduce((a, b) => a + b.qty, 0);
        if (prev.length === 1) {
          // Pertahankan box/plastik yang sudah dipilih kasir — cuma
          // sinkronkan isi & totalQty mengikuti cart terbaru.
          return [{ ...prev[0], items, totalQty }];
        }
        return [buildManualPacking(items)];
      });
      return;
    }
    setPackings((prev) => {
      const cartMap = new Map(cart.map((c) => [c.productId, c] as const));
      let next = prev.map((p) => ({
        ...p,
        items: p.items
          .filter((it) => cartMap.has(it.productId))
          .map((it) => ({ ...it, name: cartMap.get(it.productId)!.name })),
      }));
      // Cap tiap produk ke cart qty; kurangi dari packing terakhir dulu.
      for (const c of cart) {
        let allocated = next.reduce(
          (a, p) => a + (p.items.find((it) => it.productId === c.productId)?.qty ?? 0),
          0,
        );
        let overshoot = allocated - c.qty;
        for (let i = next.length - 1; i >= 0 && overshoot > 0; i--) {
          const idx = next[i].items.findIndex((it) => it.productId === c.productId);
          if (idx < 0) continue;
          const take = Math.min(overshoot, next[i].items[idx].qty);
          overshoot -= take;
          const newQty = next[i].items[idx].qty - take;
          const items =
            newQty === 0
              ? next[i].items.filter((_, j) => j !== idx)
              : next[i].items.map((it, j) => (j === idx ? { ...it, qty: newQty } : it));
          next[i] = { ...next[i], items };
        }
      }
      return next.map((p) => recomputePacking(p));
    });
  }, [cart, packingCustom]);

  // Sprint 6 (Finding #7): debounced auto-save cart ke localStorage.
  useEffect(() => {
    if (!cartRestoredRef.current) return;
    const t = setTimeout(() => {
      try {
        if (cart.length === 0) {
          localStorage.removeItem(CART_DRAFT_KEY);
        } else {
          localStorage.setItem(
            CART_DRAFT_KEY,
            JSON.stringify({ cart, saleType, customerNotes }),
          );
        }
      } catch (err) {
        console.warn("[pos] save cart draft failed", err);
      }
    }, 1000);
    return () => clearTimeout(t);
  }, [cart, saleType, customerNotes]);

  const cartTotalQty = cart.reduce((a, c) => a + c.qty, 0);
  const packingsTotalQty = packings.reduce((a, p) => a + p.totalQty, 0);
  const allocationSummary = cart.map((c) => {
    const allocated = packings.reduce(
      (a, p) => a + (p.items.find((it) => it.productId === c.productId)?.qty ?? 0),
      0,
    );
    return {
      productId: c.productId,
      name: c.name,
      cart: c.qty,
      allocated,
      remaining: c.qty - allocated,
    };
  });
  const anyRemaining = allocationSummary.some((s) => s.remaining !== 0);
  const hasEmptyPacking = packings.length > 0 && packings.some((p) => p.totalQty === 0);
  const packingConsistent = !anyRemaining && !hasEmptyPacking;

  // Real-time packaging shortage: hitung kebutuhan Launch Box + plastik
  // (diisi manual oleh kasir per Packing) + extras vs stok inventory saat
  // ini, supaya kasir tahu SEBELUM klik "Bayar" kalau packaging yang
  // dipilih tidak akan cukup.
  const packagingShortages = useMemo(() => {
    const needed = new Map<string, { name: string; qty: number }>();
    const add = (
      itemId: string | undefined,
      itemName: string | undefined,
      qty: number,
    ) => {
      if (qty <= 0) return;
      // Resolve ke inventory id (fallback via nama bila itemId kosong).
      let inv = itemId ? packagingItems.find((i) => i.id === itemId) : undefined;
      if (!inv && itemName) {
        inv = packagingItems.find(
          (i) => i.name.toLowerCase() === itemName.toLowerCase(),
        );
      }
      if (!inv) return; // packaging tidak terhubung inventory → tidak dicek
      const cur = needed.get(inv.id);
      if (cur) cur.qty += qty;
      else needed.set(inv.id, { name: inv.name, qty });
    };
    for (const p of packings) {
      add(p.boxItemId, p.boxItemName, p.boxQty);
      if (p.plastic) add(p.plastic.itemId, p.plastic.itemName, p.plastic.qty);
    }
    extras.forEach((e) => add(e.itemId, e.itemName, e.qty));
    const out: { itemId: string; name: string; needed: number; stock: number; short: number }[] = [];
    needed.forEach((v, itemId) => {
      const inv = packagingItems.find((i) => i.id === itemId);
      const stock = inv?.stock ?? 0;
      if (v.qty > stock) {
        out.push({ itemId, name: v.name, needed: v.qty, stock, short: v.qty - stock });
      }
    });
    return out;
  }, [packings, extras, packagingItems]);
  const hasPackagingShortage = packagingShortages.length > 0;





  const categories = useMemo(
    () => ["Semua", ...Array.from(new Set(products.map((p) => p.category)))],
    [products],
  );

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== "Semua" && p.category !== category) return false;
      if (!q) return true;
      const extra = p as unknown as { barcode?: string; code?: string };
      const haystack = [p.name, p.sku, extra.barcode, extra.code]
        .filter(Boolean)
        .map((v) => String(v).toLowerCase());
      return haystack.some((h) => h.includes(q));
    });
  }, [products, category, query]);

  const subtotal = cart.reduce((a, c) => a + c.price * c.qty, 0);
  const total = subtotal;

  // ---- Split-payment helpers (Sprint 7) ----
  const cashEntry = paymentEntries.find((e) => e.method === "cash");
  const tendered = cashEntry?.amount ?? 0;
  const nonCashPaid = paymentEntries
    .filter((e) => e.method !== "cash")
    .reduce((a, e) => a + (e.amount || 0), 0);
  const paidTotal = sumPaymentEntries(paymentEntries);
  const overpaidNonCash = nonCashPaid > total; // Opsi B: hanya cash boleh lebih.
  const shortage = Math.max(0, total - paidTotal);
  const changeDue = Math.max(0, paidTotal - total);
  const canCheckout = shortage === 0 && !overpaidNonCash;
  const setTendered = (v: number | ((prev: number) => number)) => {
    setPaymentEntries((prev) => {
      const next = [...prev];
      const idx = next.findIndex((e) => e.method === "cash");
      const nv = typeof v === "function" ? v(idx >= 0 ? next[idx].amount : 0) : v;
      if (idx >= 0) next[idx] = { ...next[idx], amount: Math.max(0, nv) };
      else next.push({ method: "cash", amount: Math.max(0, nv) });
      return next;
    });
  };
  const setPaymentEntryAmount = (method: PaymentMethod, amount: number) => {
    setPaymentEntries((prev) => {
      const idx = prev.findIndex((e) => e.method === method);
      const clamped = Math.max(0, amount);
      if (idx < 0) return [...prev, { method, amount: clamped }];
      const next = [...prev];
      next[idx] = { ...next[idx], amount: clamped };
      return next;
    });
  };
  const setPaymentEntryMethod = (index: number, method: PaymentMethod) => {
    setPaymentEntries((prev) => {
      // Cegah duplikasi metode.
      if (prev.some((e, i) => i !== index && e.method === method)) return prev;
      const next = [...prev];
      next[index] = { ...next[index], method };
      return next;
    });
  };
  const addPaymentEntry = () => {
    setPaymentEntries((prev) => {
      const used = new Set(prev.map((e) => e.method));
      const nextMethod = (["cash", "qris", "card", "transfer"] as PaymentMethod[]).find(
        (m) => !used.has(m),
      );
      if (!nextMethod) return prev;
      return [...prev, { method: nextMethod, amount: 0 }];
    });
  };
  const removePaymentEntry = (index: number) => {
    setPaymentEntries((prev) => (prev.length <= 1 ? prev : prev.filter((_, i) => i !== index)));
  };
  const productImageMap = useMemo(
    () => new Map(products.map((p) => [p.id, p.imageUrl] as const)),
    [products],
  );

  function stockOf(productId: string): number | undefined {
    return products.find((p) => p.id === productId)?.stock;
  }

  function addToCart(p: Product) {
    const stock = p.stock;
    const inCart = cart.find((c) => c.productId === p.id)?.qty ?? 0;
    // Pre Order tidak memotong stok saat dibuat, jadi semua produk boleh
    // dipilih meskipun ready stock 0/kurang. Validasi ketersediaan
    // dilakukan saat Complete PO (lihat preorder-page.tsx).
    if (!isPreorder && typeof stock === "number" && inCart + 1 > stock) {
      toast.error(`Stok ${p.name} tidak mencukupi (tersedia ${stock})`);
      return;
    }
    setCart((prev) => {
      const i = prev.findIndex((c) => c.productId === p.id);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + 1 };
        return next;
      }
      return [
        ...prev,
        {
          productId: p.id,
          name: p.name,
          price: priceFor(p, activePriceGroupId, customerType),
          cost: p.cost,
          qty: 1,
        },
      ];
    });
  }

  function adjust(productId: string, delta: number) {
    if (delta > 0 && !isPreorder) {
      const stock = stockOf(productId);
      const inCart = cart.find((c) => c.productId === productId)?.qty ?? 0;
      if (typeof stock === "number" && inCart + delta > stock) {
        toast.error(`Stok tidak mencukupi (tersedia ${stock})`);
        return;
      }
    }
    setCart((prev) =>
      prev
        .map((c) => (c.productId === productId ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0),
    );
  }


  function remove(productId: string) {
    setCart((prev) => prev.filter((c) => c.productId !== productId));
  }

  async function openPayment() {
    if (!cart.length) return;
    const activeShift = await shiftService.current();
    if (!activeShift) {
      setHasShift(false);
      toast.error("Buka shift terlebih dahulu sebelum transaksi");
      return;
    }
    if (!packingConsistent) {
      toast.error(
        anyRemaining
          ? "Alokasikan seluruh qty ke Packing sebelum bayar"
          : "Packing tidak boleh kosong",
      );
      setPackingOpen(true);
      return;
    }
    // Pre-check stok packaging (Launch Box/plastik/extras) — sama seperti
    // pre-check stok produk di completeSale(), supaya kasir tahu masalah
    // SEBELUM submit, bukan setelah checkout gagal. Tidak berlaku untuk Pre
    // Order karena PO tidak memotong stok packaging saat disimpan.
    if (!isPreorder && hasPackagingShortage) {
      toast.error(
        `Stok packaging tidak mencukupi: ${packagingShortages
          .map((s) => `${s.name} (tersedia ${s.stock}, butuh ${s.needed})`)
          .join("; ")}`,
        { duration: IMPORTANT_TOAST_DURATION },
      );
      setPackingOpen(true);
      return;
    }
    if (isPreorder) {
      // Sprint 5: default DP kosong (opsional). Kasir boleh skip.
      setDpAmount(0);
      setDpMethod("cash");
    } else {
      // Reset ke satu entri cash dengan jumlah = total (siap 1-tap "PAS").
      setPaymentEntries([{ method: "cash", amount: total }]);
    }
    setPaymentOpen(true);
  }

  // Keyboard shortcuts POS (tidak bentrok dengan shortcut browser):
  //  Enter = Checkout · Esc = tutup dialog · F2 = fokus search
  //  F4 = Payment · Ctrl+P = Print Invoice
  // Pengecualian: saat dialog Pre Order (DP) terbuka, Enter TIDAK auto-submit
  // — mencegah kasir yang refleks pencet Enter tidak sadar mengonfirmasi DP
  // sebelum sempat cek ulang tanggal/jam pickup & nomor HP customer. Kasir
  // harus klik tombol konfirmasi secara sadar untuk Pre Order.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const typing =
        !!target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (e.key === "F2") {
        e.preventDefault();
        searchRef.current?.focus();
      } else if (e.key === "F4") {
        e.preventDefault();
        if (!paymentOpen) openPayment();
      } else if (e.key === "Escape") {
        if (paymentOpen) setPaymentOpen(false);
        if (packingOpen) setPackingOpen(false);
      } else if ((e.ctrlKey || e.metaKey) && (e.key === "p" || e.key === "P")) {
        e.preventDefault();
        printReceipt();
      } else if (e.key === "Enter" && !typing) {
        if (paymentOpen && isPreorder) return; // lihat catatan di atas — perlu klik manual
        e.preventDefault();
        if (paymentOpen) completeSale();
        else openPayment();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentOpen, packingOpen, cart, total, lastSale, isPreorder]);




  async function completeSale() {
    // Idempoten terhadap double-click / double-Enter: bila sedang memproses,
    // panggilan berikutnya diabaikan sampai proses selesai (finally).
    if (isCompletingRef.current) return;
    isCompletingRef.current = true;
    setIsCompleting(true);
    try {
    const cashier = cashierName;
    const shift = await shiftService.current();
    if (!shift) {
      setHasShift(false);
      setPaymentOpen(false);
      toast.error("Shift tidak aktif. Transaksi dibatalkan.");
      return;
    }
    // Validasi Pre Order
    if (isPreorder) {
      if (!customerName.trim()) {
        toast.error("Nama customer wajib untuk Pre Order");
        return;
      }
      const pickupErr = validatePickup(pickupDate, pickupTime);
      if (pickupErr) {
        toast.error(pickupErr);
        return;
      }
    }
    // Validasi stok final (jaga-jaga bila stok berubah dari tab lain).
    const fresh = await productService.list();
    // Sprint 6 (Finding #8): validasi produk masih ada & aktif. Jangan
    // silent-skip — kasir harus perbaiki cart dulu.
    const invalidNames: string[] = [];
    for (const line of cart) {
      const p = fresh.find((x) => x.id === line.productId);
      if (!p) invalidNames.push(`${line.name} (dihapus)`);
      else if (!p.active) invalidNames.push(`${p.name} (nonaktif)`);
    }
    if (invalidNames.length > 0) {
      toast.error(
        `Checkout dibatalkan. Produk bermasalah: ${invalidNames.join(", ")}. Hapus dari cart untuk melanjutkan.`,
      );
      return;
    }
    if (!isPreorder) {
      for (const line of cart) {
        const p = fresh.find((x) => x.id === line.productId);
        if (p && typeof p.stock === "number" && line.qty > p.stock) {
          toast.error(`Stok ${p.name} tidak mencukupi (tersedia ${p.stock})`);
          return;
        }
      }
    }

    // Sprint 5: Untuk Pre Order, dialog "Pembayaran" menjadi dialog DP
    // (opsional). DP boleh 0 sampai dengan total. Tidak butuh tendered.
    const dpClamped = isPreorder
      ? Math.max(0, Math.min(dpAmount || 0, total))
      : 0;
    if (!isPreorder) {
      if (overpaidNonCash) {
        toast.error("QRIS/Kartu/Transfer tidak boleh melebihi total");
        return;
      }
      if (shortage > 0) {
        toast.error("Pembayaran kurang dari total");
        return;
      }
    }
    // Customer is mandatory — fall back to the configured default name
    // so the receipt and history always have a value.
    const finalCustomer = customerName.trim() || defaultCustomerName;
    const pickupAt =
      isPreorder && pickupDate && pickupTime
        ? new Date(`${pickupDate}T${pickupTime}`).toISOString()
        : undefined;
    // Sprint 9: Pre Order — TIDAK PERNAH membuat Sale di titik ini
    // (baik DP=0 maupun DP>0). Sale untuk PO hanya dibuat sekali di
    // titik Complete (finalizeComplete di preorder-page.tsx). Ini
    // menghindari double-count omset/COGS/stok.
    let createdPreorder: PreOrder | null = null;
    if (isPreorder && pickupDate && pickupTime) {
      try {
        createdPreorder = await preorderService.create({
          customerName: finalCustomer,
          customerPhone: customerPhone.trim() || undefined,
          date: pickupDate,
          time: pickupTime,
          items: cart,
          sourceOrder,
          priceGroupId: activePriceGroupId,
          saleType,
          createdBy: cashier,
          downPayment: dpClamped,
          dpMethod: dpClamped > 0 ? dpMethod : undefined,
          // Gap #5 (Packaging Fix): bawa rencana Packing yang sudah diatur
          // kasir (auto atau custom/split) sampai ke Pre Order, supaya
          // finalizeComplete() nanti tidak selalu fallback ke "1 Packing
          // gabungan berisi seluruh item" — lihat preorder-page.tsx.
          packings,
        });
      } catch (err) {
        console.error("[pos] create PreOrder failed", err);
      }
    }
    // Extras payload — packaging tambahan yang dipilih manual oleh kasir
    // (di luar box/plastik per Packing).
     const extrasPayload: SaleExtraPackaging[] | undefined =
       extras.length > 0
         ? extras.filter((e) => e.qty > 0 && e.itemName.trim().length > 0)
         : undefined;
     if (!packingConsistent) {
       toast.error("Jumlah item di Packing belum sama dengan Cart");
       return;
     }
     if (isPreorder) {
       // PO branch — tidak ada Sale, tidak ada deduksi stok.
       if (activeHoldId) {
         await holdService.remove(activeHoldId);
         invalidateHolds();
         setActiveHoldId(null);
       }
       if (dpClamped > 0 && createdPreorder) {
         toast.success(
           `Pre Order tercatat — DP ${formatIDR(dpClamped)} diterima, sisa ${formatIDR(Math.max(0, total - dpClamped))}`,
         );
         setLastPreorderDp(createdPreorder);
       } else {
         toast.success("Pre Order tercatat (tanpa DP)");
       }
       setCart([]);
       try { localStorage.removeItem(CART_DRAFT_KEY); } catch { /* ignore */ }
       setCustomerName("");
       setCustomerNotes("");
       setCustomerPhone("");
       setPickupDate("");
       setPickupTime("");
       setIsPreorder(false);
       setPaymentOpen(false);
       setPackings([]);
       setPackingCustom(false);
       setExtras([]);
       setDpAmount(0);
       invalidateProducts();
       invalidatePackaging();
       setTimeout(() => searchRef.current?.focus(), 50);
       return;
     }
      let sale: Sale;
      try {
        sale = await salesService.create({
          cashier,
          customerName: finalCustomer,
          shiftId: shift.id,
          items: cart,
          subtotal,
          total,
          payment: paymentEntries.filter((e) => e.amount > 0),
          tendered: tendered > 0 ? tendered : undefined,
          change: changeDue || undefined,
          saleType,
          customerType,
          isPreorder,
          customerPhone: customerPhone.trim() || undefined,
          pickupAt,
          sourceOrder,
          priceGroupId: activePriceGroupId,
          packings,
          extraPackaging: extrasPayload,
          customerNotes: customerNotes.trim() || undefined,
        });
      } catch (err) {
        // Kegagalan checkout (stok ready/packaging kurang, dsb.) — surface
        // pesan spesifik dari service (mis. "Stok packaging tidak mencukupi:
        // Launch Box Sedang (tersedia 2, butuh 3)"). Cart TIDAK direset,
        // dialog TIDAK ditutup, tombol Bayar re-enable via finally.
        const msg = err instanceof Error ? err.message : "Checkout gagal — coba lagi";
        console.error("[pos] checkout failed", err);
        toast.error(msg, { duration: IMPORTANT_TOAST_DURATION });
        // Refresh stok packaging supaya indikator real-time sinkron dengan
        // kondisi terbaru (mungkin stok berubah dari tab/perangkat lain).
        invalidatePackaging();
        invalidateProducts();
        return;
      }

    if (activeHoldId) {
      await holdService.remove(activeHoldId);
      invalidateHolds();
      setActiveHoldId(null);
    }
    setCart([]);
    try { localStorage.removeItem(CART_DRAFT_KEY); } catch { /* ignore */ }
    setCustomerName("");
    setCustomerNotes("");
    setCustomerPhone("");
    setPickupDate("");
    setPickupTime("");
    setIsPreorder(false);
    setPaymentOpen(false);
    setLastSale(sale);
    setPackings([]);
    setPackingCustom(false);
    setExtras([]);
    setDpAmount(0);
    // Refresh daftar produk & inventory packaging supaya stok terlihat berkurang.
    invalidateProducts();
    invalidatePackaging();
    // Fokus balik ke pencarian untuk transaksi berikutnya.
    setTimeout(() => searchRef.current?.focus(), 50);
    } finally {
      isCompletingRef.current = false;
      setIsCompleting(false);
    }
  }

  function quickCash(amount: number) {
    setTendered((prev) => (prev || 0) + amount);
  }

  async function holdCurrent() {
    if (!cart.length) {
      toast.error("Keranjang masih kosong");
      return;
    }
    const name = customerName.trim() || defaultCustomerName;
    await holdService.save(cart, name);
    invalidateHolds();
    setCart([]);
    setCustomerName("");
    setActiveHoldId(null);
    toast.success("Pesanan ditahan");
  }

  function restoreHold(order: HoldOrder) {
    setCart(order.items);
    setCustomerName(
      order.customerName && order.customerName !== defaultCustomerName ? order.customerName : "",
    );
    setActiveHoldId(order.id);
    // Cek stok terbaru vs qty yang ditahan — kalau berubah sejak hold,
    // kasir perlu tahu SEBELUM coba checkout (jangan hanya toast generik
    // "Pesanan dimuat" lalu gagal di /Bayar/). Pakai cache react-query
    // (bukan round-trip baru, dan bukan `products` yang sudah difilter
    // aktif-saja — di sini butuh full list supaya bisa bedakan "dihapus"
    // vs "nonaktif"); validasi final tetap terjadi lagi (fresh fetch) di
    // completeSale().
    const fresh = productsQ.data ?? [];
    const shortages: string[] = [];
    for (const line of order.items) {
      const p = fresh.find((x) => x.id === line.productId);
      if (!p) {
        shortages.push(`${line.name} (produk sudah dihapus)`);
        continue;
      }
      if (!p.active) {
        shortages.push(`${p.name} (nonaktif)`);
        continue;
      }
      if (typeof p.stock === "number" && line.qty > p.stock) {
        shortages.push(`${p.name} (butuh ${line.qty}, tersedia ${p.stock})`);
      }
    }
    if (shortages.length > 0) {
      toast.error(
        `Pesanan dimuat, tapi stok berubah sejak ditahan — sesuaikan sebelum checkout: ${shortages.join("; ")}`,
        { duration: IMPORTANT_TOAST_DURATION },
      );
    } else {
      toast.success(`Pesanan ${order.customerName} dimuat`);
    }
  }


  async function dropHold(id: string) {
    await holdService.remove(id);
    invalidateHolds();
    if (activeHoldId === id) setActiveHoldId(null);
  }

  function printReceipt() {
    if (!lastSale) return;
    // Sprint 6 (Finding #6): tandai cetak ulang sebagai SALINAN. Klik
    // pertama = cetak asli; klik berikutnya untuk sale yang sama = SALINAN.
    const isReprint = printedSaleIdsRef.current.has(lastSale.id);
    if (!printSaleReceipt(lastSale, isReprint)) {
      toast.error("Popup diblokir browser");
      return;
    }
    printedSaleIdsRef.current.add(lastSale.id);
  }


  // ---- Packing manipulation ----
  function enableCustomPacking() {
    setPackingCustom(true);
    if (packings.length === 0 && cart.length > 0) {
      setPackings([
        buildManualPacking(cart.map((c) => ({ productId: c.productId, name: c.name, qty: c.qty }))),
      ]);
    }
  }
  function addPacking() {
    setPackingCustom(true);
    setPackings((prev) => [
      ...prev,
      { id: newPackingId(), items: [], totalQty: 0, boxItemId: undefined, boxItemName: "", boxQty: 0 },
    ]);
  }
  function removePacking(pid: string) {
    setPackings((prev) => {
      if (prev.length <= 1) return prev;
      const removed = prev.find((p) => p.id === pid);
      const rest = prev.filter((p) => p.id !== pid);
      if (!removed) return rest;
      // Pindahkan item removed ke packing pertama agar alokasi tetap konsisten.
      const p0 = rest[0];
      const merged = [...p0.items];
      for (const it of removed.items) {
        const idx = merged.findIndex((x) => x.productId === it.productId);
        if (idx >= 0) merged[idx] = { ...merged[idx], qty: merged[idx].qty + it.qty };
        else merged.push(it);
      }
      rest[0] = recomputePacking({ ...p0, items: merged });
      return rest;
    });
  }
  function setItemQty(pid: string, productId: string, rawQty: number) {
    setPackingCustom(true);
    const cartLine = cart.find((c) => c.productId === productId);
    if (!cartLine) return;
    setPackings((prev) => {
      const otherAlloc = prev.reduce(
        (a, p) =>
          a +
          (p.id === pid ? 0 : p.items.find((it) => it.productId === productId)?.qty ?? 0),
        0,
      );
      const maxAllowed = Math.max(0, cartLine.qty - otherAlloc);
      const qty = Math.max(0, Math.min(Math.floor(rawQty || 0), maxAllowed));
      return prev.map((p) => {
        if (p.id !== pid) return p;
        const idx = p.items.findIndex((it) => it.productId === productId);
        let items = p.items;
        if (qty === 0) {
          if (idx >= 0) items = items.filter((_, j) => j !== idx);
        } else if (idx >= 0) {
          items = items.map((it, j) => (j === idx ? { ...it, qty } : it));
        } else {
          items = [...items, { productId, name: cartLine.name, qty }];
        }
        return recomputePacking({ ...p, items });
      });
    });
  }
  function setPackingLabel(pid: string, label: string) {
    setPackings((prev) => prev.map((p) => (p.id === pid ? { ...p, label } : p)));
  }
  // ---- Box & Plastik manual per Packing ----
  function setPackingBoxItem(pid: string, item: InventoryItem | undefined) {
    setPackings((prev) =>
      prev.map((p) =>
        p.id === pid
          ? {
              ...p,
              boxItemId: item?.id,
              boxItemName: item?.name ?? "",
              boxQty: p.boxQty > 0 ? p.boxQty : item ? 1 : 0,
            }
          : p,
      ),
    );
  }
  function setPackingBoxQty(pid: string, qty: number) {
    setPackings((prev) =>
      prev.map((p) => (p.id === pid ? { ...p, boxQty: Math.max(0, Math.floor(qty || 0)) } : p)),
    );
  }
  function setPackingPlasticItem(pid: string, item: InventoryItem | undefined) {
    setPackings((prev) =>
      prev.map((p) => {
        if (p.id !== pid) return p;
        if (!item) return { ...p, plastic: undefined };
        return {
          ...p,
          plastic: { itemId: item.id, itemName: item.name, qty: p.plastic?.qty && p.plastic.qty > 0 ? p.plastic.qty : 1 },
        };
      }),
    );
  }
  function setPackingPlasticQty(pid: string, qty: number) {
    setPackings((prev) =>
      prev.map((p) => {
        if (p.id !== pid || !p.plastic) return p;
        const q = Math.max(0, Math.floor(qty || 0));
        return q === 0 ? { ...p, plastic: undefined } : { ...p, plastic: { ...p.plastic, qty: q } };
      }),
    );
  }

  function addExtra() {
    setExtras((prev) => [...prev, { itemName: "", qty: 1 }]);
  }
  function updateExtra(idx: number, patch: Partial<SaleExtraPackaging>) {
    setExtras((prev) => prev.map((e, i) => (i === idx ? { ...e, ...patch } : e)));
  }
  function removeExtra(idx: number) {
    setExtras((prev) => prev.filter((_, i) => i !== idx));
  }

  // Capability guard: block roles without POS access (defense in depth on top
  // of the root route guard).
  if (!canAccessPos) {
    return <AccessDenied />;
  }

  return (
    <div
      className="flex h-[calc(100vh-3.5rem)] flex-col page-enter"
      style={{ backgroundColor: "var(--pos-page)" }}
    >



      <div className="grid min-h-0 flex-1 grid-cols-1 min-[720px]:grid-cols-[minmax(0,1fr)_320px] xl:grid-cols-[minmax(0,1fr)_420px]">
      <div className="flex min-h-0 min-w-0 flex-col gap-4 p-4 xl:p-6 min-[720px]:pr-2 xl:pr-4">


        {!hasShift && (
          <Card className="border-amber-500/30 bg-amber-500/5">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
              <div className="flex min-w-0 items-center gap-3">
                <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" strokeWidth={1.75} />
                <span className="text-foreground">
                  Tidak ada shift aktif. Buka shift sebelum melakukan transaksi.
                </span>
              </div>
              <Button asChild size="sm" variant="outline">
                <Link to="/sales/shifts">Buka shift</Link>
              </Button>
            </CardContent>
          </Card>
        )}
        {holds.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="shrink-0 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Hold
            </span>
            <div className="-mx-1 flex flex-1 gap-2 overflow-x-auto px-1 pb-1">
              {holds.map((h) => {
                const isActive = h.id === activeHoldId;
                return (
                  <div
                    key={h.id}
                    className={`group inline-flex shrink-0 items-center gap-2 rounded-full border pl-3 pr-1 py-1 text-xs transition ${
                      isActive
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-card hover:border-primary/40"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => restoreHold(h)}
                      className="flex items-center gap-2"
                    >
                      <PauseCircle className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
                      <span className="max-w-[140px] truncate font-medium">{h.customerName}</span>
                      <span className="tabular-nums text-muted-foreground">
                        {formatIDR(h.total)}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => dropHold(h.id)}
                      aria-label={`Hapus hold ${h.customerName}`}
                      className="grid h-5 w-5 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-destructive"
                    >
                      <X className="h-3 w-3" strokeWidth={2} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        <ProductGrid
          searchRef={searchRef}
          query={query}
          setQuery={setQuery}
          categories={categories}
          category={category}
          setCategory={setCategory}
          visible={visible}
          cart={cart}
          isPreorder={isPreorder}
          activePriceGroupId={activePriceGroupId}
          customerType={customerType}
          addToCart={addToCart}
        />
      </div>


      <aside className="m-4 ml-2 mt-4 flex min-h-0 flex-col overflow-hidden rounded-[22px] pos-panel min-[720px]:sticky min-[720px]:top-4 min-[720px]:h-[calc(100vh-3.5rem-2rem)]">
        <div className="flex items-center justify-between gap-2 border-b px-4 py-2">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
              <Receipt className="h-4 w-4" strokeWidth={1.75} />
            </span>
            <div className="flex min-w-0 flex-col leading-tight">
              <span className="text-sm font-semibold">Pesanan Saat Ini</span>
              <span className="text-[11px] text-muted-foreground">
                {cart.length} item · {cartTotalQty} qty
                {activeHoldId ? " · dari Hold" : ""}
              </span>
            </div>
          </div>
          {cart.length > 0 && (
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" onClick={holdCurrent} disabled={!hasShift} title="Tahan pesanan">
                <PauseCircle className="h-4 w-4" /> Tahan
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setCart([]);
                  setActiveHoldId(null);
                }}
                title="Kosongkan keranjang"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Customer + order settings — hierarki: Nama → Telepon → Catatan → Source → PO. */}
        <div className="space-y-1.5 px-4 py-2" style={{ backgroundColor: "var(--pos-surface-2)", borderBottom: "1px solid var(--pos-border-soft)" }}>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="customer" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Customer
              </Label>
              <div className="relative mt-0.5">
                <User className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder={defaultCustomerName}
                  className="h-8 pl-8 text-sm"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="customer-phone" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                No. Telepon
              </Label>
              <div className="relative mt-0.5">
                <Phone className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer-phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0812xxxxxxxx"
                  className="h-8 pl-8 text-sm"
                  inputMode="tel"
                />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-[1fr_auto] items-end gap-2">
            <div>
              <Label htmlFor="customer-notes" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Catatan <span className="normal-case text-muted-foreground/70">(opsional)</span>
              </Label>
              <div className="relative mt-0.5">
                <StickyNote className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer-notes"
                  value={customerNotes}
                  onChange={(e) => setCustomerNotes(e.target.value)}
                  placeholder="Contoh: tidak pedas, dipisah…"
                  className="h-8 pl-8 text-sm"
                />
              </div>
            </div>
            <div className="flex h-8 shrink-0 overflow-hidden rounded-md border text-[11px]">
              <button
                type="button"
                onClick={() => setCustomerType("end_user")}
                aria-pressed={customerType === "end_user"}
                className={`px-2.5 font-medium transition ${customerType === "end_user" ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted"}`}
              >
                End User
              </button>
              <button
                type="button"
                onClick={() => setCustomerType("reseller")}
                aria-pressed={customerType === "reseller"}
                className={`px-2.5 font-medium transition ${customerType === "reseller" ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted"}`}
              >
                Reseller
              </button>
            </div>
          </div>


          <div className="rounded-lg border border-border/70 bg-muted/30 p-2">
            <div className="mb-1 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              <Store className="h-3.5 w-3.5" strokeWidth={1.75} />
              Source Order
            </div>
            <div className="flex items-center gap-1.5">
              <Select value={sourceOrder} onValueChange={(v) => setSourceOrder(v as SourceOrder)}>
                <SelectTrigger className="h-8 flex-1 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SOURCE_ORDER_LIST.map((s) => (
                    <SelectItem key={s} value={s}>
                      {SOURCE_ORDER_LABEL[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex overflow-hidden rounded-md border">
                <button
                  type="button"
                  onClick={() => setSaleType("frozen")}
                  title="Frozen"
                  aria-pressed={saleType === "frozen"}
                  className={`grid h-8 w-8 place-items-center transition ${
                    saleType === "frozen" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <Snowflake className="h-3.5 w-3.5" strokeWidth={1.75} />
                </button>
                <button
                  type="button"
                  onClick={() => setSaleType("matang")}
                  title="Matang"
                  aria-pressed={saleType === "matang"}
                  className={`grid h-8 w-8 place-items-center transition ${
                    saleType === "matang" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <Flame className="h-3.5 w-3.5" strokeWidth={1.75} />
                </button>
              </div>
              <button
                type="button"
                onClick={() => setIsPreorder((v) => !v)}
                title="Pre Order"
                aria-pressed={isPreorder}
                className={`grid h-8 w-8 place-items-center rounded-md border transition ${
                  isPreorder ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <CalendarClock className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>
            {activePriceGroup && (
              <p className="mt-2 text-[10px] text-muted-foreground">
                Harga aktif: <span className="font-semibold text-foreground">{activePriceGroup.name}</span>
              </p>
            )}
          </div>

          <div
            className={`grid transition-all duration-200 ease-out ${
              isPreorder ? "mt-1 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
            }`}
            aria-hidden={!isPreorder}
          >
            <div className="overflow-hidden">
              <div
                className="grid gap-1.5 rounded-[14px] border p-2.5"
                style={{
                  backgroundColor: "#FAFAF8",
                  borderColor: "#ECE7E2",
                  boxShadow: "0 4px 12px rgba(70, 45, 25, 0.04)",
                }}
              >
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label
                      htmlFor="pickup-date"
                      className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      Tanggal Pengambilan
                    </Label>
                    <Input
                      id="pickup-date"
                      type="date"
                      value={pickupDate}
                      min={todayYmd()}
                      onChange={(e) => {
                        const v = e.target.value;
                        setPickupDate(v);
                        if (pickupTime && validatePickup(v, pickupTime)) {
                          setPickupTime("");
                        }
                      }}
                      disabled={!isPreorder}
                      tabIndex={isPreorder ? undefined : -1}
                      className="mt-0.5 h-8 text-sm"
                    />
                  </div>
                  <div>
                    <Label
                      htmlFor="pickup-time"
                      className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      Jam Pengambilan
                    </Label>
                    <Input
                      id="pickup-time"
                      type="time"
                      value={pickupTime}
                      min={pickupDate ? minPickupTimeFor(pickupDate) : undefined}
                      step={300}
                      onChange={(e) => setPickupTime(e.target.value)}
                      disabled={!isPreorder}
                      tabIndex={isPreorder ? undefined : -1}
                      className="mt-0.5 h-8 text-sm"
                    />
                  </div>
                </div>
                {isPreorder && pickupDate && pickupTime && validatePickup(pickupDate, pickupTime) && (
                  <p className="text-[11px] text-destructive">
                    {validatePickup(pickupDate, pickupTime)}
                  </p>
                )}
                {isPreorder && pickupDate === todayYmd() && (
                  <p className="text-[10px] text-muted-foreground">
                    Slot paling awal hari ini: {minPickupTimeFor(pickupDate)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Group 2 · Order Items — Daftar Pesanan (premium section, own scroll) */}
        <div className="flex min-h-0 flex-1 flex-col px-3 py-1.5">
          <section
            className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border bg-white"
            style={{
              borderColor: "#ECE7E2",
              boxShadow: "0 8px 24px rgba(70, 45, 25, 0.05)",
            }}
          >
            <header
              className="flex shrink-0 items-center gap-1.5 border-b px-3 py-1.5"
              style={{ borderColor: "#ECE7E2" }}
            >
              <ShoppingCart className="h-3 w-3 text-primary" strokeWidth={1.75} />
              <h3 className="text-[11px] font-semibold uppercase tracking-wider text-primary">Daftar Pesanan</h3>
              <span className="ml-auto text-[10px] tabular-nums text-muted-foreground">
                {cart.length} item
              </span>
            </header>


            <div className="min-h-0 flex-1 overflow-y-auto p-3">
              {cart.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center gap-3 py-10 text-center">
                  <div
                    className="grid h-16 w-16 place-items-center rounded-2xl text-primary"
                    style={{ backgroundColor: "#F6EFE9", border: "1px solid #ECE7E2" }}
                  >
                    <ShoppingBasket className="h-7 w-7" strokeWidth={1.5} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Belum ada pesanan</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Tambahkan produk untuk mulai transaksi.
                    </p>
                  </div>
                </div>
              ) : (
                <ul className="flex flex-col gap-2">
                  {cart.map((c) => {
                    const image = productImageMap.get(c.productId);
                    return (
                      <li
                        key={c.productId}
                        className="group flex items-center gap-2.5 rounded-[14px] border bg-white p-2.5 transition hover:-translate-y-0.5"
                        style={{
                          borderColor: "#ECE7E2",
                          boxShadow: "0 2px 8px rgba(70, 45, 25, 0.04)",
                        }}
                      >
                        {/* Product image */}
                        <div
                          className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-[10px]"
                          style={{
                            background:
                              "radial-gradient(85% 95% at 50% 30%, #FFFFFF 0%, #FBF7F1 100%)",
                            border: "1px solid #ECE7E2",
                          }}
                        >
                          {image ? (
                            <img
                              src={image}
                              alt={c.name}
                              loading="lazy"
                              className="h-full w-full object-contain"
                            />
                          ) : (
                            <ShoppingBasket
                              className="h-5 w-5 text-primary/40"
                              strokeWidth={1.5}
                            />
                          )}
                        </div>

                        {/* Name + unit price */}
                        <div className="min-w-0 flex-1">
                          <p className="line-clamp-2 text-[13px] font-semibold leading-snug text-foreground">
                            {c.name}
                          </p>
                          <p className="mt-0.5 text-[11px] tabular-nums text-muted-foreground">
                            {formatIDR(c.price)}
                          </p>
                        </div>

                        {/* Quantity stepper — circular, maroon hover */}
                        <div className="flex shrink-0 items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => adjust(c.productId, -1)}
                            className="grid h-8 w-8 place-items-center rounded-full border text-muted-foreground transition hover:border-primary hover:bg-primary/5 hover:text-primary active:scale-95"
                            style={{ borderColor: "#ECE7E2" }}
                            aria-label="Kurangi"
                          >
                            <Minus className="h-3.5 w-3.5" strokeWidth={2} />
                          </button>
                          <span className="min-w-[24px] text-center text-sm font-semibold tabular-nums text-foreground">
                            {c.qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => adjust(c.productId, 1)}
                            className="grid h-8 w-8 place-items-center rounded-full border text-muted-foreground transition hover:border-primary hover:bg-primary/5 hover:text-primary active:scale-95"
                            style={{ borderColor: "#ECE7E2" }}
                            aria-label="Tambah"
                          >
                            <Plus className="h-3.5 w-3.5" strokeWidth={2} />
                          </button>
                        </div>

                        {/* Subtotal */}
                        <div className="w-[76px] shrink-0 text-right">
                          <p className="text-[13px] font-semibold tabular-nums text-foreground">
                            {formatIDR(c.price * c.qty)}
                          </p>
                        </div>

                        {/* Delete — circular ghost, red hover */}
                        <button
                          type="button"
                          onClick={() => remove(c.productId)}
                          className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive active:scale-95"
                          aria-label="Hapus"
                        >
                          <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </section>
        </div>



        {/* Summary + checkout — premium sticky footer, cream, spacious. */}
        <div
          className="flex flex-col gap-2 px-4 py-2.5"
          style={{ backgroundColor: "var(--pos-page)", borderTop: "1px solid var(--pos-border-soft)" }}
        >
          {cart.length > 0 && (
            <button
              type="button"
              onClick={() => setPackingOpen(true)}
              className="flex items-center justify-between rounded-xl pos-item px-3.5 py-2 text-left text-[12px] hover:-translate-y-0.5"
            >
              <span className="flex items-center gap-2">
                <Package className="h-4 w-4 text-primary" strokeWidth={1.75} />
                <span className="font-semibold text-foreground">Packing</span>
                <span className="text-muted-foreground">
                  {packings.length} · {packingsTotalQty} pcs
                  {packings.length > 1
                    ? packings.some((p) => p.plastic && p.plastic.qty > 0)
                      ? ` · ${packings.reduce((a, p) => a + (p.plastic?.qty ?? 0), 0)} plastik (per Packing)`
                      : ""
                    : packings[0]?.plastic
                      ? ` · ${packings[0].plastic.itemName}`
                      : ""}
                  {extras.length > 0 ? ` · +${extras.length}` : ""}
                </span>
              </span>
              <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          )}
          <div className="pos-section px-4 py-2.5">
            <div className="flex items-end justify-between gap-2">
              <div className="flex flex-col leading-tight">
                <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  Grand Total
                </span>
                <span className="font-display text-[26px] font-bold leading-none tabular-nums text-primary mt-1">
                  {formatIDR(total)}
                </span>
              </div>
              <span className="pb-1 text-[11px] tabular-nums text-muted-foreground">
                {cartTotalQty} qty
              </span>
            </div>
          </div>
          <Button
            className="brand-gradient shadow-brand h-11 rounded-xl border-0 text-[13px] font-semibold tracking-wide text-primary-foreground transition hover:-translate-y-0.5 hover:shadow-[0_18px_40px_-18px_oklch(0.38_0.14_26_/_0.55)] active:scale-[0.99] disabled:cursor-not-allowed disabled:bg-none disabled:bg-muted disabled:text-muted-foreground disabled:shadow-none disabled:hover:translate-y-0"
            disabled={
              !cart.length ||
              !hasShift ||
              !packingConsistent ||
              (!isPreorder && hasPackagingShortage) ||
              isCompleting
            }
            onClick={openPayment}
          >
            <CreditCard className="mr-2 h-4 w-4" strokeWidth={1.75} />
            {!hasShift
              ? "Buka shift untuk bertransaksi"
              : !packingConsistent
                ? anyRemaining
                  ? `Alokasi Packing kurang ${cartTotalQty - packingsTotalQty}`
                  : "Packing kosong — perbaiki"
                : !isPreorder && hasPackagingShortage
                  ? "Stok packaging kurang — perbaiki"
                  : "Bayar"}
          </Button>

        </div>

      </aside>
      </div>



      {/* Atur Packing drawer */}
      <Sheet open={packingOpen} onOpenChange={setPackingOpen}>
        <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-lg">
          <SheetHeader className="border-b px-4 py-3">
            <SheetTitle className="flex items-center gap-2">
              <Package className="h-4 w-4" strokeWidth={1.75} />
              Atur Packing
            </SheetTitle>
            <p className="text-xs text-muted-foreground">
              Default seluruh produk = 1 Packing. Tanyakan ke customer: packaging mau dipisah?
              Bila tidak, isi 1 box + plastik sesuai kebutuhan. Bila dipisah, tambah Packing dan
              isi box + plastik untuk masing-masing.
            </p>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
            {/* Alokasi per produk */}
            {packingCustom && allocationSummary.length > 0 && (
              <div className="rounded-md border bg-muted/20 p-3 text-xs space-y-1.5">
                <div className="font-semibold uppercase tracking-wider text-muted-foreground">
                  Alokasi per Produk
                </div>
                {allocationSummary.map((s) => (
                  <div key={s.productId} className="flex items-center justify-between gap-2">
                    <span className="truncate">{s.name}</span>
                    <span className="tabular-nums text-muted-foreground">
                      Cart {s.cart} · Alokasi {s.allocated} ·{" "}
                      <span
                        className={
                          s.remaining === 0
                            ? "font-semibold text-emerald-600"
                            : "font-semibold text-amber-600"
                        }
                      >
                        Sisa {s.remaining}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            )}
            {/* Consistency banner */}
            {!packingConsistent && (
              <div className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-xs text-amber-700">
                {anyRemaining
                  ? `Alokasi belum sesuai Cart (${packingsTotalQty}/${cartTotalQty}).`
                  : "Ada Packing kosong. Hapus atau isi terlebih dahulu."}
              </div>
            )}
            {/* Packings */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Packing ({packings.length})
                </span>
                <div className="flex gap-1">
                  {packingCustom && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setPackingCustom(false);
                      }}
                    >
                      Reset ke 1 Packing
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={packingCustom ? addPacking : enableCustomPacking}
                  >
                    <Plus className="h-3.5 w-3.5" />
                    {packingCustom ? "Tambah Packing" : "Pisah Packing"}
                  </Button>
                </div>
              </div>
              {packings.map((p, idx) => (
                <div key={p.id} className="rounded-lg border bg-card p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold">Packing {idx + 1}</span>
                    {packings.length > 1 && (
                      <button
                        onClick={() => removePacking(p.id)}
                        className="text-xs text-muted-foreground hover:text-destructive"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                  {packingCustom && (
                    <Input
                      value={p.label ?? ""}
                      onChange={(e) => setPackingLabel(p.id, e.target.value)}
                      placeholder="Label (opsional) — mis. Rumah / Kantor"
                      className="h-8 text-xs"
                      maxLength={40}
                    />
                  )}
                  {packingCustom ? (
                    <ul className="flex flex-col divide-y">
                      {cart.map((c) => {
                        const line = p.items.find((it) => it.productId === c.productId);
                        const qty = line?.qty ?? 0;
                        const otherAlloc = packings.reduce(
                          (a, pp) =>
                            a +
                            (pp.id === p.id
                              ? 0
                              : pp.items.find((it) => it.productId === c.productId)?.qty ?? 0),
                          0,
                        );
                        const maxAllowed = Math.max(0, c.qty - otherAlloc);
                        return (
                          <li
                            key={c.productId}
                            className="flex items-center justify-between gap-2 py-2 text-sm"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="truncate">{c.name}</div>
                              <div className="text-[10px] text-muted-foreground tabular-nums">
                                Maks {maxAllowed} / Cart {c.qty}
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                type="button"
                                size="icon"
                                variant="outline"
                                className="h-7 w-7"
                                onClick={() => setItemQty(p.id, c.productId, qty - 1)}
                                disabled={qty <= 0}
                                aria-label="Kurangi"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <NumberInput
                                value={qty}
                                onChange={(v) => setItemQty(p.id, c.productId, v)}
                                min={0}
                                max={qty + maxAllowed}
                                className="h-7 w-14 text-center text-xs"
                              />
                              <Button
                                type="button"
                                size="icon"
                                variant="outline"
                                className="h-7 w-7"
                                onClick={() => setItemQty(p.id, c.productId, qty + 1)}
                                disabled={maxAllowed <= 0}
                                aria-label="Tambah"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  ) : (
                    <ul className="flex flex-col divide-y">
                      {p.items.length === 0 && (
                        <li className="py-2 text-xs italic text-muted-foreground">Belum ada item</li>
                      )}
                      {p.items.map((it) => (
                        <li key={it.productId} className="py-1.5 text-sm">
                          {it.qty}× {it.name}
                        </li>
                      ))}
                    </ul>
                  )}
                  {/* Box — dipilih manual oleh kasir dari Inventory kategori packaging. */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      Box
                    </span>
                    <div className="grid grid-cols-[1fr_72px] items-center gap-2">
                      <Select
                        value={p.boxItemId ?? ""}
                        onValueChange={(val) => {
                          const item = packagingItems.find((it) => it.id === val);
                          setPackingBoxItem(p.id, item);
                        }}
                      >
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Pilih box" />
                        </SelectTrigger>
                        <SelectContent>
                          {packagingItems.map((it) => (
                            <SelectItem key={it.id} value={it.id}>
                              {it.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <NumberInput
                        min={0}
                        value={p.boxQty}
                        onChange={(v) => setPackingBoxQty(p.id, v)}
                        className="h-9"
                      />
                    </div>
                    {!p.boxItemId && p.totalQty > 0 && (
                      <p className="text-[10px] text-amber-600">Box belum dipilih.</p>
                    )}
                  </div>
                  {/* Plastik — opsional, dipilih manual oleh kasir per Packing. */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      Plastik (opsional)
                    </span>
                    <div className="grid grid-cols-[1fr_72px] items-center gap-2">
                      <Select
                        value={p.plastic?.itemId ?? ""}
                        onValueChange={(val) => {
                          const item = packagingItems.find((it) => it.id === val);
                          setPackingPlasticItem(p.id, item);
                        }}
                      >
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Tidak pakai plastik" />
                        </SelectTrigger>
                        <SelectContent>
                          {packagingItems.map((it) => (
                            <SelectItem key={it.id} value={it.id}>
                              {it.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <NumberInput
                        min={0}
                        value={p.plastic?.qty ?? 0}
                        onChange={(v) => setPackingPlasticQty(p.id, v)}
                        disabled={!p.plastic}
                        className="h-9"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Real-time packaging shortage indicator — styled seperti indikator
                stok produk (destructive) supaya kasir langsung sadar SEBELUM
                klik Bayar bahwa transaksi akan gagal karena packaging kurang. */}
            {hasPackagingShortage && (
              <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-destructive">
                  <AlertTriangle className="h-3.5 w-3.5" strokeWidth={2} />
                  Stok packaging kurang
                </div>
                <ul className="mt-2 space-y-1 text-xs text-destructive">
                  {packagingShortages.map((s) => (
                    <li
                      key={s.itemId}
                      className="flex items-center justify-between gap-2 tabular-nums"
                    >
                      <span className="truncate font-medium">{s.name}</span>
                      <span className="shrink-0">
                        Sisa {s.stock} · butuh {s.needed}
                        <span className="ml-1 rounded bg-destructive/20 px-1.5 py-0.5 text-[10px] font-bold">
                          −{s.short}
                        </span>
                      </span>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-[10px] text-destructive/80">
                  Kurangi Launch Box/plastik, ubah packing, atau hubungi gudang sebelum checkout.
                </p>
              </div>
            )}


            {/* Extra packaging */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Packaging Tambahan
                </span>
                <Button size="sm" variant="outline" onClick={addExtra}>
                  <Plus className="h-3.5 w-3.5" /> Tambah
                </Button>
              </div>
              {extras.length === 0 && (
                <p className="text-[10px] italic text-muted-foreground">
                  Kosong. Tambah bila customer minta packaging ekstra.
                </p>
              )}
              {extras.map((ex, idx) => (
                <div key={idx} className="grid grid-cols-[1fr_80px_auto] items-center gap-2">
                  <Select
                    value={ex.itemId ?? ex.itemName ?? ""}
                    onValueChange={(val) => {
                      const item = packagingItems.find((p) => p.id === val);
                      updateExtra(idx, {
                        itemId: item?.id,
                        itemName: item?.name ?? val,
                      });
                    }}
                  >
                    <SelectTrigger className="h-9 text-xs">
                      <SelectValue placeholder="Pilih item packaging" />
                    </SelectTrigger>
                    <SelectContent>
                      {packagingItems.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <NumberInput
                    min={1}
                    value={ex.qty}
                    onChange={(v) => updateExtra(idx, { qty: Math.max(1, v) })}
                    className="h-9"
                  />
                  <Button size="icon" variant="ghost" onClick={() => removeExtra(idx)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <p className="text-[10px] text-muted-foreground">
                Harga Rp 0. Tetap mengurangi stok Inventory. Tercatat di Audit Log.
              </p>
            </div>
          </div>
          <SheetFooter className="border-t px-4 py-3">
            <Button
              className="w-full"
              disabled={!packingConsistent}
              onClick={() => setPackingOpen(false)}
            >
              {packingConsistent
                ? "Simpan Packing"
                : anyRemaining
                  ? "Alokasi belum penuh"
                  : "Ada Packing kosong"}
            </Button>
          </SheetFooter>

        </SheetContent>
      </Sheet>


      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
                <Wallet className="h-4 w-4" strokeWidth={2} />
              </span>
              {isPreorder ? "Down Payment (Opsional)" : "Pembayaran"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            {/* Amount hero */}
            <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-center">
              <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                {isPreorder ? "Total Order" : "Total Tagihan"}
              </div>
              <div className="mt-0.5 text-3xl font-bold tabular-nums text-primary">
                {formatIDR(total)}
              </div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {cart.length} produk · {cartTotalQty} qty
              </div>
            </div>

            {isPreorder && (
              <div className="flex flex-col gap-3">
                <p className="rounded-md border border-dashed border-primary/30 bg-primary/5 px-3 py-2 text-[11px] text-muted-foreground">
                  DP bersifat opsional. Kosongkan bila customer belum bayar
                  uang muka — sisa dibayar saat pengambilan.
                </p>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="dp-amount" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                    Nominal DP
                  </Label>
                  <NumberInput
                    id="dp-amount"
                    min={0}
                    max={total}
                    value={dpAmount}
                    onChange={(v) => setDpAmount(Math.max(0, Math.min(v || 0, total)))}
                    className="h-12 text-xl font-bold tabular-nums"
                    autoFocus
                  />
                  <div className="flex flex-wrap gap-1.5">
                    <Button type="button" size="sm" variant="ghost" onClick={() => setDpAmount(0)}>
                      Tanpa DP
                    </Button>
                    {[0.25, 0.5, 1].map((r) => (
                      <Button
                        key={r}
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => setDpAmount(Math.round(total * r))}
                        className="tabular-nums"
                      >
                        {r === 1 ? "Lunas" : `${Math.round(r * 100)}%`}
                      </Button>
                    ))}
                  </div>
                </div>
                {dpAmount > 0 && (
                  <div className="flex flex-col gap-2">
                    <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                      Metode DP
                    </Label>
                    <div className="grid grid-cols-2 min-[380px]:grid-cols-4 gap-2">
                      {(["cash", "qris", "card", "transfer"] as PaymentMethod[]).map((m) => {
                        const Icon = PAYMENT_ICONS[m];
                        const active = dpMethod === m;
                        return (
                          <button
                            key={m}
                            type="button"
                            aria-pressed={active}
                            onClick={() => setDpMethod(m)}
                            className={`flex flex-col items-center justify-center gap-1 rounded-xl border px-2 py-3 text-xs font-semibold transition ${
                              active
                                ? "border-primary bg-primary/10 text-primary shadow-sm"
                                : "border-border/70 bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                            }`}
                          >
                            <Icon className="h-5 w-5" strokeWidth={1.75} />
                            {PAYMENT_LABELS[m]}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between rounded-lg border bg-muted/30 px-3 py-2 text-sm">
                  <span className="text-muted-foreground">Sisa (Pelunasan)</span>
                  <span className="text-lg font-bold tabular-nums">
                    {formatIDR(Math.max(0, total - (dpAmount || 0)))}
                  </span>
                </div>
              </div>
            )}

            {!isPreorder && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Metode Bayar
                </Label>
                {paymentEntries.length < 4 && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={addPaymentEntry}
                    className="h-7 px-2 text-xs"
                  >
                    + Tambah metode
                  </Button>
                )}
              </div>

              <div className="flex flex-col gap-2">
                {paymentEntries.map((entry, idx) => {
                  const Icon = PAYMENT_ICONS[entry.method];
                  const usedMethods = new Set(
                    paymentEntries.filter((_, i) => i !== idx).map((e) => e.method),
                  );
                  const isCash = entry.method === "cash";
                  return (
                    <div
                      key={idx}
                      className="flex flex-col gap-2 rounded-xl border border-border/70 bg-card p-2.5"
                    >
                      <div className="flex items-center gap-2">
                        <div className="grid grid-cols-2 min-[380px]:grid-cols-4 gap-1.5 flex-1">
                          {(["cash", "qris", "card", "transfer"] as PaymentMethod[]).map((m) => {
                            const MIcon = PAYMENT_ICONS[m];
                            const active = entry.method === m;
                            const disabled = usedMethods.has(m) && !active;
                            return (
                              <button
                                key={m}
                                type="button"
                                aria-pressed={active}
                                disabled={disabled}
                                onClick={() => setPaymentEntryMethod(idx, m)}
                                className={`flex flex-col items-center justify-center gap-0.5 rounded-lg border px-1 py-1.5 text-[10px] font-semibold transition ${
                                  active
                                    ? "border-primary bg-primary/10 text-primary shadow-sm"
                                    : disabled
                                    ? "border-border/40 bg-muted/40 text-muted-foreground/40 cursor-not-allowed"
                                    : "border-border/70 bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                                }`}
                              >
                                <MIcon className="h-4 w-4" strokeWidth={1.75} />
                                {PAYMENT_LABELS[m]}
                              </button>
                            );
                          })}
                        </div>
                        {paymentEntries.length > 1 && (
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            onClick={() => removePaymentEntry(idx)}
                            className="h-9 w-9 shrink-0 p-0 text-muted-foreground hover:text-destructive"
                            aria-label="Hapus metode"
                          >
                            ×
                          </Button>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4 text-muted-foreground" strokeWidth={1.75} />
                        <NumberInput
                          min={0}
                          value={entry.amount}
                          onChange={(v) => setPaymentEntryAmount(entry.method, v)}
                          className="h-10 text-base font-semibold tabular-nums flex-1"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              if (isCompletingRef.current) return;
                              completeSale();
                            }
                          }}
                        />
                        {isCash && (
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            onClick={() =>
                              setPaymentEntryAmount(
                                "cash",
                                Math.max(0, total - nonCashPaid),
                              )
                            }
                            className="shrink-0"
                          >
                            Pas
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quick cash chips hanya jika ada entri cash */}
              {cashEntry && (
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_CASH.map((amt) => (
                    <Button
                      key={amt}
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => quickCash(amt)}
                      className="tabular-nums"
                    >
                      +{formatIDR(amt)}
                    </Button>
                  ))}
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => setTendered(0)}
                  >
                    Reset tunai
                  </Button>
                </div>
              )}

              {/* Ringkasan status pembayaran */}
              <div
                className={`flex items-center justify-between rounded-lg border px-3 py-2.5 text-sm transition ${
                  overpaidNonCash
                    ? "border-destructive/40 bg-destructive/5"
                    : shortage > 0
                    ? "border-destructive/40 bg-destructive/5"
                    : "border-emerald-500/30 bg-emerald-500/5"
                }`}
              >
                <span className="text-muted-foreground">
                  {overpaidNonCash
                    ? "Non-tunai melebihi total"
                    : shortage > 0
                    ? "Kekurangan"
                    : changeDue > 0
                    ? "Kembalian"
                    : "Lunas"}
                </span>
                <span
                  className={`text-lg font-bold tabular-nums ${
                    overpaidNonCash || shortage > 0 ? "text-destructive" : "text-emerald-600"
                  }`}
                >
                  {formatIDR(
                    overpaidNonCash
                      ? nonCashPaid - total
                      : shortage > 0
                      ? shortage
                      : changeDue,
                  )}
                </span>
              </div>
              {paymentEntries.length > 1 && (
                <div className="text-[11px] text-muted-foreground text-right">
                  Total dibayar: <span className="font-semibold tabular-nums">{formatIDR(paidTotal)}</span>
                </div>
              )}
            </div>
            )}
          </div>
          {hasPackagingShortage && (
            <div className="mx-6 mb-2 flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} />
              <div className="min-w-0">
                <div className="font-semibold">Stok packaging kurang — checkout akan gagal</div>
                <ul className="mt-0.5 space-y-0.5 tabular-nums">
                  {packagingShortages.map((s) => (
                    <li key={s.itemId} className="truncate">
                      {s.name}: sisa {s.stock}, butuh {s.needed} (kurang {s.short})
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:justify-between">
            <Button variant="outline" onClick={() => setPaymentOpen(false)} disabled={isCompleting}>
              Batal
            </Button>
            <Button
              onClick={completeSale}
              disabled={
                isCompleting ||
                (!isPreorder && !canCheckout) ||
                (!isPreorder && hasPackagingShortage)
              }
              className="min-w-[10rem] font-semibold"
            >
              {isCompleting
                ? "Memproses…"
                : isPreorder
                  ? dpAmount > 0
                    ? `Simpan PO · DP ${formatIDR(dpAmount)}`
                    : "Simpan PO (tanpa DP)"
                  : `Selesaikan · ${formatIDR(total)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      <Dialog open={!!lastSale} onOpenChange={(o) => !o && setLastSale(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="sr-only">
            <DialogTitle>Transaksi Berhasil</DialogTitle>
          </DialogHeader>
          {lastSale && (
            <div className="flex flex-col">
              {/* Hero status */}
              <div className="flex flex-col items-center gap-2 pb-4 pt-2 text-center">
                <div className="grid h-12 w-12 place-items-center rounded-full bg-emerald-500/10 text-emerald-600">
                  <CheckCircle2 className="h-7 w-7" strokeWidth={2} />
                </div>
                <div className="text-base font-semibold">Transaksi Berhasil</div>
                <div className="text-xs text-muted-foreground">
                  {formatDateTime(lastSale.createdAt)}
                </div>
              </div>

              {/* Headline amount */}
              <div className="rounded-xl border bg-muted/40 p-4 text-center">
                <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Total Pembayaran
                </div>
                <div className="mt-1 text-3xl font-bold tabular-nums">
                  {formatIDR(lastSale.total)}
                </div>
                <div className="mt-1 font-mono text-xs text-muted-foreground">
                  {lastSale.orderNumber ? `${lastSale.orderNumber} · ` : ""}
                  {formatSalesId(lastSale.id)}
                </div>

              </div>

              {/* Payment summary */}
              <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <dt className="text-muted-foreground">Customer</dt>
                <dd className="text-right font-medium">{lastSale.customerName ?? "—"}</dd>
                <dt className="text-muted-foreground">Metode</dt>
                <dd className="text-right font-medium">{formatPaymentSummary(lastSale)}</dd>
                {lastSale.tendered != null && (
                  <>
                    <dt className="text-muted-foreground">Tunai Diterima</dt>
                    <dd className="text-right tabular-nums">{formatIDR(lastSale.tendered)}</dd>
                  </>
                )}
                {lastSale.change != null && (
                  <>
                    <dt className="text-muted-foreground">Kembalian</dt>
                    <dd className="text-right font-semibold tabular-nums text-emerald-600">
                      {formatIDR(lastSale.change)}
                    </dd>
                  </>
                )}
              </dl>

              {/* Items */}
              <div className="mt-4 flex items-center justify-between border-b pb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <span>Item Dibeli</span>
                <span>
                  {lastSale.items.reduce((a, i) => a + i.qty, 0)} qty ·{" "}
                  {lastSale.items.length} produk
                </span>
              </div>
              <ul className="max-h-44 divide-y overflow-y-auto">
                {lastSale.items.map((i) => (
                  <li
                    key={i.productId}
                    className="flex items-start justify-between gap-2 py-2 text-sm"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{i.name}</div>
                      <div className="text-xs text-muted-foreground tabular-nums">
                        {i.qty} × {formatIDR(i.price)}
                      </div>
                    </div>
                    <div className="shrink-0 text-sm font-semibold tabular-nums">
                      {formatIDR(i.price * i.qty)}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setLastSale(null)}>
              Transaksi Baru
            </Button>
            <Button onClick={printReceipt}>
              <Printer className="h-4 w-4" /> Cetak Struk
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sprint 9: Dialog sukses untuk PO dengan DP (tanpa Sale). */}
      <Dialog open={!!lastPreorderDp} onOpenChange={(o) => !o && setLastPreorderDp(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="sr-only">
            <DialogTitle>Pre Order Tercatat</DialogTitle>
          </DialogHeader>
          {lastPreorderDp && (
            <div className="flex flex-col">
              <div className="flex flex-col items-center gap-2 pb-4 pt-2 text-center">
                <div className="grid h-12 w-12 place-items-center rounded-full bg-amber-500/10 text-amber-600">
                  <CalendarClock className="h-7 w-7" strokeWidth={2} />
                </div>
                <div className="text-base font-semibold">Pre Order Tercatat</div>
                <div className="text-xs text-muted-foreground">
                  DP diterima — belum lunas
                </div>
              </div>
              <div className="rounded-xl border border-amber-500/40 bg-amber-50 p-4 text-center dark:bg-amber-950/30">
                <div className="text-[11px] font-medium uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  DP Diterima
                </div>
                <div className="mt-1 text-3xl font-bold tabular-nums text-amber-700 dark:text-amber-300">
                  {formatIDR(lastPreorderDp.downPayment ?? 0)}
                </div>
                <div className="mt-2 text-xs text-muted-foreground">
                  Sisa pelunasan{" "}
                  <span className="font-semibold tabular-nums text-foreground">
                    {formatIDR(lastPreorderDp.remainingBalance ?? 0)}
                  </span>
                </div>
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <dt className="text-muted-foreground">Customer</dt>
                <dd className="text-right font-medium">{lastPreorderDp.customerName}</dd>
                <dt className="text-muted-foreground">Pickup</dt>
                <dd className="text-right font-medium">
                  {lastPreorderDp.date} · {lastPreorderDp.time}
                </dd>
                <dt className="text-muted-foreground">Total Pesanan</dt>
                <dd className="text-right tabular-nums">{formatIDR(lastPreorderDp.total)}</dd>
                {lastPreorderDp.dpMethod && (
                  <>
                    <dt className="text-muted-foreground">Metode DP</dt>
                    <dd className="text-right font-medium capitalize">{lastPreorderDp.dpMethod}</dd>
                  </>
                )}
              </dl>
              <div className="mt-4 flex items-center justify-between border-b pb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <span>Item Pesanan</span>
                <span>
                  {lastPreorderDp.items.reduce((a, i) => a + i.qty, 0)} qty ·{" "}
                  {lastPreorderDp.items.length} produk
                </span>
              </div>
              <ul className="max-h-44 divide-y overflow-y-auto">
                {lastPreorderDp.items.map((i) => (
                  <li
                    key={i.productId}
                    className="flex items-start justify-between gap-2 py-2 text-sm"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{i.name}</div>
                      <div className="text-xs text-muted-foreground tabular-nums">
                        {i.qty} × {formatIDR(i.price)}
                      </div>
                    </div>
                    <div className="shrink-0 text-sm font-semibold tabular-nums">
                      {formatIDR(i.price * i.qty)}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setLastPreorderDp(null)}>
              Tutup
            </Button>
            <Button
              onClick={() => {
                if (!lastPreorderDp) return;
                if (!printPreorderDpProof(lastPreorderDp)) {
                  toast.error("Popup diblokir browser");
                }
              }}
            >
              <Printer className="h-4 w-4" /> Cetak Bukti DP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}