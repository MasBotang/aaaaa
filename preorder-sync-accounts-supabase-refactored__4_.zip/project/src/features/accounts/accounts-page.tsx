/**
 * Account Management module.
 *
 * Owns: User / Role / Permission (read-only view) / Status.
 * Does NOT own: Attendance, Payroll, Activity Log, Analytics.
 *
 * Route: /accounts (admin only via role gating in navigation.ts).
 */

import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  MoreHorizontal,
  Plus,
  Search,
  ShieldCheck,
  UserCheck,
  UserMinus,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

import { ROLE_LABELS } from "@/lib/role-context";
import type { Role } from "@/services/types";
import {
  type AccountStatus,
  type AccountView,
  accountHasTransactions,
  createAccount,
  deleteAccount,
  listAccounts,
  resetAccountPassword,
  setAccountStatus,
  updateAccount,
} from "@/lib/accounts.functions";

// -------------------- Permission matrix (READ-ONLY, role-driven) --------------------
type ModuleKey =
  | "Analytics"
  | "Sales"
  | "Production"
  | "Inventory"
  | "Finance"
  | "Accounts"
  | "Settings";

const MODULES: ModuleKey[] = [
  "Analytics",
  "Sales",
  "Production",
  "Inventory",
  "Finance",
  "Accounts",
  "Settings",
];

const PERMISSION_MATRIX: Record<Role, Record<ModuleKey, boolean>> = {
  owner: {
    Analytics: true,
    Sales: true,
    Production: true,
    Inventory: true,
    Finance: true,
    Accounts: true,
    Settings: true,
  },
  admin: {
    Analytics: true,
    Sales: true,
    Production: true,
    Inventory: true,
    Finance: true,
    Accounts: false,
    Settings: true,
  },
  cashier: {
    Analytics: false,
    Sales: true,
    Production: false,
    Inventory: false,
    Finance: false,
    Accounts: false,
    Settings: false,
  },
  production: {
    Analytics: false,
    Sales: false,
    Production: true,
    Inventory: false,
    Finance: false,
    Accounts: false,
    Settings: false,
  },
};

const ROLE_LIST: Role[] = ["owner", "admin", "cashier", "production"];
const STATUS_LABEL: Record<AccountStatus, string> = {
  active: "Aktif",
  inactive: "Nonaktif",
};

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase() ?? "")
    .join("") || "?";
}

function fmtDate(iso?: string) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function fmtDateTime(iso?: string) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// -------------------- Page --------------------
export function AccountsPage() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["accounts"], queryFn: () => listAccounts() });

  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | Role>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | AccountStatus>("all");

  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<AccountView | null>(null);
  const [permOpen, setPermOpen] = useState(false);
  const [permRole, setPermRole] = useState<Role>("admin");
  const [confirmDel, setConfirmDel] = useState<AccountView | null>(null);
  const [resetFor, setResetFor] = useState<AccountView | null>(null);
  const [resetPw, setResetPw] = useState("");

  const accounts = q.data ?? [];

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return accounts.filter((a) => {
      if (roleFilter !== "all" && a.role !== roleFilter) return false;
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (!needle) return true;
      return (
        a.fullName.toLowerCase().includes(needle) ||
        a.email.toLowerCase().includes(needle)
      );
    });
  }, [accounts, search, roleFilter, statusFilter]);

  const summary = useMemo(() => {
    const byRole: Record<Role, number> = { admin: 0, owner: 0, cashier: 0, production: 0 };
    let active = 0;
    let inactive = 0;
    for (const a of accounts) {
      byRole[a.role] = (byRole[a.role] ?? 0) + 1;
      if (a.status === "active") active += 1;
      else inactive += 1;
    }
    return { total: accounts.length, active, inactive, byRole };
  }, [accounts]);

  const invalidate = () => qc.invalidateQueries({ queryKey: ["accounts"] });

  const disableM = useMutation({
    mutationFn: (a: AccountView) =>
      setAccountStatus(a.id, a.status === "active" ? "inactive" : "active"),
    onSuccess: () => {
      toast.success("Status diperbarui.");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteM = useMutation({
    mutationFn: (a: AccountView) => deleteAccount(a.id, accountHasTransactions(a)),
    onSuccess: (r) => {
      toast.success(r.deactivated ? "Akun punya transaksi — dinonaktifkan." : "Akun dihapus.");
      setConfirmDel(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const resetM = useMutation({
    mutationFn: async () => {
      if (!resetFor) return;
      await resetAccountPassword(resetFor.id, resetPw);
    },
    onSuccess: () => {
      toast.success("Password direset.");
      setResetFor(null);
      setResetPw("");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6">
      {/* Header */}
      <header className="flex flex-col gap-1 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Account Management</h1>
          <p className="text-sm text-muted-foreground">
            Pusat pengelolaan user, role, permission, dan status. Modul lain
            hanya membaca data ini — tidak boleh memodifikasi.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => { setPermRole("admin"); setPermOpen(true); }}>
            <ShieldCheck className="mr-2 h-4 w-4" /> Permission
          </Button>
          <Button onClick={() => { setEditing(null); setEditorOpen(true); }}>
            <Plus className="mr-2 h-4 w-4" /> Tambah User
          </Button>
        </div>
      </header>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <SummaryCard label="Total User" value={summary.total} icon={<Users className="h-4 w-4" />} />
        <SummaryCard label="Aktif" value={summary.active} icon={<UserCheck className="h-4 w-4" />} />
        <SummaryCard label="Nonaktif" value={summary.inactive} icon={<UserMinus className="h-4 w-4" />} />
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Distribusi Role
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-1.5">
            {ROLE_LIST.map((r) => (
              <Badge key={r} variant="secondary" className="text-[11px]">
                {ROLE_LABELS[r]}: {summary.byRole[r] ?? 0}
              </Badge>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-2 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama atau email…"
            className="pl-9"
          />
        </div>
        <Select value={roleFilter} onValueChange={(v) => setRoleFilter(v as "all" | Role)}>
          <SelectTrigger className="md:w-44"><SelectValue placeholder="Role" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua Role</SelectItem>
            {ROLE_LIST.map((r) => (
              <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as "all" | AccountStatus)}>
          <SelectTrigger className="md:w-44"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua Status</SelectItem>
            <SelectItem value="active">Aktif</SelectItem>
            <SelectItem value="inactive">Nonaktif</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Last Login</th>
                  <th className="px-4 py-3">Dibuat</th>
                  <th className="px-4 py-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {q.isLoading && (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Memuat…</td></tr>
                )}
                {!q.isLoading && filtered.length === 0 && (
                  <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Tidak ada akun yang cocok.</td></tr>
                )}
                {filtered.map((a) => (
                  <tr key={a.id} className="border-t">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs">{initials(a.fullName)}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <div className="truncate font-medium">{a.fullName}</div>
                          <div className="truncate text-xs text-muted-foreground">{a.email || "—"}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="secondary">{ROLE_LABELS[a.role]}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={a.status === "active" ? "default" : "outline"}>
                        {STATUS_LABEL[a.status]}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{fmtDateTime(a.lastLogin)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{fmtDate(a.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditing(a); setEditorOpen(true); }}>
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setPermRole(a.role); setPermOpen(true); }}>
                            Lihat Permission
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => disableM.mutate(a)}>
                            {a.status === "active" ? "Nonaktifkan" : "Aktifkan"}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setResetFor(a); setResetPw(""); }}>
                            Reset Password
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setConfirmDel(a)}
                          >
                            Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Editor drawer */}
      <UserEditor
        open={editorOpen}
        account={editing}
        onOpenChange={setEditorOpen}
        onSaved={invalidate}
      />

      {/* Permission drawer */}
      <Sheet open={permOpen} onOpenChange={setPermOpen}>
        <SheetContent className="sm:max-w-md">
          <SheetHeader>
            <SheetTitle>Permission Matrix</SheetTitle>
            <SheetDescription>
              Permission tidak dapat diedit manual. Peran (role) yang menentukan
              akses. Untuk mengubah, ubah peran user.
            </SheetDescription>
          </SheetHeader>
          <div className="mt-4 space-y-3">
            <div className="flex flex-col gap-1">
              <Label>Pilih peran</Label>
              <Select value={permRole} onValueChange={(v) => setPermRole(v as Role)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLE_LIST.map((r) => (
                    <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Separator />
            <div className="overflow-hidden rounded-lg border">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr><th className="px-3 py-2">Modul</th><th className="px-3 py-2 text-right">Akses</th></tr>
                </thead>
                <tbody>
                  {MODULES.map((m) => (
                    <tr key={m} className="border-t">
                      <td className="px-3 py-2">{m}</td>
                      <td className="px-3 py-2 text-right">
                        {PERMISSION_MATRIX[permRole][m] ? (
                          <Badge>Allowed</Badge>
                        ) : (
                          <Badge variant="outline" className="text-muted-foreground">Denied</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Delete confirmation */}
      <AlertDialog open={!!confirmDel} onOpenChange={(o) => !o && setConfirmDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus akun ini?</AlertDialogTitle>
            <AlertDialogDescription>
              {confirmDel && accountHasTransactions(confirmDel)
                ? "Akun ini sudah punya transaksi. Akan dinonaktifkan (bukan dihapus) demi jejak audit."
                : "Aksi ini permanen. Akun tanpa transaksi akan dihapus penuh."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmDel && deleteM.mutate(confirmDel)}
            >
              Lanjutkan
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reset password */}
      <AlertDialog open={!!resetFor} onOpenChange={(o) => !o && setResetFor(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset password</AlertDialogTitle>
            <AlertDialogDescription>
              Masukkan password baru untuk {resetFor?.fullName}. Minimal 8 karakter.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            type="password"
            value={resetPw}
            onChange={(e) => setResetPw(e.target.value)}
            placeholder="Password baru"
          />
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => resetM.mutate()} disabled={resetPw.length < 8}>
              Reset
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// -------------------- Summary card --------------------
function SummaryCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </CardTitle>
        <div className="text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-semibold">{value}</div>
      </CardContent>
    </Card>
  );
}

// -------------------- Editor (Create / Edit) --------------------
interface EditorState {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: Role;
  status: AccountStatus;
  employeeCode: string;
  phone: string;
  notes: string;
}

const EMPTY: EditorState = {
  fullName: "",
  email: "",
  password: "",
  confirmPassword: "",
  role: "cashier",
  status: "active",
  employeeCode: "",
  phone: "",
  notes: "",
};

function UserEditor({
  open,
  account,
  onOpenChange,
  onSaved,
}: {
  open: boolean;
  account: AccountView | null;
  onOpenChange: (v: boolean) => void;
  onSaved: () => void;
}) {
  const isEdit = !!account;
  const [state, setState] = useState<EditorState>(EMPTY);
  const [showExtra, setShowExtra] = useState(false);

  // Reset state whenever the drawer opens for a different target.
  const key = account?.id ?? "new";
  useMemoResetEditor(open, key, () =>
    setState(
      account
        ? {
            fullName: account.fullName,
            email: account.email,
            password: "",
            confirmPassword: "",
            role: account.role,
            status: account.status,
            employeeCode: account.employeeCode ?? "",
            phone: account.phone ?? "",
            notes: account.notes ?? "",
          }
        : EMPTY,
    ),
  );

  const saveM = useMutation({
    mutationFn: async () => {
      if (isEdit && account) {
        await updateAccount(account.id, {
          fullName: state.fullName,
          email: state.email,
          role: state.role,
          status: state.status,
          employeeCode: state.employeeCode,
          phone: state.phone,
          notes: state.notes,
        });
      } else {
        if (state.password !== state.confirmPassword) {
          throw new Error("Konfirmasi password tidak cocok.");
        }
        await createAccount({
          fullName: state.fullName,
          email: state.email,
          password: state.password,
          role: state.role,
          status: state.status,
          employeeCode: state.employeeCode,
          phone: state.phone,
          notes: state.notes,
        });
      }
    },
    onSuccess: () => {
      toast.success(isEdit ? "Akun diperbarui." : "Akun dibuat.");
      onOpenChange(false);
      onSaved();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>{isEdit ? "Edit User" : "Tambah User"}</SheetTitle>
          <SheetDescription>
            {isEdit
              ? "Ubah nama, email, role, atau status. ID tidak dapat diubah."
              : "Buat user baru. Email dipakai untuk login, password minimal 8 karakter."}
          </SheetDescription>
        </SheetHeader>

        <form
          className="mt-4 flex-1 space-y-4 overflow-y-auto pr-1"
          onSubmit={(e) => { e.preventDefault(); saveM.mutate(); }}
        >
          <Field label="Nama Lengkap">
            <Input value={state.fullName} onChange={(e) => setState({ ...state, fullName: e.target.value })} required />
          </Field>
          <Field label="Email">
            <Input
              type="email"
              value={state.email}
              onChange={(e) => setState({ ...state, email: e.target.value })}
              required
            />
          </Field>

          {!isEdit && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Password">
                <Input
                  type="password"
                  minLength={8}
                  required
                  value={state.password}
                  onChange={(e) => setState({ ...state, password: e.target.value })}
                />
              </Field>
              <Field label="Konfirmasi">
                <Input
                  type="password"
                  minLength={8}
                  required
                  value={state.confirmPassword}
                  onChange={(e) => setState({ ...state, confirmPassword: e.target.value })}
                />
              </Field>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="Role">
              <Select value={state.role} onValueChange={(v) => setState({ ...state, role: v as Role })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLE_LIST.map((r) => (
                    <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <div className="flex h-10 items-center gap-3 rounded-md border border-input bg-background px-3">
                <Switch
                  checked={state.status === "active"}
                  onCheckedChange={(c) => setState({ ...state, status: c ? "active" : "inactive" })}
                />
                <span className="text-sm">{STATUS_LABEL[state.status]}</span>
              </div>
            </Field>
          </div>

          <div>
            <button
              type="button"
              className="text-xs font-medium text-muted-foreground underline-offset-2 hover:underline"
              onClick={() => setShowExtra((s) => !s)}
            >
              {showExtra ? "Sembunyikan" : "Tampilkan"} field opsional (employee code, phone, notes)
            </button>
          </div>
          {showExtra && (
            <div className="space-y-3 rounded-lg border border-dashed p-3">
              <Field label="Employee Code">
                <Input value={state.employeeCode} onChange={(e) => setState({ ...state, employeeCode: e.target.value })} />
              </Field>
              <Field label="Phone">
                <Input value={state.phone} onChange={(e) => setState({ ...state, phone: e.target.value })} />
              </Field>
              <Field label="Notes">
                <Textarea rows={3} value={state.notes} onChange={(e) => setState({ ...state, notes: e.target.value })} />
              </Field>
            </div>
          )}
        </form>

        <SheetFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)} type="button">Batal</Button>
          <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>
            {saveM.isPending ? "Menyimpan…" : isEdit ? "Simpan" : "Buat User"}
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

// Small helper: reset editor state whenever `open` flips true or the target key changes.
function useMemoResetEditor(open: boolean, key: string, reset: () => void) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useMemo(() => {
    if (open) reset();
  }, [open, key]);
}
