import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ShoppingCart,
  ListChecks,
  Clock,
  Wallet,
  ArrowRight,
  ArrowUpRight,
  Store,
  CheckCircle2,
  Loader2,
  Sparkles,
  TrendingUp,
  UserRound,
  Timer,
  Coins,
  PlayCircle,
} from "lucide-react";
import {
  salesSummaryService,
  salesTargetService,
  type DailySummary,
} from "@/services/sales-summary.service";
import { shiftService } from "@/services/shift.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";
import { useRole } from "@/lib/role-context";
import { usePermission } from "@/lib/permissions";
import { formatIDR } from "@/lib/format";
import { toast } from "sonner";
import { PageShell, PageHeader, StatCard } from "@/components/app/page-shell";
import { useSalesData } from "@/hooks/use-sales-data";
import { useQueueData } from "@/hooks/use-queue-data";

function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatTime(iso?: string) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

function firstName(full?: string | null, fallback?: string | null) {
  const src = full || fallback || "";
  const stripped = src.includes("@") ? src.split("@")[0] : src;
  const clean = stripped.replace(/[._-]+/g, " ").trim();
  if (!clean) return "kembali";
  const w = clean.split(/\s+/)[0];
  return w.charAt(0).toUpperCase() + w.slice(1);
}

export function SalesHomePage() {
  useSalesData();
  useQueueData();
  const { profile, user } = useRole();
  const { can } = usePermission();
  const [summary, setSummary] = useState<DailySummary>(() => salesSummaryService.today());
  const [targetInput, setTargetInput] = useState<string>("");
  // shiftService.current() sekarang async (Supabase) — dibungkus react-query
  // supaya bebas dari Promise-in-useMemo dan bisa di-invalidate bersama
  // dengan mutasi shift.
  const shiftQ = useQuery({
    queryKey: ["shifts", "current"],
    queryFn: () => shiftService.current(),
  });
  const shift = shiftQ.data ?? null;

  function refresh() {
    setSummary(salesSummaryService.today());
  }

  // Instant refresh saat ada sale/shift baru — di tab ini (mis. kasir buka
  // POS di tab lain, device sama) atau tab lain (native storage event).
  const salesTick = useSalesRefresh();
  useEffect(() => {
    refresh();
    shiftQ.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [salesTick]);

  useEffect(() => {
    // Polling tetap dipertahankan sebagai fallback (mis. event listener
    // gagal terpasang di browser lama) — interval diperlebar karena jalur
    // utama sekarang event-driven, bukan lagi jalur satu-satunya.
    const iv = setInterval(refresh, 60_000);
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(iv);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  async function saveTarget() {
    const n = Number(targetInput.replace(/\D/g, ""));
    if (!Number.isFinite(n) || n <= 0) {
      toast.error("Masukkan target dalam angka");
      return;
    }
    try {
      await salesTargetService.setForDate(todayKey(), n);
      await salesTargetService.loadAll();
      setTargetInput("");
      toast.success("Target hari ini disimpan");
      refresh();
    } catch (err) {
      console.error("[home] saveTarget failed", err);
      toast.error("Gagal menyimpan target — coba lagi");
    }
  }

  const progressPct = Math.round(summary.progress * 100);
  // Sourced from central MATRIX (Finding B): no manual role === "..." checks.
  const canManageTarget = can("action.manageTarget");
  const name = firstName(profile?.full_name, user?.email);
  const avgTicket =
    summary.totalOrders > 0 ? Math.round(summary.totalRevenue / summary.totalOrders) : 0;

  return (
    <PageShell>
      {/* soft ambient warm wash */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] opacity-[0.55]"
        style={{
          background:
            "radial-gradient(60% 60% at 15% 0%, oklch(0.94 0.05 60 / 0.55), transparent 70%), radial-gradient(50% 50% at 100% 0%, oklch(0.92 0.05 30 / 0.35), transparent 70%)",
        }}
      />

      {/* Header — Home keeps its personal greeting nada, no breadcrumb */}
      <PageHeader
        title={<>Selamat datang kembali, {name} <span aria-hidden>👋</span></>}
        description="Berikut ringkasan penjualan hari ini."
        actions={
          <>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border/70 bg-card/80 px-3 py-1.5 text-[12px] font-medium text-foreground shadow-[0_1px_0_oklch(1_0_0_/_0.9)_inset,0_1px_2px_oklch(0.22_0.025_40_/_0.04)] backdrop-blur">
              <Store className="h-3.5 w-3.5 text-primary/80" />
              Outlet Utama
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/20 bg-emerald-500/8 px-3 py-1.5 text-[12px] font-medium text-emerald-700">
              <span className="relative inline-flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
              </span>
              Data Hari Ini
            </span>
          </>
        }
      />

      {/* Revenue Hero — dominant editorial card with attached supporting metrics */}
      <section
        className="relative overflow-hidden rounded-[28px] border border-primary/25 text-primary-foreground shadow-[0_1px_0_oklch(1_0_0_/_0.15)_inset,0_30px_60px_-30px_oklch(0.38_0.14_26_/_0.55),0_10px_25px_-15px_oklch(0.38_0.14_26_/_0.35)]"
        style={{
          background:
            "radial-gradient(120% 140% at 0% 0%, oklch(0.5 0.18 30) 0%, oklch(0.42 0.16 26) 40%, oklch(0.34 0.13 26) 100%)",
        }}
      >
        {/* decorative wheat line art */}
        <svg
          aria-hidden
          viewBox="0 0 200 200"
          className="pointer-events-none absolute -right-6 -top-6 h-56 w-56 opacity-[0.13]"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.9"
        >
          <path d="M100 20 C 95 70 95 130 100 190" />
          <path d="M100 55 C 78 60 66 74 62 92" />
          <path d="M100 55 C 122 60 134 74 138 92" />
          <path d="M100 90 C 76 96 62 112 60 130" />
          <path d="M100 90 C 124 96 138 112 140 130" />
          <path d="M100 125 C 80 130 70 142 68 158" />
          <path d="M100 125 C 120 130 130 142 132 158" />
        </svg>
        <div className="pointer-events-none absolute -left-24 -bottom-24 h-72 w-72 rounded-full bg-white/8 blur-3xl" />

        {/* subtle chart line */}
        <svg
          aria-hidden
          viewBox="0 0 400 100"
          preserveAspectRatio="none"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-24 w-full opacity-30"
        >
          <defs>
            <linearGradient id="rev-fill" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="currentColor" stopOpacity="0.35" />
              <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d="M0,80 C40,65 70,88 110,72 C160,52 190,90 230,66 C280,38 320,76 360,48 L400,42 L400,100 L0,100 Z"
            fill="url(#rev-fill)"
          />
          <path
            d="M0,80 C40,65 70,88 110,72 C160,52 190,90 230,66 C280,38 320,76 360,48 L400,42"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.25"
            opacity="0.7"
          />
        </svg>

        <div className="relative grid gap-8 p-7 lg:grid-cols-[1.4fr_1fr] lg:gap-10 lg:p-9">
          {/* Left: revenue */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.18em] text-primary-foreground/75">
              <Sparkles className="h-3.5 w-3.5" />
              Omset Hari Ini
            </div>

            <div className="flex flex-col gap-3">
              <div className="font-display text-[44px] font-bold leading-none tracking-tight tabular-nums sm:text-[54px]">
                {formatIDR(summary.totalRevenue)}
              </div>
              <div className="flex flex-wrap items-center gap-2 text-[13px] text-primary-foreground/85">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-2.5 py-1 text-[12px] font-medium ring-1 ring-white/15">
                  <TrendingUp className="h-3.5 w-3.5" />
                  {summary.totalOrders} pesanan
                </span>
                <span className="text-[12px] text-primary-foreground/70">
                  Diperbarui otomatis · 15 detik
                </span>
              </div>
            </div>

            {/* Progress bar embedded */}
            <div className="flex flex-col gap-2 pt-1">
              <div className="flex items-baseline justify-between text-[12px]">
                <span className="font-medium uppercase tracking-[0.12em] text-primary-foreground/75">
                  Target Harian
                </span>
                <span className="font-semibold tabular-nums text-primary-foreground">
                  {summary.targetRevenue > 0 ? formatIDR(summary.targetRevenue) : "Belum diset"}
                  {summary.targetRevenue > 0 && (
                    <span className="ml-2 text-primary-foreground/70">· {progressPct}%</span>
                  )}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-white/95 to-[oklch(0.9_0.1_85)] transition-all duration-500"
                  style={{ width: `${Math.min(100, progressPct)}%` }}
                />
              </div>
              {canManageTarget && summary.targetRevenue === 0 && (
                <div className="mt-2 flex gap-2">
                  <Input
                    value={targetInput}
                    onChange={(e) => setTargetInput(e.target.value)}
                    placeholder="Set target hari ini (Rp)"
                    className="h-9 rounded-lg border-white/20 bg-white/10 text-primary-foreground placeholder:text-primary-foreground/60 focus-visible:ring-white/40"
                  />
                  <Button
                    size="sm"
                    onClick={saveTarget}
                    className="h-9 rounded-lg bg-white px-4 text-primary hover:bg-white/90"
                  >
                    Simpan
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Right: attached supporting mini metrics */}
          <div className="relative grid grid-cols-2 gap-3 self-stretch lg:border-l lg:border-white/12 lg:pl-8">
            <StatCard variant="inverse" label="Pesanan" value={String(summary.totalOrders)} hint="Total hari ini" />
            <StatCard variant="inverse" label="Rata-rata" value={formatIDR(avgTicket)} hint="Per pesanan" />
            <StatCard variant="inverse" label="Selesai" value={String(summary.completedOrders)} hint="Sudah dibayar" />
            <StatCard variant="inverse" label="Refund" value={String(summary.refundedOrders)} hint="Perlu ditinjau" />
          </div>
        </div>

        {/* Target editor for existing target (outside gradient card, admin only) */}
      </section>

      {canManageTarget && summary.targetRevenue > 0 && (
        <div className="-mt-4 flex flex-wrap items-center gap-2 text-[12px] text-muted-foreground">
          <span>Ubah target hari ini:</span>
          <Input
            value={targetInput}
            onChange={(e) => setTargetInput(e.target.value)}
            placeholder={formatIDR(summary.targetRevenue)}
            className="h-8 w-44 rounded-lg bg-card text-[12px]"
          />
          <Button size="sm" variant="outline" className="h-8 rounded-lg px-3 text-[12px]" onClick={saveTarget}>
            Simpan
          </Button>
        </div>
      )}

      {/* Status Pesanan */}
      <section className="flex flex-col gap-4">
        <SectionHeader
          eyebrow="Operasional"
          title="Status Pesanan"
          subtitle="Snapshot antrean pesanan berjalan"
        />
        <div className="grid gap-4 md:grid-cols-3">
          <StatusCard
            label="Pesanan Baru"
            value={summary.newOrders}
            hint="Menunggu diproses"
            icon={<Sparkles className="h-5 w-5" />}
            tone="rose"
          />
          <StatusCard
            label="Diproses"
            value={summary.inProgressOrders}
            hint="Sedang dikerjakan"
            icon={<Loader2 className="h-5 w-5" />}
            tone="gold"
          />
          <StatusCard
            label="Selesai"
            value={summary.completedOrders}
            hint="Siap diambil / kirim"
            icon={<CheckCircle2 className="h-5 w-5" />}
            tone="sage"
          />
        </div>
      </section>

      {/* Shift */}
      <section className="flex flex-col gap-4">
        <SectionHeader
          eyebrow="Kasir"
          title="Shift"
          subtitle="Panel operasional kasir saat ini"
        />
        {shift ? (
          <ShiftActivePanel shift={shift} />
        ) : (
          <ShiftEmptyState />
        )}
      </section>

      {/* Quick Actions */}
      <section className="flex flex-col gap-4">
        <SectionHeader
          eyebrow="Aksi"
          title="Aksi Cepat"
          subtitle="Akses langsung ke tugas harian"
        />
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <PrimaryAction
              to="/sales/pos"
              title="Buat Pesanan"
              description="Buka Point of Sale dan mulai transaksi baru"
              icon={<ShoppingCart className="h-6 w-6" />}
            />
          </div>
          <div className="grid gap-4">
            <SecondaryAction
              to="/sales/pesanan"
              title="Lihat Pesanan"
              description="Antrean & riwayat pesanan"
              icon={<ListChecks className="h-5 w-5" />}
            />
            <SecondaryAction
              to="/sales/shifts"
              title="Open / Close Shift"
              description="Audit kas & marketplace"
              icon={<Clock className="h-5 w-5" />}
            />
          </div>
        </div>
      </section>
    </PageShell>
  );
}

/* ------------------------------------------------------------------ */

function SectionHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-primary/80">
        {eyebrow}
      </span>
      <div className="flex items-baseline gap-3">
        <h2 className="font-display text-[18px] font-semibold tracking-tight text-foreground">
          {title}
        </h2>
        {subtitle && (
          <span className="text-[13px] text-muted-foreground">{subtitle}</span>
        )}
      </div>
    </div>
  );
}

function StatusCard({
  label,
  value,
  hint,
  icon,
  tone,
}: {
  label: string;
  value: number;
  hint: string;
  icon: React.ReactNode;
  tone: "rose" | "gold" | "sage";
}) {
  const tones: Record<string, { bg: string; fg: string; accent: string; ring: string }> = {
    rose: {
      bg: "bg-[oklch(0.96_0.03_25)]",
      fg: "text-[oklch(0.5_0.16_26)]",
      accent: "bg-[oklch(0.55_0.18_26)]",
      ring: "ring-[oklch(0.55_0.18_26)/0.15]",
    },
    gold: {
      bg: "bg-[oklch(0.96_0.05_85)]",
      fg: "text-[oklch(0.5_0.14_75)]",
      accent: "bg-[oklch(0.72_0.14_80)]",
      ring: "ring-[oklch(0.72_0.14_80)/0.2]",
    },
    sage: {
      bg: "bg-[oklch(0.94_0.05_150)]",
      fg: "text-[oklch(0.4_0.12_150)]",
      accent: "bg-[oklch(0.55_0.14_150)]",
      ring: "ring-[oklch(0.55_0.14_150)/0.18]",
    },
  };
  const t = tones[tone];
  return (
    <div
      className={`group relative overflow-hidden rounded-2xl border border-border/60 bg-card p-5 shadow-[0_1px_0_oklch(1_0_0_/_0.6)_inset,0_1px_2px_oklch(0.22_0.025_40_/_0.04),0_8px_24px_-16px_oklch(0.22_0.025_40_/_0.25)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_0_oklch(1_0_0_/_0.6)_inset,0_2px_4px_oklch(0.22_0.025_40_/_0.05),0_18px_36px_-18px_oklch(0.22_0.025_40_/_0.35)]`}
    >
      {/* left accent */}
      <span className={`absolute inset-y-4 left-0 w-[3px] rounded-r-full ${t.accent} opacity-90`} />
      <div className="flex items-start justify-between gap-3 pl-2">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
            {label}
          </span>
          <span className="font-display text-[36px] font-bold leading-none tabular-nums text-foreground">
            {value}
          </span>
          <span className="text-[12px] text-muted-foreground">{hint}</span>
        </div>
        <div
          className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${t.bg} ${t.fg} ring-1 ${t.ring} transition-transform duration-300 group-hover:scale-105`}
        >
          {icon}
        </div>
      </div>
    </div>
  );
}

function ShiftActivePanel({
  shift,
}: {
  shift: { cashier: string; openingCash: number; openedAt: string };
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-card p-6 shadow-[0_1px_0_oklch(1_0_0_/_0.6)_inset,0_10px_30px_-20px_oklch(0.22_0.025_40_/_0.3)]">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <div className="relative grid h-12 w-12 place-items-center rounded-2xl bg-[oklch(0.94_0.05_150)] text-[oklch(0.42_0.12_150)] ring-1 ring-[oklch(0.55_0.14_150)/0.2]">
            <PlayCircle className="h-6 w-6" />
            <span className="absolute -right-1 -top-1 flex h-3 w-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
              <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-card" />
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-[16px] font-semibold text-foreground">
                Shift Aktif
              </span>
              <span className="rounded-full bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-700 ring-1 ring-emerald-500/20">
                Live
              </span>
            </div>
            <p className="mt-0.5 text-[13px] text-muted-foreground">
              Transaksi POS berjalan pada shift ini
            </p>
          </div>
        </div>
        <Button
          asChild
          variant="outline"
          size="sm"
          className="h-9 rounded-lg border-border/70 px-4 shadow-sm hover:border-primary/40 hover:text-primary"
        >
          <Link to="/sales/shifts">Kelola / Tutup Shift</Link>
        </Button>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <MiniBlock icon={<UserRound className="h-4 w-4" />} label="Kasir" value={shift.cashier} />
        <MiniBlock icon={<Store className="h-4 w-4" />} label="Outlet" value="Outlet Utama" />
        <MiniBlock
          icon={<Coins className="h-4 w-4" />}
          label="Kas Pembuka"
          value={formatIDR(shift.openingCash)}
        />
        <MiniBlock
          icon={<Timer className="h-4 w-4" />}
          label="Jam Mulai"
          value={formatTime(shift.openedAt)}
        />
      </div>
    </div>
  );
}

function MiniBlock({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-border/50 bg-background/60 p-3.5 transition-colors hover:border-primary/25">
      <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        <span className="text-primary/70">{icon}</span>
        {label}
      </div>
      <div className="mt-1 truncate text-[14px] font-semibold text-foreground">{value}</div>
    </div>
  );
}

function ShiftEmptyState() {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-dashed border-border bg-gradient-to-br from-card to-[oklch(0.96_0.02_75)] p-8 text-center">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-24 opacity-40" style={{
        background: "radial-gradient(50% 100% at 50% 0%, oklch(0.9 0.06 60 / 0.5), transparent 70%)",
      }} />
      <div className="relative mx-auto flex max-w-md flex-col items-center gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-muted-foreground ring-1 ring-border/60">
          <Wallet className="h-5 w-5" />
        </div>
        <div className="flex flex-col gap-1">
          <span className="font-display text-[16px] font-semibold text-foreground">
            Belum ada shift aktif
          </span>
          <p className="text-[13px] text-muted-foreground">
            Buka shift untuk mencatat kas awal dan mulai menerima transaksi kasir.
          </p>
        </div>
        <Button asChild size="sm" className="mt-1 h-9 rounded-lg px-5">
          <Link to="/sales/shifts">
            <PlayCircle className="mr-1.5 h-4 w-4" /> Buka Shift
          </Link>
        </Button>
      </div>
    </div>
  );
}

function PrimaryAction({
  to,
  title,
  description,
  icon,
}: {
  to: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}) {
  return (
    <Link
      to={to}
      className="group relative flex h-full min-h-[168px] flex-col justify-between overflow-hidden rounded-2xl border border-primary/25 p-6 text-primary-foreground shadow-[0_1px_0_oklch(1_0_0_/_0.15)_inset,0_20px_40px_-24px_oklch(0.38_0.14_26_/_0.55)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_0_oklch(1_0_0_/_0.15)_inset,0_30px_50px_-24px_oklch(0.38_0.14_26_/_0.65)]"
      style={{
        background:
          "linear-gradient(135deg, oklch(0.5 0.18 30) 0%, oklch(0.42 0.16 26) 55%, oklch(0.34 0.13 26) 100%)",
      }}
    >
      <div className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full bg-white/10 blur-3xl" />
      <svg
        aria-hidden
        viewBox="0 0 120 120"
        className="pointer-events-none absolute right-4 bottom-4 h-24 w-24 opacity-15"
        fill="none"
        stroke="currentColor"
        strokeWidth="0.9"
      >
        <path d="M60 10 C 55 40 55 70 60 110" />
        <path d="M60 30 C 40 34 30 46 28 60" />
        <path d="M60 30 C 80 34 90 46 92 60" />
      </svg>
      <div className="relative flex items-start justify-between">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/15 ring-1 ring-white/20 backdrop-blur-sm">
          {icon}
        </div>
        <div className="grid h-10 w-10 place-items-center rounded-full bg-white/15 ring-1 ring-white/20 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-0.5">
          <ArrowUpRight className="h-4 w-4" />
        </div>
      </div>
      <div className="relative">
        <div className="font-display text-[20px] font-semibold tracking-tight">{title}</div>
        <div className="mt-1 text-[13px] text-primary-foreground/80">{description}</div>
      </div>
    </Link>
  );
}

function SecondaryAction({
  to,
  title,
  description,
  icon,
}: {
  to: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}) {
  return (
    <Link
      to={to}
      className="group relative flex items-center gap-4 rounded-2xl border border-border/60 bg-card p-4 shadow-[0_1px_0_oklch(1_0_0_/_0.6)_inset,0_1px_2px_oklch(0.22_0.025_40_/_0.04)] transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-[0_8px_24px_-16px_oklch(0.22_0.025_40_/_0.35)]"
    >
      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-accent/60 text-primary transition-transform duration-300 group-hover:scale-105">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[14px] font-semibold text-foreground">{title}</div>
        <div className="truncate text-[12px] text-muted-foreground">{description}</div>
      </div>
      <ArrowRight className="h-4 w-4 text-muted-foreground transition-all duration-300 group-hover:translate-x-1 group-hover:text-primary" />
    </Link>
  );
}
