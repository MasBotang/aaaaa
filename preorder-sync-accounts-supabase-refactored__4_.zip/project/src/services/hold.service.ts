import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import type { HoldOrder, SaleItem, SourceOrder } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 2 — Hold Orders): holdService sekarang
// menyimpan hold di tabel `public.hold_orders` (bukan localStorage lagi).
//
// Public API dipertahankan sepersis mungkin — list()/save()/remove()/clear()
// jadi async. Callers (pos-page.tsx) sudah dikonversi ke useQuery/mutasi
// bersamaan dengan tahap ini.
//
// RLS: hold_orders masuk kelompok "Sales/POS operasional" — admin +
// cashier boleh INSERT/UPDATE/DELETE.
// ---------------------------------------------------------------------------

interface HoldRow {
  id: string;
  legacy_id: string | null;
  created_at: string;
  customer_name: string;
  items: SaleItem[] | null;
  total: number | string;
  source_order: SourceOrder | null;
  price_group_id: string | null;
}

function toNumber(v: number | string): number {
  const n = typeof v === "string" ? Number(v) : v;
  return Number.isFinite(n) ? n : 0;
}

function fromRow(row: HoldRow): HoldOrder {
  return {
    id: row.legacy_id ?? row.id,
    createdAt: row.created_at,
    customerName: row.customer_name,
    items: row.items ?? [],
    total: toNumber(row.total),
  };
}

function fireChangeEvent() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key: StorageKeys.holdOrders } }),
    );
  } catch {
    /* ignore */
  }
}

export const holdService = {
  async list(): Promise<HoldOrder[]> {
    const { data, error } = await supabase
      .from("hold_orders")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data as HoldRow[]).map(fromRow);
  },

  async save(items: SaleItem[], customerName: string): Promise<HoldOrder> {
    const dbId = crypto.randomUUID();
    const legacyId = `hold_${crypto.randomUUID()}`;
    const total = items.reduce((a, i) => a + i.price * i.qty, 0);
    const insertRow = {
      id: dbId,
      legacy_id: legacyId,
      created_at: new Date().toISOString(),
      customer_name: customerName.trim(),
      items,
      total,
    };
    const { data, error } = await supabase
      .from("hold_orders")
      .insert(insertRow)
      .select()
      .single();
    if (error) throw error;
    fireChangeEvent();
    return fromRow(data as HoldRow);
  },

  async remove(id: string): Promise<void> {
    // id yang dilihat kasir bisa `hold_...` (legacy) atau uuid.
    const { error } = await supabase
      .from("hold_orders")
      .delete()
      .or(`id.eq.${id},legacy_id.eq.${id}`);
    if (error) throw error;
    fireChangeEvent();
  },

  async clear(): Promise<void> {
    // Delete all rows. `neq` dengan id impossible supaya where-clause valid.
    const { error } = await supabase
      .from("hold_orders")
      .delete()
      .neq("id", "00000000-0000-0000-0000-000000000000");
    if (error) throw error;
    fireChangeEvent();
  },
};
