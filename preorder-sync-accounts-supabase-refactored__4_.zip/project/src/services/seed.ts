import { storage, StorageKeys } from "./storage";
import { userService } from "./user.service";
import type { InventoryItem, Product, RecipeType, User } from "./types";

const seedProducts: Product[] = [
  // ---- Risol (matang / showcase) ----
  { id: "p1", name: "Original Mayo", category: "Risol", price: 5000, cost: 2000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p2", name: "Nori Spicy Mayo", category: "Risol", price: 6000, cost: 2500, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p3", name: "Mayo Special", category: "Risol", price: 6500, cost: 2800, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p4", name: "Ragout", category: "Risol", price: 5500, cost: 2300, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p5", name: "Ayam Suwir Pedas", category: "Risol", price: 5500, cost: 2300, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p6", name: "Choco Crunchy", category: "Risol", price: 5000, cost: 2000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p7", name: "Choco Cheese", category: "Risol", price: 5500, cost: 2200, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p8", name: "Matcha", category: "Risol", price: 5500, cost: 2200, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  // ---- Frozen (1 Pack, freezer) ----
  { id: "p9", name: "1 Pack Original Mayo", category: "Frozen", price: 45000, cost: 20000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p10", name: "1 Pack Nori Spicy Mayo", category: "Frozen", price: 55000, cost: 25000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p11", name: "1 Pack Mayo Special", category: "Frozen", price: 60000, cost: 28000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p12", name: "1 Pack Ragout", category: "Frozen", price: 50000, cost: 23000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p13", name: "1 Pack Ayam Suwir", category: "Frozen", price: 50000, cost: 23000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p14", name: "1 Pack Choco Crunchy", category: "Frozen", price: 45000, cost: 20000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p15", name: "1 Pack Choco Cheese", category: "Frozen", price: 50000, cost: 22000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  { id: "p16", name: "1 Pack Matcha", category: "Frozen", price: 50000, cost: 22000, stock: 0, active: true, stockSource: "freezer", imageUrl: "" },
  // ---- Paket ----
  { id: "p17", name: "Paket Asin", category: "Paket", price: 55000, cost: 25000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p18", name: "Paket Manis", category: "Paket", price: 50000, cost: 22000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p19", name: "Paket Creamy Pedas", category: "Paket", price: 60000, cost: 28000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
  { id: "p20", name: "Paket Spesial Manis", category: "Paket", price: 55000, cost: 24000, stock: 0, active: true, stockSource: "showcase", imageUrl: "" },
];

const seedUsers: User[] = [
  { id: "u1", name: "Andi", role: "admin" },
  { id: "u2", name: "Budi", role: "owner" },
  { id: "u3", name: "Citra", role: "cashier" },
  { id: "u4", name: "Dewi", role: "production" },
];

// ---------------------------------------------------------------------------
// Migrasi Data Referensi (Prompt 2): seedIfEmpty() / seedInventoryIfEmpty() /
// seedRecipesIfEmpty() TIDAK LAGI melakukan seeding Product/Inventory/Recipe
// dari sini. Dua alasan:
//
// 1. RLS. `products_write_ins` mensyaratkan role admin untuk INSERT;
//    `inventory_items_write_production_ins` admin ATAU production;
//    `price_groups_write_admin` admin-only. Fungsi-fungsi ini sebelumnya
//    dipanggil untuk SIAPA SAJA yang login (lihat role-context.tsx) —
//    begitu yang login pertama adalah cashier/owner, RLS akan menolak
//    insert-nya (bukan silent no-op seperti localStorage, tapi error).
// 2. `productService.save()` / `inventoryService.save()` (bulk replace-
//    seluruh-tabel) sudah tidak ada di API baru — Supabase tidak punya
//    padanan langsung "replace semua baris sekaligus" yang aman dipanggil
//    dari client (dan kalaupun ada, race antar-device saat kosong akan
//    menduplikasi data).
//
// Seeding data starter dipindah ke SQL, dijalankan sekali oleh operator
// lewat Supabase Dashboard/SQL Editor:
//   - supabase/seed/price-groups.sql
//   - supabase/seed/products-and-inventory.sql
// Resep (recipes) belum ada seed SQL-nya — recipeService saat ini juga
// belum dikonsumsi UI manapun (belum ada halaman Recipe), jadi belum
// mendesak; seedRecipes di bawah dipertahankan sebagai referensi struktur
// data, bukan dieksekusi.
//
// `seedProducts` / `seedInventory` / `seedRecipes` (array di bawah) TETAP
// ada di file ini — itulah yang dipakai untuk MEN-GENERATE isi kedua file
// SQL seed di atas. Dipertahankan sebagai sumber kebenaran/referensi,
// bukan lagi dieksekusi langsung dari sini.
// ---------------------------------------------------------------------------

export function seedIfEmpty() {
  if (storage.has(StorageKeys.seeded)) return;
  if (userService.list().length === 0) userService.save(seedUsers);
  storage.set(StorageKeys.seeded, true);
}

// ---------------- Inventory (Version 2) ----------------
type SeedInv = Omit<InventoryItem, "id" | "createdAt" | "updatedAt" | "costPerUnit"> & {
  id?: string;
};

const seedInventory: SeedInv[] = [
  // Operasional
  { name: "Air Mineral", category: "operational", unit: "botol", stock: 40, minStock: 20, purchasePrice: 5000, purchaseQuantity: 1, active: true },
  { name: "Gas LPG 3kg", category: "operational", unit: "tabung", stock: 6, minStock: 3, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Sabun Cuci", category: "operational", unit: "pcs", stock: 10, minStock: 3, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  { name: "Sabun Tangan", category: "operational", unit: "pcs", stock: 5, minStock: 2, purchasePrice: 15000, purchaseQuantity: 1, active: true },
  { name: "Tisu", category: "operational", unit: "pack", stock: 20, minStock: 5, purchasePrice: 12000, purchaseQuantity: 1, active: true },
  { name: "Lakban", category: "operational", unit: "roll", stock: 10, minStock: 3, purchasePrice: 15000, purchaseQuantity: 1, active: true },
  { name: "Spidol", category: "operational", unit: "pcs", stock: 5, minStock: 2, purchasePrice: 8000, purchaseQuantity: 1, active: true },
  { name: "Masker", category: "operational", unit: "box", stock: 5, minStock: 1, purchasePrice: 25000, purchaseQuantity: 1, active: true },
  { name: "Sarung Tangan", category: "operational", unit: "box", stock: 5, minStock: 1, purchasePrice: 30000, purchaseQuantity: 1, active: true },
  { name: "Kantong Sampah", category: "operational", unit: "pack", stock: 8, minStock: 2, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  // Packaging — Launch Box
  { name: "Launch Box Xtra Kecil (Isi 2)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 800, purchaseQuantity: 1, active: true },
  { name: "Launch Box Kecil (Isi 3)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1000, purchaseQuantity: 1, active: true },
  { name: "Launch Box Sedang (Isi 4-5)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1200, purchaseQuantity: 1, active: true },
  { name: "Launch Box Sedang Xtra (Isi 6-8)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1500, purchaseQuantity: 1, active: true },
  // Packaging — Plastik Non PE
  { name: "Plastik Non PE Kecil", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 200, purchaseQuantity: 1, active: true },
  { name: "Plastik Non PE Sedang", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 300, purchaseQuantity: 1, active: true },
  { name: "Plastik Non PE Besar", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 400, purchaseQuantity: 1, active: true },
  // Packaging — Plastik PE
  { name: "Plastik PE Kecil", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 250, purchaseQuantity: 1, active: true },
  { name: "Plastik PE Sedang", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 350, purchaseQuantity: 1, active: true },
  { name: "Plastik PE Besar", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 500, purchaseQuantity: 1, active: true },
  // Bahan Baku
  { name: "Bawang Merah", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Bawang Putih", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Cabai Kriting", category: "raw", unit: "kg", stock: 2, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Cabai Rawit", category: "raw", unit: "kg", stock: 2, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Carnation 2kg", category: "raw", unit: "kg", stock: 8, minStock: 4, purchasePrice: 477100, purchaseQuantity: 8, active: true },
  { name: "Choco Crunchy 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 611000, purchaseQuantity: 12, active: true },
  { name: "Cidea Crabstick 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 573900, purchaseQuantity: 12, active: true },
  { name: "Dada Fillet", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 55000, purchaseQuantity: 1, active: true },
  { name: "Daun Salam & Jeruk", category: "raw", unit: "ikat", stock: 3, minStock: 1, purchasePrice: 2000, purchaseQuantity: 1, active: true },
  { name: "Delmonte Cabe 1kg", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 220000, purchaseQuantity: 10, active: true },
  { name: "Garam", category: "raw", unit: "pcs", stock: 3, minStock: 1, purchasePrice: 6000, purchaseQuantity: 1, active: true },
  { name: "Greentea Crunchy 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 680000, purchaseQuantity: 12, active: true },
  { name: "Gula", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Jagung", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 12000, purchaseQuantity: 1, active: true },
  { name: "Kentang", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  { name: "Kewpie 1kg", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 395000, purchaseQuantity: 6, active: true },
  { name: "Ladaku", category: "raw", unit: "sachet", stock: 24, minStock: 12, purchasePrice: 11500, purchaseQuantity: 12, active: true },
  { name: "Mamayo 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 255000, purchaseQuantity: 12, active: true },
  { name: "Mentega", category: "raw", unit: "gram", stock: 1000, minStock: 400, purchasePrice: 5000, purchaseQuantity: 200, active: true },
  { name: "Minyak 1 KG Tropical", category: "raw", unit: "liter", stock: 10, minStock: 4, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Minyak Adonan Risol", category: "raw", unit: "liter", stock: 5, minStock: 2, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Nori MamaSuka", category: "raw", unit: "pcs", stock: 10, minStock: 4, purchasePrice: 13800, purchaseQuantity: 1, active: true },
  { name: "Panir Pita 10kg", category: "raw", unit: "kg", stock: 10, minStock: 5, purchasePrice: 133000, purchaseQuantity: 10, active: true },
  { name: "Prochiz Gold Cheddar 2kg", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 815000, purchaseQuantity: 8, active: true },
  { name: "Prochiz Quick Melt Slice", category: "raw", unit: "pcs", stock: 48, minStock: 24, purchasePrice: 500000, purchaseQuantity: 48, active: true },
  { name: "Rice Crispy 1kg", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 50000, purchaseQuantity: 1, active: true },
  { name: "Slice Beef 1kg", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 950000, purchaseQuantity: 10, active: true },
  { name: "Susu UHT Diamond", category: "raw", unit: "kg", stock: 10, minStock: 5, purchasePrice: 190000, purchaseQuantity: 10, active: true },
  { name: "Telur", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 28000, purchaseQuantity: 1, active: true },
  { name: "Tepung Tapioka Gunung", category: "raw", unit: "pcs", stock: 10, minStock: 5, purchasePrice: 105000, purchaseQuantity: 20, active: true },
  { name: "Tepung Terigu", category: "raw", unit: "kg", stock: 25, minStock: 10, purchasePrice: 213000, purchaseQuantity: 25, active: true },
  { name: "Totole Kaldu Jamur", category: "raw", unit: "gram", stock: 800, minStock: 400, purchasePrice: 51000, purchaseQuantity: 400, active: true },
  { name: "Wortel", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 15000, purchaseQuantity: 1, active: true },
];

/**
 * @deprecated Dinonaktifkan pada migrasi Prompt 2 — lihat catatan besar di
 * atas `seedIfEmpty()`. Gunakan supabase/seed/products-and-inventory.sql.
 * Dipertahankan sebagai no-op (bukan dihapus) supaya pemanggilnya di
 * role-context.tsx tidak perlu ikut diubah.
 */
export function seedInventoryIfEmpty() {
  // no-op — lihat catatan di atas seedIfEmpty().
}

// ---------------- Recipes (Version 1) ----------------
type SeedRecipeIngredient = { name: string; quantity: number };
type SeedRecipe = {
  name: string;
  type: RecipeType;
  outputName: string;
  outputQuantity: number;
  outputUnit: string;
  notes?: string;
  ingredients: SeedRecipeIngredient[];
};

const seedRecipes: SeedRecipe[] = [
  {
    name: "Kulit Risol",
    type: "semi_finished",
    outputName: "Kulit Risol",
    outputQuantity: 90,
    outputUnit: "pcs",
    notes: "Untuk 1 kg adonan kulit (asumsi 90 lembar).",
    ingredients: [
      { name: "Tepung Terigu", quantity: 1 },
      { name: "Tepung Tapioka Gunung", quantity: 0.26 },
      { name: "Garam", quantity: 0.05 },
      { name: "Air", quantity: 2.6 },
      { name: "Telur", quantity: 0.133 },
      { name: "Minyak Adonan Risol", quantity: 0.04 },
      { name: "Gas LPG 3kg", quantity: 0.6 },
    ],
  },
  {
    name: "Panir",
    type: "semi_finished",
    outputName: "Adonan Panir",
    outputQuantity: 90,
    outputUnit: "pcs",
    notes: "Komposisi panir untuk 1 kg kulit risol.",
    ingredients: [
      { name: "Tepung Terigu", quantity: 0.2 },
      { name: "Air", quantity: 0.6 },
      { name: "Panir Pita 10kg", quantity: 0.765 },
    ],
  },
  {
    name: "Saus Mayo Original",
    type: "semi_finished",
    outputName: "Saus Mayo Original",
    outputQuantity: 35,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
    ],
  },
  {
    name: "Saus Spicy Mayo",
    type: "semi_finished",
    outputName: "Saus Spicy Mayo",
    outputQuantity: 70,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
      { name: "Delmonte Cabe 1kg", quantity: 1 },
      { name: "Nori MamaSuka", quantity: 0.296 },
    ],
  },
  {
    name: "Saus Mayo Spesial",
    type: "semi_finished",
    outputName: "Saus Mayo Spesial",
    outputQuantity: 70,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
      { name: "Delmonte Cabe 1kg", quantity: 0.5 },
      { name: "Kewpie 1kg", quantity: 0.5 },
    ],
  },
  {
    name: "Isian Ayam Pedas",
    type: "semi_finished",
    outputName: "Isian Ayam Pedas",
    outputQuantity: 100,
    outputUnit: "porsi",
    notes: "Bumbu (bawang, cabai, kaldu, garam, gula, minyak) ditambahkan secukupnya sesuai selera.",
    ingredients: [
      { name: "Dada Fillet", quantity: 1 },
      { name: "Gas LPG 3kg", quantity: 5 },
    ],
  },
  {
    name: "Isian Ragout",
    type: "semi_finished",
    outputName: "Isian Ragout",
    outputQuantity: 100,
    outputUnit: "porsi",
    ingredients: [
      { name: "Wortel", quantity: 1 },
      { name: "Kentang", quantity: 1 },
      { name: "Jagung", quantity: 1 },
      { name: "Dada Fillet", quantity: 1 },
      { name: "Mentega", quantity: 50 },
      { name: "Totole Kaldu Jamur", quantity: 100 },
      { name: "Susu UHT Diamond", quantity: 1 },
      { name: "Air", quantity: 0.5 },
      { name: "Garam", quantity: 0.1 },
      { name: "Tepung Terigu", quantity: 0.15 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.25 },
      { name: "Gas LPG 3kg", quantity: 1.2 },
    ],
  },
  // ---- Finished (Varian Risol) ----
  {
    name: "Risol Mayo Original",
    type: "finished",
    outputName: "Risol Mayo Original",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Mayo Original", quantity: 1 },
      { name: "Slice Beef 1kg", quantity: 0.05 },
      { name: "Telur", quantity: 0.0085 },
    ],
  },
  {
    name: "Risol Spicy Nori",
    type: "finished",
    outputName: "Risol Spicy Nori",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Spicy Mayo", quantity: 1 },
      { name: "Cidea Crabstick 1kg", quantity: 0.06 },
      { name: "Telur", quantity: 0.0085 },
    ],
  },
  {
    name: "Risol Mayo Spesial",
    type: "finished",
    outputName: "Risol Mayo Spesial",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Mayo Spesial", quantity: 1 },
      { name: "Slice Beef 1kg", quantity: 0.05 },
      { name: "Telur", quantity: 0.0085 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.004 },
      { name: "Prochiz Quick Melt Slice", quantity: 0.0667 },
    ],
  },
  {
    name: "Risol Ragout Ayam",
    type: "finished",
    outputName: "Risol Ragout Ayam",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Isian Ragout", quantity: 1 },
    ],
  },
  {
    name: "Risol Coklat Crispy",
    type: "finished",
    outputName: "Risol Coklat Crispy",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Choco Crunchy 1kg", quantity: 0.022 },
      { name: "Rice Crispy 1kg", quantity: 0.01 },
    ],
  },
  {
    name: "Risol Matcha Cheese",
    type: "finished",
    outputName: "Risol Matcha Cheese",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Greentea Crunchy 1kg", quantity: 0.025 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.02 },
    ],
  },
  {
    name: "Risol Choco Cheese",
    type: "finished",
    outputName: "Risol Choco Cheese",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Choco Crunchy 1kg", quantity: 0.025 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.02 },
    ],
  },
];

/**
 * @deprecated Dinonaktifkan pada migrasi Prompt 2 — lihat catatan besar di
 * atas `seedIfEmpty()`. recipeService belum dikonsumsi UI manapun, jadi
 * belum ada seed SQL untuk resep. Dipertahankan sebagai no-op (bukan
 * dihapus) supaya pemanggilnya di role-context.tsx tidak perlu ikut diubah.
 */
export function seedRecipesIfEmpty() {
  // no-op — lihat catatan di atas seedIfEmpty().
}