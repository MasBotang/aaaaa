import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import { preorderService } from "./preorder.service";
import { auditService } from "./audit.service";
import type { PreOrder, Role } from "./types";

export type PreOrderCancelStatus = "pending" | "approved" | "rejected";

export const PREORDER_CANCEL_STATUS_LABEL: Record<PreOrderCancelStatus, string> = {
  pending: "Menunggu Approval",
  approved: "Disetujui (Dibatalkan)",
  rejected: "Ditolak",
};

export interface PreOrderCancelRequest {
  id: string;
  preorderId: string;
  requestedBy: string;
  requestedByRole?: Role;
  requestedAt: string;
  reason: string;
  status: PreOrderCancelStatus;
  decidedBy?: string;
  decidedByRole?: Role;
  decidedAt?: string;
  decisionNote?: string;
  downPaymentAtRequest: number;
}

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 4 — Pre Order Cancel Requests): sekarang
// bersandar pada tabel `public.preorder_cancel_requests`. Semua mutasi
// async; permukaan sync (`listCached`, `pendingCountCached`, `byPreorder`)
// dipakai UI (badge & lookup pending per PO) — dipopulasikan oleh `list()`
// dan mutasi.
// ---------------------------------------------------------------------------

interface Row {
  id: string;
  legacy_id: string | null;
  preorder_id: string;
  requested_by: string;
  requested_by_role: Role | null;
  requested_at: string;
  reason: string;
  status: PreOrderCancelStatus;
  decided_by: string | null;
  decided_by_role: Role | null;
  decided_at: string | null;
  decision_note: string | null;
  down_payment_at_request: number;
}

function fromRow(r: Row): PreOrderCancelRequest {
  return {
    id: r.id,
    preorderId: r.preorder_id,
    requestedBy: r.requested_by,
    requestedByRole: r.requested_by_role ?? undefined,
    requestedAt: r.requested_at,
    reason: r.reason,
    status: r.status,
    decidedBy: r.decided_by ?? undefined,
    decidedByRole: r.decided_by_role ?? undefined,
    decidedAt: r.decided_at ?? undefined,
    decisionNote: r.decision_note ?? undefined,
    downPaymentAtRequest: Number(r.down_payment_at_request) || 0,
  };
}

let _cache: PreOrderCancelRequest[] = [];
function setCache(rows: PreOrderCancelRequest[]) {
  _cache = rows;
}
function upsertCache(r: PreOrderCancelRequest) {
  const i = _cache.findIndex((x) => x.id === r.id);
  if (i >= 0) _cache = [..._cache.slice(0, i), r, ..._cache.slice(i + 1)];
  else _cache = [r, ..._cache];
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, {
        detail: { key: StorageKeys.preorderCancelRequests },
      }),
    );
  } catch (err) {
    console.error("[preorder-cancel] emit storage-write failed", err);
  }
}

export const preorderCancelService = {
  async list(): Promise<PreOrderCancelRequest[]> {
    const { data, error } = await supabase
      .from("preorder_cancel_requests")
      .select("*")
      .order("requested_at", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  listCached(): PreOrderCancelRequest[] {
    return _cache;
  },

  byPreorder(preorderId: string): PreOrderCancelRequest | undefined {
    return _cache.find((r) => r.preorderId === preorderId && r.status === "pending");
  },

  async request(input: {
    preorderId: string;
    reason: string;
    actor: string;
    actorRole?: Role;
  }): Promise<PreOrderCancelRequest> {
    // Cek duplikat via server supaya konkuren aman (cache mungkin belum
    // punya baris yang baru dibuat di tab/device lain).
    {
      const { data, error } = await supabase
        .from("preorder_cancel_requests")
        .select("*")
        .eq("preorder_id", input.preorderId)
        .eq("status", "pending")
        .maybeSingle();
      if (error) throw error;
      if (data) {
        const existing = fromRow(data as Row);
        upsertCache(existing);
        return existing;
      }
    }
    const po = await preorderService.byId(input.preorderId);
    const insert = {
      preorder_id: input.preorderId,
      reason: input.reason,
      requested_by: input.actor,
      requested_by_role: input.actorRole ?? null,
      requested_at: new Date().toISOString(),
      status: "pending" as const,
      down_payment_at_request: po?.downPayment ?? 0,
    };
    const { data, error } = await supabase
      .from("preorder_cancel_requests")
      .insert(insert)
      .select("*")
      .single();
    if (error) throw error;
    const rec = fromRow(data as Row);
    upsertCache(rec);
    emit();
    try {
      auditService.log({
        actor: input.actor,
        actorRole: input.actorRole,
        action: "preorder_cancel_requested",
        entity: "preorder",
        entityId: input.preorderId,
        reason: input.reason,
        metadata: { downPayment: rec.downPaymentAtRequest },
      });
    } catch (err) {
      console.error("[preorder-cancel] request: audit log failed", err);
    }
    return rec;
  },

  async approve(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): Promise<
    { ok: true; request: PreOrderCancelRequest } | { ok: false; reason: string }
  > {
    // Ambil pengajuan yang paling akhir dari DB (bukan cache) supaya
    // approval yang sudah dilakukan admin lain di device lain terdeteksi.
    const { data: cur, error: e1 } = await supabase
      .from("preorder_cancel_requests")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!cur) return { ok: false, reason: "Pengajuan pembatalan tidak ditemukan" };
    const req = fromRow(cur as Row);
    if (req.status !== "pending") {
      return { ok: false, reason: "Pengajuan pembatalan sudah diputuskan" };
    }
    const po = await preorderService.byId(req.preorderId);
    if (!po) return { ok: false, reason: "Pre Order tidak ditemukan" };
    if (po.status === "completed" || po.status === "cancelled") {
      return {
        ok: false,
        reason: `Pre Order sudah berstatus ${po.status} — tidak bisa diproses lagi`,
      };
    }
    // Batalkan PO dulu (idem seperti versi lama — mencegah state setengah).
    let cancelledPo;
    try {
      cancelledPo = await preorderService.cancel(req.preorderId);
    } catch (err) {
      console.error("[preorder-cancel] approve: gagal membatalkan PO", err);
      return { ok: false, reason: "Gagal membatalkan Pre Order — coba lagi" };
    }
    if (!cancelledPo) {
      return { ok: false, reason: "Pre Order tidak ditemukan / gagal diupdate" };
    }
    const now = new Date().toISOString();
    const { data, error: e2 } = await supabase
      .from("preorder_cancel_requests")
      .update({
        status: "approved",
        decided_at: now,
        decided_by: opts.actor,
        decided_by_role: opts.actorRole ?? null,
        decision_note: opts.note ?? null,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2 || !data) {
      console.error(
        "[preorder-cancel] approve: gagal simpan status approval, rollback PO",
        e2,
      );
      try {
        await preorderService.update(req.preorderId, {
          status: po.status,
          queueId: po.queueId,
        });
      } catch (rollbackErr) {
        console.error("[preorder-cancel] approve: rollback PO juga gagal", rollbackErr);
      }
      return { ok: false, reason: "Gagal menyimpan status approval — coba lagi" };
    }
    const updated = fromRow(data as Row);
    upsertCache(updated);
    emit();
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "preorder_cancel_approved",
        entity: "preorder",
        entityId: req.preorderId,
        reason: opts.note,
        metadata: { downPaymentForfeited: po.downPayment ?? 0 },
      });
    } catch (err) {
      console.error("[preorder-cancel] approve: audit log failed", err);
    }
    return { ok: true, request: updated };
  },

  async reject(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): Promise<PreOrderCancelRequest | null> {
    const { data: cur, error: e1 } = await supabase
      .from("preorder_cancel_requests")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!cur) return null;
    const req = fromRow(cur as Row);
    if (req.status !== "pending") {
      upsertCache(req);
      return req;
    }
    const now = new Date().toISOString();
    const { data, error: e2 } = await supabase
      .from("preorder_cancel_requests")
      .update({
        status: "rejected",
        decided_at: now,
        decided_by: opts.actor,
        decided_by_role: opts.actorRole ?? null,
        decision_note: opts.note ?? null,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2) throw e2;
    if (!data) return null;
    const updated = fromRow(data as Row);
    upsertCache(updated);
    emit();
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "preorder_cancel_rejected",
        entity: "preorder",
        entityId: req.preorderId,
        reason: opts.note,
      });
    } catch (err) {
      console.error("[preorder-cancel] reject: audit log failed", err);
    }
    return updated;
  },

  pendingCount(): number {
    return _cache.filter((r) => r.status === "pending").length;
  },
};

// Silence unused warning bila PreOrder type di atas hanya dipakai untuk
// dokumentasi.
export type _PreOrderRef = PreOrder;
