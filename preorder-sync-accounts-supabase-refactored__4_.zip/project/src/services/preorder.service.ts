import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import type {
  PaymentMethod,
  PreOrder,
  PreOrderStatus,
  SaleItem,
  SalePacking,
  SaleType,
  SourceOrder,
} from "./types";
import { queueService } from "./queue.service";
import { auditService } from "./audit.service";
import { productionNeedService } from "./production-need.service";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 4 — Pre Order): preorderService kini membaca &
// menulis tabel `public.preorders` di Supabase. Semua mutasi async; permukaan
// sync (`listCached`, `byIdCached`, `countActiveCached`, `byDateCached`,
// `productionNeedFor`) dipertahankan untuk compute pipeline lama:
//   - `analytics/sales/data.ts` → `preorderAnalytics()` (useMemo sync)
//   - `products-page.tsx` → filter PO aktif saat konfirmasi hapus produk
//   - `pesanan-page.tsx` → badge PO aktif
// Halaman-halaman itu memasang `usePreorderData()` untuk memicu prefetch +
// re-tick, sama pola dengan queue/sales.
//
// `create`/`update`/`payDp`/`setStatus`/`cancel`/`undoMarkReady`/`remove`/
// `promoteDue` semuanya async. `queueService.create()` sengaja masih SYNC
// (lihat header queue.service.ts) — dipanggil apa adanya dari promoteDue,
// tapi `queueService.removeBySale()`/`.relinkSale()` sudah async dan
// di-await di sini.
//
// Helper waktu (`todayYmd`, `minPickupTimeFor`, `validatePickup`) tetap
// sync — murni logika kalender.
// ---------------------------------------------------------------------------

function nowIso() {
  return new Date().toISOString();
}

function totalOf(items: SaleItem[]) {
  return items.reduce((a, i) => a + i.price * i.qty, 0);
}

/**
 * Buffer minimum (menit) antara waktu saat ini dengan jam pickup untuk PO
 * yang dibuat hari ini.
 */
export const PREORDER_MIN_LEAD_MINUTES = 30;

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function todayYmd(now: Date = new Date()): string {
  return ymd(now);
}

export function minPickupTimeFor(date: string, now: Date = new Date()): string {
  if (!date) return "00:00";
  if (date > todayYmd(now)) return "00:00";
  if (date < todayYmd(now)) return "23:59";
  const t = new Date(now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000);
  return `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}`;
}

export function validatePickup(
  date: string,
  time: string,
  now: Date = new Date(),
): string | null {
  if (!date) return "Tanggal pengambilan wajib diisi";
  if (!time) return "Jam pengambilan wajib diisi";
  const today = todayYmd(now);
  if (date < today) return "Tanggal pengambilan tidak boleh di masa lalu";
  const dt = new Date(`${date}T${time}:00`);
  if (Number.isNaN(dt.getTime())) return "Format tanggal/jam tidak valid";
  const minMs = now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000;
  if (dt.getTime() < minMs) {
    return `Jam pengambilan minimal ${PREORDER_MIN_LEAD_MINUTES} menit dari sekarang`;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Row <-> domain mapping
// ---------------------------------------------------------------------------

interface Row {
  id: string;
  legacy_id: string | null;
  customer_name: string;
  customer_phone: string | null;
  date: string;
  time: string;
  items: SaleItem[] | null;
  total: number;
  notes: string | null;
  status: PreOrderStatus;
  source_order: SourceOrder;
  price_group_id: string | null;
  sale_type: SaleType | null;
  sale_id: string | null;
  queue_id: string | null;
  down_payment: number | null;
  remaining_balance: number | null;
  dp_paid_at: string | null;
  dp_method: PaymentMethod | null;
  packings: SalePacking[] | null;
  created_at: string;
  created_by: string;
  updated_at: string;
}

function fromRow(r: Row): PreOrder {
  return {
    id: r.id,
    customerName: r.customer_name,
    customerPhone: r.customer_phone ?? undefined,
    date: r.date,
    time: r.time,
    items: r.items ?? [],
    total: Number(r.total) || 0,
    notes: r.notes ?? undefined,
    status: r.status,
    sourceOrder: r.source_order,
    priceGroupId: r.price_group_id ?? undefined,
    saleType: r.sale_type ?? undefined,
    saleId: r.sale_id ?? undefined,
    queueId: r.queue_id ?? undefined,
    createdAt: r.created_at,
    createdBy: r.created_by,
    updatedAt: r.updated_at,
    downPayment: r.down_payment != null ? Number(r.down_payment) : undefined,
    remainingBalance:
      r.remaining_balance != null ? Number(r.remaining_balance) : undefined,
    dpPaidAt: r.dp_paid_at ?? undefined,
    dpMethod: r.dp_method ?? undefined,
    packings: r.packings ?? undefined,
  };
}

function toInsertRow(p: PreOrder): Record<string, unknown> {
  return {
    id: p.id,
    customer_name: p.customerName,
    customer_phone: p.customerPhone ?? null,
    date: p.date,
    time: p.time,
    items: p.items,
    total: p.total,
    notes: p.notes ?? null,
    status: p.status,
    source_order: p.sourceOrder,
    price_group_id: p.priceGroupId ?? null,
    sale_type: p.saleType ?? null,
    sale_id: p.saleId ?? null,
    queue_id: p.queueId ?? null,
    down_payment: p.downPayment ?? null,
    remaining_balance: p.remainingBalance ?? null,
    dp_paid_at: p.dpPaidAt ?? null,
    dp_method: p.dpMethod ?? null,
    packings: p.packings ?? [],
    created_at: p.createdAt,
    created_by: p.createdBy,
    updated_at: p.updatedAt,
  };
}

// ---------------------------------------------------------------------------
// In-memory cache untuk permukaan sync (sama pola dengan sales/queue).
// ---------------------------------------------------------------------------

let _cache: PreOrder[] = [];
function setCache(rows: PreOrder[]) {
  _cache = rows;
}
function upsertCache(p: PreOrder) {
  const i = _cache.findIndex((r) => r.id === p.id);
  if (i >= 0) _cache = [..._cache.slice(0, i), p, ..._cache.slice(i + 1)];
  else _cache = [p, ..._cache];
}
function removeFromCacheById(id: string) {
  _cache = _cache.filter((p) => p.id !== id);
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key: StorageKeys.preorders } }),
    );
  } catch (err) {
    console.error("[preorder] emit storage-write failed", err);
  }
  // Backward compat untuk listener yang belum diporting.
  try {
    window.dispatchEvent(new Event("desalut:preorders-changed"));
  } catch {
    /* older browsers */
  }
}

export const preorderService = {
  async list(): Promise<PreOrder[]> {
    const { data, error } = await supabase
      .from("preorders")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  listCached(): PreOrder[] {
    return _cache;
  },

  async byId(id: string): Promise<PreOrder | undefined> {
    const { data, error } = await supabase
      .from("preorders")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (error) throw error;
    return data ? fromRow(data as Row) : undefined;
  },

  byIdCached(id: string): PreOrder | undefined {
    return _cache.find((p) => p.id === id);
  },

  async create(input: {
    customerName: string;
    customerPhone?: string;
    date: string;
    time: string;
    items: SaleItem[];
    notes?: string;
    sourceOrder: SourceOrder;
    priceGroupId?: string;
    saleType?: SaleType;
    createdBy: string;
    outletId?: string;
    downPayment?: number;
    dpMethod?: PaymentMethod;
    packings?: SalePacking[];
  }): Promise<PreOrder> {
    const err = validatePickup(input.date, input.time);
    if (err) throw new Error(err);
    const t = nowIso();
    const total = totalOf(input.items);
    const dp = Math.max(0, Math.min(input.downPayment ?? 0, total));
    const rec: PreOrder = {
      id: crypto.randomUUID(),
      status: "scheduled",
      total,
      createdAt: t,
      updatedAt: t,
      ...input,
      downPayment: dp,
      remainingBalance: total - dp,
      dpPaidAt: dp > 0 ? t : undefined,
      dpMethod: dp > 0 ? input.dpMethod : undefined,
    };
    const { data, error } = await supabase
      .from("preorders")
      .insert(toInsertRow(rec))
      .select("*")
      .single();
    if (error) throw error;
    const saved = fromRow(data as Row);
    upsertCache(saved);
    emit();
    try {
      await productionNeedService.addForPreorder(saved);
    } catch (err) {
      console.error("[preorder] production-need addForPreorder failed", err);
    }
    if (dp > 0) {
      try {
        auditService.log({
          actor: input.createdBy,
          action: "preorder_dp_paid",
          entity: "preorder",
          entityId: saved.id,
          metadata: {
            total,
            downPayment: dp,
            remainingBalance: total - dp,
            method: input.dpMethod,
          },
        });
      } catch (err) {
        console.error("[preorder] audit dp failed", err);
      }
    }
    return saved;
  },

  async update(id: string, patch: Partial<PreOrder>): Promise<PreOrder | null> {
    const cur = (await preorderService.byId(id)) ?? _cache.find((p) => p.id === id);
    if (!cur) return null;
    const prevStatus = cur.status;
    const merged: PreOrder = {
      ...cur,
      ...patch,
      updatedAt: nowIso(),
    };
    if (patch.items) merged.total = totalOf(patch.items);
    const dp = Math.max(0, Math.min(merged.downPayment ?? 0, merged.total));
    merged.downPayment = dp;
    merged.remainingBalance = merged.total - dp;

    const dbPatch: Record<string, unknown> = { updated_at: merged.updatedAt };
    if (patch.items !== undefined) dbPatch.items = merged.items;
    if (patch.items !== undefined || patch.downPayment !== undefined) {
      dbPatch.total = merged.total;
      dbPatch.down_payment = merged.downPayment;
      dbPatch.remaining_balance = merged.remainingBalance;
    }
    if (patch.status !== undefined) dbPatch.status = merged.status;
    if (patch.notes !== undefined) dbPatch.notes = merged.notes ?? null;
    if (patch.customerName !== undefined) dbPatch.customer_name = merged.customerName;
    if (patch.customerPhone !== undefined)
      dbPatch.customer_phone = merged.customerPhone ?? null;
    if (patch.date !== undefined) dbPatch.date = merged.date;
    if (patch.time !== undefined) dbPatch.time = merged.time;
    if (patch.saleType !== undefined) dbPatch.sale_type = merged.saleType ?? null;
    if ("saleId" in patch) dbPatch.sale_id = merged.saleId ?? null;
    if ("queueId" in patch) dbPatch.queue_id = merged.queueId ?? null;
    if (patch.dpPaidAt !== undefined) dbPatch.dp_paid_at = merged.dpPaidAt ?? null;
    if (patch.dpMethod !== undefined) dbPatch.dp_method = merged.dpMethod ?? null;
    if (patch.packings !== undefined) dbPatch.packings = merged.packings ?? [];
    if (patch.sourceOrder !== undefined) dbPatch.source_order = merged.sourceOrder;
    if (patch.priceGroupId !== undefined)
      dbPatch.price_group_id = merged.priceGroupId ?? null;

    const { data, error } = await supabase
      .from("preorders")
      .update(dbPatch)
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (error) throw error;
    if (!data) return null;
    const saved = fromRow(data as Row);
    upsertCache(saved);
    emit();
    if (
      patch.status &&
      patch.status !== prevStatus &&
      (patch.status === "cancelled" || patch.status === "completed")
    ) {
      try {
        await productionNeedService.releaseForPreorder(id, patch.status);
      } catch (err) {
        console.error("[preorder] production-need releaseForPreorder failed", err);
      }
    }
    return saved;
  },

  async payDp(
    id: string,
    amount: number,
    ctx: { actor: string; method?: PaymentMethod },
  ): Promise<PreOrder | null> {
    const cur = await preorderService.byId(id);
    if (!cur) return null;
    const dp = Math.max(0, Math.min((cur.downPayment ?? 0) + amount, cur.total));
    const next = await preorderService.update(id, {
      downPayment: dp,
      dpPaidAt: nowIso(),
      dpMethod: ctx.method ?? cur.dpMethod,
    });
    try {
      auditService.log({
        actor: ctx.actor,
        action: "preorder_dp_paid",
        entity: "preorder",
        entityId: id,
        metadata: {
          added: amount,
          total: cur.total,
          downPayment: dp,
          remainingBalance: cur.total - dp,
          method: ctx.method ?? cur.dpMethod,
        },
      });
    } catch (err) {
      console.error("[preorder] audit payDp failed", err);
    }
    return next;
  },

  async setStatus(id: string, status: PreOrderStatus): Promise<PreOrder | null> {
    return preorderService.update(id, { status });
  },

  /**
   * Batalkan PO — jalur batal langsung (DP=0) atau approval pembatalan
   * (DP>0). Bersihkan entri Queue placeholder bila PO sempat auto-promote.
   */
  async cancel(id: string): Promise<PreOrder | null> {
    const po = await preorderService.byId(id);
    if (!po) return null;
    if (po.queueId) {
      try {
        await queueService.removeBySale(po.id);
      } catch (err) {
        console.error("[preorder] cancel: gagal hapus entri queue", err);
      }
    }
    return preorderService.update(id, { status: "cancelled", queueId: undefined });
  },

  async undoMarkReady(
    id: string,
    ctx: { actor: string; actorRole?: string },
  ): Promise<
    { ok: true; preorder: PreOrder } | { ok: false; reason: string }
  > {
    const po = await preorderService.byId(id);
    if (!po) return { ok: false, reason: "Pre Order tidak ditemukan" };
    if (po.status !== "ready_to_process") {
      return { ok: false, reason: "Hanya bisa diurungkan dari status Siap Diproses" };
    }
    if (po.queueId) {
      try {
        await queueService.removeBySale(po.id);
      } catch (err) {
        console.error("[preorder] undoMarkReady: gagal hapus entri queue", err);
      }
    }
    const next = await preorderService.update(id, { status: "scheduled", queueId: undefined });
    if (!next) return { ok: false, reason: "Pre Order tidak ditemukan" };
    try {
      auditService.log({
        actor: ctx.actor,
        actorRole: ctx.actorRole,
        action: "preorder_mark_ready_undo",
        entity: "preorder",
        entityId: id,
      });
    } catch {
      /* best-effort */
    }
    return { ok: true, preorder: next };
  },

  async remove(id: string): Promise<void> {
    // Lepas ledger dulu (FK on delete restrict → tidak bisa hapus baris
    // preorders selama ada production_need_additions yang mengacu).
    try {
      await productionNeedService.releaseForPreorder(id, "manual");
    } catch (err) {
      console.error("[preorder] production-need release on remove failed", err);
    }
    // production_need_additions.preorder_id ON DELETE RESTRICT — hapus
    // baris ledger terlebih dahulu supaya delete preorder tidak gagal.
    // (Baris ledger sudah dilepas jadi status='released'; sekarang dihapus
    // permanen — histori PO sudah tidak relevan sekali PO itu sendiri
    // dihapus permanen dari UI oleh admin.)
    try {
      const { error } = await supabase
        .from("production_need_additions")
        .delete()
        .eq("preorder_id", id);
      if (error) console.error("[preorder] delete ledger rows failed", error);
    } catch (err) {
      console.error("[preorder] delete ledger rows threw", err);
    }
    const { error } = await supabase.from("preorders").delete().eq("id", id);
    if (error) throw error;
    removeFromCacheById(id);
    emit();
  },

  byDate(date: string): PreOrder[] {
    return _cache.filter((p) => p.date === date);
  },

  /**
   * Promote PO scheduled yang sudah jatuh tempo (date+time <= now) menjadi
   * ready_to_process dan buat entri Queue. Tidak membuat Sale.
   */
  async promoteDue(now = new Date()): Promise<{ promoted: PreOrder[] }> {
    // Query hanya PO scheduled — hemat payload.
    const { data, error } = await supabase
      .from("preorders")
      .select("*")
      .eq("status", "scheduled");
    if (error) throw error;
    const scheduled = ((data ?? []) as Row[]).map(fromRow);
    const promoted: PreOrder[] = [];
    for (const po of scheduled) {
      const dt = new Date(`${po.date}T${po.time || "00:00"}:00`);
      if (Number.isNaN(dt.getTime())) continue;
      if (dt.getTime() > now.getTime()) continue;
      let queueId = po.queueId;
      if (!queueId) {
        try {
          // queueService.create() SYNC (lihat header queue.service.ts).
          const q = queueService.create({
            saleId: po.id,
            saleCode: po.id,
            saleType: po.saleType ?? "frozen",
            customerName: po.customerName,
            customerPhone: po.customerPhone,
            pickupAt: dt.toISOString(),
            isPreorder: true,
            itemCount: po.items.reduce((a, c) => a + c.qty, 0),
            itemsSummary: po.items.map((i) => `${i.qty}× ${i.name}`).join(", "),
            sourceOrder: po.sourceOrder,
          });
          queueId = q.id;
        } catch (err) {
          console.error("[preorder] promote → queue.create failed", err);
        }
      }
      const updated = await preorderService.update(po.id, {
        status: "ready_to_process",
        queueId,
      });
      if (updated) promoted.push(updated);
    }
    return { promoted };
  },

  countByDate(date: string): number {
    return _cache.filter(
      (p) => p.date === date && p.status !== "cancelled" && p.status !== "completed",
    ).length;
  },

  countActive(): number {
    return _cache.filter((p) => p.status !== "cancelled" && p.status !== "completed").length;
  },

  productionNeedFor(dates: string[]): { productId: string; name: string; qty: number }[] {
    const map = new Map<string, { productId: string; name: string; qty: number }>();
    for (const p of _cache) {
      if (!dates.includes(p.date)) continue;
      if (p.status === "cancelled" || p.status === "completed") continue;
      for (const it of p.items) {
        const cur = map.get(it.productId);
        if (cur) cur.qty += it.qty;
        else map.set(it.productId, { productId: it.productId, name: it.name, qty: it.qty });
      }
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty);
  },
};
