import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import type {
  Sale,
  SaleType,
  SourceOrder,
  SalePacking,
  SalePlastic,
  SaleExtraPackaging,
  PaymentEntry,
  SaleItem,
  CustomerType,
} from "./types";
import { productService } from "./product.service";
import { queueService } from "./queue.service";
import { auditService } from "./audit.service";
import { stockMovementService } from "./stock-movement.service";
import { inventoryService } from "./inventory.service";
import {
  buildManualPacking,
  resolveSalePlasticDeductions,
  summarizePackingsPlasticForDisplay,
} from "./packing";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 2 — Sales/POS): salesService sekarang membaca
// dan menulis tabel `public.sales` di Supabase (bukan localStorage lagi).
//
// Public API — sepersis mungkin dengan versi localStorage — tapi mutasi &
// list utama menjadi async:
//   list() -> Promise<Sale[]>            — fetch + prime cache
//   listCached() -> Sale[]               — sinkron, baca cache terakhir
//   refresh() -> Promise<Sale[]>         — alias eksplisit list()
//   byDateRange(from, to) -> Promise<Sale[]>  — server-side filter
//   create(input) -> Promise<Sale>       — validasi + deduct + insert
//   void(id, opts) -> Promise<void>      — soft-void + rollback stok
//   canRefund(id) -> Promise<{...}>      — cek eligibility (async karena
//                                          butuh row dari DB)
//
// Kenapa `listCached()` sinkron? Sejumlah compute pipeline lama
// (finance-analytics, finance-aggregation, analytics/sales/data,
// analytics/sales/operational-data, sales-summary, production-planning,
// shift.service.savePackagingUsage baseline, dan pesanan-page) mengiterasi
// `salesService.list()` dari dalam `useMemo` sinkron atau helper murni.
// Refactor mereka ke async param-passing berada di scope prompt 3+
// (queue/preorder/refund) — untuk sekarang kita pertahankan permukaan
// sinkron dengan cache in-memory yang dipopulasikan oleh `list()` (async)
// dan diperbarui oleh create()/void(). Halaman yang mengonsumsi compute
// tersebut memasang `useSalesData()` (react-query) untuk memicu prefetch
// dan bereaksi pada invalidasi — sama pola dengan `useShiftData()` di
// Tahap 1.
//
// KEPUTUSAN TRANSAKSI CHECKOUT (didokumentasikan di docs/sales-domain-
// migration.md §"2. Sales/POS"):
//
//   1. Ambil nomor invoice & nomor antrean via RPC `next_daily_counter`
//      (atomik UPSERT + RETURNING) — race condition versi localStorage
//      hilang di sini.
//   2. Validasi ready stock + packaging (baca products & inventory).
//   3. Insert baris `sales` dengan `voided=false`.
//   4. Panggil `productService.deduct()` (RPC atomik) per baris item.
//      Bila gagal DI TENGAH loop: rollback manual (a) DELETE baris sales
//      yang baru dibuat, (b) addStock() balik untuk item yang sudah
//      terlanjur dipotong, lalu throw. Bagian ini memang bukan satu
//      transaksi Postgres — pilihan sadar supaya tetap memakai RPC
//      deduct/addStock yang sudah audit-friendly, dan bukan bikin RPC
//      monolit `checkout_sale()` baru. Kegagalan parsial rollback (mis.
//      produk sudah dihapus admin antara deduct dan rollback) dicatat
//      lewat audit `sales_rollback_partial_failure` supaya bisa
//      direkonsiliasi manual.
//   5. Setelah deduct sukses: catat stock movement packaging, insert
//      antrean, tulis audit log — kegagalan di langkah ini TIDAK
//      membatalkan Sale (behavior existing dipertahankan, dicatat sebagai
//      audit anomaly).
//
// RLS: tabel `sales` sudah diberi policy insert/update untuk role
// `admin` & `cashier` (lihat init migration §Section 7). Cashier boleh
// checkout & void; delete admin-only (tidak dipakai di UI — void =
// soft-delete via kolom `voided`).
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Row <-> domain mapping
// ---------------------------------------------------------------------------

interface SaleRow {
  id: string;
  legacy_id: string | null;
  created_at: string;
  cashier: string;
  customer_name: string | null;
  shift_id: string | null;
  items: SaleItem[] | null;
  subtotal: number | string;
  total: number | string;
  payment: PaymentEntry[] | null;
  tendered: number | string | null;
  change: number | string | null;
  voided: boolean;
  void_reason: string | null;
  voided_by: string | null;
  voided_at: string | null;
  sale_type: SaleType | null;
  customer_type: CustomerType | null;
  is_preorder: boolean;
  customer_phone: string | null;
  pickup_at: string | null;
  source_order: SourceOrder | null;
  price_group_id: string | null;
  preorder_id: string | null;
  order_number: string | null;
  packings: SalePacking[] | null;
  plastic: SalePlastic | null;
  extra_packaging: SaleExtraPackaging[] | null;
  customer_notes: string | null;
}

function n(v: number | string | null | undefined): number | undefined {
  if (v === null || v === undefined) return undefined;
  const x = typeof v === "string" ? Number(v) : v;
  return Number.isFinite(x) ? x : undefined;
}

function fromRow(row: SaleRow): Sale {
  return {
    id: row.id,
    createdAt: row.created_at,
    cashier: row.cashier,
    customerName: row.customer_name ?? undefined,
    shiftId: row.shift_id ?? undefined,
    items: row.items ?? [],
    subtotal: n(row.subtotal) ?? 0,
    total: n(row.total) ?? 0,
    payment: row.payment ?? [],
    tendered: n(row.tendered),
    change: n(row.change),
    voided: row.voided,
    voidReason: row.void_reason ?? undefined,
    voidedBy: row.voided_by ?? undefined,
    voidedAt: row.voided_at ?? undefined,
    saleType: row.sale_type ?? undefined,
    customerType: row.customer_type ?? undefined,
    isPreorder: row.is_preorder,
    customerPhone: row.customer_phone ?? undefined,
    pickupAt: row.pickup_at ?? undefined,
    // Backfill: sale lama tanpa sourceOrder dianggap "outlet".
    sourceOrder: (row.source_order ?? "outlet") as SourceOrder,
    priceGroupId: row.price_group_id ?? undefined,
    preorderId: row.preorder_id ?? undefined,
    orderNumber: row.order_number ?? undefined,
    packings: row.packings ?? undefined,
    plastic: row.plastic ?? undefined,
    extraPackaging: row.extra_packaging ?? undefined,
    customerNotes: row.customer_notes ?? undefined,
  };
}

// ---------------------------------------------------------------------------
// In-memory cache for sync accessors (see comment at top).
// ---------------------------------------------------------------------------

let _cache: Sale[] | null = null;

function setCache(list: Sale[]) {
  _cache = list;
  // Backward-compat event supaya `useSalesRefresh` (yang men-subscribe
  // `desalut:storage-write` dengan key `sales`) tetap re-tick — dengan
  // begitu pages yang lama listen event storage tidak perlu diubah.
  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(
        new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key: StorageKeys.sales } }),
      );
    } catch {
      /* ignore — SSR / non-DOM environment */
    }
  }
}

function upsertInCache(sale: Sale) {
  if (!_cache) {
    _cache = [sale];
  } else {
    const idx = _cache.findIndex((s) => s.id === sale.id);
    if (idx >= 0) {
      const next = [..._cache];
      next[idx] = sale;
      _cache = next;
    } else {
      _cache = [sale, ..._cache];
    }
  }
  setCache(_cache);
}

// ---------------------------------------------------------------------------
// Counter helpers.
//
// Skema init migration menyiapkan `public.daily_counters` untuk UPSERT
// atomik, tapi tabelnya hanya diberi policy SELECT untuk `authenticated`
// (INSERT/UPDATE tidak ada). Migrasi RPC SECURITY DEFINER yang
// direncanakan untuk membuka jalur UPSERT atomik dari kasir belum bisa
// ditulis di prompt ini (migration tooling belum tersedia untuk agent —
// akan disusulkan di prompt berikutnya sekaligus tabel `daily_counters`
// yang sekarang belum terpakai).
//
// Sementara itu, nomor invoice diturunkan dari MAX(legacy_id) hari ini +
// 1. Karena `sales.legacy_id` adalah kolom `text unique`, race condition
// dua tab tidak akan silent-corrupt: satu tab akan mendapat error 23505
// dan create() otomatis me-retry dengan nomor berikutnya (hingga 5x).
// Nomor antrean (`order_number`) tidak unique, tapi diturunkan dari
// MAX(order_number) hari ini + 1 sehingga collision berupa duplicate
// display-only saja (tidak fatal, sesuai perilaku versi localStorage
// yang juga tidak enforce uniqueness).
// ---------------------------------------------------------------------------

function dayBounds(now: Date): { fromIso: string; toIso: string; ymd: string } {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return { fromIso: start.toISOString(), toIso: end.toISOString(), ymd: `${y}${m}${d}` };
}

async function nextSalesSeq(now: Date, ymd: string, fromIso: string, toIso: string): Promise<number> {
  const prefix = `INV-${ymd}-`;
  const { data, error } = await supabase
    .from("sales")
    .select("legacy_id")
    .like("legacy_id", `${prefix}%`)
    .gte("created_at", fromIso)
    .lte("created_at", toIso)
    .order("legacy_id", { ascending: false })
    .limit(1);
  if (error) throw error;
  const rows = (data ?? []) as { legacy_id: string | null }[];
  const last = rows[0]?.legacy_id ?? null;
  if (!last) return 1;
  const n = Number(last.slice(prefix.length));
  return Number.isFinite(n) ? n + 1 : 1;
}

async function nextOrderNum(fromIso: string, toIso: string): Promise<number> {
  const { data, error } = await supabase
    .from("sales")
    .select("order_number")
    .not("order_number", "is", null)
    .gte("created_at", fromIso)
    .lte("created_at", toIso);
  if (error) throw error;
  const rows = (data ?? []) as { order_number: string | null }[];
  let max = 0;
  for (const r of rows) {
    if (!r.order_number) continue;
    const n = Number(r.order_number.replace(/[^0-9]/g, ""));
    if (Number.isFinite(n) && n > max) max = n;
  }
  return max + 1;
}

// ---------------------------------------------------------------------------
// Fetch helpers
// ---------------------------------------------------------------------------

async function fetchAll(): Promise<Sale[]> {
  const { data, error } = await supabase
    .from("sales")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as SaleRow[]).map(fromRow);
}

async function fetchOne(id: string): Promise<Sale | null> {
  // `id` dari kasir bisa format "INV-..." (legacy_id) — coba dua kolom.
  const { data, error } = await supabase
    .from("sales")
    .select("*")
    .or(`id.eq.${id},legacy_id.eq.${id}`)
    .maybeSingle();
  if (error) throw error;
  return data ? fromRow(data as SaleRow) : null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export const salesService = {
  async list(): Promise<Sale[]> {
    const rows = await fetchAll();
    setCache(rows);
    return rows;
  },

  /**
   * Sync accessor untuk compute pipeline lama (analytics/finance-aggregation/
   * sales-summary/pesanan-page/shift savePackagingUsage baseline). Nilai
   * berasal dari cache yang dipopulasikan `list()`/`create()`/`void()`;
   * kosong sebelum `list()` pertama dipanggil. Halaman yang mengonsumsi
   * compute tersebut memasang `useSalesData()` untuk menjamin cache
   * terisi & ikut invalidasi.
   */
  listCached(): Sale[] {
    return _cache ?? [];
  },

  async refresh(): Promise<Sale[]> {
    return salesService.list();
  },

  async byDateRange(from: Date, to: Date): Promise<Sale[]> {
    const { data, error } = await supabase
      .from("sales")
      .select("*")
      .gte("created_at", from.toISOString())
      .lte("created_at", to.toISOString())
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data as SaleRow[]).map(fromRow);
  },

  async create(input: Omit<Sale, "id" | "createdAt">): Promise<Sale> {
    const now = new Date();
    const restInput = input;
    const saleType: SaleType = restInput.saleType ?? "frozen";
    const sourceOrder: SourceOrder = (restInput.sourceOrder ?? "outlet") as SourceOrder;

    if (!restInput.shiftId) {
      // Prompt 2 requirement: sales.shift_id FK ke shifts(id) — checkout
      // MUST reject bila caller tidak menyertakan shift aktif. Pesan
      // jelas ke UI (bukan constraint violation Postgres).
      throw new Error("Shift belum dibuka — transaksi tidak bisa disimpan");
    }

    const hasExplicitPackings = !!(restInput.packings && restInput.packings.length > 0);
    const packings: SalePacking[] = hasExplicitPackings
      ? (restInput.packings as SalePacking[])
      : [
          buildManualPacking(
            restInput.items.map((i) => ({ productId: i.productId, name: i.name, qty: i.qty })),
          ),
        ];

    const isSplit = packings.length > 1;
    const packingsFinal: SalePacking[] = packings;
    const plastic: SalePlastic | undefined = isSplit
      ? summarizePackingsPlasticForDisplay(packingsFinal)
      : packingsFinal[0]?.plastic;
    const extraPackaging: SaleExtraPackaging[] | undefined = restInput.extraPackaging;

    // ---- Validasi ready stock & packaging (fail-fast, sama seperti versi
    //      localStorage — lihat commit history untuk konteks H-1) ----
    const productsForValidation = await productService.list();
    const neededByProduct = new Map<string, number>();
    for (const line of restInput.items) {
      neededByProduct.set(
        line.productId,
        (neededByProduct.get(line.productId) ?? 0) + line.qty,
      );
    }
    const missingStock: string[] = [];
    for (const [productId, qty] of neededByProduct) {
      const p = productsForValidation.find((x) => x.id === productId);
      if (!p) continue;
      const cur = p.stock ?? 0;
      if (cur < qty) {
        missingStock.push(`${p.name} (tersedia ${cur}, butuh ${qty})`);
      }
    }
    if (missingStock.length) {
      throw new Error(`Ready stock tidak mencukupi: ${missingStock.join("; ")}`);
    }

    const need = new Map<string, { qty: number; name: string }>();
    const unresolvedPackaging: { name: string; qty: number }[] = [];
    const addNeed = (itemId: string | undefined, qty: number, name: string) => {
      if (qty <= 0) return;
      if (!itemId) {
        unresolvedPackaging.push({ name, qty });
        return;
      }
      const cur = need.get(itemId);
      if (cur) cur.qty += qty;
      else need.set(itemId, { qty, name });
    };
    for (const p of packingsFinal) addNeed(p.boxItemId, p.boxQty, p.boxItemName);
    for (const pl of resolveSalePlasticDeductions({ packings: packingsFinal, plastic })) {
      addNeed(pl.itemId, pl.qty, pl.itemName || "plastik");
    }
    for (const ex of extraPackaging ?? []) addNeed(ex.itemId, ex.qty, ex.itemName);
    const shortage: string[] = [];
    for (const [itemId, v] of need) {
      const inv = await inventoryService.get(itemId);
      if (!inv) {
        unresolvedPackaging.push({ name: v.name, qty: v.qty });
        continue;
      }
      if (inv.stock < v.qty) {
        shortage.push(`${inv.name} (tersedia ${inv.stock}, butuh ${v.qty})`);
      }
    }
    if (shortage.length) {
      throw new Error(`Stok packaging tidak mencukupi: ${shortage.join("; ")}`);
    }

    // ---- Seluruh validasi lolos — ambil nomor urut & INSERT (retry
    //      pada tabrakan legacy_id akibat race dua-tab). ----
    const { fromIso, toIso, ymd } = dayBounds(now);
    let orderNumStart = await nextOrderNum(fromIso, toIso);
    let attempt = 0;
    let inserted: SaleRow | null = null;
    let legacyId = "";
    let orderNumber = "";
    let dbId = "";
    while (attempt < 5 && !inserted) {
      const seq = (await nextSalesSeq(now, ymd, fromIso, toIso)) + attempt;
      legacyId = `INV-${ymd}-${String(seq).padStart(4, "0")}`;
      orderNumber = `#${String(orderNumStart + attempt).padStart(3, "0")}`;
      dbId = crypto.randomUUID();
      const insertRow = {
        id: dbId,
        legacy_id: legacyId,
        created_at: now.toISOString(),
        cashier: restInput.cashier,
        customer_name: restInput.customerName ?? null,
        shift_id: restInput.shiftId,
        items: restInput.items,
        subtotal: restInput.subtotal,
        total: restInput.total,
        payment: restInput.payment,
        tendered: restInput.tendered ?? null,
        change: restInput.change ?? null,
        voided: false,
        sale_type: saleType,
        customer_type: restInput.customerType ?? null,
        is_preorder: !!restInput.isPreorder,
        customer_phone: restInput.customerPhone ?? null,
        pickup_at: restInput.pickupAt ?? null,
        source_order: sourceOrder,
        price_group_id: restInput.priceGroupId ?? null,
        preorder_id: restInput.preorderId ?? null,
        order_number: orderNumber,
        packings: packingsFinal,
        plastic: plastic ?? null,
        extra_packaging: extraPackaging ?? [],
        customer_notes: restInput.customerNotes ?? null,
      };
      const { data, error: insertErr } = await supabase
        .from("sales")
        .insert(insertRow)
        .select()
        .single();
      if (!insertErr) {
        inserted = data as SaleRow;
        break;
      }
      // 23505 = unique_violation di legacy_id → tab lain menang; retry.
      const pgErr = insertErr as { code?: string; message?: string };
      const isDup = pgErr.code === "23505" || /legacy_id/i.test(pgErr.message ?? "");
      if (!isDup) throw insertErr;
      attempt += 1;
      // orderNumStart tidak perlu di-refresh: attempt-offset di atas
      // sudah melampauinya, dan collision order_number tidak fatal.
    }
    if (!inserted) {
      throw new Error("Gagal menyimpan Sale — nomor invoice bentrok berulang, coba lagi");
    }
    const sale: Sale = fromRow(inserted);
    // Gunakan legacy_id (INV-...) sebagai id "yang dilihat kasir" supaya
    // UI/receipt/print/audit tetap identik dengan versi localStorage.
    const uiSale: Sale = { ...sale, id: legacyId };
    // Simpan agregate dbId untuk kebutuhan void() nanti (lihat void()).
    dbIdByLegacy.set(legacyId, dbId);

    if (unresolvedPackaging.length > 0) {
      auditService.log({
        actor: uiSale.cashier,
        action: "packaging_name_mismatch",
        entity: "sale",
        entityId: uiSale.id,
        reason: `Packaging tidak terhubung ke Inventory (nama tidak cocok/item dihapus) — pengurangan stok otomatis TIDAK berjalan untuk: ${unresolvedPackaging
          .map((u) => `${u.name} (butuh ${u.qty})`)
          .join("; ")}`,
        metadata: { saleId: uiSale.id, items: unresolvedPackaging },
      });
    }

    // ---- Deduct ready stock (RPC atomik). Rollback manual bila gagal
    //      di tengah loop: hapus Sale + addStock() balik untuk yang
    //      sudah terpotong. ----
    const deducted: { productId: string; qty: number }[] = [];
    try {
      for (const line of uiSale.items) {
        await productService.deduct(line.productId, line.qty, {
          actor: uiSale.cashier,
          reason: `Sale ${uiSale.id}`,
          source: "sales",
          entityId: uiSale.id,
        });
        deducted.push({ productId: line.productId, qty: line.qty });
      }
    } catch (err) {
      console.error("[sales] deduct failed — rolling back", err);
      // Rollback: kembalikan stok item yang sudah terpotong, lalu hapus
      // baris sales. Kegagalan sub-step dicatat ke audit, TIDAK menelan
      // error asli (yang tetap di-throw ke caller supaya UI tampilkan
      // pesan spesifik "Stok X tidak mencukupi").
      const rollbackErrors: string[] = [];
      for (const d of deducted) {
        try {
          await productService.addStock(d.productId, d.qty, {
            actor: uiSale.cashier,
            reason: `Rollback checkout Sale ${uiSale.id} (deduct gagal)`,
            source: "sales",
            entityId: uiSale.id,
          });
        } catch (rbErr) {
          rollbackErrors.push(`${d.productId}: ${(rbErr as Error).message ?? rbErr}`);
        }
      }
      const { error: delErr } = await supabase.from("sales").delete().eq("id", dbId);
      if (delErr) rollbackErrors.push(`delete sale: ${delErr.message}`);
      dbIdByLegacy.delete(legacyId);
      if (rollbackErrors.length) {
        auditService.log({
          actor: uiSale.cashier,
          action: "sales_rollback_partial_failure",
          entity: "sale",
          entityId: uiSale.id,
          reason: `Rollback checkout tidak sempurna — perlu rekonsiliasi manual: ${rollbackErrors.join("; ")}`,
          metadata: { saleId: uiSale.id, deducted, errors: rollbackErrors },
        });
      }
      throw err;
    }

    // ---- Packaging movement recording — kegagalan di sini TIDAK
    //      membatalkan Sale (behavior existing). ----
    const processedMovements: { itemId: string; label: string; qty: number }[] = [];
    try {
      const usedBoxes: { itemId: string; name: string; qty: number }[] = [];
      for (const p of packingsFinal) {
        if (p.boxItemId && p.boxQty > 0) {
          await stockMovementService.record({
            itemId: p.boxItemId,
            type: "sales_packaging_usage",
            quantity: p.boxQty,
            reason: `Sale ${uiSale.id} · ${uiSale.orderNumber}`,
          });
          usedBoxes.push({ itemId: p.boxItemId, name: p.boxItemName, qty: p.boxQty });
          processedMovements.push({ itemId: p.boxItemId, label: p.boxItemName, qty: p.boxQty });
        }
      }
      const plasticDeductions = resolveSalePlasticDeductions({ packings: packingsFinal, plastic });
      for (const pl of plasticDeductions) {
        if (pl.itemId && pl.qty > 0) {
          await stockMovementService.record({
            itemId: pl.itemId,
            type: "sales_packaging_usage",
            quantity: pl.qty,
            reason: `Sale ${uiSale.id} · plastik`,
          });
          processedMovements.push({ itemId: pl.itemId, label: pl.itemName || "plastik", qty: pl.qty });
        }
      }
      if (extraPackaging && extraPackaging.length) {
        for (const ex of extraPackaging) {
          if (ex.itemId && ex.qty > 0) {
            await stockMovementService.record({
              itemId: ex.itemId,
              type: "sales_packaging_usage",
              quantity: ex.qty,
              reason: `Sale ${uiSale.id} · packaging tambahan`,
            });
            processedMovements.push({ itemId: ex.itemId, label: ex.itemName, qty: ex.qty });
          }
        }
        auditService.log({
          actor: uiSale.cashier,
          action: "sales_extra_packaging_added",
          entity: "sale",
          entityId: uiSale.id,
          metadata: { extras: extraPackaging, orderNumber: uiSale.orderNumber },
        });
      }
      auditService.log({
        actor: uiSale.cashier,
        action: "sales_packaging_used",
        entity: "sale",
        entityId: uiSale.id,
        metadata: {
          orderNumber: uiSale.orderNumber,
          boxes: usedBoxes,
          plastic: plastic ?? null,
          isSplitPacking: isSplit,
          plasticDeductions,
        },
      });
    } catch (err) {
      console.error("[sales] packaging movement recording failed", err);
      const msg = err instanceof Error ? err.message : String(err);
      auditService.log({
        actor: uiSale.cashier,
        action: "packaging_movement_partial_failure",
        entity: "sale",
        entityId: uiSale.id,
        reason: `Pencatatan pergerakan stok packaging berhenti di tengah jalan (Sale tetap dianggap sukses): ${msg}`,
        metadata: {
          saleId: uiSale.id,
          orderNumber: uiSale.orderNumber,
          processedBeforeFailure: processedMovements,
          error: msg,
        },
      });
    }

    // ---- Queue insert (Pre Order tidak masuk queue) ----
    if (!uiSale.isPreorder) {
      try {
        const totalQty = uiSale.items.reduce((a, c) => a + c.qty, 0);
        queueService.create({
          saleId: uiSale.id,
          saleCode: uiSale.id,
          saleType,
          customerName: uiSale.customerName ?? "-",
          customerPhone: uiSale.customerPhone,
          pickupAt: uiSale.pickupAt,
          isPreorder: false,
          itemCount: totalQty,
          itemsSummary: uiSale.items.map((i) => `${i.qty}× ${i.name}`).join(", "),
          sourceOrder,
          preorderId: uiSale.preorderId,
          orderNumber: uiSale.orderNumber,
          packings: packingsFinal,
        });
      } catch (err) {
        console.error("[sales] queue insert failed", err);
      }
    }

    // ---- Audit ----
    auditService.log({
      actor: uiSale.cashier,
      action: "sale_created",
      entity: "sale",
      entityId: uiSale.id,
      metadata: {
        total: uiSale.total,
        payment: uiSale.payment,
        saleType,
        customerType: uiSale.customerType,
        isPreorder: uiSale.isPreorder,
        sourceOrder,
        priceGroupId: uiSale.priceGroupId,
        orderNumber: uiSale.orderNumber,
        packingCount: packings.length,
      },
    });

    upsertInCache(uiSale);
    return uiSale;
  },

  async void(id: string, opts: { reason: string; actor: string; actorRole?: string }): Promise<void> {
    const now = new Date().toISOString();
    // Resolve dbId dari cache/legacy_id → id.
    const target = await fetchOne(id);
    if (!target) return;
    if (target.voided) return; // idempoten

    const dbId = dbIdByLegacy.get(id) ?? (await resolveDbIdFromLegacy(id));
    if (!dbId) {
      console.error("[sales] void: dbId tidak ditemukan untuk", id);
      return;
    }

    const { error: updErr } = await supabase
      .from("sales")
      .update({
        voided: true,
        void_reason: opts.reason,
        voided_by: opts.actor,
        voided_at: now,
      })
      .eq("id", dbId);
    if (updErr) throw updErr;

    // ---- Rollback penuh transaksi (behavior existing dipertahankan) ----
    for (const line of target.items) {
      try {
        await productService.addStock(line.productId, line.qty, {
          actor: opts.actor,
          reason: `Refund rollback · Sale ${target.id}`,
          source: "refund_rollback",
          entityId: target.id,
        });
      } catch (err) {
        console.error("[sales] refund rollback: ready stock restore failed", err);
      }
    }

    try {
      await queueService.removeBySale(target.id);
    } catch (err) {
      console.error("[sales] refund rollback: queue removal failed", err);
    }

    try {
      const restore = async (itemId: string | undefined, qty: number, note: string) => {
        if (!itemId || qty <= 0) return;
        if (!(await inventoryService.get(itemId))) return;
        await stockMovementService.record({
          itemId,
          type: "restock",
          quantity: qty,
          reason: `Refund rollback · Sale ${target.id}`,
          notes: note,
        });
      };
      for (const p of target.packings ?? []) {
        await restore(p.boxItemId, p.boxQty, "box packing dikembalikan");
      }
      for (const pl of resolveSalePlasticDeductions(target)) {
        await restore(pl.itemId, pl.qty, "plastik dikembalikan");
      }
      for (const ex of target.extraPackaging ?? []) {
        await restore(ex.itemId, ex.qty, "packaging tambahan dikembalikan");
      }
    } catch (err) {
      console.error("[sales] refund rollback: packaging restore failed", err);
    }

    auditService.log({
      actor: opts.actor,
      actorRole: opts.actorRole,
      action: "sale_voided",
      entity: "sale",
      entityId: id,
      reason: opts.reason,
      metadata: {
        total: target.total,
        payment: target.payment,
        rollback: {
          readyStock: target.items.map((i) => ({ productId: i.productId, qty: i.qty })),
          queueRemoved: true,
          packaging: {
            boxes: (target.packings ?? [])
              .filter((p) => p.boxItemId && p.boxQty > 0)
              .map((p) => ({ itemId: p.boxItemId, qty: p.boxQty })),
            plastic: target.plastic ?? null,
            plasticDeductions: resolveSalePlasticDeductions(target),
            extras: target.extraPackaging ?? [],
          },
          sourceOrder: target.sourceOrder,
        },
      },
    });

    // Update cache
    const voidedSale: Sale = {
      ...target,
      voided: true,
      voidReason: opts.reason,
      voidedBy: opts.actor,
      voidedAt: now,
    };
    upsertInCache(voidedSale);
  },

  /**
   * Business rule: refund/void TIDAK dibatasi status produksi. Async
   * sekarang supaya bisa langsung baca dari Supabase (bukan cache) —
   * dipanggil dari refund.service.approve() yang sudah async.
   */
  async canRefund(id: string): Promise<{ ok: true } | { ok: false; reason: string }> {
    const sale = await fetchOne(id);
    if (!sale) return { ok: false, reason: "Transaksi tidak ditemukan" };
    if (sale.voided) return { ok: false, reason: "Transaksi sudah di-refund" };
    return { ok: true };
  },
};

// ---------------------------------------------------------------------------
// Legacy id (INV-...) <-> db uuid mapping. Sale yang di-list dari DB
// memakai legacy_id sebagai `sale.id` (supaya UI/print tidak berubah);
// mutasi seperti void() butuh dbId untuk WHERE clause. Kita cache mapping
// dari hasil list() & create(); fallback ke query bila missing.
// ---------------------------------------------------------------------------

const dbIdByLegacy = new Map<string, string>();

async function resolveDbIdFromLegacy(legacyOrId: string): Promise<string | null> {
  // Coba `id` dulu (mungkin uuid), lalu `legacy_id`.
  const { data, error } = await supabase
    .from("sales")
    .select("id, legacy_id")
    .or(`id.eq.${legacyOrId},legacy_id.eq.${legacyOrId}`)
    .maybeSingle();
  if (error || !data) return null;
  const row = data as { id: string; legacy_id: string | null };
  if (row.legacy_id) dbIdByLegacy.set(row.legacy_id, row.id);
  return row.id;
}
