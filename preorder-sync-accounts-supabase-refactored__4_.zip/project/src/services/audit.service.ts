import { storage, StorageKeys } from "./storage";

export type AuditAction =
  | "sale_created"
  | "sale_voided"
  | "stock_adjustment"
  | "packaging_rule_upsert"
  | "packaging_rule_delete"
  | "product_price_edit"
  | "product_upsert"
  | "settings_update"
  | "shift_open"
  | "shift_close"
  | "queue_status_change"
  | "operational_expense_added"
  | "operational_expense_updated"
  | "operational_expense_deleted"
  | "packaging_usage_saved"
  | "packaging_usage_updated"
  | "sales_packaging_used"
  | "sales_extra_packaging_added"
  | "packaging_name_mismatch"
  | "packaging_movement_partial_failure"
  | "sales_rollback_partial_failure"
  | "production_record_created"
  | "production_release"
  | "production_planning_saved"
  | "refund_requested"
  | "refund_approved"
  | "refund_rejected"
  | "refund_approve_blocked"
  | "preorder_cancel_requested"
  | "preorder_cancel_approved"
  | "preorder_cancel_rejected"
  | "preorder_mark_ready_undo"
  | "product_stock_write"
  | "whatsapp_notification_sent"
  | "preorder_dp_paid"
  | "settlement_posted";

export interface AuditEntry {
  id: string;
  createdAt: string;
  actor: string;
  actorRole?: string;
  action: AuditAction;
  entity?: string;
  entityId?: string;
  reason?: string;
  metadata?: Record<string, unknown>;
}

function uid() {
  return `aud_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

/**
 * Append-only audit log. Tidak menyediakan `remove` / `update` secara sengaja —
 * jejak audit tidak boleh dihapus dari kode aplikasi.
 */
export const auditService = {
  list(): AuditEntry[] {
    return storage.get<AuditEntry[]>(StorageKeys.auditLog) ?? [];
  },
  log(entry: Omit<AuditEntry, "id" | "createdAt">): AuditEntry {
    const rec: AuditEntry = {
      id: uid(),
      createdAt: new Date().toISOString(),
      ...entry,
    };
    const list = auditService.list();
    list.unshift(rec);
    // Sprint 1 (M-7): cap dinaikkan ke 10.000 entry supaya outlet ramai punya
    // buffer >1 bulan sebelum entri tertua terpotong. Rotasi/arsip ke Cloud
    // menyusul saat multi-outlet aktif (BRD Roadmap).
    if (list.length > 10000) list.length = 10000;
    storage.set(StorageKeys.auditLog, list);
    return rec;
  },
  byAction(action: AuditAction): AuditEntry[] {
    return auditService.list().filter((e) => e.action === action);
  },
};

export const AUDIT_ACTION_LABEL: Record<AuditAction, string> = {
  sale_created: "Transaksi Dibuat",
  sale_voided: "Void Transaksi",
  stock_adjustment: "Penyesuaian Stok",
  packaging_rule_upsert: "Ubah Aturan Kemasan",
  packaging_rule_delete: "Hapus Aturan Kemasan",
  product_price_edit: "Ubah Harga Produk",
  product_upsert: "Ubah Produk",
  settings_update: "Ubah Pengaturan",
  shift_open: "Buka Shift",
  shift_close: "Tutup Shift",
  queue_status_change: "Ubah Status Antrean",
  operational_expense_added: "Tambah Pengeluaran Operasional",
  operational_expense_updated: "Ubah Pengeluaran Operasional",
  operational_expense_deleted: "Hapus Pengeluaran Operasional",
  packaging_usage_saved: "Simpan Pemakaian Packaging",
  packaging_usage_updated: "Ubah Pemakaian Packaging",
  sales_packaging_used: "Pemakaian Packaging Penjualan",
  sales_extra_packaging_added: "Packaging Tambahan Penjualan",
  packaging_name_mismatch: "Nama Packaging Tidak Cocok Dengan Inventory",
  packaging_movement_partial_failure: "Pencatatan Pergerakan Packaging Gagal Sebagian",
  sales_rollback_partial_failure: "Rollback Checkout Gagal Sebagian",
  production_record_created: "Pencatatan Produksi",
  production_release: "Release Produksi ke Sales",
  production_planning_saved: "Simpan Planning Produksi",
  refund_requested: "Pengajuan Refund",
  refund_approved: "Refund Disetujui",
  refund_rejected: "Refund Ditolak",
  refund_approve_blocked: "Refund Ditolak Otomatis (sudah produksi)",
  preorder_cancel_requested: "Pengajuan Pembatalan Pre Order",
  preorder_cancel_approved: "Pembatalan Pre Order Disetujui (DP Hangus)",
  preorder_cancel_rejected: "Pengajuan Pembatalan Pre Order Ditolak",
  preorder_mark_ready_undo: "Urungkan Tandai Siap Diproses (Pre Order)",
  product_stock_write: "Tulis Ready Stock Produk",
  whatsapp_notification_sent: "Kirim Notifikasi WhatsApp",
  preorder_dp_paid: "Pembayaran DP Pre Order",
  settlement_posted: "Posting Settlement Marketplace",
};