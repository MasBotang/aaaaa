import type { Storage } from "./storage";

const isBrowser = typeof window !== "undefined" && typeof window.localStorage !== "undefined";

/**
 * Custom event dispatched on every same-tab storage write. Native `storage`
 * event only fires on OTHER tabs, so components that need to refresh after a
 * local write subscribe to this event as well.
 */
export const STORAGE_WRITE_EVENT = "desalut:storage-write";

/**
 * KNOWN LIMITATION — race condition lintas-tab pada pola read-modify-write.
 *
 * Semua service (`sales.service.ts`, `preorder.service.ts`,
 * `queue.service.ts`, `refund.service.ts`, `shift.service.ts`, dst) menulis
 * dengan pola:
 *   const list = storage.get(KEY);   // baca
 *   list.unshift(item);              // ubah di memory
 *   storage.set(KEY, list);          // tulis balik
 *
 * Ini AMAN dalam satu tab (JS single-threaded, gak ada kode lain yang bisa
 * nyelip di antara baca-ubah-tulis karena gak ada `await` di antaranya).
 * TAPI kalau device yang sama buka 2 tab (mis. kasir checkout di POS tab 1,
 * admin approve refund di tab 2, nyaris bersamaan), dua tab itu bisa
 * sama-sama baca versi lama sebelum salah satu sempat nulis — yang nulis
 * belakangan akan MENIMPA perubahan yang nulis duluan.
 *
 * Fix yang benar (serialize write per-key pakai Web Locks API,
 * `navigator.locks.request`) butuh entire read-modify-write chain — semua
 * fungsi service di atas DAN semua caller-nya di UI yang baca return
 * value-nya secara sinkron (mis. `const result = refundService.approve(...)`)
 * — diubah jadi async. Itu perubahan besar yang nyentuh hampir semua
 * handler checkout/approve di seluruh Sales module. SENGAJA belum
 * dikerjakan di sini karena environment ini gak punya build/test loop buat
 * verifikasi tiap call site ke-update dengan benar — resiko regresi diam-
 * diam di kode checkout terlalu tinggi untuk dikerjain buta. Kerjakan ini
 * di environment dengan `npm run build`/`npm run dev` aktif.
 */

function emitWrite(key: string) {
  if (!isBrowser) return;
  try {
    window.dispatchEvent(new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key } }));
  } catch (err) {
    // older browsers without CustomEvent — non-fatal (komponen lain di tab
    // yang sama mungkin tidak auto-refresh), tapi tetap dicatat di console
    // supaya tidak benar-benar silent.
    console.warn("[storage] emitWrite failed", key, err);
  }
}

export const localStorageAdapter: Storage = {
  get<T>(key: string): T | null {
    if (!isBrowser) return null;
    try {
      const raw = window.localStorage.getItem(key);
      return raw == null ? null : (JSON.parse(raw) as T);
    } catch {
      return null;
    }
  },
  set<T>(key: string, value: T) {
    if (!isBrowser) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      emitWrite(key);
    } catch {
      /* quota / private mode: swallow */
    }
  },
  remove(key: string) {
    if (!isBrowser) return;
    window.localStorage.removeItem(key);
    emitWrite(key);
  },
  has(key: string) {
    if (!isBrowser) return false;
    return window.localStorage.getItem(key) !== null;
  },
};
