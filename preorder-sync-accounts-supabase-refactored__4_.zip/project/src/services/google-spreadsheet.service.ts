/**
 * Google Spreadsheet Service — placeholder interface.
 *
 * V2 scope: arsitektur siap dipakai. Implementasi OAuth belum dilakukan.
 * Semua method mengembalikan `{ ok: false, reason: "coming-soon" }`.
 */

export interface GoogleSpreadsheetResult {
  ok: boolean;
  reason?: "coming-soon" | "not-connected" | "error";
  message?: string;
}

export interface GoogleSpreadsheetService {
  isConfigured(): boolean;
  isConnected(): boolean;
  connect(): Promise<GoogleSpreadsheetResult>;
  disconnect(): Promise<GoogleSpreadsheetResult>;
  pushLedger(rows: unknown[]): Promise<GoogleSpreadsheetResult>;
  pushExpense(rows: unknown[]): Promise<GoogleSpreadsheetResult>;
  pushDebt(rows: unknown[]): Promise<GoogleSpreadsheetResult>;
  pushFund(rows: unknown[]): Promise<GoogleSpreadsheetResult>;
}

const notReady: GoogleSpreadsheetResult = {
  ok: false,
  reason: "coming-soon",
  message: "Integrasi Google Spreadsheet akan tersedia setelah OAuth dikonfigurasi.",
};

export const googleSpreadsheetService: GoogleSpreadsheetService = {
  isConfigured: () => false,
  isConnected: () => false,
  connect: async () => notReady,
  disconnect: async () => notReady,
  pushLedger: async () => notReady,
  pushExpense: async () => notReady,
  pushDebt: async () => notReady,
  pushFund: async () => notReady,
};
