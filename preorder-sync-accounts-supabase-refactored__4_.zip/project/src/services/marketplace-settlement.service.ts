import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import { auditService } from "./audit.service";
import type { MarketplaceSettlement, MarketplaceSource, Role, Sale } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 5 — Marketplace Settlements): sekarang
// bersandar pada tabel `public.marketplace_settlements`. Semua mutasi async;
// permukaan sync (`listCached`, `statusFor`, `find`) dipakai UI Shift &
// Finance — dipopulasikan oleh `list()` di halaman konsumen.
// ---------------------------------------------------------------------------

export type SettlementStatus = "settled" | "unsettled";

interface Row {
  id: string;
  legacy_id: string | null;
  date: string;
  marketplace: MarketplaceSource;
  order_count: number;
  gross_sales: number;
  marketplace_fee: number;
  net_received: number;
  notes: string | null;
  created_at: string;
  created_by: string;
}

function fromRow(r: Row): MarketplaceSettlement {
  return {
    id: r.id,
    date: r.date,
    marketplace: r.marketplace,
    orderCount: Number(r.order_count) || 0,
    grossSales: Number(r.gross_sales) || 0,
    marketplaceFee: Number(r.marketplace_fee) || 0,
    netReceived: Number(r.net_received) || 0,
    notes: r.notes ?? undefined,
    createdAt: r.created_at,
    createdBy: r.created_by,
  } as MarketplaceSettlement;
}

let _cache: MarketplaceSettlement[] = [];
function setCache(rows: MarketplaceSettlement[]) {
  _cache = rows;
}
function upsertCache(r: MarketplaceSettlement) {
  const i = _cache.findIndex(
    (x) => x.date === r.date && x.marketplace === r.marketplace,
  );
  if (i >= 0) _cache = [..._cache.slice(0, i), r, ..._cache.slice(i + 1)];
  else _cache = [r, ..._cache];
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, {
        detail: { key: StorageKeys.marketplaceSettlements },
      }),
    );
  } catch (err) {
    console.error("[settlement] emit storage-write failed", err);
  }
}

export const marketplaceSettlementService = {
  async list(): Promise<MarketplaceSettlement[]> {
    const { data, error } = await supabase
      .from("marketplace_settlements")
      .select("*")
      .order("date", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  listCached(): MarketplaceSettlement[] {
    return _cache;
  },

  find(date: string, marketplace: MarketplaceSource): MarketplaceSettlement | undefined {
    return _cache.find((r) => r.date === date && r.marketplace === marketplace);
  },

  async upsert(
    input: Omit<MarketplaceSettlement, "id" | "createdAt"> & {
      actor?: string;
      actorRole?: Role;
    },
  ): Promise<MarketplaceSettlement> {
    const { actor, actorRole, ...payload } = input;
    const before = marketplaceSettlementService.find(payload.date, payload.marketplace);
    const row = {
      date: payload.date,
      marketplace: payload.marketplace,
      order_count: payload.orderCount,
      gross_sales: payload.grossSales,
      marketplace_fee: payload.marketplaceFee,
      net_received: payload.netReceived,
      notes: payload.notes ?? null,
      created_by: payload.createdBy,
    };
    let result: MarketplaceSettlement;
    if (before) {
      const { data, error } = await supabase
        .from("marketplace_settlements")
        .update(row)
        .eq("id", before.id)
        .select("*")
        .single();
      if (error) throw error;
      result = fromRow(data as Row);
    } else {
      const { data, error } = await supabase
        .from("marketplace_settlements")
        .insert(row)
        .select("*")
        .single();
      if (error) throw error;
      result = fromRow(data as Row);
    }
    upsertCache(result);
    emit();
    try {
      auditService.log({
        actor: actor ?? "system",
        actorRole,
        action: "settlement_posted",
        entity: "marketplace_settlement",
        entityId: result.id,
        metadata: {
          date: result.date,
          marketplace: result.marketplace,
          grossSales: result.grossSales,
          marketplaceFee: result.marketplaceFee,
          netReceived: result.netReceived,
          before,
        },
      });
    } catch (err) {
      console.error("[settlement] audit failed", err);
    }
    return result;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from("marketplace_settlements").delete().eq("id", id);
    if (error) throw error;
    _cache = _cache.filter((r) => r.id !== id);
    emit();
  },

  statusFor(date: string, marketplace: MarketplaceSource): SettlementStatus {
    return marketplaceSettlementService.find(date, marketplace) ? "settled" : "unsettled";
  },

  outstandingPairs(sales: Sale[]): { date: string; marketplace: MarketplaceSource }[] {
    const set = new Map<string, { date: string; marketplace: MarketplaceSource }>();
    for (const s of sales) {
      if (s.voided) continue;
      const src = s.sourceOrder;
      if (src !== "shopeefood" && src !== "gofood" && src !== "grabfood") continue;
      const d = new Date(s.createdAt);
      if (Number.isNaN(d.getTime())) continue;
      const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
        d.getDate(),
      ).padStart(2, "0")}`;
      const key = `${dateStr}|${src}`;
      if (!set.has(key)) set.set(key, { date: dateStr, marketplace: src });
    }
    return Array.from(set.values()).sort((a, b) => (a.date < b.date ? 1 : -1));
  },
};
