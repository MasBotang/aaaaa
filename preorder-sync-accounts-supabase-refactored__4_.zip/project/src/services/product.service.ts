import { supabase } from "@/lib/supabase-client";
import type { Product } from "./types";
import { priceGroupService } from "./price-group.service";
import { auditService } from "./audit.service";

// ---------------------------------------------------------------------------
// Migrasi Data Referensi: productService sekarang menyimpan Product di
// Supabase (tabel `products`), bukan localStorage lagi. Semua fungsi jadi
// async — nama & parameter dipertahankan sepersis mungkin supaya pemanggil
// (products-page.tsx, pos-page.tsx, dll.) cuma perlu menambah `await` +
// react-query, bukan menulis ulang logic.
//
// `Product.id` sekarang adalah uuid dari kolom `products.id` (bukan lagi
// string custom seperti "p1" / "p_1699999999999" dari versi localStorage).
// Kolom `legacy_id` di skema DB menyimpan id lama HANYA untuk baris yang
// diimpor lewat supabase/seed/products-and-inventory.sql — tidak dipakai
// sebagai identitas oleh kode aplikasi.
// ---------------------------------------------------------------------------

interface ProductRow {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  sku: string | null;
  stock: number;
  wip_stock: number;
  min_stock: number | null;
  image_url: string | null;
  active: boolean;
  stock_source: "freezer" | "showcase" | null;
  prices: Record<string, number> | null;
}

function fromRow(row: ProductRow): Product {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: Number(row.price),
    cost: Number(row.cost),
    sku: row.sku ?? undefined,
    stock: Number(row.stock),
    wipStock: Number(row.wip_stock),
    minStock: row.min_stock == null ? undefined : Number(row.min_stock),
    imageUrl: row.image_url ?? undefined,
    active: row.active,
    stockSource: row.stock_source ?? undefined,
    prices: row.prices ?? undefined,
  };
}

/** Payload untuk insert/update — TANPA id (biar DB yang generate saat create). */
function toPayload(p: Product) {
  return {
    name: p.name,
    category: p.category,
    price: p.price,
    cost: p.cost,
    sku: p.sku ?? null,
    stock: p.stock ?? 0,
    wip_stock: p.wipStock ?? 0,
    min_stock: p.minStock ?? null,
    image_url: p.imageUrl ?? null,
    active: p.active,
    stock_source: p.stockSource ?? null,
    prices: p.prices ?? {},
  };
}

export const productService = {
  async list(): Promise<Product[]> {
    const { data, error } = await supabase.from("products").select("*").order("name");
    if (error) throw error;
    return (data as ProductRow[]).map(fromRow);
  },

  /**
   * Insert (bila `p.id` belum ada di tabel) atau update (bila sudah ada).
   * `p.id` HARUS berupa uuid yang valid — untuk produk baru, generate dengan
   * `crypto.randomUUID()` di pemanggil (lihat products-page.tsx →
   * emptyProduct()), bukan format id lama ("p_" + timestamp).
   */
  async upsert(p: Product): Promise<Product> {
    const { data, error } = await supabase
      .from("products")
      .upsert({ id: p.id, ...toPayload(p) })
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as ProductRow);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) throw error;
  },

  /**
   * Diubah dari `categories(): string[]` (sebelumnya fetch list sendiri
   * secara sinkron) menjadi fungsi pure yang menerima list yang sudah
   * di-fetch react-query — satu-satunya pemanggilnya (products-page.tsx)
   * sudah menyimpan `products` dari `useQuery`, jadi tidak perlu round-trip
   * lagi ke Supabase hanya untuk menghitung kategori.
   */
  categories(list: Product[]): string[] {
    const set = new Set<string>();
    for (const p of list) if (p.category) set.add(p.category);
    return Array.from(set).sort();
  },

  /**
   * Bug fix (M-2, dipertahankan dari versi localStorage): SKU manual di
   * form tidak pernah dicek terhadap produk lain. Sekarang menerima `list`
   * yang sudah di-fetch (react-query) — sama seperti `categories()` di atas,
   * pure & sinkron, tidak butuh round-trip.
   */
  isSkuTaken(list: Product[], sku: string, excludeId?: string): boolean {
    const normalized = sku.trim().toLowerCase();
    if (!normalized) return false;
    return list.some(
      (p) => p.id !== excludeId && (p.sku ?? "").trim().toLowerCase() === normalized,
    );
  },

  generateSku(list: Product[], category: string): string {
    const prefix = (category || "PRD")
      .replace(/[^a-zA-Z0-9]/g, "")
      .slice(0, 3)
      .toUpperCase()
      .padEnd(3, "X");
    const existing = list.filter((p) => p.sku?.startsWith(prefix + "-"));
    const nums = existing
      .map((p) => parseInt(p.sku!.split("-")[1] ?? "0", 10))
      .filter((n) => !isNaN(n));
    const next = (nums.length ? Math.max(...nums) : 0) + 1;
    return `${prefix}-${String(next).padStart(4, "0")}`;
  },

  /** Effective price for a product under a Price Group. Pure, tidak berubah. */
  priceFor(product: Product, priceGroupId: string | undefined): number {
    return priceGroupService.priceFor(product, priceGroupId);
  },

  /**
   * Sprint 1 (H-1 + H-4): satu-satunya jalur mengurangi ready stock.
   * Fail-loud bila stok tidak mencukupi (throw).
   *
   * Diubah dari "SELECT lalu UPDATE terpisah" (localStorage) menjadi RPC
   * `deduct_product_stock` — satu statement atomic di Postgres
   * (`UPDATE ... WHERE stock >= qty RETURNING *`). Ini yang menghilangkan
   * race condition dua device/tab checkout produk yang sama nyaris
   * bersamaan (bug class yang sama seperti localStorage, sekarang tidak
   * mungkin terjadi lagi karena database yang mengunci baris, bukan client
   * yang baca-lalu-tulis). Lihat
   * supabase/migrations/20260718100000_reference_data_rpc.sql.
   */
  async deduct(
    productId: string,
    qty: number,
    ctx: { actor: string; reason: string; source: string; entityId?: string },
  ): Promise<{ productId: string; before: number; after: number; delta: number }> {
    if (qty <= 0) throw new Error("Qty deduksi harus > 0");

    const { data, error } = await supabase.rpc("deduct_product_stock", {
      p_product_id: productId,
      p_qty: qty,
    });
    if (error) throw new Error(error.message);

    const row = data as ProductRow;
    const after = Number(row.stock);
    const before = after + qty;

    try {
      auditService.log({
        actor: ctx.actor,
        action: "product_stock_write",
        entity: "product",
        entityId: productId,
        reason: ctx.reason,
        metadata: {
          op: "deduct",
          source: ctx.source,
          entityId: ctx.entityId,
          before,
          after,
          delta: -qty,
          name: row.name,
        },
      });
    } catch (err) {
      console.error("[product] audit deduct failed", err);
    }
    return { productId, before, after, delta: -qty };
  },

  /**
   * Menambah ready stock. Sesuai BRD 6 "Ready Stock hanya berasal dari
   * Production" — dipanggil dari Production, refund rollback, atau seed.
   *
   * Sama seperti deduct(): sekarang RPC `add_product_stock`, atomic di
   * Postgres. Mengembalikan `null` untuk qty<=0 atau produk tidak
   * ditemukan — TIDAK throw — persis perilaku versi localStorage lama.
   */
  async addStock(
    productId: string,
    qty: number,
    ctx: { actor: string; reason: string; source: string; entityId?: string },
  ): Promise<{ productId: string; before: number; after: number; delta: number } | null> {
    if (qty <= 0) return null;

    const { data, error } = await supabase.rpc("add_product_stock", {
      p_product_id: productId,
      p_qty: qty,
    });
    if (error) throw new Error(error.message);
    if (!data) return null; // produk tidak ditemukan — RPC mengembalikan NULL, tidak throw

    const row = data as ProductRow;
    const after = Number(row.stock);
    const before = after - qty;

    try {
      auditService.log({
        actor: ctx.actor,
        action: "product_stock_write",
        entity: "product",
        entityId: productId,
        reason: ctx.reason,
        metadata: {
          op: "add",
          source: ctx.source,
          entityId: ctx.entityId,
          before,
          after,
          delta: qty,
          name: row.name,
        },
      });
    } catch (err) {
      console.error("[product] audit add failed", err);
    }
    return { productId, before, after, delta: qty };
  },
};
