import { supabase } from "@/lib/supabase-client";
import { inventoryService } from "./inventory.service";
import type { Recipe, RecipeIngredient } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Data Referensi: recipeService sekarang menyimpan Recipe di
// Supabase (tabel `recipes`), bukan localStorage lagi. Semua fungsi jadi
// async — nama & parameter dipertahankan sepersis mungkin.
//
// `Recipe.id` sekarang uuid dari kolom `recipes.id` (digenerate DB).
//
// `outputRefId: ""` (sentinel untuk resep tipe "panir" yang tidak
// menghasilkan output stockable — lihat resolveOutput() di bawah) di-
// terjemahkan ke/dari `NULL` di boundary Supabase (kolom `output_ref_id`
// dilonggarkan jadi nullable khusus untuk kasus ini — lihat migration
// 20260718100000_reference_data_rpc.sql) supaya kontrak
// `Recipe.outputRefId: string` di kode aplikasi TIDAK berubah sama sekali.
//
// CATATAN: recipeService saat ini tidak dikonsumsi oleh UI manapun (belum
// ada halaman Recipe) — hanya dipanggil dari dirinya sendiri dan dari
// src/services/seed.ts (yang seeding-nya untuk domain ini sudah dinonaktifkan
// di migrasi ini, lihat seed.ts). Tetap dimigrasikan penuh sesuai instruksi,
// supaya siap dipakai begitu halaman Recipe dibuat.
// ---------------------------------------------------------------------------

interface RecipeRow {
  id: string;
  name: string;
  type: Recipe["type"];
  output_target_type: Recipe["outputTargetType"];
  output_ref_id: string | null;
  output_name: string;
  output_quantity: number;
  output_unit: string;
  estimated_yield_pct: number;
  estimated_net_weight: number | null;
  estimated_net_weight_unit: "g" | "kg" | null;
  notes: string | null;
  ingredients: RecipeIngredient[];
  active: boolean;
  created_at: string;
  updated_at: string;
}

function fromRow(row: RecipeRow): Recipe {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    outputTargetType: row.output_target_type,
    outputRefId: row.output_ref_id ?? "",
    outputName: row.output_name,
    outputQuantity: Number(row.output_quantity),
    outputUnit: row.output_unit,
    estimatedYieldPct: Number(row.estimated_yield_pct),
    estimatedNetWeight: row.estimated_net_weight == null ? undefined : Number(row.estimated_net_weight),
    estimatedNetWeightUnit: row.estimated_net_weight_unit ?? undefined,
    notes: row.notes ?? undefined,
    ingredients: row.ingredients ?? [],
    active: row.active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export type NewRecipe = Omit<Recipe, "id" | "createdAt" | "updatedAt">;

export interface RecipeValidationError {
  field: string;
  message: string;
}

/**
 * Auto-create/link inventory item untuk output resep.
 * Mengembalikan field2 turunan: outputRefId, outputTargetType, outputUnit, outputName.
 */
async function resolveOutput(
  input: NewRecipe,
): Promise<Pick<Recipe, "outputRefId" | "outputTargetType" | "outputUnit" | "outputName">> {
  const name = input.outputName?.trim() || input.name?.trim() || "Panir";
  const unit = input.outputUnit?.trim() || "pcs";
  // Panir recipes are pure compositions — they don't produce a stockable
  // output. Skip auto-creating an inventory item.
  if (input.type === "panir") {
    return {
      outputTargetType: "inventory",
      outputRefId: "",
      outputName: name,
      outputUnit: unit,
    };
  }
  const item = await inventoryService.ensureProductionItem(name, unit);
  return {
    outputTargetType: "inventory",
    outputRefId: item.id,
    outputName: name,
    outputUnit: item.unit,
  };
}

async function validate(input: NewRecipe, ignoreId?: string): Promise<RecipeValidationError[]> {
  const errs: RecipeValidationError[] = [];
  if (!input.name.trim()) errs.push({ field: "name", message: "Nama resep wajib diisi" });
  if (await recipeService.isDuplicateName(input.name, ignoreId))
    errs.push({ field: "name", message: "Nama resep sudah digunakan" });
  // Panir recipes are pure compositions (per 1 pcs) — output name/qty/unit
  // are not required from the user; they'll be auto-defaulted.
  if (input.type !== "panir") {
    if (!input.outputName?.trim())
      errs.push({ field: "outputName", message: "Nama output wajib diisi" });
    if (!(input.outputQuantity > 0))
      errs.push({ field: "outputQuantity", message: "Qty output harus > 0" });
    if (!input.outputUnit.trim()) errs.push({ field: "outputUnit", message: "Satuan output wajib" });
  }
  if (input.estimatedYieldPct < 0 || input.estimatedYieldPct > 100)
    errs.push({ field: "estimatedYieldPct", message: "Yield 0–100%" });
  if (!input.ingredients.length)
    errs.push({ field: "ingredients", message: "Minimal 1 bahan" });
  const seen = new Set<string>();
  for (const ing of input.ingredients) {
    if (!ing.inventoryItemId) {
      errs.push({
        field: "ingredients",
        message:
          ing.source === "recipe"
            ? "Pilih adonan sumber untuk setiap bahan"
            : "Setiap bahan harus dipilih dari inventaris",
      });
      continue;
    }
    if (seen.has(ing.inventoryItemId)) {
      errs.push({ field: "ingredients", message: "Bahan duplikat tidak diperbolehkan" });
    }
    seen.add(ing.inventoryItemId);
    if (!(ing.quantity > 0))
      errs.push({ field: "ingredients", message: "Qty bahan harus > 0" });
    if (!(await inventoryService.get(ing.inventoryItemId)))
      errs.push({ field: "ingredients", message: "Bahan tidak ditemukan di inventaris" });
  }
  return errs;
}

function toPayload(
  r: NewRecipe & Pick<Recipe, "outputRefId" | "outputTargetType" | "outputUnit" | "outputName">,
) {
  return {
    name: r.name,
    type: r.type,
    output_target_type: r.outputTargetType,
    output_ref_id: r.outputRefId || null,
    output_name: r.outputName,
    output_quantity: r.outputQuantity,
    output_unit: r.outputUnit,
    estimated_yield_pct: r.estimatedYieldPct,
    estimated_net_weight: r.estimatedNetWeight ?? null,
    estimated_net_weight_unit: r.estimatedNetWeightUnit ?? null,
    notes: r.notes ?? null,
    ingredients: r.ingredients,
    active: r.active,
  };
}

export const recipeService = {
  async list(): Promise<Recipe[]> {
    const { data, error } = await supabase.from("recipes").select("*").order("name");
    if (error) throw error;
    return (data as RecipeRow[]).map(fromRow);
  },

  async get(id: string): Promise<Recipe | undefined> {
    const { data, error } = await supabase.from("recipes").select("*").eq("id", id).maybeSingle();
    if (error) throw error;
    return data ? fromRow(data as RecipeRow) : undefined;
  },

  async active(): Promise<Recipe[]> {
    const { data, error } = await supabase
      .from("recipes")
      .select("*")
      .eq("active", true)
      .order("name");
    if (error) throw error;
    return (data as RecipeRow[]).map(fromRow);
  },

  async isDuplicateName(name: string, ignoreId?: string): Promise<boolean> {
    const n = name.trim();
    if (!n) return false;
    let query = supabase.from("recipes").select("id").ilike("name", n);
    if (ignoreId) query = query.neq("id", ignoreId);
    const { data, error } = await query;
    if (error) throw error;
    return (data?.length ?? 0) > 0;
  },

  validate,

  async create(input: NewRecipe): Promise<Recipe> {
    const errs = await validate(input);
    if (errs.length) throw new Error(errs[0].message);
    const resolved = await resolveOutput(input);
    const { data, error } = await supabase
      .from("recipes")
      .insert(toPayload({ ...input, ...resolved }))
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as RecipeRow);
  },

  async update(id: string, patch: Partial<NewRecipe>): Promise<Recipe | undefined> {
    const current = await recipeService.get(id);
    if (!current) return undefined;
    const merged: NewRecipe = { ...current, ...patch } as NewRecipe;
    const errs = await validate(merged, id);
    if (errs.length) throw new Error(errs[0].message);
    const resolved = await resolveOutput(merged);
    const { data, error } = await supabase
      .from("recipes")
      .update(toPayload({ ...merged, ...resolved }))
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as RecipeRow);
  },

  async setActive(id: string, active: boolean): Promise<void> {
    const { error } = await supabase
      .from("recipes")
      .update({ active, updated_at: new Date().toISOString() })
      .eq("id", id);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from("recipes").delete().eq("id", id);
    if (error) throw error;
  },

  emptyIngredient(): RecipeIngredient {
    return { inventoryItemId: "", quantity: 0, source: "inventory" };
  },
};
