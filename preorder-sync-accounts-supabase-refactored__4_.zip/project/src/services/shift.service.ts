import { supabase } from "@/lib/supabase-client";
import { stockMovementService } from "./stock-movement.service";
import { inventoryService } from "./inventory.service";
import { auditService } from "./audit.service";
import { salesService } from "./sales.service";
import { aggregatePackagingUsageFromSales } from "./packing";
import type {
  Shift,
  ShiftMarketplaceReconciliation,
  ShiftOperationalExpense,
  ShiftPackagingUsage,
  ShiftPaymentReconciliation,
} from "./types";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 1 — Shift): shiftService sekarang menyimpan
// Shift di Supabase (tabel `shifts`), bukan localStorage lagi. Semua fungsi
// mutasi jadi async — nama & parameter dipertahankan sepersis mungkin.
//
// `Shift.id` sekarang uuid dari kolom `shifts.id` (digenerate DB via
// `gen_random_uuid()` saat insert), bukan lagi `shift_${ts}_${rand}`.
//
// "Current shift" bukan lagi entri localStorage terpisah — ia adalah baris
// `shifts` yang `closed_at IS NULL`. Unique partial index
// `shifts_only_one_open_idx` di DB menjamin cuma ada satu shift terbuka
// pada satu waktu; percobaan open() kedua langsung ditolak DB dengan
// error 23505 (unique_violation) dan diterjemahkan jadi pesan yang jelas
// di UI (bukan "database error" generic).
//
// `operational_expenses`, `packaging_usage`, `marketplace_reconciliations`,
// dan `payment_reconciliations` di skema DB adalah kolom JSONB — dibaca
// dan ditulis sebagai satu unit per shift (sengaja tidak dinormalisasi;
// lihat komentar di 20260717080000_sales_pos_init.sql).
//
// `isShiftLocked()`, `canMutateShift()`, `assertCanMutateShift()` tetap
// SINKRON — mereka hanya membaca properti objek Shift yang sudah di-fetch,
// dipakai di dalam JSX (mis. render tombol edit/hapus) yang tidak boleh
// jadi async.
//
// `cashier` di kolom DB adalah text (nama aktor) — bukan FK ke profiles/
// auth.users, konsisten dengan pola "Identitas Aktor" di
// docs/storage-migration/schema-mapping.md. Nama aktor di-derive di
// pemanggil (profile.full_name ?? user.email ?? "Kasir").
//
// TODO(prompt berikutnya): salesService, queueService, preorderService,
// refundService masih localStorage. Beberapa jalur di file ini masih
// bergantung pada mereka (mis. baseline packaging di savePackagingUsage
// masih baca `salesService.listCached()` sync dari localStorage) — pola itu
// akan diperbarui saat domain Sales dimigrasikan.
// ---------------------------------------------------------------------------

/**
 * Setelah shift ditutup, seluruh data dianggap final. Hanya admin/owner
 * yang boleh mengubah — kasir dikunci di UI dan di service layer.
 */
export function isShiftLocked(shift: Shift | null | undefined): boolean {
  return !!shift?.closedAt;
}
export function canMutateShift(shift: Shift, role?: string | null): boolean {
  if (!shift.closedAt) return true;
  return role === "admin" || role === "owner";
}
/**
 * Service-layer guard. Setiap fungsi mutasi Shift WAJIB memanggil ini
 * sebelum melakukan perubahan agar kasir tidak dapat mengubah shift
 * yang sudah ditutup meskipun service dipanggil secara langsung.
 */
export function assertCanMutateShift(shift: Shift, role?: string | null): void {
  if (!canMutateShift(shift, role)) {
    throw new Error(
      "Shift sudah ditutup — hanya Admin/Owner yang dapat mengubah data shift ini.",
    );
  }
}

export interface CloseShiftInput {
  closingCash: number;
  expectedCash: number;
  cashDifferenceReason?: string;
  totalOrders: number;
  totalRevenue: number;
  cashSales: number;
  qrisSales: number;
  transferSales: number;
  marketplaceSales: number;
  marketplaceReconciliations: ShiftMarketplaceReconciliation[];
  paymentReconciliations: ShiftPaymentReconciliation[];
  actor: string;
  actorRole?: string;
}

export interface AddOperationalExpenseInput {
  at?: string;
  itemId: string;
  qty: number;
  price: number;
  notes?: string;
  actor: string;
  actorRole?: string;
}

export interface UpdateOperationalExpenseInput {
  shiftId: string;
  expenseId: string;
  at?: string;
  itemId: string;
  qty: number;
  price: number;
  notes?: string;
  actor: string;
  actorRole?: string;
}

export interface SavePackagingUsageInput {
  entries: { itemId: string; qty: number }[];
  actor: string;
  actorRole?: string;
}

// ---------------------------------------------------------------------------
// Row <-> domain mapping
// ---------------------------------------------------------------------------

interface ShiftRow {
  id: string;
  cashier: string;
  opened_at: string;
  closed_at: string | null;
  opening_cash: number | string;
  closing_cash: number | string | null;
  expected_cash: number | string | null;
  cash_difference_reason: string | null;
  total_orders: number | null;
  total_revenue: number | string | null;
  cash_sales: number | string | null;
  qris_sales: number | string | null;
  transfer_sales: number | string | null;
  marketplace_sales: number | string | null;
  operational_expenses: ShiftOperationalExpense[] | null;
  total_operational_expense: number | string | null;
  packaging_usage: ShiftPackagingUsage[] | null;
  total_packaging_qty: number | string | null;
  packaging_usage_saved_at: string | null;
  packaging_usage_saved_by: string | null;
  marketplace_reconciliations: ShiftMarketplaceReconciliation[] | null;
  payment_reconciliations: ShiftPaymentReconciliation[] | null;
}

function n(v: number | string | null | undefined): number | undefined {
  if (v === null || v === undefined) return undefined;
  const x = typeof v === "string" ? Number(v) : v;
  return Number.isFinite(x) ? x : undefined;
}

function fromRow(row: ShiftRow): Shift {
  return {
    id: row.id,
    cashier: row.cashier,
    openedAt: row.opened_at,
    closedAt: row.closed_at ?? undefined,
    openingCash: n(row.opening_cash) ?? 0,
    closingCash: n(row.closing_cash),
    expectedCash: n(row.expected_cash),
    cashDifferenceReason: row.cash_difference_reason ?? undefined,
    totalOrders: row.total_orders ?? undefined,
    totalRevenue: n(row.total_revenue),
    cashSales: n(row.cash_sales),
    qrisSales: n(row.qris_sales),
    transferSales: n(row.transfer_sales),
    marketplaceSales: n(row.marketplace_sales),
    operationalExpenses: row.operational_expenses ?? [],
    totalOperationalExpense: n(row.total_operational_expense) ?? 0,
    packagingUsage: row.packaging_usage ?? [],
    totalPackagingQty: n(row.total_packaging_qty) ?? 0,
    packagingUsageSavedAt: row.packaging_usage_saved_at ?? undefined,
    packagingUsageSavedBy: row.packaging_usage_saved_by ?? undefined,
    marketplaceReconciliations: row.marketplace_reconciliations ?? [],
    paymentReconciliations: row.payment_reconciliations ?? [],
  };
}

function recalcOperationalTotal(list: ShiftOperationalExpense[]): number {
  return list.reduce((a, e) => a + (e.total ?? 0), 0);
}

function recalcPackagingTotal(list: ShiftPackagingUsage[]): number {
  return list.reduce((a, p) => a + (p.qty ?? 0), 0);
}

// ---------------------------------------------------------------------------
// Internal error helpers
// ---------------------------------------------------------------------------

interface PgLikeError {
  code?: string;
  message?: string;
}

function isUniqueViolation(err: unknown): boolean {
  const e = err as PgLikeError | null | undefined;
  return !!e && (e.code === "23505" || /shifts_only_one_open_idx/i.test(e.message ?? ""));
}

async function fetchShiftRow(id: string): Promise<ShiftRow | null> {
  const { data, error } = await supabase
    .from("shifts")
    .select("*")
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  return (data as ShiftRow | null) ?? null;
}

async function fetchCurrentRow(): Promise<ShiftRow | null> {
  const { data, error } = await supabase
    .from("shifts")
    .select("*")
    .is("closed_at", null)
    .order("opened_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return (data as ShiftRow | null) ?? null;
}

/** Apply a signed delta to inventory + record movement. */
async function moveStock(
  itemId: string,
  signedDelta: number,
  reason: string,
  notes?: string,
  packaging = false,
): Promise<void> {
  if (signedDelta === 0) return;
  if (signedDelta < 0) {
    await stockMovementService.record({
      itemId,
      type: packaging ? "sales_packaging_usage" : "operational_usage",
      quantity: Math.abs(signedDelta),
      reason,
      notes,
    });
  } else {
    const item = await inventoryService.get(itemId);
    await stockMovementService.record({
      itemId,
      type: "adjustment",
      adjustmentAbsolute: true,
      quantity: (item?.stock ?? 0) + signedDelta,
      reason,
      notes: notes ? `${notes} (koreksi +${signedDelta})` : `Koreksi +${signedDelta}`,
    });
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export const shiftService = {
  async list(): Promise<Shift[]> {
    const { data, error } = await supabase
      .from("shifts")
      .select("*")
      .order("opened_at", { ascending: false });
    if (error) throw error;
    return (data as ShiftRow[]).map(fromRow);
  },

  async current(): Promise<Shift | null> {
    const row = await fetchCurrentRow();
    return row ? fromRow(row) : null;
  },

  async get(id: string): Promise<Shift | undefined> {
    const row = await fetchShiftRow(id);
    return row ? fromRow(row) : undefined;
  },

  /**
   * Buka shift baru. DB `shifts_only_one_open_idx` (unique partial index
   * WHERE closed_at IS NULL) menjamin satu shift terbuka pada satu waktu —
   * open() kedua langsung ditolak DB dengan error 23505. Return value
   * membedakan sukses vs "shift lain masih aktif", konsisten dengan versi
   * lama (pola salesService.canRefund).
   */
  async open(
    cashier: string,
    openingCash: number,
    actorRole?: string,
  ): Promise<{ ok: true; shift: Shift } | { ok: false; reason: string; shift: Shift | null }> {
    const id = crypto.randomUUID();
    const openedAt = new Date().toISOString();
    const { data, error } = await supabase
      .from("shifts")
      .insert({
        id,
        cashier,
        opened_at: openedAt,
        opening_cash: openingCash,
        operational_expenses: [],
        total_operational_expense: 0,
        packaging_usage: [],
        marketplace_reconciliations: [],
        payment_reconciliations: [],
      })
      .select()
      .single();

    if (error) {
      if (isUniqueViolation(error)) {
        const existing = await shiftService.current();
        return {
          ok: false,
          reason: existing
            ? `Shift lain masih aktif atas nama ${existing.cashier}`
            : "Shift lain masih aktif",
          shift: existing,
        };
      }
      throw error;
    }

    const shift = fromRow(data as ShiftRow);
    auditService.log({
      actor: cashier,
      actorRole,
      action: "shift_open",
      entity: "shift",
      entityId: shift.id,
      metadata: { openingCash },
    });
    return { ok: true, shift };
  },

  // -------------------- Operational Expense --------------------
  async addOperationalExpense(
    input: AddOperationalExpenseInput,
  ): Promise<ShiftOperationalExpense | null> {
    const cur = await shiftService.current();
    if (!cur) throw new Error("Tidak ada shift aktif");
    assertCanMutateShift(cur, input.actorRole);
    const item = await inventoryService.get(input.itemId);
    if (!item) throw new Error("Barang tidak ditemukan");
    if (item.category !== "operational")
      throw new Error("Barang harus kategori Operasional");
    if (input.qty <= 0) throw new Error("Qty harus > 0");
    if (input.price < 0) throw new Error("Harga tidak valid");

    const entry: ShiftOperationalExpense = {
      id: crypto.randomUUID(),
      at: input.at ?? new Date().toISOString(),
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      qty: input.qty,
      price: input.price,
      total: input.qty * input.price,
      notes: input.notes?.trim() || undefined,
      createdBy: input.actor,
    };

    // Deduct inventory immediately.
    await moveStock(
      item.id,
      -input.qty,
      `Shift ${cur.id} · Pengeluaran Operasional`,
      entry.notes,
    );

    const nextList = [...(cur.operationalExpenses ?? []), entry];
    const { error } = await supabase
      .from("shifts")
      .update({
        operational_expenses: nextList,
        total_operational_expense: recalcOperationalTotal(nextList),
      })
      .eq("id", cur.id);
    if (error) throw error;

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "operational_expense_added",
      entity: "shift_operational_expense",
      entityId: entry.id,
      metadata: {
        shiftId: cur.id,
        itemId: entry.itemId,
        itemName: entry.itemName,
        qty: entry.qty,
        price: entry.price,
        total: entry.total,
        notes: entry.notes,
      },
    });
    return entry;
  },

  async updateOperationalExpense(
    input: UpdateOperationalExpenseInput,
  ): Promise<ShiftOperationalExpense> {
    const shift = await shiftService.get(input.shiftId);
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, input.actorRole);
    const list = shift.operationalExpenses ?? [];
    const idx = list.findIndex((e) => e.id === input.expenseId);
    if (idx < 0) throw new Error("Data pengeluaran tidak ditemukan");
    const prev = list[idx];
    const item = await inventoryService.get(input.itemId);
    if (!item) throw new Error("Barang tidak ditemukan");
    if (item.category !== "operational")
      throw new Error("Barang harus kategori Operasional");
    if (input.qty <= 0) throw new Error("Qty harus > 0");

    // Pre-validate shortage sebelum reverse+deduct (lihat versi lama).
    {
      const targetItem = await inventoryService.get(item.id);
      const targetStock = targetItem?.stock ?? 0;
      const effectiveAvailable =
        targetStock + (prev.itemId === item.id ? prev.qty : 0);
      if (effectiveAvailable < input.qty) {
        throw new Error(
          `Stok ${item.name} tidak mencukupi (tersedia ${effectiveAvailable}, butuh ${input.qty})`,
        );
      }
    }
    await moveStock(
      prev.itemId,
      +prev.qty,
      `Shift ${shift.id} · Koreksi Pengeluaran Operasional (reverse)`,
      `Edit oleh ${input.actor}`,
    );
    await moveStock(
      item.id,
      -input.qty,
      `Shift ${shift.id} · Koreksi Pengeluaran Operasional`,
      input.notes?.trim() || undefined,
    );

    const updated: ShiftOperationalExpense = {
      ...prev,
      at: input.at ?? prev.at,
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      qty: input.qty,
      price: input.price,
      total: input.qty * input.price,
      notes: input.notes?.trim() || undefined,
      updatedAt: new Date().toISOString(),
      updatedBy: input.actor,
    };
    const nextList = [...list];
    nextList[idx] = updated;
    const { error } = await supabase
      .from("shifts")
      .update({
        operational_expenses: nextList,
        total_operational_expense: recalcOperationalTotal(nextList),
      })
      .eq("id", shift.id);
    if (error) throw error;

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "operational_expense_updated",
      entity: "shift_operational_expense",
      entityId: updated.id,
      metadata: { shiftId: shift.id, before: prev, after: updated },
    });
    return updated;
  },

  async deleteOperationalExpense(params: {
    shiftId: string;
    expenseId: string;
    actor: string;
    actorRole?: string;
  }): Promise<void> {
    const shift = await shiftService.get(params.shiftId);
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, params.actorRole);
    const list = shift.operationalExpenses ?? [];
    const idx = list.findIndex((e) => e.id === params.expenseId);
    if (idx < 0) throw new Error("Data pengeluaran tidak ditemukan");
    const prev = list[idx];

    await moveStock(
      prev.itemId,
      +prev.qty,
      `Shift ${shift.id} · Hapus Pengeluaran Operasional`,
      `Hapus oleh ${params.actor}`,
    );

    const nextList = list.filter((e) => e.id !== params.expenseId);
    const { error } = await supabase
      .from("shifts")
      .update({
        operational_expenses: nextList,
        total_operational_expense: recalcOperationalTotal(nextList),
      })
      .eq("id", shift.id);
    if (error) throw error;

    auditService.log({
      actor: params.actor,
      actorRole: params.actorRole,
      action: "operational_expense_deleted",
      entity: "shift_operational_expense",
      entityId: prev.id,
      metadata: { shiftId: shift.id, entry: prev },
    });
  },

  // -------------------- Packaging Usage --------------------
  /**
   * Simpan (atau ubah) Pemakaian Packaging pada shift target. Selisih dengan
   * data sebelumnya diaplikasikan ke stok Inventory. Baseline penyimpanan
   * pertama = agregasi neto dari Sale-Sale checkout shift ini (menghindari
   * double-deduct — lihat gap #2 di versi lama). Baseline update berikutnya
   * = shift.packagingUsage tersimpan.
   *
   * TODO(prompt berikutnya): salesService.listCached() masih baca localStorage
   * secara sinkron di sini. Setelah domain Sales pindah ke Supabase,
   * baseline harus di-await dari Supabase juga.
   */
  async savePackagingUsage(
    input: SavePackagingUsageInput & { shiftId?: string },
  ): Promise<Shift> {
    const shift = input.shiftId
      ? await shiftService.get(input.shiftId)
      : await shiftService.current();
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, input.actorRole);

    const prev = shift.packagingUsage ?? [];
    const isUpdate = prev.length > 0 || !!shift.packagingUsageSavedAt;

    const checkoutBaseline = aggregatePackagingUsageFromSales(
      salesService.listCached().filter((s) => s.shiftId === shift.id && !s.voided),
    );
    const prevMap = new Map<string, number>(
      isUpdate
        ? prev.map((p): [string, number] => [p.itemId, p.qty])
        : Array.from(checkoutBaseline.values()).map((v): [string, number] => [v.itemId, v.qty]),
    );

    const nextEntries: ShiftPackagingUsage[] = [];
    for (const e of input.entries) {
      if (e.qty < 0) throw new Error("Qty packaging tidak boleh negatif");
      const item = await inventoryService.get(e.itemId);
      if (!item) continue;
      if (item.category !== "packaging") continue;
      if (e.qty > 0) {
        nextEntries.push({
          itemId: item.id,
          itemName: item.name,
          unit: item.unit,
          qty: e.qty,
        });
      }
    }

    // Pre-validasi shortage (lihat komentar di versi lama).
    const seen = new Set<string>();
    const deltaPlan: {
      itemId: string;
      signed: number;
      itemName: string;
      available: number;
    }[] = [];
    for (const nEntry of nextEntries) {
      seen.add(nEntry.itemId);
      const oldQty = prevMap.get(nEntry.itemId) ?? 0;
      const delta = nEntry.qty - oldQty;
      if (delta !== 0) {
        const inv = await inventoryService.get(nEntry.itemId);
        deltaPlan.push({
          itemId: nEntry.itemId,
          signed: -delta,
          itemName: inv?.name ?? nEntry.itemName,
          available: inv?.stock ?? 0,
        });
      }
    }
    for (const [itemId, oldQty] of prevMap) {
      if (seen.has(itemId)) continue;
      if (oldQty > 0) {
        const inv = await inventoryService.get(itemId);
        deltaPlan.push({
          itemId,
          signed: +oldQty,
          itemName: inv?.name ?? itemId,
          available: inv?.stock ?? 0,
        });
      }
    }
    const simStock = new Map<string, number>();
    const shortages: string[] = [];
    for (const step of deltaPlan) {
      const cur = simStock.get(step.itemId) ?? step.available;
      const after = cur + step.signed;
      if (after < 0) {
        shortages.push(
          `${step.itemName} (tersedia ${cur}, butuh ${Math.abs(step.signed)})`,
        );
      }
      simStock.set(step.itemId, after);
    }
    if (shortages.length) {
      throw new Error(`Stok packaging tidak mencukupi: ${shortages.join("; ")}`);
    }

    for (const step of deltaPlan) {
      await moveStock(
        step.itemId,
        step.signed,
        step.signed > 0
          ? `Shift ${shift.id} · Koreksi Pemakaian Packaging`
          : `Shift ${shift.id} · Pemakaian Packaging`,
        step.signed > 0
          ? "Item dihapus/dikurangi dari pemakaian"
          : isUpdate
            ? "Update pemakaian"
            : undefined,
        true,
      );
    }

    const nowIso = new Date().toISOString();
    const { data, error } = await supabase
      .from("shifts")
      .update({
        packaging_usage: nextEntries,
        total_packaging_qty: recalcPackagingTotal(nextEntries),
        packaging_usage_saved_at: nowIso,
        packaging_usage_saved_by: input.actor,
      })
      .eq("id", shift.id)
      .select()
      .single();
    if (error) throw error;

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: isUpdate ? "packaging_usage_updated" : "packaging_usage_saved",
      entity: "shift_packaging_usage",
      entityId: shift.id,
      metadata: { shiftId: shift.id, before: prev, after: nextEntries },
    });
    return fromRow(data as ShiftRow);
  },

  // -------------------- Close Shift --------------------
  async close(input: CloseShiftInput): Promise<Shift | null> {
    const cur = await shiftService.current();
    if (!cur) return null;

    const closedAt = new Date().toISOString();
    const { data, error } = await supabase
      .from("shifts")
      .update({
        closed_at: closedAt,
        closing_cash: input.closingCash,
        expected_cash: input.expectedCash,
        cash_difference_reason: input.cashDifferenceReason ?? null,
        total_orders: input.totalOrders,
        total_revenue: input.totalRevenue,
        cash_sales: input.cashSales,
        qris_sales: input.qrisSales,
        transfer_sales: input.transferSales,
        marketplace_sales: input.marketplaceSales,
        marketplace_reconciliations: input.marketplaceReconciliations,
        payment_reconciliations: input.paymentReconciliations,
      })
      .eq("id", cur.id)
      .select()
      .single();
    if (error) throw error;

    const closed = fromRow(data as ShiftRow);
    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "shift_close",
      entity: "shift",
      entityId: closed.id,
      metadata: {
        totalOrders: closed.totalOrders,
        totalRevenue: closed.totalRevenue,
        cashSales: closed.cashSales,
        qrisSales: closed.qrisSales,
        transferSales: closed.transferSales,
        marketplaceSales: closed.marketplaceSales,
        totalOperationalExpense: closed.totalOperationalExpense ?? 0,
        totalPackagingQty: closed.totalPackagingQty ?? 0,
        expectedCash: closed.expectedCash,
        closingCash: closed.closingCash,
        cashDifference:
          (closed.closingCash ?? 0) - (closed.expectedCash ?? 0),
        cashDifferenceReason: closed.cashDifferenceReason,
        marketplaceReconciliations: closed.marketplaceReconciliations,
        paymentReconciliations: closed.paymentReconciliations,
      },
    });
    return closed;
  },
};
