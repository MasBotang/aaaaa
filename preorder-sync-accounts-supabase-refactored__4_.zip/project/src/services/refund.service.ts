import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import { salesService } from "./sales.service";
import { auditService } from "./audit.service";
import type { Role } from "./types";

export type RefundStatus = "pending" | "approved" | "rejected";

export const REFUND_STATUS_LABEL: Record<RefundStatus, string> = {
  pending: "Menunggu Approval",
  approved: "Disetujui (Refund)",
  rejected: "Ditolak",
};

export interface RefundRequest {
  id: string;
  saleId: string;
  requestedBy: string;
  requestedByRole?: Role;
  requestedAt: string;
  reason: string;
  status: RefundStatus;
  decidedBy?: string;
  decidedByRole?: Role;
  decidedAt?: string;
  decisionNote?: string;
}

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 5 — Refund Requests): sekarang bersandar pada
// tabel `public.refund_requests`. Semua mutasi async; permukaan sync
// (`listCached`, `pendingCountCached`, `bySale`) dipakai UI (badge & lookup
// per Sale) — dipopulasikan oleh `list()` dan mutasi.
// ---------------------------------------------------------------------------

interface Row {
  id: string;
  legacy_id: string | null;
  sale_id: string;
  requested_by: string;
  requested_by_role: Role | null;
  requested_at: string;
  reason: string;
  status: RefundStatus;
  decided_by: string | null;
  decided_by_role: Role | null;
  decided_at: string | null;
  decision_note: string | null;
}

function fromRow(r: Row): RefundRequest {
  return {
    id: r.id,
    saleId: r.sale_id,
    requestedBy: r.requested_by,
    requestedByRole: r.requested_by_role ?? undefined,
    requestedAt: r.requested_at,
    reason: r.reason,
    status: r.status,
    decidedBy: r.decided_by ?? undefined,
    decidedByRole: r.decided_by_role ?? undefined,
    decidedAt: r.decided_at ?? undefined,
    decisionNote: r.decision_note ?? undefined,
  };
}

let _cache: RefundRequest[] = [];
function setCache(rows: RefundRequest[]) {
  _cache = rows;
}
function upsertCache(r: RefundRequest) {
  const i = _cache.findIndex((x) => x.id === r.id);
  if (i >= 0) _cache = [..._cache.slice(0, i), r, ..._cache.slice(i + 1)];
  else _cache = [r, ..._cache];
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, {
        detail: { key: StorageKeys.refundRequests },
      }),
    );
  } catch (err) {
    console.error("[refund] emit storage-write failed", err);
  }
}

const ALLOWED_ROLES: Role[] = ["admin", "owner", "cashier", "production"];
function safeRole(r: Role | undefined): Role | null {
  return r && ALLOWED_ROLES.includes(r) ? r : null;
}

export const refundService = {
  async list(): Promise<RefundRequest[]> {
    const { data, error } = await supabase
      .from("refund_requests")
      .select("*")
      .order("requested_at", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  listCached(): RefundRequest[] {
    return _cache;
  },

  /**
   * Refund aktif (pending / approved) untuk sebuah Sale — sinkron dari
   * cache. Cache diisi oleh `list()` di halaman konsumen.
   */
  bySale(saleId: string): RefundRequest | undefined {
    return _cache.find((r) => r.saleId === saleId && r.status !== "rejected");
  },

  async request(input: {
    saleId: string;
    reason: string;
    actor: string;
    actorRole?: Role;
  }): Promise<RefundRequest> {
    // Dedup lewat DB (aman untuk multi-device / multi-tab).
    {
      const { data, error } = await supabase
        .from("refund_requests")
        .select("*")
        .eq("sale_id", input.saleId)
        .neq("status", "rejected")
        .order("requested_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      if (data) {
        const existing = fromRow(data as Row);
        upsertCache(existing);
        return existing;
      }
    }
    const insert = {
      sale_id: input.saleId,
      reason: input.reason,
      requested_by: input.actor,
      requested_by_role: safeRole(input.actorRole),
      requested_at: new Date().toISOString(),
      status: "pending" as const,
    };
    const { data, error } = await supabase
      .from("refund_requests")
      .insert(insert)
      .select("*")
      .single();
    if (error) throw error;
    const rec = fromRow(data as Row);
    upsertCache(rec);
    emit();
    try {
      auditService.log({
        actor: input.actor,
        actorRole: input.actorRole,
        action: "refund_requested",
        entity: "sale",
        entityId: input.saleId,
        reason: input.reason,
      });
    } catch (err) {
      console.error("[refund] request: audit log failed", err);
    }
    return rec;
  },

  async approve(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): Promise<{ ok: true; request: RefundRequest } | { ok: false; reason: string }> {
    // Ambil dari DB (bukan cache) supaya keputusan tab/device lain terdeteksi.
    const { data: cur, error: e1 } = await supabase
      .from("refund_requests")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!cur) return { ok: false, reason: "Pengajuan refund tidak ditemukan" };
    const req = fromRow(cur as Row);
    if (req.status !== "pending") {
      upsertCache(req);
      return { ok: false, reason: "Pengajuan refund sudah diputuskan" };
    }

    // Guard: pesanan yang sudah masuk produksi tidak boleh direfund.
    const guard = await salesService.canRefund(req.saleId);
    if (!guard.ok) {
      try {
        auditService.log({
          actor: opts.actor,
          actorRole: opts.actorRole,
          action: "refund_approve_blocked",
          entity: "sale",
          entityId: req.saleId,
          reason: guard.reason,
        });
      } catch {
        /* audit best-effort */
      }
      return { ok: false, reason: guard.reason };
    }

    // Urutan atomic-logis: void sale DULU (rollback stock, queue, packaging,
    // ringkasan), baru tandai refund `approved`. Kalau void gagal, status
    // refund tetap `pending` sehingga admin bisa retry / reject.
    try {
      await salesService.void(req.saleId, {
        reason: `Refund: ${req.reason}${opts.note ? ` · ${opts.note}` : ""}`,
        actor: opts.actor,
        actorRole: opts.actorRole,
      });
    } catch (err) {
      console.error("[refund] approve: salesService.void() gagal", err);
      return {
        ok: false,
        reason: "Gagal mengembalikan stok/antrean transaksi — coba lagi",
      };
    }

    const now = new Date().toISOString();
    const { data, error: e2 } = await supabase
      .from("refund_requests")
      .update({
        status: "approved",
        decided_at: now,
        decided_by: opts.actor,
        decided_by_role: safeRole(opts.actorRole),
        decision_note: opts.note ?? null,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2 || !data) {
      // Sale sudah voided; tandai perlu perhatian manual. Approve refund
      // secara logis sukses (uang harus dikembalikan) tapi status DB gagal.
      console.error(
        "[refund] approve: sale sudah voided TAPI update status refund gagal — inkonsisten, cek manual",
        e2,
      );
      return {
        ok: false,
        reason:
          "Stok/antrean sudah dikembalikan, tapi status refund gagal disimpan — refresh & cek manual",
      };
    }
    const updated = fromRow(data as Row);
    upsertCache(updated);
    emit();
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "refund_approved",
        entity: "sale",
        entityId: req.saleId,
        reason: opts.note,
      });
    } catch (err) {
      console.error("[refund] approve: audit log failed", err);
    }
    return { ok: true, request: updated };
  },

  async reject(
    id: string,
    opts: { actor: string; actorRole?: Role; note?: string },
  ): Promise<RefundRequest | null> {
    const { data: cur, error: e1 } = await supabase
      .from("refund_requests")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!cur) return null;
    const req = fromRow(cur as Row);
    if (req.status !== "pending") {
      upsertCache(req);
      return req;
    }
    const now = new Date().toISOString();
    const { data, error: e2 } = await supabase
      .from("refund_requests")
      .update({
        status: "rejected",
        decided_at: now,
        decided_by: opts.actor,
        decided_by_role: safeRole(opts.actorRole),
        decision_note: opts.note ?? null,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2) throw e2;
    if (!data) return null;
    const updated = fromRow(data as Row);
    upsertCache(updated);
    emit();
    try {
      auditService.log({
        actor: opts.actor,
        actorRole: opts.actorRole,
        action: "refund_rejected",
        entity: "sale",
        entityId: req.saleId,
        reason: opts.note,
      });
    } catch (err) {
      console.error("[refund] reject: audit log failed", err);
    }
    return updated;
  },

  async pendingCount(): Promise<number> {
    const { count, error } = await supabase
      .from("refund_requests")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending");
    if (error) throw error;
    return count ?? 0;
  },

  /** Sinkron — dari cache. Untuk badge sidebar yang sudah punya react-query di root. */
  pendingCountCached(): number {
    return _cache.filter((r) => r.status === "pending").length;
  },
};
