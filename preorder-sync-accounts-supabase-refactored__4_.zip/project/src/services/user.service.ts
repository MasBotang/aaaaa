import { storage, StorageKeys } from "./storage";
import type { User } from "./types";

export const userService = {
  list(): User[] {
    return storage.get<User[]>(StorageKeys.users) ?? [];
  },
  save(users: User[]) {
    storage.set(StorageKeys.users, users);
  },
};