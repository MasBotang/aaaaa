/**
 * Finance Report / Export Service — read-only.
 *
 * Menyediakan generator laporan (harian/mingguan/bulanan/tahunan) dan helper
 * export CSV & Excel. Tidak menulis storage. Semua agregasi angka bisnis
 * WAJIB memakai canonical helpers dari `finance-aggregation.ts` — service
 * ini hanya melakukan formatting, bukan menghitung ulang.
 */

import * as XLSX from "xlsx";
import { financeAnalytics } from "./finance.service";
import {
  aggregateSalesRange,
  sumExpensesRange,
  sumWithdrawRange,
  sumDebtPaymentsRange,
  type DateRange,
} from "./finance-aggregation";

export type ReportPeriod = "daily" | "weekly" | "monthly" | "yearly";

export const REPORT_PERIOD_LABEL: Record<ReportPeriod, string> = {
  daily: "Harian",
  weekly: "Mingguan",
  monthly: "Bulanan",
  yearly: "Tahunan",
};

export interface ReportRange {
  from: Date;
  to: Date;
  label: string;
}

export function reportRange(period: ReportPeriod, ref = new Date()): ReportRange {
  const r = new Date(ref);
  r.setHours(0, 0, 0, 0);
  if (period === "daily") {
    const to = new Date(r);
    to.setDate(to.getDate() + 1);
    return {
      from: r,
      to,
      label: r.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" }),
    };
  }
  if (period === "weekly") {
    const day = r.getDay() || 7;
    const from = new Date(r);
    from.setDate(from.getDate() - day + 1);
    const to = new Date(from);
    to.setDate(to.getDate() + 7);
    return {
      from,
      to,
      label: `Minggu ${from.toLocaleDateString("id-ID", { day: "2-digit", month: "short" })} – ${new Date(
        to.getTime() - 86400000,
      ).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })}`,
    };
  }
  if (period === "monthly") {
    const from = new Date(r.getFullYear(), r.getMonth(), 1);
    const to = new Date(r.getFullYear(), r.getMonth() + 1, 1);
    return {
      from,
      to,
      label: from.toLocaleDateString("id-ID", { month: "long", year: "numeric" }),
    };
  }
  const from = new Date(r.getFullYear(), 0, 1);
  const to = new Date(r.getFullYear() + 1, 0, 1);
  return { from, to, label: `${from.getFullYear()}` };
}

export interface ReportSummary {
  period: ReportPeriod;
  range: ReportRange;
  revenue: number;
  hpp: number;
  grossProfit: number;
  expenses: number;
  netProfit: number;
  orders: number;
  cashIn: number;
  cashOut: number;
  netCashflow: number;
  fundWithdraws: number;
  debtPayments: number;
}

export function buildReport(period: ReportPeriod, ref = new Date()): ReportSummary {
  const range = reportRange(period, ref);
  const asDateRange: DateRange = { from: range.from, to: range.to };
  const salesAgg = aggregateSalesRange(asDateRange);
  const expenses = sumExpensesRange(asDateRange);
  const fundWithdraws = sumWithdrawRange(asDateRange);
  const debtPayments = sumDebtPaymentsRange(asDateRange);
  const cashIn = salesAgg.revenue;
  const cashOut = expenses + fundWithdraws + debtPayments;
  return {
    period,
    range,
    revenue: salesAgg.revenue,
    hpp: salesAgg.hpp,
    grossProfit: salesAgg.grossProfit,
    expenses,
    netProfit: salesAgg.grossProfit - expenses,
    orders: salesAgg.orders,
    cashIn,
    cashOut,
    netCashflow: cashIn - cashOut,
    fundWithdraws,
    debtPayments,
  };
}

/* ------------------------- Export helpers ------------------------- */

export function toCSV(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    if (v == null) return "";
    const s = String(v).replace(/"/g, '""');
    return /[",\n;]/.test(s) ? `"${s}"` : s;
  };
  return [headers.join(","), ...rows.map((r) => headers.map((h) => esc(r[h])).join(","))].join("\n");
}

export function downloadBlob(content: BlobPart, filename: string, type: string) {
  if (typeof window === "undefined") return;
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}

export function downloadCSV(rows: Record<string, unknown>[], filename: string) {
  downloadBlob("\ufeff" + toCSV(rows), filename, "text/csv;charset=utf-8");
}

export function downloadXLSX(
  sheets: { name: string; rows: Record<string, unknown>[] }[],
  filename: string,
) {
  const wb = XLSX.utils.book_new();
  for (const s of sheets) {
    const ws = XLSX.utils.json_to_sheet(s.rows);
    XLSX.utils.book_append_sheet(wb, ws, s.name.slice(0, 31));
  }
  const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  downloadBlob(buf, filename, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
}

/* ------------- Convenience rows for the Ledger / Reports ------------- */

export function ledgerRowsForExport() {
  return financeAnalytics.ledger().map((r) => ({
    Tanggal: new Date(r.at).toLocaleString("id-ID"),
    Arah: r.direction === "in" ? "Masuk" : "Keluar",
    Kategori: r.category,
    Pot: r.pot ?? "",
    Channel: r.payment,
    Jumlah: r.amount,
    Keterangan: r.description,
    Referensi: r.refId,
  }));
}

export function reportSummaryRow(r: ReportSummary): Record<string, unknown> {
  return {
    Periode: REPORT_PERIOD_LABEL[r.period],
    Rentang: r.range.label,
    Omset: r.revenue,
    HPP: r.hpp,
    "Laba Kotor": r.grossProfit,
    Pengeluaran: r.expenses,
    "Laba Bersih": r.netProfit,
    Order: r.orders,
    "Kas Masuk": r.cashIn,
    "Kas Keluar": r.cashOut,
    "Net Cashflow": r.netCashflow,
    "Pencairan Fund": r.fundWithdraws,
    "Pembayaran Hutang": r.debtPayments,
  };
}
