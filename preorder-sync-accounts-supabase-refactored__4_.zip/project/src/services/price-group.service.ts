import { supabase } from "@/lib/supabase-client";
import type { PriceGroup, Product, SourceOrder } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Data Referensi: priceGroupService sekarang menyimpan PriceGroup
// di Supabase (tabel `price_groups`), bukan localStorage lagi. Semua fungsi
// jadi async — nama & parameter dipertahankan sepersis mungkin.
//
// `PriceGroup.id` sekarang uuid (bukan lagi "pg_outlet" dst). 5 grup default
// TIDAK di-auto-seed dari client lagi (berbeda dari ensureSeed() versi
// localStorage) — RLS `price_groups_write_admin` mensyaratkan role admin
// untuk INSERT, jadi kalau kasir yang membuka POS duluan mencoba men-trigger
// seed, akan ditolak RLS. Seeding dipindah ke
// supabase/seed/price-groups.sql (jalankan sekali via SQL Editor). `list()`
// sekarang murni SELECT, tidak ada side-effect apa pun.
//
// `PriceGroup.outletId` ("Future-ready Multi Outlet") TIDAK ada kolomnya di
// skema saat ini (belum dipakai di mana pun di kode) — selalu undefined
// saat dibaca, diabaikan saat ditulis.
//
// `byId()` TIDAK punya pemanggil di luar file ini saat migrasi ini ditulis
// — dipertahankan sebagai pure helper (menerima list yang sudah di-fetch)
// untuk kelengkapan API, sama seperti forSource().
// ---------------------------------------------------------------------------

interface PriceGroupRow {
  id: string;
  name: string;
  sources: SourceOrder[];
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

function fromRow(row: PriceGroupRow): PriceGroup {
  return {
    id: row.id,
    name: row.name,
    sources: row.sources ?? [],
    isDefault: row.is_default,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export const priceGroupService = {
  async list(): Promise<PriceGroup[]> {
    const { data, error } = await supabase.from("price_groups").select("*").order("name");
    if (error) throw error;
    return (data as PriceGroupRow[]).map(fromRow);
  },

  /**
   * Insert (bila `pg.id` belum ada) atau update. `pg.id` harus uuid valid
   * untuk grup baru — generate dengan `crypto.randomUUID()` di pemanggil
   * (lihat settings-page.tsx).
   */
  async upsert(pg: PriceGroup): Promise<PriceGroup> {
    const { data, error } = await supabase
      .from("price_groups")
      .upsert({
        id: pg.id,
        name: pg.name,
        sources: pg.sources,
        is_default: pg.isDefault ?? false,
      })
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as PriceGroupRow);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from("price_groups").delete().eq("id", id);
    if (error) throw error;
  },

  /**
   * Baru: menggantikan pola lama di settings-page.tsx (tombol "Set
   * default") yang sebelumnya baca SELURUH list, remap `isDefault` di
   * memory, lalu bulk-save semuanya. Sekarang dua UPDATE terarah: lepas
   * default dari grup lama, pasang ke grup baru.
   */
  async setDefault(id: string): Promise<void> {
    const { error: clearErr } = await supabase
      .from("price_groups")
      .update({ is_default: false })
      .eq("is_default", true)
      .neq("id", id);
    if (clearErr) throw clearErr;
    const { error: setErr } = await supabase
      .from("price_groups")
      .update({ is_default: true })
      .eq("id", id);
    if (setErr) throw setErr;
  },

  byId(list: PriceGroup[], id: string | undefined): PriceGroup | undefined {
    if (!id) return undefined;
    return list.find((x) => x.id === id);
  },

  /**
   * Resolve which price group applies to a source. Falls back to default.
   * Diubah menerima `list` (react-query, sudah di-fetch pemanggil) alih-alih
   * fetch sendiri — satu-satunya pemanggil (pos-page.tsx) sudah menyimpan
   * `priceGroups` dari `useQuery`.
   */
  forSource(list: PriceGroup[], source: SourceOrder): PriceGroup | undefined {
    const hit = list.find((g) => g.sources.includes(source));
    if (hit) return hit;
    return list.find((g) => g.isDefault) ?? list[0];
  },

  /** Return the effective price of a product under a price group. Pure, tidak berubah. */
  priceFor(product: Product, priceGroupId: string | undefined): number {
    if (priceGroupId && product.prices) {
      const explicit = product.prices[priceGroupId];
      if (typeof explicit === "number" && explicit > 0) return explicit;
    }
    return product.price;
  },
};
