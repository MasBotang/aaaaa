import type {
  SalePacking,
  SalePackingItem,
  SalePlastic,
  SaleExtraPackaging,
} from "./types";

/**
 * =====================================================================
 * PACKAGING — MODE MANUAL
 * =====================================================================
 * Sebelumnya modul ini berisi "Packaging Consumption Engine": Launch Box
 * dan Plastik dihitung OTOMATIS dari jumlah pcs per Packing + Source Order.
 * Atas keputusan bisnis, mekanisme itu DIHAPUS — kasir sekarang mengisi
 * sendiri box & plastik yang dipakai untuk tiap Packing (dipilih langsung
 * dari daftar Inventory kategori "packaging", sama seperti pola "Packaging
 * Tambahan"/extras). Tidak ada lagi aturan tier/kapasitas/threshold.
 *
 * Alurnya: kasir ditanya "packaging dipisah?" —
 *  - Tidak dipisah → 1 Packing, kasir isi manual 1 box + plastik sesuai
 *    kebutuhan (qty bebas, biasanya 1).
 *  - Dipisah → beberapa Packing, tiap Packing punya box & plastik sendiri
 *    yang diisi manual oleh kasir (mis. 2 packing = 2 plastik).
 *
 * File ini masih menjadi tempat helper yang FORMAT-AGNOSTIC — dipakai baik
 * oleh checkout (sales.service.ts, deduksi/rollback stok) maupun agregasi
 * Shift Closing & Analytics — supaya konsisten terhadap `Sale.packings` /
 * `Sale.plastic` / `Sale.extraPackaging` apa pun sumber angkanya (dulu
 * auto, sekarang manual).
 * =====================================================================
 */

export function newPackingId(): string {
  return `pk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

/**
 * Buat 1 Packing baru berisi seluruh item yang diberikan. Box & plastik
 * SENGAJA dikosongkan (bukan dihitung) — kasir mengisi manual di UI
 * (lihat pos-page.tsx, Sheet "Atur Packing").
 */
export function buildManualPacking(
  items: { productId: string; name: string; qty: number }[],
): SalePacking {
  const packItems: SalePackingItem[] = items.map((i) => ({
    productId: i.productId,
    name: i.name,
    qty: i.qty,
  }));
  const totalQty = packItems.reduce((a, b) => a + b.qty, 0);
  return {
    id: newPackingId(),
    items: packItems,
    totalQty,
    boxItemId: undefined,
    boxItemName: "",
    boxQty: 0,
  };
}

/**
 * Hitung ulang `items`/`totalQty` sebuah Packing (mis. setelah alokasi
 * cart berubah) TANPA menyentuh box/plastik yang sudah diisi manual oleh
 * kasir — beda dari versi lama yang otomatis menimpa box berdasarkan
 * jumlah pcs.
 */
export function recomputePacking(p: SalePacking): SalePacking {
  const totalQty = p.items.reduce((a, b) => a + b.qty, 0);
  return { ...p, totalQty };
}

/**
 * Sumber kebenaran: baris plastik mana saja yang BENAR-BENAR mewakili
 * pemotongan stok untuk 1 Sale. Dipakai baik oleh `sales.service.ts` (saat
 * checkout & saat void/refund merestore stok) maupun oleh agregasi neto
 * Shift Closing / Analytics (`aggregatePackagingUsageFromSales` di bawah),
 * supaya ketiganya konsisten terhadap satu aturan yang sama:
 *
 *  - Bila ada minimal satu `SalePacking.plastic` (Sale di-split ke >1
 *    Packing, tiap Packing punya plastiknya sendiri), maka breakdown PER
 *    Packing itulah yang dipakai.
 *  - Bila tidak (Sale 1 Packing), fallback ke `Sale.plastic` tunggal.
 */
export function resolveSalePlasticDeductions(sale: {
  packings?: SalePacking[];
  plastic?: SalePlastic;
}): SalePlastic[] {
  const perPackingPlastics = (sale.packings ?? [])
    .map((p) => p.plastic)
    .filter((pl): pl is SalePlastic => !!pl && pl.qty > 0);
  if (perPackingPlastics.length > 0) return perPackingPlastics;
  return sale.plastic && sale.plastic.qty > 0 ? [sale.plastic] : [];
}

/**
 * Ringkasan tampilan (Sale.plastic, field lama/singular) dari plastik
 * per-Packing yang diisi manual oleh kasir — dipakai HANYA untuk Sale yang
 * di-split ke >1 Packing, supaya Receipt (yang membaca `Sale.plastic`
 * sebagai satu baris) tetap menampilkan sesuatu yang bermakna tanpa perlu
 * ada perubahan pada Receipt itu sendiri.
 *
 * PENTING: hasil fungsi ini HANYA untuk tampilan/kompatibilitas — BUKAN
 * sumber kebenaran pemotongan stok. Pemotongan stok untuk Sale yang
 * di-split memakai `SalePacking.plastic` per-Packing (lihat
 * `resolveSalePlasticDeductions`), supaya tidak ada risiko dobel-hitung.
 */
export function summarizePackingsPlasticForDisplay(
  packings: SalePacking[],
): SalePlastic | undefined {
  const withPlastic = packings
    .map((p) => p.plastic)
    .filter((pl): pl is SalePlastic => !!pl && pl.qty > 0);
  if (withPlastic.length === 0) return undefined;

  const distinctKeys = new Set(withPlastic.map((pl) => pl.itemId ?? `name:${pl.itemName}`));
  const totalQty = withPlastic.reduce((a, pl) => a + pl.qty, 0);

  if (distinctKeys.size === 1) {
    const first = withPlastic[0];
    return { itemId: first.itemId, itemName: first.itemName, qty: totalQty };
  }

  // Campuran >1 jenis/ukuran plastik lintas Packing — field tunggal lama
  // tidak bisa merepresentasikan ini secara presisi. itemId sengaja
  // dikosongkan supaya tidak ada proses lain yang keliru memakainya untuk
  // memotong Inventory (hindari dobel-potong dengan breakdown per-Packing).
  const names = Array.from(new Set(withPlastic.map((pl) => pl.itemName))).join(" + ");
  return { itemId: undefined, itemName: `Campuran: ${names}`, qty: totalQty };
}

/** Satu baris kebutuhan packaging teragregasi (dipakai Shift Closing & Analytics). */
export interface PackagingUsageAggregateEntry {
  itemId: string;
  itemName: string;
  qty: number;
}

/**
 * Agregasi NETO pemakaian packaging (Launch Box + Plastik + Extra Packaging)
 * langsung dari Sale-Sale yang valid. Sale adalah sumber kebenaran transaksi
 * (`sale.packings` / `sale.plastic` sudah final saat checkout — diisi
 * manual oleh kasir, lihat sales.service.ts), sehingga caller WAJIB
 * memfilter sendiri Sale mana yang relevan (mis. per shift via `shiftId`,
 * atau `!voided`, atau rentang tanggal) SEBELUM memanggil fungsi ini —
 * fungsi ini murni menjumlahkan apa yang diberikan, tidak melakukan
 * filtering.
 */
export function aggregatePackagingUsageFromSales(
  sales: {
    packings?: SalePacking[];
    plastic?: SalePlastic;
    extraPackaging?: SaleExtraPackaging[];
  }[],
): Map<string, PackagingUsageAggregateEntry> {
  const map = new Map<string, PackagingUsageAggregateEntry>();
  const add = (itemId: string | undefined, itemName: string, qty: number) => {
    if (!itemId || qty <= 0) return;
    const cur = map.get(itemId);
    if (cur) cur.qty += qty;
    else map.set(itemId, { itemId, itemName, qty });
  };
  for (const s of sales) {
    for (const p of s.packings ?? []) {
      add(p.boxItemId, p.boxItemName, p.boxQty);
    }
    for (const pl of resolveSalePlasticDeductions(s)) {
      add(pl.itemId, pl.itemName, pl.qty);
    }
    for (const ex of s.extraPackaging ?? []) {
      add(ex.itemId, ex.itemName, ex.qty);
    }
  }
  return map;
}

/** Total qty packaging (box + plastik + extras) yang dipakai 1 Sale — dipakai untuk tren harian Analytics. */
export function totalPackagingQtyForSale(sale: {
  packings?: SalePacking[];
  plastic?: SalePlastic;
  extraPackaging?: SaleExtraPackaging[];
}): number {
  let n = 0;
  for (const p of sale.packings ?? []) n += p.boxQty;
  for (const pl of resolveSalePlasticDeductions(sale)) n += pl.qty;
  for (const ex of sale.extraPackaging ?? []) n += ex.qty;
  return n;
}
