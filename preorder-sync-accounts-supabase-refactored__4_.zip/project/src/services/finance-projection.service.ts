/**
 * Finance Projection & KPI Service — read-only.
 *
 * Menghitung proyeksi kas 30/60/90 hari, KPI turunan, dan alert rule-based.
 * Semua agregasi sales / expense / withdraw / debt payment WAJIB memakai
 * canonical helpers dari `finance-aggregation.ts` — tidak boleh looping
 * sendiri.
 */

import { financeAnalytics, financeDebts } from "./finance.service";
import {
  aggregateSalesRange,
  sumExpensesRange,
  sumWithdrawRange,
  sumDebtPaymentsRange,
  monthRange,
  type DateRange,
} from "./finance-aggregation";
import { salesService } from "./sales.service";
import { financeExpenses, financeFundWithdraws } from "./finance.service";
import { financeBudgets, budgetActuals } from "./finance-budget.service";
import {
  DEFAULT_HISTORY_DAYS,
  PROJECTION_HORIZONS,
  RUNWAY_WARN_DAYS,
  RUNWAY_DANGER_DAYS,
  BUDGET_WARN_RATIO,
  BUDGET_OVER_RATIO,
  GROWTH_ALERT_THRESHOLD,
  DEBT_DUE_SOON_DAYS,
  type ProjectionHorizonDays,
} from "./finance.constants";

/** Rata-rata harian arus kas berbasis N hari histori terakhir. */
export interface DailyAverages {
  days: number;
  avgRevenue: number;
  avgExpense: number;
  avgWithdraw: number;
  avgDebtPayment: number;
  avgOutflow: number;
  avgNetCashflow: number;
  avgGrossProfit: number;
}

function daysAgoRange(n: number): DateRange {
  const from = new Date();
  from.setHours(0, 0, 0, 0);
  from.setDate(from.getDate() - n + 1);
  const to = new Date(8640000000000000);
  return { from, to };
}

export function dailyAverages(historyDays = DEFAULT_HISTORY_DAYS): DailyAverages {
  const range = daysAgoRange(historyDays);
  const salesAgg = aggregateSalesRange(range);
  const exp = sumExpensesRange(range);
  const wd = sumWithdrawRange(range);
  const dp = sumDebtPaymentsRange(range);

  // Rata-rata harian dibagi dengan jumlah HARI AKTIF (hari dengan minimal
  // satu transaksi apa pun), bukan `historyDays` mati. Kalau baru ada
  // aktivitas 4 hari, pembagi = 4 — bukan 30 — supaya average mencerminkan
  // kenyataan bisnis yang baru mulai/pause. Fallback ke 1 agar tak dibagi 0.
  const activeDayKeys = new Set<string>();
  const bucket = (iso: string) => activeDayKeys.add(iso.slice(0, 10));
  salesService.listCached()
    .filter((s) => !s.voided && new Date(s.createdAt) >= range.from)
    .forEach((s) => bucket(s.createdAt));
  financeExpenses.list().filter((e) => new Date(e.at) >= range.from).forEach((e) => bucket(e.at));
  financeFundWithdraws.list().filter((w) => new Date(w.at) >= range.from).forEach((w) => bucket(w.at));
  financeDebts.payments().filter((p) => new Date(p.at) >= range.from).forEach((p) => bucket(p.at));
  const divisor = Math.max(1, activeDayKeys.size);

  const avgRevenue = salesAgg.revenue / divisor;
  const avgExpense = exp / divisor;
  const avgWithdraw = wd / divisor;
  const avgDebtPayment = dp / divisor;
  const avgOutflow = avgExpense + avgWithdraw + avgDebtPayment;
  const avgGrossProfit = salesAgg.grossProfit / divisor;
  return {
    days: divisor,
    avgRevenue,
    avgExpense,
    avgWithdraw,
    avgDebtPayment,
    avgOutflow,
    avgNetCashflow: avgRevenue - avgOutflow,
    avgGrossProfit,
  };
}

/** Saldo kas aktual saat ini (sum semua channel). */
export function currentCashBalance(): number {
  return financeAnalytics.cashPosition().reduce((a, c) => a + c.balance, 0);
}

export interface ProjectionHorizon {
  horizonDays: ProjectionHorizonDays;
  projectedRevenue: number;
  projectedOutflow: number;
  projectedOperationalNeed: number;
  projectedGrossProfit: number;
  projectedCashBalance: number;
  runwayDays: number | null; // null = unlimited
}

export function projectHorizon(
  days: ProjectionHorizonDays,
  avgs = dailyAverages(DEFAULT_HISTORY_DAYS),
): ProjectionHorizon {
  const projectedRevenue = avgs.avgRevenue * days;
  const projectedOutflow = avgs.avgOutflow * days;
  const projectedOperationalNeed = avgs.avgExpense * days;
  const projectedGrossProfit = avgs.avgGrossProfit * days;
  const projectedCashBalance = currentCashBalance() + avgs.avgNetCashflow * days;
  let runwayDays: number | null = null;
  if (avgs.avgNetCashflow < 0) {
    const burn = -avgs.avgNetCashflow;
    runwayDays = Math.max(0, Math.floor(currentCashBalance() / burn));
  }
  return {
    horizonDays: days,
    projectedRevenue,
    projectedOutflow,
    projectedOperationalNeed,
    projectedGrossProfit,
    projectedCashBalance,
    runwayDays,
  };
}

export function allHorizons(): ProjectionHorizon[] {
  const avgs = dailyAverages(DEFAULT_HISTORY_DAYS);
  return PROJECTION_HORIZONS.map((d) => projectHorizon(d, avgs));
}

/* -------------------------- Financial KPIs -------------------------- */

export interface FinancialKpis {
  averageOrderValue: number;
  expenseRatio: number;
  operatingRatio: number;
  profitGrowth: number;
  revenueGrowth: number;
  debtRatio: number;
  cashBurnPerDay: number;
  runwayDays: number | null;
}

function monthOffsetRange(offset: number): DateRange {
  const now = new Date();
  const from = new Date(now.getFullYear(), now.getMonth() + offset, 1);
  const to = new Date(now.getFullYear(), now.getMonth() + offset + 1, 1);
  return { from, to };
}

export function financialKpis(): FinancialKpis {
  const cur = offsetOrCurrent(0);
  const prev = monthOffsetRange(-1);
  const curSales = aggregateSalesRange(cur);
  const prevSales = aggregateSalesRange(prev);
  const curExp = sumExpensesRange(cur);
  const prevExp = sumExpensesRange(prev);
  const curProfit = curSales.grossProfit - curExp;
  const prevProfit = prevSales.grossProfit - prevExp;
  const debtTotals = financeDebts.totals();
  const avgs = dailyAverages(DEFAULT_HISTORY_DAYS);
  const burn = Math.max(0, -avgs.avgNetCashflow);
  return {
    averageOrderValue: curSales.orders > 0 ? curSales.revenue / curSales.orders : 0,
    expenseRatio: curSales.revenue > 0 ? curExp / curSales.revenue : 0,
    operatingRatio:
      curSales.revenue > 0 ? (curSales.hpp + curExp) / curSales.revenue : 0,
    profitGrowth:
      prevProfit !== 0 ? (curProfit - prevProfit) / Math.abs(prevProfit) : 0,
    revenueGrowth:
      prevSales.revenue > 0 ? (curSales.revenue - prevSales.revenue) / prevSales.revenue : 0,
    debtRatio: curSales.revenue > 0 ? debtTotals.remaining / curSales.revenue : 0,
    cashBurnPerDay: burn,
    runwayDays: burn > 0 ? Math.max(0, Math.floor(currentCashBalance() / burn)) : null,
  };
}

function offsetOrCurrent(offset: number): DateRange {
  return offset === 0 ? monthRange() : monthOffsetRange(offset);
}

/* -------------------------- Alert Center -------------------------- */

export interface FinanceAlert {
  id: string;
  level: "green" | "yellow" | "red";
  title: string;
  detail?: string;
}

export function financeAlerts(): FinanceAlert[] {
  const alerts: FinanceAlert[] = [];
  const kpi = financialKpis();

  if (Number.isFinite(kpi.profitGrowth) && kpi.profitGrowth >= GROWTH_ALERT_THRESHOLD) {
    alerts.push({
      id: "profit-up",
      level: "green",
      title: `Profit naik ${(kpi.profitGrowth * 100).toFixed(0)}%`,
      detail: "Dibandingkan bulan sebelumnya.",
    });
  } else if (
    Number.isFinite(kpi.profitGrowth) &&
    kpi.profitGrowth <= -GROWTH_ALERT_THRESHOLD
  ) {
    alerts.push({
      id: "profit-down",
      level: "yellow",
      title: `Profit turun ${Math.abs(kpi.profitGrowth * 100).toFixed(0)}%`,
      detail: "Perlu evaluasi biaya atau harga jual.",
    });
  }

  const acts = budgetActuals();
  for (const b of financeBudgets.list()) {
    if (b.monthlyAmount <= 0) continue;
    const actual = acts[b.category] ?? 0;
    const pct = actual / b.monthlyAmount;
    if (pct >= BUDGET_OVER_RATIO) {
      alerts.push({
        id: `budget-over-${b.category}`,
        level: "red",
        title: `Budget ${b.category} sudah terlampaui`,
        detail: `Realisasi ${(pct * 100).toFixed(0)}% dari target bulanan.`,
      });
    } else if (pct >= BUDGET_WARN_RATIO) {
      alerts.push({
        id: `budget-warn-${b.category}`,
        level: "yellow",
        title: `Budget ${b.category} hampir habis`,
        detail: `Sudah terpakai ${(pct * 100).toFixed(0)}%.`,
      });
    }
  }

  const now = new Date();
  for (const d of financeDebts.list()) {
    if (!d.active) continue;
    if (!d.targetDate) continue;
    const due = new Date(d.targetDate);
    const diff = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diff <= 0) {
      alerts.push({
        id: `debt-overdue-${d.id}`,
        level: "red",
        title: `Hutang ${d.name} sudah jatuh tempo`,
      });
    } else if (diff <= DEBT_DUE_SOON_DAYS) {
      alerts.push({
        id: `debt-soon-${d.id}`,
        level: "red",
        title: `Hutang ${d.name} jatuh tempo ${diff} hari lagi`,
      });
    }
  }

  const devWithdraws = financeFundWithdraws.list().filter((w) => w.pot === "development");
  if (devWithdraws.length === 0) {
    alerts.push({
      id: "dev-idle",
      level: "yellow",
      title: "Development Fund belum pernah digunakan",
      detail: "Alokasikan untuk investasi pertumbuhan bisnis.",
    });
  }

  if (kpi.runwayDays !== null && kpi.runwayDays <= RUNWAY_DANGER_DAYS) {
    alerts.push({
      id: "runway-low",
      level: "red",
      title: `Kas diprediksi habis dalam ${kpi.runwayDays} hari`,
      detail: "Turunkan pengeluaran atau tingkatkan omset.",
    });
  } else if (kpi.runwayDays !== null && kpi.runwayDays <= RUNWAY_WARN_DAYS) {
    alerts.push({
      id: "runway-warn",
      level: "yellow",
      title: `Runway kas ${kpi.runwayDays} hari`,
      detail: "Waspadai arus kas 2 bulan ke depan.",
    });
  }

  return alerts;
}
