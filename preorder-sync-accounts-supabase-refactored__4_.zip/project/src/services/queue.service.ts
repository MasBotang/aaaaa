import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import type { SalePacking, SaleType, SourceOrder } from "./types";
import { auditService } from "./audit.service";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 3 — Order Queue): queueService sekarang
// membaca & menulis tabel `public.order_queue` di Supabase — bukan
// localStorage lagi. API dipertahankan sepersis mungkin dgn versi lama;
// list()/advance()/setStatus()/active()/bySale()/removeBySale()/relinkSale()
// menjadi async. `nextStatus()` tetap sync (murni logika transisi status).
//
// KEPUTUSAN — `create()` sengaja dipertahankan SYNC:
//   - `preorder.service.promoteDue()` dan `sales.service.create()` memanggil
//     ini di dalam try/catch tanpa `await`. Mengubah create menjadi async
//     akan memaksa mengedit preorder.service.ts (yang eksplisit di-scope
//     ulang ke tahap 4). Nilai kembalian juga harus punya `.id` di titik
//     panggilan (promoteDue menyimpan `q.id` ke `po.queueId`).
//   - Implementasinya: generate `id` di client (`crypto.randomUUID()`),
//     update cache in-memory, lalu INSERT ke Supabase secara fire-and-forget
//     dengan `void (async ...)`. Kegagalan insert di-log & row di-rollback
//     dari cache. Emit event storage-write agar `useSalesRefresh` +
//     `useQueueData` re-fetch.
//
// KEPUTUSAN — `order_queue.sale_id` TIDAK punya FK ke `sales.id`
//   Sesuai komentar eksplisit di migration init: `promoteDue()` menulis
//   `preorder.id` ke kolom ini sebagai PLACEHOLDER hingga PO di-Complete,
//   baru di-relink ke `sales.id` via `relinkSale()`. Layer aplikasi juga
//   TIDAK boleh menambahkan validasi "sale_id harus valid FK" — jaga agar
//   `create()` & `relinkSale()` menerima UUID apa pun (preorder id atau
//   sales id).
//
// RLS (init migration §Section 7):
//   - SELECT: semua authenticated.
//   - INSERT: `admin`, `cashier` (checkout POS + promoteDue oleh kasir/admin).
//   - UPDATE: `admin`, `cashier` (block generic Sales/POS) DAN `admin`,
//     `production` (policy tambahan `order_queue_write_production_upd`) —
//     efektif: admin/cashier/production semua bisa `advance()` status masak
//     & packing. Prompt sempat menyebut "hanya production" — di praktiknya
//     policy yang ada memang lebih permisif; enforcement per-role tetap
//     jadi tanggung jawab UI (`permissions.ts` matrix).
//   - DELETE: `admin` (generic policy) DAN `cashier` (policy tambahan
//     `order_queue_delete_cashier` di migration 20260720000000 — dibutuhkan
//     oleh `sales.void()` rollback saat kasir refund pesanannya sendiri).
//
// `nextStatus()` — pure sync, TIDAK diubah.
// ---------------------------------------------------------------------------

export type QueueStatus =
  | "waiting"
  | "cooking"
  | "packing"
  | "ready"
  | "completed";

export const QUEUE_STATUS_LABEL: Record<QueueStatus, string> = {
  waiting: "Menunggu",
  cooking: "Memasak",
  packing: "Packing",
  ready: "Siap",
  completed: "Selesai",
};

export interface QueueOrder {
  id: string;
  saleId: string;
  saleCode: string;
  createdAt: string;
  updatedAt: string;
  status: QueueStatus;
  saleType: SaleType;
  customerName: string;
  customerPhone?: string;
  pickupAt?: string;
  isPreorder: boolean;
  itemCount: number;
  itemsSummary: string;
  timeline: { status: QueueStatus; at: string; by?: string }[];
  lastActor?: string;
  sourceOrder?: SourceOrder;
  /** Id Pre Order sumber, bila queue ini di-promote dari PO. */
  preorderId?: string;
  outletId?: string;
  /** Nomor antrean harian dari Sale (contoh "#024"). */
  orderNumber?: string;
  /** Detail pembagian packing untuk ditampilkan pada Queue. */
  packings?: SalePacking[];
}

// ---------------------------------------------------------------------------
// Row <-> domain mapping
// ---------------------------------------------------------------------------

interface QueueRow {
  id: string;
  legacy_id: string | null;
  sale_id: string;
  sale_code: string;
  created_at: string;
  updated_at: string;
  status: QueueStatus;
  sale_type: SaleType;
  customer_name: string;
  customer_phone: string | null;
  pickup_at: string | null;
  is_preorder: boolean;
  item_count: number;
  items_summary: string | null;
  timeline: { status: QueueStatus; at: string; by?: string }[] | null;
  last_actor: string | null;
  source_order: SourceOrder | null;
  preorder_id: string | null;
  order_number: string | null;
  packings: SalePacking[] | null;
}

function fromRow(r: QueueRow): QueueOrder {
  return {
    id: r.id,
    saleId: r.sale_id,
    saleCode: r.sale_code,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    status: r.status,
    saleType: r.sale_type,
    customerName: r.customer_name,
    customerPhone: r.customer_phone ?? undefined,
    pickupAt: r.pickup_at ?? undefined,
    isPreorder: r.is_preorder,
    itemCount: r.item_count,
    itemsSummary: r.items_summary ?? "",
    timeline: r.timeline ?? [],
    lastActor: r.last_actor ?? undefined,
    sourceOrder: r.source_order ?? undefined,
    preorderId: r.preorder_id ?? undefined,
    orderNumber: r.order_number ?? undefined,
    packings: r.packings ?? undefined,
  };
}

function toInsertRow(q: QueueOrder): Record<string, unknown> {
  return {
    id: q.id,
    sale_id: q.saleId,
    sale_code: q.saleCode,
    created_at: q.createdAt,
    updated_at: q.updatedAt,
    status: q.status,
    sale_type: q.saleType,
    customer_name: q.customerName,
    customer_phone: q.customerPhone ?? null,
    pickup_at: q.pickupAt ?? null,
    is_preorder: q.isPreorder,
    item_count: q.itemCount,
    items_summary: q.itemsSummary ?? null,
    timeline: q.timeline,
    last_actor: q.lastActor ?? null,
    source_order: q.sourceOrder ?? null,
    preorder_id: q.preorderId ?? null,
    order_number: q.orderNumber ?? null,
    packings: q.packings ?? [],
  };
}

// ---------------------------------------------------------------------------
// In-memory cache untuk permukaan sync (listCached), sama pola dengan
// salesService: dipopulasikan oleh list() dan diperbarui setiap mutasi.
// ---------------------------------------------------------------------------

let _cache: QueueOrder[] = [];

function setCache(rows: QueueOrder[]) {
  _cache = rows;
}
function upsertCache(q: QueueOrder) {
  const i = _cache.findIndex((r) => r.id === q.id);
  if (i >= 0) _cache = [..._cache.slice(0, i), q, ..._cache.slice(i + 1)];
  else _cache = [q, ..._cache];
}
function removeFromCacheBySale(saleId: string) {
  _cache = _cache.filter((q) => q.saleId !== saleId);
}
function removeFromCacheById(id: string) {
  _cache = _cache.filter((q) => q.id !== id);
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key: StorageKeys.orderQueue } }),
    );
  } catch (err) {
    console.error("[queue] emit storage-write failed", err);
  }
  try {
    window.dispatchEvent(new Event("desalut:queue-changed"));
  } catch {
    /* older browsers */
  }
}

// ---------------------------------------------------------------------------
// Status transition logic — MURNI SYNC.
// Alur:
//   frozen : waiting → packing → ready → completed
//   matang : waiting → cooking → packing → ready → completed
// ---------------------------------------------------------------------------

export function nextStatus(
  current: QueueStatus,
  saleType: SaleType,
): QueueStatus | null {
  if (current === "completed") return null;
  if (saleType === "matang") {
    if (current === "waiting") return "cooking";
    if (current === "cooking") return "packing";
  } else {
    if (current === "waiting") return "packing";
  }
  if (current === "packing") return "ready";
  if (current === "ready") return "completed";
  return null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export const queueService = {
  async list(): Promise<QueueOrder[]> {
    const { data, error } = await supabase
      .from("order_queue")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as QueueRow[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  /**
   * Sync accessor untuk compute pipeline lama (sales-summary, dsb).
   * Populated by list()/create()/advance()/setStatus()/removeBySale()/
   * relinkSale(). Kosong sebelum list() pertama dijalankan — halaman
   * konsumen memasang `useQueueData()` untuk memastikan cache terisi.
   */
  listCached(): QueueOrder[] {
    return _cache;
  },

  async active(): Promise<QueueOrder[]> {
    const { data, error } = await supabase
      .from("order_queue")
      .select("*")
      .neq("status", "completed")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return ((data ?? []) as QueueRow[]).map(fromRow);
  },

  async bySale(saleId: string): Promise<QueueOrder | undefined> {
    const { data, error } = await supabase
      .from("order_queue")
      .select("*")
      .eq("sale_id", saleId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    return data ? fromRow(data as QueueRow) : undefined;
  },

  /**
   * SYNC — lihat header file. Menghasilkan `id` di client dan mengirim
   * INSERT ke Supabase fire-and-forget. Kembalian object dipakai kaller
   * (`preorder.service.promoteDue`, `sales.service.create`) tanpa await.
   */
  create(
    input: Omit<QueueOrder, "id" | "createdAt" | "updatedAt" | "status" | "timeline">,
  ): QueueOrder {
    const now = new Date().toISOString();
    const initial: QueueStatus = "waiting";
    const rec: QueueOrder = {
      id: crypto.randomUUID(),
      status: initial,
      createdAt: now,
      updatedAt: now,
      timeline: [{ status: initial, at: now }],
      ...input,
    };
    upsertCache(rec);
    emit();
    void (async () => {
      const { error } = await supabase.from("order_queue").insert(toInsertRow(rec));
      if (error) {
        console.error("[queue] insert failed", error);
        removeFromCacheById(rec.id);
        emit();
        return;
      }
      emit();
    })();
    return rec;
  },

  async advance(id: string, actor?: string): Promise<QueueOrder | null> {
    const { data: curData, error: e1 } = await supabase
      .from("order_queue")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!curData) return null;
    const cur = fromRow(curData as QueueRow);
    const next = nextStatus(cur.status, cur.saleType);
    if (!next) return cur;

    const now = new Date().toISOString();
    const newTimeline = [...cur.timeline, { status: next, at: now, by: actor }];
    const { data: updData, error: e2 } = await supabase
      .from("order_queue")
      .update({
        status: next,
        updated_at: now,
        last_actor: actor ?? null,
        timeline: newTimeline,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2) throw e2;
    const updated = updData
      ? fromRow(updData as QueueRow)
      : { ...cur, status: next, updatedAt: now, lastActor: actor, timeline: newTimeline };

    upsertCache(updated);

    // Sprint 1 (H-3): audit log semua perubahan status antrean.
    try {
      auditService.log({
        actor: actor ?? "system",
        action: "queue_status_change",
        entity: "queue",
        entityId: id,
        metadata: {
          from: cur.status,
          to: next,
          saleId: cur.saleId,
          orderNumber: cur.orderNumber,
          customerName: cur.customerName,
        },
      });
    } catch (err) {
      console.error("[queue] audit log failed", err);
    }
    emit();
    return updated;
  },

  /**
   * Bug fix (M-3, dipertahankan): validasi transisi memakai `nextStatus()`
   * yang sama dengan `advance()` — mundur atau melompat status ditolak.
   */
  async setStatus(
    id: string,
    status: QueueStatus,
    actor?: string,
  ): Promise<{ ok: true; queue: QueueOrder } | { ok: false; reason: string }> {
    const { data: curData, error: e1 } = await supabase
      .from("order_queue")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (e1) throw e1;
    if (!curData) return { ok: false, reason: "Antrean tidak ditemukan" };
    const prev = fromRow(curData as QueueRow);
    if (status !== nextStatus(prev.status, prev.saleType)) {
      return {
        ok: false,
        reason: `Transisi status tidak valid: ${prev.status} → ${status}`,
      };
    }
    const now = new Date().toISOString();
    const newTimeline = [...prev.timeline, { status, at: now, by: actor }];
    const { data: updData, error: e2 } = await supabase
      .from("order_queue")
      .update({
        status,
        updated_at: now,
        last_actor: actor ?? null,
        timeline: newTimeline,
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (e2) throw e2;
    const updated = updData
      ? fromRow(updData as QueueRow)
      : { ...prev, status, updatedAt: now, lastActor: actor, timeline: newTimeline };
    upsertCache(updated);
    try {
      auditService.log({
        actor: actor ?? "system",
        action: "queue_status_change",
        entity: "queue",
        entityId: id,
        metadata: {
          from: prev.status,
          to: status,
          saleId: prev.saleId,
          orderNumber: prev.orderNumber,
          customerName: prev.customerName,
          manual: true,
        },
      });
    } catch (err) {
      console.error("[queue] audit log failed", err);
    }
    emit();
    return { ok: true, queue: updated };
  },

  /**
   * Hapus entri queue untuk sale tertentu. Dipakai saat rollback refund:
   * pesanan yang direfund tidak boleh tetap tampil di antrean produksi.
   * Idempoten — return false bila tidak ada entri.
   *
   * RLS: cashier butuh policy DELETE (lihat migration 20260720000000).
   */
  async removeBySale(saleId: string): Promise<boolean> {
    const { data, error } = await supabase
      .from("order_queue")
      .delete()
      .eq("sale_id", saleId)
      .select("id");
    if (error) throw error;
    const removed = (data ?? []).length > 0;
    if (removed) {
      removeFromCacheBySale(saleId);
      emit();
    }
    return removed;
  },

  /**
   * Sprint 3 (Finding #3B): relink saleId Queue lama saat Pre Order di-Complete.
   * Queue awalnya dibuat dengan placeholder `saleId = po.id` di promoteDue().
   * Setelah PO di-Complete dan Sale asli terbentuk, saleId harus dipindah
   * ke sale.id agar deriveStatus() & canRefund() menemukan Queue yang benar.
   * Status Queue (waiting/cooking/…) sengaja dipertahankan.
   * Idempoten & aman — return null bila queue tidak ditemukan.
   *
   * PENTING: kolom `order_queue.sale_id` sengaja tanpa FK. Update ke UUID
   * sales.id (dari placeholder preorder.id) tidak akan pernah ditolak DB
   * dengan FK violation — lihat komentar migration init.
   */
  async relinkSale(queueId: string, newSaleId: string): Promise<QueueOrder | null> {
    const { data: curData, error: e1 } = await supabase
      .from("order_queue")
      .select("*")
      .eq("id", queueId)
      .maybeSingle();
    if (e1) throw e1;
    if (!curData) return null;
    const cur = fromRow(curData as QueueRow);
    if (cur.saleId === newSaleId) return cur;

    const now = new Date().toISOString();
    const { data: updData, error: e2 } = await supabase
      .from("order_queue")
      .update({ sale_id: newSaleId, updated_at: now })
      .eq("id", queueId)
      .select("*")
      .maybeSingle();
    if (e2) throw e2;
    const updated = updData
      ? fromRow(updData as QueueRow)
      : { ...cur, saleId: newSaleId, updatedAt: now };
    upsertCache(updated);
    emit();
    return updated;
  },
};
