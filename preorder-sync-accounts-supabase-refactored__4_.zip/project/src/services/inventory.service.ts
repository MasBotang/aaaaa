import { supabase } from "@/lib/supabase-client";
import type { InventoryCategory, InventoryItem } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Data Referensi: inventoryService sekarang menyimpan InventoryItem
// di Supabase (tabel `inventory_items`), bukan localStorage lagi. Semua
// fungsi jadi async — nama & parameter dipertahankan sepersis mungkin.
//
// `InventoryItem.id` sekarang uuid dari kolom `inventory_items.id`
// (digenerate DB via gen_random_uuid() saat insert) — bukan lagi
// `inv_${timestamp}_${random}` seperti versi localStorage. Karena itu
// helper `uid()` lokal sudah tidak diperlukan/dihapus.
// ---------------------------------------------------------------------------

interface InventoryItemRow {
  id: string;
  name: string;
  category: InventoryCategory;
  unit: string;
  stock: number;
  min_stock: number;
  purchase_price: number;
  purchase_quantity: number;
  cost_per_unit: number;
  active: boolean;
  created_at: string;
  updated_at: string;
  safety_stock: number | null;
  purchase_type: "satuan" | "karton" | null;
  units_per_carton: number | null;
  last_purchase_price: number | null;
  last_purchase_at: string | null;
  last_supplier: string | null;
}

function fromRow(row: InventoryItemRow): InventoryItem {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    unit: row.unit,
    stock: Number(row.stock),
    minStock: Number(row.min_stock),
    purchasePrice: Number(row.purchase_price),
    purchaseQuantity: Number(row.purchase_quantity),
    costPerUnit: Number(row.cost_per_unit),
    active: row.active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    safetyStock: row.safety_stock == null ? undefined : Number(row.safety_stock),
    purchaseType: row.purchase_type ?? undefined,
    unitsPerCarton: row.units_per_carton == null ? undefined : Number(row.units_per_carton),
    lastPurchasePrice: row.last_purchase_price == null ? undefined : Number(row.last_purchase_price),
    lastPurchaseAt: row.last_purchase_at ?? undefined,
    lastSupplier: row.last_supplier ?? undefined,
  };
}

function computeCostPerUnit(price: number, qty: number): number {
  if (!Number.isFinite(price) || !Number.isFinite(qty) || qty <= 0) return 0;
  return Math.round((price / qty) * 100) / 100;
}

export type NewInventoryItem = Omit<
  InventoryItem,
  "id" | "createdAt" | "updatedAt" | "costPerUnit"
>;

function toPayload(input: NewInventoryItem, costPerUnit: number) {
  return {
    name: input.name,
    category: input.category,
    unit: input.unit,
    stock: input.stock,
    min_stock: input.minStock,
    purchase_price: input.purchasePrice,
    purchase_quantity: input.purchaseQuantity,
    cost_per_unit: costPerUnit,
    active: input.active,
    safety_stock: input.safetyStock ?? null,
    purchase_type: input.purchaseType ?? null,
    units_per_carton: input.unitsPerCarton ?? null,
    last_purchase_price: input.lastPurchasePrice ?? null,
    last_purchase_at: input.lastPurchaseAt ?? null,
    last_supplier: input.lastSupplier ?? null,
  };
}

export const inventoryService = {
  async list(): Promise<InventoryItem[]> {
    const { data, error } = await supabase.from("inventory_items").select("*").order("name");
    if (error) throw error;
    return (data as InventoryItemRow[]).map(fromRow);
  },

  async get(id: string): Promise<InventoryItem | undefined> {
    const { data, error } = await supabase
      .from("inventory_items")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (error) throw error;
    return data ? fromRow(data as InventoryItemRow) : undefined;
  },

  async findByName(name: string): Promise<InventoryItem | undefined> {
    const n = name.trim();
    if (!n) return undefined;
    // `ilike` tanpa wildcard = exact match case-insensitive, setara
    // `.trim().toLowerCase() === n` yang dipakai versi localStorage.
    const { data, error } = await supabase
      .from("inventory_items")
      .select("*")
      .ilike("name", n)
      .maybeSingle();
    if (error) throw error;
    return data ? fromRow(data as InventoryItemRow) : undefined;
  },

  /**
   * Pastikan ada InventoryItem untuk output produksi.
   * Jika belum ada, otomatis buat dengan kategori `production_item`.
   * Jika sudah ada, kembalikan item tersebut (tanpa mengubah kategori/unit).
   */
  async ensureProductionItem(name: string, unit: string): Promise<InventoryItem> {
    const existing = await inventoryService.findByName(name);
    if (existing) return existing;
    const input: NewInventoryItem = {
      name: name.trim(),
      category: "production_item",
      unit: unit.trim() || "pcs",
      stock: 0,
      minStock: 0,
      purchasePrice: 0,
      purchaseQuantity: 0,
      active: true,
    };
    const { data, error } = await supabase
      .from("inventory_items")
      .insert(toPayload(input, 0))
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as InventoryItemRow);
  },

  async byCategory(cat: InventoryCategory): Promise<InventoryItem[]> {
    const { data, error } = await supabase
      .from("inventory_items")
      .select("*")
      .eq("category", cat)
      .order("name");
    if (error) throw error;
    return (data as InventoryItemRow[]).map(fromRow);
  },

  /** Case-insensitive duplicate-name check. Excludes `ignoreId` (for edits). */
  async isDuplicateName(name: string, ignoreId?: string): Promise<boolean> {
    const n = name.trim();
    if (!n) return false;
    let query = supabase.from("inventory_items").select("id").ilike("name", n);
    if (ignoreId) query = query.neq("id", ignoreId);
    const { data, error } = await query;
    if (error) throw error;
    return (data?.length ?? 0) > 0;
  },

  async create(input: NewInventoryItem): Promise<InventoryItem> {
    if (await inventoryService.isDuplicateName(input.name)) {
      throw new Error("Nama item sudah digunakan");
    }
    const costPerUnit = computeCostPerUnit(input.purchasePrice, input.purchaseQuantity);
    const { data, error } = await supabase
      .from("inventory_items")
      .insert(toPayload(input, costPerUnit))
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as InventoryItemRow);
  },

  async update(id: string, patch: Partial<NewInventoryItem>): Promise<InventoryItem | undefined> {
    const current = await inventoryService.get(id);
    if (!current) return undefined;
    if (patch.name && (await inventoryService.isDuplicateName(patch.name, id))) {
      throw new Error("Nama item sudah digunakan");
    }
    const next = { ...current, ...patch };
    next.costPerUnit = computeCostPerUnit(next.purchasePrice, next.purchaseQuantity);
    const { data, error } = await supabase
      .from("inventory_items")
      .update(toPayload(next, next.costPerUnit))
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as InventoryItemRow);
  },

  /**
   * Internal: apply a signed stock delta. Used by stockMovementService.
   *
   * Diubah dari read-then-write (`Math.max(0, list[i].stock + delta)` di
   * client) menjadi RPC `adjust_inventory_stock` — satu statement atomic
   * (`UPDATE stock = GREATEST(0, stock + delta) RETURNING *`). Bug class
   * yang identik dengan productService.deduct/addStock, diperbaiki dengan
   * cara yang sama meski tidak diminta eksplisit di scope Prompt 2 — lihat
   * db-audit-report.md untuk kenapa ini juga dianggap perlu.
   */
  async adjustStock(id: string, delta: number): Promise<InventoryItem | undefined> {
    const { data, error } = await supabase.rpc("adjust_inventory_stock", {
      p_item_id: id,
      p_delta: delta,
    });
    if (error) throw error;
    return data ? fromRow(data as InventoryItemRow) : undefined;
  },

  async setActive(id: string, active: boolean): Promise<void> {
    await inventoryService.update(id, { active } as Partial<NewInventoryItem>);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from("inventory_items").delete().eq("id", id);
    if (error) throw error;
  },

  async stats() {
    const items = await inventoryService.list();
    const total = items.length;
    const active = items.filter((i) => i.active).length;
    const low = items.filter(
      (i) => i.active && i.minStock > 0 && i.stock > 0 && i.stock <= i.minStock,
    ).length;
    const out = items.filter((i) => i.active && i.stock <= 0).length;
    const byCategory: Record<InventoryCategory, number> = {
      raw: 0,
      packaging: 0,
      operational: 0,
      production_item: 0,
    };
    for (const i of items) byCategory[i.category]++;
    return { total, active, low, out, byCategory };
  },
};
