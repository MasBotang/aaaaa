import { salesService } from "./sales.service";
import { productService } from "./product.service";
import { inventoryService } from "./inventory.service";
import { settingsService } from "./settings.service";
import type { Product, ProductionSettings } from "./types";

export interface PlanningRow {
  productId: string;
  name: string;
  /** Rata-rata penjualan hari yang sama (dalam N minggu terakhir). */
  avgSameDay: number;
  /** Buffer (pcs) hasil bufferPct × avgSameDay. */
  buffer: number;
  /** Ready stock siap dijual (product.stock). */
  readyStockSales: number;
  /** Ready stock produksi (product.wipStock — belum release). */
  readyStockProduction: number;
  /** Target akhir = max(0, avg + buffer − rsSales − rsProd). */
  target: number;
}

export interface KulitRecommendation {
  totalTarget: number;
  yieldPerKg: number;
  rawKg: number;
  /** Sudah dibulatkan ke atas ke kelipatan step (default 0.5). */
  roundedKg: number;
  stepKg: number;
  /** Estimasi pcs dari roundedKg × yield. */
  estimatedPcs: number;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function ceilTo(step: number, value: number): number {
  if (step <= 0) return value;
  return Math.ceil(value / step) * step;
}

export const productionPlanningService = {
  // TODO(next prompt): productService/inventoryService/settingsService di
  // bawah sudah Supabase (async) — sales tetap localStorage untuk sekarang.
  // productionPlanningService sendiri belum dipakai oleh UI manapun (di-cek
  // via grep saat migrasi Prompt 2), jadi konversi ke async ini murni
  // forward-compat supaya tidak diam-diam rusak begitu ada halaman yang
  // memakainya.
  async settings(): Promise<ProductionSettings> {
    return settingsService.production();
  },

  /**
   * Hitung avg penjualan per produk pada hari yang sama (weekday) dalam N minggu terakhir.
   * targetDate default = hari ini.
   */
  computeAvgSameDay(targetDate = new Date(), weeks = 4): Map<string, number> {
    const wd = targetDate.getDay();
    const today = startOfDay(targetDate);
    const oldest = new Date(today);
    oldest.setDate(oldest.getDate() - weeks * 7);

    const sales = salesService.listCached();
    const perProductPerDay = new Map<string, Map<string, number>>();
    for (const s of sales) {
      const d = new Date(s.createdAt);
      if (d < oldest || d >= today) continue;
      if (d.getDay() !== wd) continue;
      const dayKey = startOfDay(d).toISOString();
      for (const it of s.items) {
        let m = perProductPerDay.get(it.productId);
        if (!m) {
          m = new Map<string, number>();
          perProductPerDay.set(it.productId, m);
        }
        m.set(dayKey, (m.get(dayKey) ?? 0) + (Number(it.qty) || 0));
      }
    }

    const out = new Map<string, number>();
    for (const [pid, m] of perProductPerDay.entries()) {
      const total = Array.from(m.values()).reduce((s, v) => s + v, 0);
      const avg = weeks > 0 ? total / weeks : 0;
      out.set(pid, avg);
    }
    return out;
  },

  /** Bangun tabel rekomendasi produksi untuk seluruh produk aktif. */
  async buildPlanning(targetDate = new Date()): Promise<PlanningRow[]> {
    const s = await productionPlanningService.settings();
    const avg = productionPlanningService.computeAvgSameDay(targetDate, s.avgWeeks);
    const allProducts = await productService.list();
    const products = allProducts.filter((p: Product) => p.active !== false);
    const rows: PlanningRow[] = products.map((p) => {
      const a = avg.get(p.id) ?? 0;
      const buffer = (a * s.bufferPct) / 100;
      const rsSales = p.stock ?? 0;
      const rsProd = p.wipStock ?? 0;
      const rawTarget = a + buffer - rsSales - rsProd;
      const target = Math.max(0, Math.round(rawTarget));
      return {
        productId: p.id,
        name: p.name,
        avgSameDay: Math.round(a * 100) / 100,
        buffer: Math.round(buffer * 100) / 100,
        readyStockSales: rsSales,
        readyStockProduction: rsProd,
        target,
      };
    });
    return rows.sort((a, b) => b.target - a.target || a.name.localeCompare(b.name));
  },

  /** Rekomendasi kebutuhan kulit berdasarkan total target produksi. */
  async recommendKulit(totalTarget: number): Promise<KulitRecommendation> {
    const s = await productionPlanningService.settings();
    const y = s.kulitYieldPerKg > 0 ? s.kulitYieldPerKg : 82;
    const step = s.kulitStepKg > 0 ? s.kulitStepKg : 0.5;
    const rawKg = totalTarget > 0 ? totalTarget / y : 0;
    const roundedKg = Math.round(ceilTo(step, rawKg) * 100) / 100;
    const estimatedPcs = Math.round(roundedKg * y);
    return {
      totalTarget: Math.round(totalTarget),
      yieldPerKg: y,
      rawKg: Math.round(rawKg * 1000) / 1000,
      roundedKg,
      stepKg: step,
      estimatedPcs,
    };
  },

  /** Ringkasan Ready Stock Production: semi-finished inventory + waiting-release finished. */
  async readyStockProductionSummary(): Promise<{
    semiFinished: { itemId: string; name: string; unit: string; stock: number }[];
    waitingFinished: { productId: string; name: string; qty: number }[];
    totalWaitingFinished: number;
    totalSemiCount: number;
  }> {
    const items = await inventoryService.byCategory("production_item");
    const semi = items.map((i) => ({ itemId: i.id, name: i.name, unit: i.unit, stock: i.stock }));
    const allProducts = await productService.list();
    const waiting = allProducts
      .filter((p) => (p.wipStock ?? 0) > 0)
      .map((p) => ({ productId: p.id, name: p.name, qty: p.wipStock ?? 0 }));
    return {
      semiFinished: semi,
      waitingFinished: waiting,
      totalWaitingFinished: waiting.reduce((s, r) => s + r.qty, 0),
      totalSemiCount: semi.length,
    };
  },
};
