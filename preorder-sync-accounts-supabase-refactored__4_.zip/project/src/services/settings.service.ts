import { supabase } from "@/lib/supabase-client";
import { DEFAULT_PRODUCTION_SETTINGS, type BusinessSettings, type ProductionSettings } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Data Referensi: settingsService sekarang menyimpan BusinessSettings
// di Supabase (tabel `business_settings`, baris singleton id=1), bukan
// localStorage lagi. Semua fungsi jadi async — nama & parameter
// dipertahankan sepersis mungkin.
//
// `getCached()` (BARU): beberapa file lintas-domain (whatsapp.service.ts,
// pos/invoice-receipt.ts) memakai `businessName` di dalam fungsi FORMATTING
// SINKRON yang dipanggil dari halaman Queue/Preorder/Pesanan — domain yang
// SENGAJA tidak disentuh di tahap migrasi ini. Supaya tidak perlu mengubah
// signature fungsi-fungsi itu (yang akan merambat ke pemanggilnya di
// halaman-halaman domain lain), `getCached()` menyediakan cache in-memory
// sinkron yang otomatis terisi setiap kali `get()` async berhasil dipanggil
// DI MANA PUN dalam sesi ini (mis. saat pos-page.tsx atau settings-page.tsx
// melakukan `useQuery` untuk settings). Sebelum settings pernah ter-load
// sekali di sesi berjalan, `getCached()` mengembalikan DEFAULTS (fallback
// yang sama seperti sebelumnya) — nama bisnis akan tampil "DeSalut" sampai
// settings ter-load, bukan crash.
// ---------------------------------------------------------------------------

const DEFAULTS: BusinessSettings = {
  businessName: "DeSalut",
  salesTargetDaily: 2_000_000,
  defaultCustomerName: "Pelanggan Umum",
  production: DEFAULT_PRODUCTION_SETTINGS,
};

let cache: BusinessSettings = DEFAULTS;

interface BusinessSettingsRow {
  business_name: string;
  business_logo: string | null;
  sales_target_daily: number;
  default_customer_name: string;
  production: ProductionSettings | null;
}

function fromRow(row: BusinessSettingsRow | null): BusinessSettings {
  if (!row) return DEFAULTS;
  return {
    businessName: row.business_name || DEFAULTS.businessName,
    businessLogo: row.business_logo ?? undefined,
    salesTargetDaily: Number(row.sales_target_daily),
    defaultCustomerName: row.default_customer_name || DEFAULTS.defaultCustomerName,
    production: { ...DEFAULT_PRODUCTION_SETTINGS, ...(row.production ?? {}) },
  };
}

export const settingsService = {
  async get(): Promise<BusinessSettings> {
    const { data, error } = await supabase
      .from("business_settings")
      .select("*")
      .eq("id", 1)
      .maybeSingle();
    if (error) throw error;
    const merged = fromRow(data as BusinessSettingsRow | null);
    cache = merged;
    return merged;
  },

  /** Sinkron, best-effort — lihat catatan di atas. */
  getCached(): BusinessSettings {
    return cache;
  },

  async save(s: BusinessSettings): Promise<void> {
    const { error } = await supabase.from("business_settings").upsert({
      id: 1,
      business_name: s.businessName,
      business_logo: s.businessLogo ?? null,
      sales_target_daily: s.salesTargetDaily,
      default_customer_name: s.defaultCustomerName,
      production: s.production ?? DEFAULT_PRODUCTION_SETTINGS,
    });
    if (error) throw error;
    cache = s;
  },

  async production(): Promise<ProductionSettings> {
    const s = await settingsService.get();
    return s.production ?? DEFAULT_PRODUCTION_SETTINGS;
  },

  async updateProduction(patch: Partial<ProductionSettings>): Promise<ProductionSettings> {
    const cur = await settingsService.get();
    const next: BusinessSettings = {
      ...cur,
      production: { ...(cur.production ?? DEFAULT_PRODUCTION_SETTINGS), ...patch },
    };
    await settingsService.save(next);
    return next.production!;
  },
};
