import { auditService } from "./audit.service";
import { settingsService } from "./settings.service";
import type { QueueStatus } from "./queue.service";

/**
 * Sprint 1 (C-1): WhatsApp Notification Automation.
 *
 * Client-only implementation via wa.me deep link — tidak butuh gateway
 * berbayar. Kasir menekan tombol; browser membuka WA (web/app) dengan
 * pesan siap kirim. Tetap ter-audit lewat `whatsapp_notification_sent`
 * sehingga jejak notifikasi ke customer bisa direview.
 */

export type WhatsAppTemplate =
  | "ready"
  | "completed"
  | "preorder_reminder"
  | "preorder_dp"
  | "void"
  | "refund";

export function normalizePhone(raw?: string): string | null {
  if (!raw) return null;
  const digits = raw.replace(/[^0-9]/g, "");
  if (!digits) return null;
  if (digits.startsWith("62")) return digits;
  if (digits.startsWith("0")) return `62${digits.slice(1)}`;
  if (digits.startsWith("8")) return `62${digits}`;
  return digits;
}

export function buildMessage(
  template: WhatsAppTemplate,
  ctx: {
    customerName?: string;
    orderNumber?: string;
    total?: number;
    downPayment?: number;
    remainingBalance?: number;
    date?: string;
    time?: string;
    items?: { qty: number; name: string }[];
  },
): string {
  // settingsService.get() sekarang async (Supabase) — buildMessage() dipakai
  // sinkron dari halaman Queue/Preorder (di luar scope migrasi tahap ini),
  // jadi pakai cache sinkron (lihat catatan di settings.service.ts).
  const brand = settingsService.getCached().businessName || "DeSalut";
  const name = ctx.customerName?.trim() || "Bapak/Ibu";
  const order = ctx.orderNumber ? ` *#${ctx.orderNumber}*` : "";
  const fmt = (n?: number) =>
    typeof n === "number"
      ? new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n)
      : "-";
  const itemsBlock =
    ctx.items && ctx.items.length > 0
      ? "\n\nDetail pesanan:\n" + ctx.items.map((i) => `• ${i.qty}× ${i.name}`).join("\n") + "\n"
      : "";
  const sign = `\n\nTerima kasih telah mempercayakan pesanan kepada kami 🙏\nSalam hangat,\n_${brand}_`;

  switch (template) {
    case "ready":
      return (
        `Halo ${name},\n\n` +
        `Ini pesan otomatis dari *${brand}*. ` +
        `Kami ingin menginformasikan bahwa pesanan Anda${order} sudah *SIAP DIAMBIL* di outlet kami.` +
        itemsBlock +
        `\nSilakan datang di waktu yang paling nyaman untuk Anda.` +
        sign
      );
    case "completed":
      return (
        `Halo ${name},\n\n` +
        `Pesanan Anda${order} di *${brand}* telah selesai. ` +
        `Terima kasih sudah berbelanja bersama kami. ` +
        `Semoga produknya berkenan dan hari Anda menyenangkan 😊` +
        sign
      );
    case "preorder_reminder":
      return (
        `Halo ${name},\n\n` +
        `Sekadar mengingatkan pre-order Anda${order} di *${brand}*` +
        (ctx.date ? ` dijadwalkan pada *${ctx.date}*${ctx.time ? ` pukul *${ctx.time}*` : ""}` : "") +
        `.` +
        itemsBlock +
        `\nBila ada perubahan jadwal, jangan ragu untuk memberi tahu kami.` +
        sign
      );
    case "preorder_dp":
      return (
        `Halo ${name},\n\n` +
        `Terima kasih atas DP untuk pre-order${order} di *${brand}*.\n\n` +
        `• Total pesanan: *${fmt(ctx.total)}*\n` +
        `• DP diterima: *${fmt(ctx.downPayment)}*\n` +
        `• Sisa saat pengambilan: *${fmt(ctx.remainingBalance)}*` +
        (ctx.date ? `\n• Jadwal ambil: *${ctx.date}*${ctx.time ? ` pukul *${ctx.time}*` : ""}` : "") +
        sign
      );
    case "void":
      return (
        `Halo ${name},\n\n` +
        `Mohon maaf, transaksi${order} di *${brand}* telah kami batalkan (void). ` +
        `Bila Anda merasa ada yang perlu dikonfirmasi, silakan hubungi kami kembali ya. ` +
        `Terima kasih atas pengertiannya 🙏` +
        sign
      );
    case "refund":
      return (
        `Halo ${name},\n\n` +
        `Refund untuk pesanan Anda${order} di *${brand}* telah kami proses` +
        (typeof ctx.total === "number" ? ` sebesar *${fmt(ctx.total)}*` : "") +
        `. Mohon maaf atas ketidaknyamanannya, dan terima kasih atas kepercayaan Anda kepada kami 🙏` +
        sign
      );
  }
}

export const whatsappService = {
  normalizePhone,
  buildMessage,
  templateForQueueStatus(status: QueueStatus): WhatsAppTemplate | null {
    if (status === "ready") return "ready";
    if (status === "completed") return "completed";
    return null;
  },
  /**
   * Bangun URL wa.me + catat audit. Caller wajib membuka URL sendiri (window.open)
   * karena browser mem-block popup bila tidak dari user gesture langsung.
   */
  buildLink(
    template: WhatsAppTemplate,
    ctx: Parameters<typeof buildMessage>[1] & { phone?: string; actor?: string; entityId?: string; entity?: string },
  ): { url: string; message: string; phone: string } | { error: string } {
    const phone = normalizePhone(ctx.phone);
    if (!phone) return { error: "Nomor WhatsApp customer tidak tersedia" };
    const message = buildMessage(template, ctx);
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    try {
      auditService.log({
        actor: ctx.actor ?? "system",
        action: "whatsapp_notification_sent",
        entity: ctx.entity ?? "sale",
        entityId: ctx.entityId ?? "-",
        metadata: {
          template,
          phone,
          orderNumber: ctx.orderNumber,
          customerName: ctx.customerName,
        },
      });
    } catch (err) {
      console.error("[whatsapp] audit failed", err);
    }
    return { url, message, phone };
  },
};