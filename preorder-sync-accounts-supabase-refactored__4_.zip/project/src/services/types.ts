export type Role = "admin" | "owner" | "cashier" | "production";

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  sku?: string;
  /** Ready stock — barang siap dijual via Sales/POS. */
  stock?: number;
  /** Work-in-progress stock — finished goods belum tervalidasi (tidak bisa dijual). */
  wipStock?: number;
  minStock?: number;
  imageUrl?: string;
  active: boolean;
  /**
   * Sumber stok default produk. `freezer` untuk barang frozen,
   * `showcase` untuk barang matang yang display di etalase.
   * Otomatis mengarah ke sale type saat POS memilih Frozen/Matang.
   */
  stockSource?: "freezer" | "showcase";
  /**
   * Harga per Price Group. Key = PriceGroup.id.
   * Fallback ke `price` bila kosong / 0.
   */
  prices?: Record<string, number>;
}

export type PaymentMethod = "cash" | "qris" | "card" | "transfer";

/**
 * Sprint 7 (Split Payment): satu transaksi dapat memiliki >1 metode
 * pembayaran. Kombinasi (method, amount) mewakili nominal per metode.
 */
export interface PaymentEntry {
  method: PaymentMethod;
  amount: number;
}

export type SaleType = "frozen" | "matang";
export type CustomerType = "end_user" | "reseller";

/**
 * Asal transaksi. Wajib dipilih sebelum checkout. Menentukan Price Group
 * yang dipakai secara otomatis.
 */
export type SourceOrder =
  | "outlet"
  | "shopeefood"
  | "gofood"
  | "grabfood"
  | "whatsapp"
  | "reseller";

export const SOURCE_ORDER_LABEL: Record<SourceOrder, string> = {
  outlet: "Outlet",
  shopeefood: "ShopeeFood",
  gofood: "GoFood",
  grabfood: "GrabFood",
  whatsapp: "WhatsApp",
  reseller: "Reseller",
};

export const SOURCE_ORDER_LIST: SourceOrder[] = [
  "outlet",
  "shopeefood",
  "gofood",
  "grabfood",
  "whatsapp",
  "reseller",
];

export type MarketplaceSource = "shopeefood" | "gofood" | "grabfood";
export const MARKETPLACE_SOURCES: MarketplaceSource[] = ["shopeefood", "gofood", "grabfood"];

export interface PriceGroup {
  id: string;
  name: string;
  /** Source order yang otomatis memakai grup ini. Boleh kosong. */
  sources: SourceOrder[];
  /** Grup default (dipakai bila tidak ada mapping). */
  isDefault?: boolean;
  /** Future-ready Multi Outlet. */
  outletId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MarketplaceSettlement {
  id: string;
  /** YYYY-MM-DD */
  date: string;
  marketplace: MarketplaceSource;
  orderCount: number;
  grossSales: number;
  marketplaceFee: number;
  netReceived: number;
  notes?: string;
  createdAt: string;
  createdBy: string;
  outletId?: string;
}

export type PreOrderStatus =
  | "scheduled"
  | "ready_to_process"
  | "completed"
  | "cancelled";

export const PREORDER_STATUS_LABEL: Record<PreOrderStatus, string> = {
  scheduled: "Dijadwalkan",
  ready_to_process: "Siap Diproses",
  completed: "Selesai",
  cancelled: "Dibatalkan",
};

export interface PreOrder {
  id: string;
  customerName: string;
  customerPhone?: string;
  /** YYYY-MM-DD */
  date: string;
  /** HH:mm */
  time: string;
  items: SaleItem[];
  total: number;
  notes?: string;
  status: PreOrderStatus;
  sourceOrder: SourceOrder;
  priceGroupId?: string;
  saleType?: SaleType;
  saleId?: string;
  queueId?: string;
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  outletId?: string;
  /**
   * Sprint 1 (C-3): DP Pre-Order. `downPayment` = uang muka yang sudah
   * dibayar customer; `remainingBalance` = total - downPayment (di-cache
   * untuk kemudahan reporting). Nilai default 0 (tidak DP).
   */
  downPayment?: number;
  remainingBalance?: number;
  dpPaidAt?: string;
  dpMethod?: PaymentMethod;
  /**
   * Sprint (Packaging Fix — Gap #5): rencana pembagian Packing yang sudah
   * diatur kasir saat Pre Order dibuat (bila kasir sempat memakai mode
   * split packing sebelum menyimpan PO). Optional & backward compatible —
   * PO lama tanpa field ini tetap fallback ke "1 Packing gabungan berisi
   * seluruh item" di titik finalize (lihat preorder-page.tsx → finalizeComplete
   * dan sales.service.ts → create()), sama seperti perilaku sebelumnya.
   */
  packings?: SalePacking[];
}

export interface SaleItem {
  productId: string;
  name: string;
  price: number;
  cost: number;
  qty: number;
}

/**
 * Production Need Ledger — kebutuhan produksi TAMBAHAN yang lahir dari PO.
 *
 * Filosofi: ready stock outlet TIDAK dipakai untuk memenuhi PO (PO dianggap
 * "pasti keluar"). Setiap PO yang dibuat mencatat satu baris per item di
 * sini sebagai porsi produksi tambahan, terpisah dari perhitungan
 * kebutuhan produksi normal (forecast/avgSameDay dsb). Baris ini dilacak
 * per PO (`preorderId`) sehingga bisa di-rollback (status → "released")
 * saat PO dibatalkan/selesai, tanpa menyentuh perhitungan normal.
 */
export type ProductionNeedStatus = "active" | "released";

export type ProductionNeedReleaseReason = "cancelled" | "completed" | "expired" | "manual";

export interface ProductionNeedAddition {
  id: string;
  /** PO asal — dipakai untuk rollback & audit trail. */
  preorderId: string;
  productId: string;
  productName: string;
  qty: number;
  /** Tanggal pickup PO (YYYY-MM-DD) saat baris ini dibuat. */
  date: string;
  status: ProductionNeedStatus;
  createdAt: string;
  releasedAt?: string;
  releaseReason?: ProductionNeedReleaseReason;
}

export interface SalePackingItem {
  productId: string;
  name: string;
  qty: number;
}

export interface SalePacking {
  id: string;
  /** Label opsional dari customer (contoh "Rumah", "Kantor"). */
  label?: string;
  items: SalePackingItem[];
  totalQty: number;
  /** Box packaging (Inventory kategori "packaging") dipilih manual oleh kasir. */
  boxItemId?: string;
  /** Nama box sesuai item Inventory yang dipilih kasir. */
  boxItemName: string;
  boxQty: number;
  /**
   * Plastik yang dipilih manual oleh kasir KHUSUS untuk Packing ini —
   * dipakai saat Sale di-split ke >1 Packing (setiap Packing = paket fisik
   * terpisah, dibungkus plastiknya sendiri). Optional — tidak diisi
   * (undefined) untuk Sale yang tidak displit (1 Packing); pada kondisi itu
   * plastik direpresentasikan oleh `Sale.plastic` (field tunggal). Lihat
   * packing.ts → `resolveSalePlasticDeductions()`.
   */
  plastic?: SalePlastic;
}

export interface SalePlastic {
  itemId?: string;
  itemName: string;
  qty: number;
}

export interface SaleExtraPackaging {
  itemId?: string;
  itemName: string;
  qty: number;
}

export interface Sale {
  id: string;
  createdAt: string;
  cashier: string;
  customerName?: string;
  shiftId?: string;
  items: SaleItem[];
  subtotal: number;
  total: number;
  /**
   * Sprint 7: array metode pembayaran (Split Payment). Legacy Sale dari
   * storage yang masih menyimpan string tunggal dinormalisasi ke array
   * saat dibaca via `salesService.list()` melalui `normalizeSalePayment`.
   */
  payment: PaymentEntry[];
  tendered?: number;
  change?: number;
  voided?: boolean;
  voidReason?: string;
  voidedBy?: string;
  voidedAt?: string;
  saleType?: SaleType;
  customerType?: CustomerType;
  isPreorder?: boolean;
  customerPhone?: string;
  pickupAt?: string;
  /** Asal transaksi. Sale lama tanpa field ini dianggap "outlet". */
  sourceOrder?: SourceOrder;
  /** Price Group yang aktif saat transaksi. */
  priceGroupId?: string;
  /** Pre Order sumber (bila transaksi ini generated dari PO). */
  preorderId?: string;
  /** Future-ready Multi Outlet. */
  outletId?: string;
  /** Nomor antrean harian singkat (contoh "#024"). Reset per hari. */
  orderNumber?: string;
  /** Pembagian pesanan ke beberapa Packing. */
  packings?: SalePacking[];
  /** Plastik yang dipilih (Rp 0, tetap kurangi stok packaging). */
  plastic?: SalePlastic;
  /** Packaging tambahan atas permintaan customer (Rp 0). */
  extraPackaging?: SaleExtraPackaging[];
  /** Catatan customer (opsional). Muncul di invoice & reprint. */
  customerNotes?: string;
}

export interface ShiftOperationalExpense {
  /** Unique id per entry (multiple entries for same item allowed). */
  id: string;
  /** ISO timestamp — kapan pengeluaran dicatat. */
  at: string;
  /** InventoryItem.id — kategori `operational`. */
  itemId: string;
  itemName: string;
  unit: string;
  qty: number;
  price: number;
  total: number;
  notes?: string;
  createdBy: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface ShiftPackagingUsage {
  /** InventoryItem.id — kategori `packaging`. */
  itemId: string;
  itemName: string;
  unit: string;
  qty: number;
}

/**
 * Rekonsiliasi settlement marketplace untuk 1 shift.
 * `systemTotal` = agregasi transaksi shift ini (dari sales-summary.service).
 * `settlementAmount` = nilai yang diinput kasir dari laporan marketplace.
 * `difference` = settlementAmount − systemTotal.
 */
export interface ShiftMarketplaceReconciliation {
  marketplace: MarketplaceSource;
  systemTotal: number;
  systemOrders: number;
  /** Nominal yang diinput. `null` = belum diinput. */
  settlementAmount: number | null;
  difference: number;
  notes?: string;
}

/**
 * Rekonsiliasi pembayaran untuk 1 shift (Cash/QRIS/Transfer/Marketplace).
 * `systemTotal` diambil dari sales-summary.service.
 * `actualTotal` opsional — hanya bila kasir memverifikasi manual.
 */
export type PaymentBucket = "cash" | "qris" | "transfer" | "marketplace";
export interface ShiftPaymentReconciliation {
  bucket: PaymentBucket;
  systemTotal: number;
  actualTotal?: number;
  difference?: number;
  notes?: string;
}

export interface Shift {
  id: string;
  cashier: string;
  openedAt: string;
  closedAt?: string;
  openingCash: number;
  closingCash?: number;
  expectedCash?: number;
  /** Alasan bila cash difference ≠ 0 (wajib). */
  cashDifferenceReason?: string;
  /** Ringkasan penjualan pada shift ini (dihitung saat close). */
  totalOrders?: number;
  totalRevenue?: number;
  cashSales?: number;
  qrisSales?: number;
  transferSales?: number;
  marketplaceSales?: number;
  /** Pengeluaran operasional — dicatat kapan saja selama shift aktif. */
  operationalExpenses?: ShiftOperationalExpense[];
  totalOperationalExpense?: number;
  /** Pemakaian packaging — diinput sekali sebelum closing. */
  packagingUsage?: ShiftPackagingUsage[];
  totalPackagingQty?: number;
  /** Timestamp terakhir Pemakaian Packaging disimpan. */
  packagingUsageSavedAt?: string;
  packagingUsageSavedBy?: string;
  /** Rekonsiliasi marketplace, disimpan saat Close Shift. */
  marketplaceReconciliations?: ShiftMarketplaceReconciliation[];
  /** Rekonsiliasi pembayaran, disimpan saat Close Shift. */
  paymentReconciliations?: ShiftPaymentReconciliation[];
}

export interface User {
  id: string;
  name: string;
  role: Role;
}

export interface BusinessSettings {
  businessName: string;
  /** Business logo — data URL or remote URL. Optional. */
  businessLogo?: string;
  salesTargetDaily: number;
  defaultCustomerName: string;
  /** Production settings — optional & backward-compatible. */
  production?: ProductionSettings;
}

export interface ProductionSettings {
  /** Yield kulit dalam pcs per kg (default 82). */
  kulitYieldPerKg: number;
  /** Kelipatan pembulatan adonan kulit (kg). Default 0.5. */
  kulitStepKg: number;
  /** Buffer persen di atas rata-rata penjualan hari yang sama. Default 20. */
  bufferPct: number;
  /** Jumlah minggu histori penjualan yang dipakai untuk avg same-day. Default 4. */
  avgWeeks: number;
}

export const DEFAULT_PRODUCTION_SETTINGS: ProductionSettings = {
  kulitYieldPerKg: 82,
  kulitStepKg: 0.5,
  bufferPct: 20,
  avgWeeks: 4,
};

export interface HoldOrder {
  id: string;
  createdAt: string;
  customerName: string;
  items: SaleItem[];
  total: number;
  sourceOrder?: SourceOrder;
  priceGroupId?: string;
}

// ============================================================
// Inventory (Version 2)
// ============================================================

export type InventoryCategory = "raw" | "packaging" | "operational" | "production_item";

export const INVENTORY_CATEGORY_LABEL: Record<InventoryCategory, string> = {
  raw: "Bahan Baku",
  packaging: "Kemasan",
  operational: "Operasional",
  production_item: "Hasil Produksi",
};

export interface InventoryItem {
  id: string;
  name: string;
  category: InventoryCategory;
  unit: string;
  stock: number;
  minStock: number;
  purchasePrice: number;
  purchaseQuantity: number;
  /** Auto-computed = purchasePrice / purchaseQuantity. Stored for downstream modules. */
  costPerUnit: number;
  active: boolean;
  createdAt: string;
  updatedAt: string;
  /**
   * Batas aman restock (Safety Stock). Dipakai Inventory Dashboard untuk
   * menyusun Daftar Belanja. Fallback ke `minStock` bila kosong.
   */
  safetyStock?: number;
  /**
   * Jenis pembelian default: per satuan atau per karton.
   * Menentukan cara pembulatan pada Daftar Belanja otomatis.
   */
  purchaseType?: "satuan" | "karton";
  /** Isi per karton (unit). Wajib jika purchaseType = "karton". */
  unitsPerCarton?: number;
  /** Harga per unit dari pembelian terakhir (Barang Masuk). Untuk display. */
  lastPurchasePrice?: number;
  /** ISO timestamp pembelian terakhir. */
  lastPurchaseAt?: string;
  /** Supplier terakhir (opsional). */
  lastSupplier?: string;
}

export type StockMovementType =
  | "restock"
  | "operational_usage"
  | "adjustment"
  | "production_consumption"
  | "production_output"
  // reserved for future automatic flows — do not implement now
  | "sales_packaging_usage";

export const STOCK_MOVEMENT_LABEL: Record<StockMovementType, string> = {
  restock: "Restock",
  operational_usage: "Pemakaian Operasional",
  adjustment: "Penyesuaian",
  production_consumption: "Pemakaian Produksi",
  production_output: "Hasil Produksi",
  sales_packaging_usage: "Pemakaian Kemasan Penjualan",
};

export interface StockMovement {
  id: string;
  createdAt: string;
  itemId: string;
  itemName: string;
  unit: string;
  type: StockMovementType;
  /** Always positive; direction is derived from `type`. */
  quantity: number;
  /** Signed delta applied to stock at the time of writing (+in / -out). */
  delta: number;
  reason?: string;
  notes?: string;
  /** Stock balance immediately after this movement. */
  balanceAfter: number;
}

// ============================================================
// Production (Version 3) — fully data-driven
// ============================================================

export type RecipeType = "semi_finished" | "finished" | "panir";

export const RECIPE_TYPE_LABEL: Record<RecipeType, string> = {
  semi_finished: "Adonan",
  finished: "Barang Jadi",
  panir: "Panir",
};

/** Output of a recipe can target an Inventory Item or a sales Product. */
export type OutputTargetType = "inventory" | "product";

export interface RecipeIngredient {
  /** MUST reference an existing InventoryItem.id — no free text allowed. */
  inventoryItemId: string;
  /** Quantity required per single recipe execution, in the item's unit. */
  quantity: number;
  /**
   * UX discriminator: "inventory" for raw materials, "recipe" when this ingredient
   * is the output of another (semi-finished) recipe. Storage tetap menggunakan
   * inventoryItemId (untuk source=recipe, ini adalah inventory item yang
   * di-auto-create dari resep adonan tersebut). Optional untuk back-compat.
   */
  source?: "inventory" | "recipe";
  /** Hanya diisi saat source="recipe" — id resep adonan sumber. */
  recipeId?: string;
}

export interface Recipe {
  id: string;
  name: string;
  type: RecipeType;
  outputTargetType: OutputTargetType;
  /** InventoryItem.id when target=inventory, Product.id when target=product. */
  outputRefId: string;
  /** Nama output (single source of truth). Inventory item di-auto-create dari nama ini. */
  outputName: string;
  outputQuantity: number;
  outputUnit: string;
  /** Estimated yield percentage 0–100. */
  estimatedYieldPct: number;
  /**
   * Estimasi berat bersih hasil 1× resep dijalankan (untuk konversi berat →
   * batch aktual saat pembuatan adonan). Disimpan dalam satuan `estimatedNetWeightUnit`.
   */
  estimatedNetWeight?: number;
  estimatedNetWeightUnit?: "g" | "kg";
  notes?: string;
  ingredients: RecipeIngredient[];
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ProductionRunConsumed {
  itemId: string;
  name: string;
  unit: string;
  quantity: number;
}

export type ProductionActivity =
  | "create_adonan"
  | "produce_finished"
  | "panir"
  | "finishing_validation";

export const PRODUCTION_ACTIVITY_LABEL: Record<ProductionActivity, string> = {
  create_adonan: "Buat Adonan",
  produce_finished: "Lipat Risol",
  panir: "Panir (Total Final)",
  finishing_validation: "Validasi Finishing",
};

export interface ProductionRun {
  id: string;
  createdAt: string;
  /** Aktivitas yang dijalankan. Optional untuk back-compat dengan data lama. */
  activity?: ProductionActivity;
  /** Kosong untuk activity=finishing_validation. */
  recipeId: string;
  recipeName: string;
  batches: number;
  producedQuantity: number;
  outputUnit: string;
  outputTargetType: OutputTargetType;
  outputRefId: string;
  outputName: string;
  operator: string;
  notes?: string;
  consumed: ProductionRunConsumed[];
  /** Hanya diisi pada activity=finishing_validation. */
  rejectedQuantity?: number;
  /** Label pelipat (misal "Pelipat A", "Pelipat B") untuk activity=produce_finished. */
  folderLabel?: string;
  /** Selisih lipat − panir pada activity=panir (positif = loss). */
  lossQuantity?: number;
  /** Berat aktual hasil adonan (gram/kg) untuk activity=create_adonan. */
  actualWeight?: number;
  actualWeightUnit?: "g" | "kg";
  /** Batch aktual hasil perhitungan berat/estimasi, activity=create_adonan. */
  actualBatches?: number;
  /** Produk rusak/waste pada activity=produce_finished. */
  wasteQuantity?: number;
}

export interface FinishingValidation {
  id: string;
  createdAt: string;
  productId: string;
  productName: string;
  validatedQty: number;
  rejectedQty: number;
  operator: string;
  notes?: string;
}

// ---------------- Finance Module ----------------

export type FundPot = "owner" | "development" | "operational" | "debt";

export const FUND_POT_LABEL: Record<FundPot, string> = {
  owner: "Owner Fund",
  development: "Development Fund",
  operational: "Operational Fund",
  debt: "Debt Fund",
};

export type FinancePayment = "cash" | "qris" | "bank" | "dompet";

export const FINANCE_PAYMENT_LABEL: Record<FinancePayment, string> = {
  cash: "Cash",
  qris: "QRIS",
  bank: "Bank",
  dompet: "Dompet",
};

export type ExpenseCategory =
  | "operational"
  | "utilities"
  | "equipment"
  | "marketing"
  | "maintenance"
  | "payroll"
  | "other";

export const EXPENSE_CATEGORY_LABEL: Record<ExpenseCategory, string> = {
  operational: "Operasional",
  utilities: "Utilitas",
  equipment: "Peralatan",
  marketing: "Marketing",
  maintenance: "Maintenance",
  payroll: "Payroll",
  other: "Lainnya",
};

export interface FinanceExpense {
  id: string;
  at: string;
  description: string;
  category: ExpenseCategory;
  pot: FundPot;
  payment: FinancePayment;
  amount: number;
  createdBy?: string;
}

export interface FinanceDebt {
  id: string;
  name: string;
  principal: number;
  createdAt: string;
  targetDate?: string;
  notes?: string;
  active: boolean;
}

export interface FinanceDebtPayment {
  id: string;
  debtId: string;
  at: string;
  amount: number;
  payment: FinancePayment;
  notes?: string;
}

export interface FinanceFundWithdraw {
  id: string;
  at: string;
  pot: FundPot;
  amount: number;
  description: string;
  payment: FinancePayment;
}

export interface FinanceAllocation {
  owner: number;
  development: number;
  operational: number;
  debt: number;
}

export interface FinanceSettings {
  allocation: FinanceAllocation;
  developmentTarget: number;
  openingBalance: {
    cash: number;
    qris: number;
    bank: number;
    dompet: number;
  };
}
