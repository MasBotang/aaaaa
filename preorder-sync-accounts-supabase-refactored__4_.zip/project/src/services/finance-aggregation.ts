/**
 * Canonical aggregation helpers for the Finance module — Single Source of
 * Truth for looping sales / expenses / withdrawals / debt payments over a
 * date range. Every service (finance-analytics, finance-report,
 * finance-projection, finance-budget) MUST use these helpers instead of
 * re-implementing the same loops.
 *
 * Read-only. Does not touch storage directly beyond delegating to the owner
 * services (`salesService`, `financeExpenses`, `financeDebts`,
 * `financeFundWithdraws`).
 */

import { salesService } from "./sales.service";
import {
  financeExpenses,
  financeDebts,
  financeFundWithdraws,
} from "./finance.service";
import type { Sale, FundPot } from "./types";

/** Half-open date range: `from <= t < to`. */
export interface DateRange {
  from: Date;
  to: Date;
}

export interface SalesAggregate {
  revenue: number;
  hpp: number;
  grossProfit: number;
  margin: number;
  orders: number;
}

// ---------- internal predicates ----------

function inRange(iso: string, r?: DateRange): boolean {
  if (!r) return true;
  const d = new Date(iso);
  return d >= r.from && d < r.to;
}

// ---------- canonical helpers ----------

/**
 * Aggregate a list of sales (already filtered / scoped) — voided sales are
 * excluded. Used internally by {@link aggregateSalesRange}.
 */
export function aggregateSalesList(sales: Sale[]): SalesAggregate {
  let revenue = 0;
  let hpp = 0;
  let orders = 0;
  for (const s of sales) {
    if (s.voided) continue;
    orders++;
    revenue += s.total;
    for (const it of s.items) hpp += (it.cost ?? 0) * it.qty;
  }
  const grossProfit = revenue - hpp;
  const margin = revenue > 0 ? grossProfit / revenue : 0;
  return { revenue, hpp, grossProfit, margin, orders };
}

/**
 * Aggregate sales in an optional date range. Skips voided sales.
 * Omit `range` to aggregate the entire history.
 */
export function aggregateSalesRange(range?: DateRange): SalesAggregate {
  const list = salesService.listCached().filter((s) => !s.voided && inRange(s.createdAt, range));
  return aggregateSalesList(list);
}

/** Sum of expenses in a range, optionally filtered by pot. */
export function sumExpensesRange(range?: DateRange, opts?: { pot?: FundPot }): number {
  return financeExpenses
    .list()
    .filter((e) => inRange(e.at, range) && (!opts?.pot || e.pot === opts.pot))
    .reduce((a, e) => a + e.amount, 0);
}

/** Sum of fund withdrawals in a range, optionally filtered by pot. */
export function sumWithdrawRange(range?: DateRange, opts?: { pot?: FundPot }): number {
  return financeFundWithdraws
    .list()
    .filter((w) => inRange(w.at, range) && (!opts?.pot || w.pot === opts.pot))
    .reduce((a, w) => a + w.amount, 0);
}

/** Sum of debt payments in a range. */
export function sumDebtPaymentsRange(range?: DateRange): number {
  return financeDebts
    .payments()
    .filter((p) => inRange(p.at, range))
    .reduce((a, p) => a + p.amount, 0);
}

// ---------- range builders (calendar-aware, half-open) ----------

export function dayRange(ref = new Date()): DateRange {
  const from = new Date(ref);
  from.setHours(0, 0, 0, 0);
  const to = new Date(from);
  to.setDate(to.getDate() + 1);
  return { from, to };
}

export function monthRange(ref = new Date()): DateRange {
  const from = new Date(ref.getFullYear(), ref.getMonth(), 1);
  const to = new Date(ref.getFullYear(), ref.getMonth() + 1, 1);
  return { from, to };
}

/** Last `days` days ending now (inclusive of today). */
export function trailingDaysRange(days: number, ref = new Date()): DateRange {
  const to = new Date(ref);
  to.setHours(0, 0, 0, 0);
  to.setDate(to.getDate() + 1); // exclusive end = tomorrow 00:00
  const from = new Date(to);
  from.setDate(from.getDate() - days);
  return { from, to };
}
