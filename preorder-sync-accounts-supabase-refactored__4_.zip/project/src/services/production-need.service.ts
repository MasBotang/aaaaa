import { supabase } from "@/lib/supabase-client";
import { STORAGE_WRITE_EVENT } from "./storage/localStorageAdapter";
import { StorageKeys } from "./storage/keys";
import type {
  PreOrder,
  ProductionNeedAddition,
  ProductionNeedReleaseReason,
} from "./types";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (Tahap 4 — Pre Order): productionNeedService kini
// membaca & menulis tabel `public.production_need_additions` di Supabase.
// Semua mutasi async; permukaan sync (`listCached`, `activeTotals`,
// `activeByDate`) dipertahankan untuk compute pipeline yang belum diporting
// (production-recommendation.service.ts saat ini belum ada file-nya, tapi
// signatur di-pertahankan supaya migrasi berikutnya tinggal menyambung).
//
// Ledger ini TIDAK dikonsumsi oleh UI manapun secara langsung — cukup
// dipanggil oleh preorderService.create/update/remove. Karena begitu,
// cache in-memory hanya di-populasi ketika `list()` dipanggil eksplisit
// (mis. dari halaman recommendation nanti); untuk saat ini `addForPreorder`
// / `releaseForPreorder` juga menyisipkan / memutasi cache supaya konsumen
// sync tetap konsisten dalam satu tab.
// ---------------------------------------------------------------------------

interface Row {
  id: string;
  legacy_id: string | null;
  preorder_id: string;
  product_id: string;
  product_name: string;
  qty: number;
  date: string;
  status: "active" | "released";
  created_at: string;
  released_at: string | null;
  release_reason: ProductionNeedReleaseReason | null;
}

function fromRow(r: Row): ProductionNeedAddition {
  return {
    id: r.id,
    preorderId: r.preorder_id,
    productId: r.product_id,
    productName: r.product_name,
    qty: Number(r.qty) || 0,
    date: r.date,
    status: r.status,
    createdAt: r.created_at,
    releasedAt: r.released_at ?? undefined,
    releaseReason: r.release_reason ?? undefined,
  };
}

let _cache: ProductionNeedAddition[] = [];
function setCache(rows: ProductionNeedAddition[]) {
  _cache = rows;
}
function upsertMany(rows: ProductionNeedAddition[]) {
  const map = new Map(_cache.map((r) => [r.id, r]));
  for (const r of rows) map.set(r.id, r);
  _cache = Array.from(map.values());
}

function emit() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(STORAGE_WRITE_EVENT, {
        detail: { key: StorageKeys.productionNeedAdditions },
      }),
    );
  } catch (err) {
    console.error("[production-need] emit storage-write failed", err);
  }
}

function nowIso() {
  return new Date().toISOString();
}

export const productionNeedService = {
  async list(): Promise<ProductionNeedAddition[]> {
    const { data, error } = await supabase
      .from("production_need_additions")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    setCache(rows);
    return rows;
  },

  listCached(): ProductionNeedAddition[] {
    return _cache;
  },

  async byPreorderId(preorderId: string): Promise<ProductionNeedAddition[]> {
    const { data, error } = await supabase
      .from("production_need_additions")
      .select("*")
      .eq("preorder_id", preorderId);
    if (error) throw error;
    return ((data ?? []) as Row[]).map(fromRow);
  },

  async addForPreorder(po: PreOrder): Promise<ProductionNeedAddition[]> {
    if (!po.items || po.items.length === 0) return [];
    const t = nowIso();
    const inserts = po.items
      .filter((it) => (Number(it.qty) || 0) > 0)
      .map((it) => ({
        preorder_id: po.id,
        product_id: it.productId,
        product_name: it.name,
        qty: Number(it.qty) || 0,
        date: po.date,
        status: "active" as const,
        created_at: t,
      }));
    if (inserts.length === 0) return [];
    const { data, error } = await supabase
      .from("production_need_additions")
      .insert(inserts)
      .select("*");
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    upsertMany(rows);
    emit();
    return rows;
  },

  async releaseForPreorder(
    preorderId: string,
    reason: ProductionNeedReleaseReason,
  ): Promise<ProductionNeedAddition[]> {
    const t = nowIso();
    const { data, error } = await supabase
      .from("production_need_additions")
      .update({ status: "released", released_at: t, release_reason: reason })
      .eq("preorder_id", preorderId)
      .eq("status", "active")
      .select("*");
    if (error) throw error;
    const rows = ((data ?? []) as Row[]).map(fromRow);
    if (rows.length > 0) {
      upsertMany(rows);
      emit();
    }
    return rows;
  },

  activeTotals(): Map<string, number> {
    const out = new Map<string, number>();
    for (const row of _cache) {
      if (row.status !== "active") continue;
      out.set(row.productId, (out.get(row.productId) ?? 0) + row.qty);
    }
    return out;
  },

  activeByDate(dates: string[]): { productId: string; name: string; qty: number }[] {
    const map = new Map<string, { productId: string; name: string; qty: number }>();
    for (const row of _cache) {
      if (row.status !== "active") continue;
      if (!dates.includes(row.date)) continue;
      const cur = map.get(row.productId);
      if (cur) cur.qty += row.qty;
      else map.set(row.productId, { productId: row.productId, name: row.productName, qty: row.qty });
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty);
  },
};
