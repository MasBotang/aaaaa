import { createFileRoute } from "@tanstack/react-router";
import { ProductsPage } from "@/features/products/products-page";

export const Route = createFileRoute("/_app/sales/products")({
  head: () => ({ meta: [{ title: "Atur Produk · DeSalut" }] }),
  component: ProductsPage,
});
