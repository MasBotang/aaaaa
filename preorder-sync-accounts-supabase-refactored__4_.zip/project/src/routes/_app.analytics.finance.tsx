import { createFileRoute } from "@tanstack/react-router";
import { FinanceAnalyticsPage } from "@/features/analytics/finance/finance-analytics-page";

export const Route = createFileRoute("/_app/analytics/finance")({
  head: () => ({ meta: [{ title: "Finance Analytics · DeSalut" }] }),
  component: FinanceAnalyticsPage,
});
