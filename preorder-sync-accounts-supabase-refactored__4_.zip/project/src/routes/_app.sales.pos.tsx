import { createFileRoute } from "@tanstack/react-router";
import { POSPage } from "@/features/pos/pos-page";

export const Route = createFileRoute("/_app/sales/pos")({
  head: () => ({ meta: [{ title: "Point of Sale · DeSalut" }] }),
  component: POSPage,
});