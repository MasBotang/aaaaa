import { createFileRoute, Outlet } from "@tanstack/react-router";
import { useRole } from "@/lib/role-context";
import type { Role } from "@/services/types";
import { ShieldAlert } from "lucide-react";

/**
 * Halaman Finance hanya boleh diakses oleh admin & owner. Guard di sini
 * (bukan redirect setelah render di child) memastikan role non-Finance
 * TIDAK sempat melihat halaman sepersekian detik pun.
 */
const ALLOWED_ROLES: Role[] = ["admin", "owner"];

function FinanceGuard() {
  const { role, hydrated } = useRole();

  // Sebelum session ter-hidrasi kita tidak render Outlet — hindari flash of
  // content saat role masih null.
  if (!hydrated) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <div className="text-sm text-muted-foreground">Memuat…</div>
      </div>
    );
  }

  if (!role || !ALLOWED_ROLES.includes(role)) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-16 text-center">
        <div className="grid h-12 w-12 place-items-center rounded-full border border-dashed border-border bg-muted/40 text-muted-foreground">
          <ShieldAlert className="h-5 w-5" aria-hidden />
        </div>
        <h1 className="text-lg font-semibold text-foreground">Akses Ditolak</h1>
        <p className="text-sm text-muted-foreground">
          Modul Finance hanya bisa diakses oleh Admin atau Owner. Hubungi
          administrator jika Anda merasa ini keliru.
        </p>
      </div>
    );
  }

  return <Outlet />;
}

export const Route = createFileRoute("/_app/finance")({ component: FinanceGuard });
