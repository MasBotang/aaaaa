import { createFileRoute } from "@tanstack/react-router";
import { ShiftsPage } from "@/features/sales/shifts-page";

export const Route = createFileRoute("/_app/sales/shifts")({
  head: () => ({ meta: [{ title: "Shifts · DeSalut" }] }),
  component: ShiftsPage,
});