import { createFileRoute, redirect } from "@tanstack/react-router";

/**
 * /sales/preorder telah dilebur secara UX ke dalam /sales/pesanan sebagai tab.
 * Route ini dipertahankan sebagai redirect kompatibilitas untuk bookmark /
 * deep link lama. Service, model data, dan workflow Pre Order tidak berubah.
 */
export const Route = createFileRoute("/_app/sales/preorder")({
  beforeLoad: () => {
    throw redirect({
      to: "/sales/pesanan",
      search: { tab: "preorder" as const },
      replace: true,
    });
  },
});
