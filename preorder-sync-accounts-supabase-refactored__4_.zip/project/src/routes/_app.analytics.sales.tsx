import { createFileRoute } from "@tanstack/react-router";
import { SalesAnalyticsPage } from "@/features/analytics/sales/sales-analytics-page";

export const Route = createFileRoute("/_app/analytics/sales")({
  head: () => ({ meta: [{ title: "Sales Analytics · DeSalut" }] }),
  component: SalesAnalyticsPage,
});
