import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/_app/sales/")({
  component: SalesIndex,
});

function SalesIndex() {
  const router = useRouter();
  useEffect(() => {
    router.navigate({ to: "/sales/home", replace: true });
  }, [router]);
  return null;
}