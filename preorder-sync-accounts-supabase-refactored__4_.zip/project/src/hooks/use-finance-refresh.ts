import { useEffect, useState } from "react";
import { STORAGE_WRITE_EVENT } from "@/services/storage/localStorageAdapter";
import { StorageKeys } from "@/services/storage/keys";

/**
 * Keys yang mempengaruhi analytics Finance. Perubahan pada salah satu key
 * ini akan memicu re-compute pada halaman yang memakai `useFinanceRefresh`.
 */
const FINANCE_KEYS = new Set<string>([
  StorageKeys.sales,
  StorageKeys.financeExpenses,
  StorageKeys.financeDebts,
  StorageKeys.financeDebtPayments,
  StorageKeys.financeFundWithdraws,
  StorageKeys.financeSettings,
  StorageKeys.financeBudgets,
]);

/**
 * Increments a tick whenever a finance-relevant storage key is written —
 * baik pada tab yang sama (via CustomEvent) maupun tab lain (via native
 * `storage` event). Gunakan nilai kembalian sebagai dependency `useMemo`
 * agar analytics dashboard/ledger/kpi/projection ikut refresh tanpa reload.
 */
export function useFinanceRefresh(): number {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const bump = () => setTick((t) => t + 1);

    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent<{ key?: string }>).detail;
      if (!detail?.key || FINANCE_KEYS.has(detail.key)) bump();
    };

    const onStorage = (e: StorageEvent) => {
      if (!e.key || FINANCE_KEYS.has(e.key)) bump();
    };

    window.addEventListener(STORAGE_WRITE_EVENT, onCustom);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(STORAGE_WRITE_EVENT, onCustom);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  return tick;
}
