import { useEffect, useState } from "react";
import { STORAGE_WRITE_EVENT } from "@/services/storage/localStorageAdapter";
import { StorageKeys, type StorageKey } from "@/services/storage/keys";

/**
 * Keys yang mempengaruhi halaman-halaman Sales (Home, Pesanan, Pre Order,
 * Shifts). Perubahan pada salah satu key ini akan memicu refresh instan —
 * baik di tab yang sama (kasir buka POS) maupun tab lain (admin buka
 * Pesanan), tanpa menunggu polling interval atau pindah tab.
 *
 * Sama seperti `useFinanceRefresh` (lihat use-finance-refresh.ts) — dua
 * hook terpisah supaya masing-masing modul jelas key mana yang relevan,
 * dan supaya tick salah satu modul tidak memicu re-render modul lain.
 */
const SALES_KEYS = new Set<string>([
  StorageKeys.sales,
  StorageKeys.orderQueue,
  StorageKeys.refundRequests,
  StorageKeys.preorders,
  StorageKeys.preorderCancelRequests,
  StorageKeys.shifts,
  StorageKeys.currentShift,
  StorageKeys.holdOrders,
]);

/**
 * Increments a tick whenever a Sales-relevant storage key is written —
 * baik pada tab yang sama (via CustomEvent `desalut:storage-write`) maupun
 * tab lain (via native `storage` event). Gunakan nilai kembalian sebagai
 * dependency `useEffect`/`useMemo` untuk refresh data tanpa reload.
 *
 * @param extraKeys - key tambahan di luar SALES_KEYS yang ingin diikutkan
 *   (mis. halaman tertentu juga mau bereaksi terhadap key khusus).
 */
export function useSalesRefresh(extraKeys?: StorageKey[]): number {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const keys = extraKeys && extraKeys.length ? new Set([...SALES_KEYS, ...extraKeys]) : SALES_KEYS;
    const bump = () => setTick((t) => t + 1);

    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent<{ key?: string }>).detail;
      if (!detail?.key || keys.has(detail.key)) bump();
    };

    const onStorage = (e: StorageEvent) => {
      if (!e.key || keys.has(e.key)) bump();
    };

    window.addEventListener(STORAGE_WRITE_EVENT, onCustom);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(STORAGE_WRITE_EVENT, onCustom);
      window.removeEventListener("storage", onStorage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [extraKeys?.join(",")]);

  return tick;
}
