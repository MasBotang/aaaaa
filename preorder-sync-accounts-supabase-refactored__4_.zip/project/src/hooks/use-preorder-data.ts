import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { preorderService } from "@/services/preorder.service";
import { preorderCancelService } from "@/services/preorder-cancel.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime the in-memory preorder cache (dipakai `preorderService.listCached()`
 * + `countActive()`/`byDate()`/`productionNeedFor()` di analytics/products/
 * pesanan badges). Ikut `useSalesRefresh()` supaya event storage-write
 * (dipancarkan setiap mutasi preorderService) langsung memicu refetch.
 */
export function usePreorderData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["preorders", "list"],
    queryFn: () => preorderService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["preorders", "list"] });
  }, [tick, qc]);
  return q;
}

/**
 * Prime cache pengajuan pembatalan PO. Pola identik dengan usePreorderData.
 */
export function usePreorderCancelData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["preorder-cancel", "list"],
    queryFn: () => preorderCancelService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["preorder-cancel", "list"] });
  }, [tick, qc]);
  return q;
}
