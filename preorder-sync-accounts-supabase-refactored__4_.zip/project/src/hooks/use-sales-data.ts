import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { salesService } from "@/services/sales.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime the in-memory sales cache (used by sync compute pipelines in
 * analytics/finance-aggregation/sales-summary/production-planning/pesanan/
 * shift savePackagingUsage). Any page that renders one of those computes
 * MUST call this hook so `salesService.listCached()` has data.
 *
 * Ikut `useSalesRefresh()` supaya invalidasi (salesService.create/void
 * memancarkan `desalut:storage-write`) langsung memicu refetch — persis
 * pola lama saat sales masih localStorage.
 */
export function useSalesData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["sales", "list"],
    queryFn: () => salesService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["sales", "list"] });
  }, [tick, qc]);
  return q;
}
