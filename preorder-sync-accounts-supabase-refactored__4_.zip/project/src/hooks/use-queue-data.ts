import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { queueService } from "@/services/queue.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime the in-memory queue cache (dipakai `queueService.listCached()` di
 * sales-summary + pesanan-page). Ikut `useSalesRefresh()` sehingga event
 * `desalut:storage-write` (dipancarkan setiap mutasi queueService) langsung
 * memicu refetch — sama pola dengan `useSalesData`.
 */
export function useQueueData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["order-queue", "list"],
    queryFn: () => queueService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["order-queue", "list"] });
  }, [tick, qc]);
  return q;
}
