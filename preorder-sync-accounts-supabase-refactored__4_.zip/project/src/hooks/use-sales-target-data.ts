import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { salesTargetService } from "@/services/sales-summary.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime cache in-memory untuk salesTargetService.get() (sinkron) — dipakai
 * salesSummaryService.today() dan home-page StatCard Target. Data disimpan
 * di tabel `public.sales_targets`.
 */
export function useSalesTargetData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["sales-targets", "all"],
    queryFn: () => salesTargetService.loadAll(),
    staleTime: 60_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["sales-targets", "all"] });
  }, [tick, qc]);
  return q;
}
