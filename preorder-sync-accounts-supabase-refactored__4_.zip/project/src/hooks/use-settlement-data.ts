import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { marketplaceSettlementService } from "@/services/marketplace-settlement.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime the in-memory marketplace settlement cache. Dipakai halaman
 * Shift (blocking status settlement) dan Finance Analytics.
 */
export function useSettlementData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["marketplace-settlements", "list"],
    queryFn: () => marketplaceSettlementService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["marketplace-settlements", "list"] });
  }, [tick, qc]);
  return q;
}
