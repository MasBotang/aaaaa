import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { refundService } from "@/services/refund.service";
import { useSalesRefresh } from "@/hooks/use-sales-refresh";

/**
 * Prime the in-memory refund cache. Any page that renders a sync
 * compute pipeline reading `refundService.listCached()`
 * (pesanan-page, sales-analytics/data.ts, operational-data.ts, sidebar
 * badge) MUST call this hook.
 *
 * Ikut `useSalesRefresh()` supaya request/approve/reject refund yang
 * memancarkan `desalut:storage-write` langsung memicu refetch.
 */
export function useRefundData() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["refunds", "list"],
    queryFn: () => refundService.list(),
    staleTime: 30_000,
  });
  const tick = useSalesRefresh();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["refunds", "list"] });
  }, [tick, qc]);
  return q;
}
