/**
 * Account Management — server-only implementation.
 *
 * Everything here runs exclusively on the server via TanStack Start
 * `createServerFn`. `supabaseAdmin` (service_role) is dynamically imported
 * inside each handler body — never at module top level — per the contract
 * documented in `src/integrations/supabase/client.server.ts`.
 *
 * This file is the privileged counterpart to the client-safe
 * `accounts.functions.ts`, which re-exports these under the same names the
 * UI (`accounts-page.tsx`) already imports.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";
import type { Role } from "@/services/types";

// ---------- Types ----------
// TODO: remove this augmentation once `supabase gen types typescript` is
// regenerated after migration 20260721000000_profiles_account_fields.sql is
// applied — generated types.ts doesn't know about these columns yet.
type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"] & {
  status: "active" | "inactive";
  employee_code: string | null;
  phone: string | null;
  notes: string | null;
};

export type AccountStatus = "active" | "inactive";

export interface AccountView {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  status: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

const roleSchema = z.enum(["admin", "owner", "cashier", "production"]);
const statusSchema = z.enum(["active", "inactive"]);

function toAccountView(row: ProfileRow, email: string, lastLogin?: string): AccountView {
  return {
    id: row.id,
    fullName: row.full_name ?? "",
    email,
    role: row.role as Role,
    status: row.status,
    employeeCode: row.employee_code ?? undefined,
    phone: row.phone ?? undefined,
    notes: row.notes ?? undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastLogin,
  };
}

// ---------- Authorization guard ----------
// requireSupabaseAuth proves WHO the caller is (valid session). It does not
// prove they're allowed to manage other users' accounts — that's checked
// here, against their own profile row, via the caller's own RLS-scoped
// client (not supabaseAdmin — no need for elevated access just to read your
// own row, and profiles_select_own already permits it).
async function requireAdminCaller(context: {
  supabase: { from: (table: "profiles") => any };
  userId: string;
}) {
  const { data, error } = await context.supabase
    .from("profiles")
    .select("role")
    .eq("id", context.userId)
    .single();
  if (error || !data || data.role !== "admin") {
    throw new Error("Forbidden: hanya admin yang boleh mengelola akun.");
  }
}

// ---------- getAccounts ----------
export const getAccountsFn = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requireAdminCaller(context);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [profilesRes, usersRes] = await Promise.all([
      supabaseAdmin.from("profiles").select("*").returns<ProfileRow[]>(),
      // NOTE: single page, up to 1000 users. Fine for this app's scale;
      // revisit with pagination if the roster ever exceeds that.
      supabaseAdmin.auth.admin.listUsers({ perPage: 1000 }),
    ]);

    if (profilesRes.error) throw new Error(profilesRes.error.message);
    if (usersRes.error) throw new Error(usersRes.error.message);

    const usersById = new Map(usersRes.data.users.map((u) => [u.id, u]));

    return (profilesRes.data ?? [])
      .map((row) => {
        const user = usersById.get(row.id);
        return toAccountView(row, user?.email ?? "", user?.last_sign_in_at ?? undefined);
      })
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
  });

// ---------- createAccount ----------
const createAccountSchema = z.object({
  fullName: z.string().min(1),
  email: z.string().email("Email wajib diisi dan valid — dipakai untuk login."),
  password: z.string().min(8, "Password minimal 8 karakter."),
  role: roleSchema,
  status: statusSchema.optional(),
  employeeCode: z.string().optional(),
  phone: z.string().optional(),
  notes: z.string().optional(),
});

export const createAccountFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(createAccountSchema)
  .handler(async ({ context, data }) => {
    await requireAdminCaller(context);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.fullName, role: data.role },
    });
    if (createError || !created.user) {
      throw new Error(createError?.message ?? "Gagal membuat akun.");
    }

    // handle_new_user() (existing trigger) already inserted the base
    // profiles row with full_name/role — this fills in the fields the
    // trigger doesn't know about.
    const { data: updated, error: updateError } = await supabaseAdmin
      .from("profiles")
      .update({
        status: data.status ?? "active",
        employee_code: data.employeeCode || null,
        phone: data.phone || null,
        notes: data.notes || null,
      })
      .eq("id", created.user.id)
      .select("*")
      .returns<ProfileRow[]>()
      .single();

    if (updateError || !updated) {
      // Roll back the auth user so we don't leave an orphaned login with no
      // usable profile.
      await supabaseAdmin.auth.admin.deleteUser(created.user.id);
      throw new Error(updateError?.message ?? "Gagal menyimpan detail akun.");
    }

    return toAccountView(updated, data.email);
  });

// ---------- updateAccount ----------
const updateAccountSchema = z.object({
  id: z.string().uuid(),
  patch: z.object({
    fullName: z.string().min(1).optional(),
    email: z.string().email().optional(),
    role: roleSchema.optional(),
    status: statusSchema.optional(),
    employeeCode: z.string().optional(),
    phone: z.string().optional(),
    notes: z.string().optional(),
  }),
});

export const updateAccountFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(updateAccountSchema)
  .handler(async ({ context, data }) => {
    await requireAdminCaller(context);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: current, error: currentError } = await supabaseAdmin
      .from("profiles")
      .select("*")
      .eq("id", data.id)
      .returns<ProfileRow[]>()
      .single();
    if (currentError || !current) throw new Error("Akun tidak ditemukan.");

    // Preserve the original guard: must leave >=1 active admin.
    const willBeAdmin = (data.patch.role ?? current.role) === "admin";
    const willBeActive = (data.patch.status ?? current.status) === "active";
    if (current.role === "admin" && current.status === "active" && !(willBeAdmin && willBeActive)) {
      const { count, error: countError } = await supabaseAdmin
        .from("profiles")
        .select("id", { count: "exact", head: true })
        .eq("role", "admin")
        .eq("status", "active")
        .neq("id", data.id);
      if (countError) throw new Error(countError.message);
      if (!count) throw new Error("Harus tersisa minimal 1 admin aktif.");
    }

    if (data.patch.email) {
      const { error: emailError } = await supabaseAdmin.auth.admin.updateUserById(data.id, {
        email: data.patch.email,
      });
      if (emailError) throw new Error(emailError.message);
    }

    const patch: Record<string, unknown> = {};
    if (data.patch.fullName !== undefined) patch.full_name = data.patch.fullName;
    if (data.patch.role !== undefined) patch.role = data.patch.role;
    if (data.patch.status !== undefined) patch.status = data.patch.status;
    if (data.patch.employeeCode !== undefined) patch.employee_code = data.patch.employeeCode || null;
    if (data.patch.phone !== undefined) patch.phone = data.patch.phone || null;
    if (data.patch.notes !== undefined) patch.notes = data.patch.notes || null;

    const { data: updated, error: updateError } = await supabaseAdmin
      .from("profiles")
      .update(patch)
      .eq("id", data.id)
      .select("*")
      .returns<ProfileRow[]>()
      .single();
    if (updateError || !updated) throw new Error(updateError?.message ?? "Gagal memperbarui akun.");

    const { data: userRes } = await supabaseAdmin.auth.admin.getUserById(data.id);
    return toAccountView(updated, userRes.user?.email ?? "");
  });

// ---------- deleteAccount ----------
// Whether the account "has transactions" can only be answered client-side —
// Sales/PreOrder/Purchase/etc. are still localStorage-only (out of scope
// for this migration, see docs/auth-migration.md), so there's nothing for a
// server function to query. The caller computes this via the existing
// `accountHasTransactions()` and passes the decision through.
const deleteAccountSchema = z.object({
  id: z.string().uuid(),
  deactivateInstead: z.boolean(),
});

export const deleteAccountFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(deleteAccountSchema)
  .handler(async ({ context, data }) => {
    await requireAdminCaller(context);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: current, error: currentError } = await supabaseAdmin
      .from("profiles")
      .select("*")
      .eq("id", data.id)
      .returns<ProfileRow[]>()
      .single();
    if (currentError || !current) throw new Error("Akun tidak ditemukan.");

    if (current.role === "admin") {
      const { count, error: countError } = await supabaseAdmin
        .from("profiles")
        .select("id", { count: "exact", head: true })
        .eq("role", "admin")
        .eq("status", "active")
        .neq("id", data.id);
      if (countError) throw new Error(countError.message);
      if (!count) throw new Error("Harus tersisa minimal 1 admin aktif.");
    }

    if (data.deactivateInstead) {
      const { error } = await supabaseAdmin
        .from("profiles")
        .update({ status: "inactive" })
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { deactivated: true };
    }

    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.id);
    if (error) throw new Error(error.message);
    return { deactivated: false };
  });

// ---------- resetAccountPassword ----------
const resetPasswordSchema = z.object({
  id: z.string().uuid(),
  newPassword: z.string().min(8, "Password minimal 8 karakter."),
});

export const resetAccountPasswordFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(resetPasswordSchema)
  .handler(async ({ context, data }) => {
    await requireAdminCaller(context);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.id, {
      password: data.newPassword,
    });
    if (error) throw new Error(error.message);
  });

// ---------- setAccountStatus ----------
const setStatusSchema = z.object({
  id: z.string().uuid(),
  status: statusSchema,
});

export const setAccountStatusFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(setStatusSchema)
  .handler(async ({ context, data }) => {
    return updateAccountFn({ data: { id: data.id, patch: { status: data.status } } });
  });
