/**
 * Split Payment helpers (Sprint 7).
 *
 * Sale.payment adalah array PaymentEntry. Data lama (payment: PaymentMethod)
 * tetap dapat dibaca melalui `normalizeSalePayment` — dinormalisasi menjadi
 * satu entry dengan amount = sale.total.
 */
import type { PaymentEntry, PaymentMethod, Sale } from "@/services/types";

export const PAYMENT_METHOD_LABEL: Record<PaymentMethod, string> = {
  cash: "Tunai",
  qris: "QRIS",
  card: "Kartu",
  transfer: "Transfer",
};

/** Legacy sale shape sebelum split payment. */
type LegacyPaymentField = PaymentMethod | PaymentEntry[] | undefined | null;

interface MaybeLegacySale {
  total?: number;
  payment?: LegacyPaymentField;
}

/**
 * Normalisasi Sale.payment ke `PaymentEntry[]`.
 * - Array baru → dikembalikan apa adanya (di-filter entry rusak).
 * - String (data lama) → `[{ method, amount: sale.total }]`.
 * - Kosong → array kosong.
 */
export function normalizeSalePayment(sale: MaybeLegacySale): PaymentEntry[] {
  const p = sale?.payment;
  if (Array.isArray(p)) {
    return p
      .filter(
        (e): e is PaymentEntry =>
          !!e && typeof e.method === "string" && typeof e.amount === "number",
      )
      .map((e) => ({ method: e.method, amount: Math.max(0, e.amount) }));
  }
  if (typeof p === "string") {
    return [{ method: p as PaymentMethod, amount: sale?.total ?? 0 }];
  }
  return [];
}

/**
 * Ambil metode dominan (nominal terbesar). Berguna untuk kolom / label
 * yang hanya menampung 1 metode (mis. laporan legacy).
 */
export function dominantPaymentMethod(sale: MaybeLegacySale): PaymentMethod {
  const entries = normalizeSalePayment(sale);
  if (entries.length === 0) return "cash";
  return entries.reduce((a, b) => (b.amount > a.amount ? b : a)).method;
}

/**
 * Ringkasan tampilan pembayaran:
 * - 1 entry: label metode ("Tunai", "QRIS").
 * - >1 entry: "Cash + QRIS" (gabungan label singkat).
 */
export function formatPaymentSummary(sale: MaybeLegacySale): string {
  const entries = normalizeSalePayment(sale);
  if (entries.length === 0) return "—";
  if (entries.length === 1) return PAYMENT_METHOD_LABEL[entries[0].method];
  return entries.map((e) => PAYMENT_METHOD_LABEL[e.method]).join(" + ");
}

/** Total nominal seluruh entry. */
export function sumPaymentEntries(entries: PaymentEntry[]): number {
  return entries.reduce((a, e) => a + (e.amount || 0), 0);
}

/**
 * Split total sale berdasarkan tiap entry: `{ method → amount }`.
 * Jumlah kelebihan cash (bila ada) dipangkas ke total sale — hanya
 * porsi yang benar-benar diterima sebagai revenue yang diaggregasi.
 */
export function saleAmountByMethod(sale: MaybeLegacySale): Record<PaymentMethod, number> {
  const out: Record<PaymentMethod, number> = { cash: 0, qris: 0, card: 0, transfer: 0 };
  const entries = normalizeSalePayment(sale);
  const total = sale?.total ?? sumPaymentEntries(entries);
  // Non-cash entries: full amount (harus pas dengan tagihan porsi mereka).
  // Cash entry: sisa (total - jumlah non-cash) supaya kelebihan cash (kembalian)
  // tidak double-count sebagai revenue.
  const nonCashSum = entries
    .filter((e) => e.method !== "cash")
    .reduce((a, e) => a + e.amount, 0);
  for (const e of entries) {
    if (e.method === "cash") continue;
    out[e.method] += e.amount;
  }
  const cashRevenue = Math.max(0, total - nonCashSum);
  out.cash += cashRevenue;
  return out;
}

/** Alias domain-friendly: satu sale legacy → seluruh entry pembayaran. */
export function paymentEntriesOf(sale: Sale): PaymentEntry[] {
  return normalizeSalePayment(sale);
}
