import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import type { Role } from "@/services/types";
import { supabase } from "@/lib/supabase-client";
import { seedIfEmpty, seedInventoryIfEmpty, seedRecipesIfEmpty } from "@/services/seed";

const VALID_ROLES: readonly Role[] = ["admin", "owner", "cashier", "production"];
function isRole(v: unknown): v is Role {
  return typeof v === "string" && (VALID_ROLES as readonly string[]).includes(v);
}

interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
}

interface LocalUser {
  id: string;
  email: string;
}

interface AuthContextValue {
  role: Role | null;
  user: LocalUser | null;
  session: { userId: string } | null;
  profile: Profile | null;
  hydrated: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function loadProfile(u: User): Promise<{ profile: Profile; role: Role | null }> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, full_name, role")
    .eq("id", u.id)
    .maybeSingle();
  if (error) console.error("[auth] load profile failed", error);
  const full_name = (data?.full_name as string | null) ?? null;
  const role = isRole(data?.role) ? (data!.role as Role) : null;
  return {
    profile: { id: u.id, full_name, email: u.email ?? null },
    role,
  };
}

export function RoleProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [session, setSession] = useState<{ userId: string } | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const activeUserId = useRef<string | null>(null);

  const applySession = useCallback(async (s: Session | null) => {
    const u = s?.user ?? null;
    activeUserId.current = u?.id ?? null;
    if (!u) {
      setUser(null);
      setSession(null);
      setProfile(null);
      setRole(null);
      return;
    }
    setUser({ id: u.id, email: u.email ?? "" });
    setSession({ userId: u.id });
    const { profile: p, role: r } = await loadProfile(u);
    // Guard terhadap race saat user berganti cepat.
    if (activeUserId.current !== u.id) return;
    setProfile(p);
    setRole(r);
  }, []);

  useEffect(() => {
    Promise.resolve().then(() => seedIfEmpty()).catch((err) => console.error("[seed]", err));
    Promise.resolve()
      .then(() => seedInventoryIfEmpty())
      .then(() => seedRecipesIfEmpty())
      .catch((err) => console.error("[seed-inv]", err));

    let mounted = true;
    (async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!mounted) return;
        await applySession(data.session);
      } catch (err) {
        console.error("[auth] restore session failed", err);
      } finally {
        if (mounted) setHydrated(true);
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      if (
        event !== "SIGNED_IN" &&
        event !== "SIGNED_OUT" &&
        event !== "USER_UPDATED" &&
        event !== "TOKEN_REFRESHED"
      ) {
        return;
      }
      void applySession(s);
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, [applySession]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
    await applySession(data.session);
  }, [applySession]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) console.error("[auth] signOut", error);
    // onAuthStateChange akan trigger applySession(null), tapi kita reset
    // eksplisit supaya UI langsung update.
    activeUserId.current = null;
    setUser(null);
    setSession(null);
    setProfile(null);
    setRole(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ role, user, session, profile, hydrated, signIn, signOut }),
    [role, user, session, profile, hydrated, signIn, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useRole() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useRole must be used inside RoleProvider");
  return ctx;
}

export const useAuth = useRole;

export const ROLE_LABELS: Record<Role, string> = {
  admin: "Admin",
  owner: "Owner",
  cashier: "Kasir",
  production: "Tim Produksi",
};

export const ROLE_DESCRIPTIONS: Record<Role, string> = {
  admin: "Akses penuh untuk mengoperasikan dan mengonfigurasi seluruh sistem.",
  owner: "Akses read-only untuk memantau performa bisnis.",
  cashier: "Workspace fokus untuk transaksi kasir.",
  production: "Operasional inventaris, produksi, dan tim.",
};
