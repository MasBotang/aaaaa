/**
 * Account Management — client-safe entry point.
 *
 * Thin wrapper around `accounts.server-fn.ts`. No Supabase admin access
 * happens in this file or anywhere reachable from it — every exported
 * function here just calls a TanStack Start server function, whose handler
 * body (including the dynamic `supabaseAdmin` import) never ships to the
 * client bundle.
 *
 * `accountHasTransactions` is the one exception and stays fully local: it
 * reads Sales/PreOrder/Purchase/etc., which are still localStorage-only
 * (out of scope for this migration — see docs/auth-migration.md), so a
 * server function has nothing to query for it.
 */

import { storage, StorageKeys } from "@/services/storage";

import {
  createAccountFn,
  deleteAccountFn,
  getAccountsFn,
  resetAccountPasswordFn,
  setAccountStatusFn,
  updateAccountFn,
  type AccountStatus,
  type AccountView,
} from "@/lib/accounts.server-fn";
import type { Role } from "@/services/types";

export type { AccountStatus, AccountView };

// ---------- Transaction guard (client-only, unchanged logic) ----------
interface CreatedByRow {
  createdBy?: string;
}

/**
 * Sudah punya transaksi = akun ini pernah tercatat sebagai `createdBy` di
 * Sales / PreOrder / Purchase (baseline modul yang men-stamp aktor). Dipakai
 * untuk memilih hard-delete vs deactivate.
 */
export function accountHasTransactions(
  acc: Pick<AccountView, "id" | "fullName" | "email">,
): boolean {
  const needles = [acc.id, acc.fullName, acc.email]
    .filter(Boolean)
    .map((s) => s.toLowerCase());
  const keys: string[] = [
    StorageKeys.sales,
    StorageKeys.preorders,
    StorageKeys.purchases,
    StorageKeys.marketplaceSettlements,
    StorageKeys.shifts,
  ];
  for (const key of keys) {
    const rows = storage.get<CreatedByRow[]>(key) ?? [];
    if (!Array.isArray(rows)) continue;
    if (rows.some((r) => r?.createdBy && needles.includes(String(r.createdBy).toLowerCase()))) {
      return true;
    }
  }
  return false;
}

// ---------- Public API ----------
export async function listAccounts(): Promise<AccountView[]> {
  return getAccountsFn();
}

export interface CreateAccountInput {
  fullName: string;
  email: string;
  password: string;
  role: Role;
  status?: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
}

export async function createAccount(input: CreateAccountInput): Promise<AccountView> {
  return createAccountFn({ data: input });
}

export interface UpdateAccountInput {
  fullName?: string;
  email?: string;
  role?: Role;
  status?: AccountStatus;
  employeeCode?: string;
  phone?: string;
  notes?: string;
}

export async function updateAccount(id: string, patch: UpdateAccountInput): Promise<AccountView> {
  return updateAccountFn({ data: { id, patch } });
}

export async function setAccountStatus(id: string, status: AccountStatus): Promise<AccountView> {
  return setAccountStatusFn({ data: { id, status } });
}

export async function resetAccountPassword(id: string, newPassword: string): Promise<void> {
  return resetAccountPasswordFn({ data: { id, newPassword } });
}

/**
 * Hard-delete jika belum ada transaksi. Kalau sudah ada → deactivate saja
 * — pemanggil harus menawarkan pilihan ini lewat `accountHasTransactions`.
 */
export async function deleteAccount(
  id: string,
  deactivateInstead: boolean,
): Promise<{ deactivated: boolean }> {
  return deleteAccountFn({ data: { id, deactivateInstead } });
}
