// Re-export dari integrasi Lovable Cloud supaya kode aplikasi cukup
// `import { supabase } from "@/lib/supabase-client"`. URL / anon key
// dibaca dari env di src/integrations/supabase/client.ts — tidak
// hardcoded di sini.
//
// NB: `src/integrations/supabase/types.ts` adalah file auto-generate
// dan saat ini belum berisi definisi semua tabel aplikasi (product,
// inventory_items, shifts, dst). Supaya service layer bebas memanggil
// `.from("<table>")` tanpa cast tiap baris, kita ekspor client dengan
// tipe longgar (`SupabaseClient<any, any, any>`). Ketika types.ts sudah
// digenerate ulang untuk mencakup skema baru, tipe longgar ini bisa
// diganti kembali ke `SupabaseClient<Database>`.
import type { SupabaseClient } from "@supabase/supabase-js";
import { supabase as typedSupabase } from "@/integrations/supabase/client";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const supabase = typedSupabase as unknown as SupabaseClient<any, any, any>;
