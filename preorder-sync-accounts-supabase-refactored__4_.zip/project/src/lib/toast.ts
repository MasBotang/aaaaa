/**
 * Durasi (ms) untuk toast error yang membawa pesan penting & spesifik —
 * biasanya detail dari service layer (kekurangan stok per-item, alasan
 * penolakan, dsb.) yang lebih panjang & lebih krusial dibaca sampai
 * selesai dibanding toast validasi biasa ("Isi alasan", "Qty harus > 0").
 *
 * Bug fix (UX Rendah — audit Sprint 1): sebelumnya cuma dipakai ad-hoc di
 * satu tempat ("Complete PO gagal...", 10 detik) sementara pesan sejenis
 * lain (gagal approve refund/pembatalan, checkout gagal, dll) pakai
 * default toast (~4 detik) atau angka custom lain (8 detik). Sekarang satu
 * konstanta dipakai konsisten di semua toast "pesan penting yang perlu
 * waktu baca lebih lama" lintas Sales & POS.
 */
export const IMPORTANT_TOAST_DURATION = 10000;
