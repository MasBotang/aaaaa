import { Outlet, useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./app-sidebar";
import { useRole } from "@/lib/role-context";
import { canAccess, ROLE_LANDING } from "@/lib/navigation";
import { capabilityForPath, roleCan } from "@/lib/permissions";
import { AccessDenied } from "./access-denied";
import { preorderService } from "@/services/preorder.service";



export function AppShell({ children }: { children?: ReactNode }) {
  const { role, hydrated, user } = useRole();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (!hydrated) return;
    if (!user) {
      router.navigate({ to: "/auth", search: { redirect: pathname }, replace: true });
      return;
    }
    if (!role) return;
    if (!canAccess(role, pathname)) {
      router.navigate({ to: ROLE_LANDING[role], replace: true });
    }
  }, [hydrated, user, role, pathname, router]);

  useEffect(() => {
    if (!user) return;
    const tick = () => {
      void preorderService.promoteDue(new Date()).catch((err) => {
        console.error("[preorder] promoteDue failed", err);
      });
    };
    tick();
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, [user]);



  if (!hydrated || !user || !role) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Memuat workspace…
      </div>
    );
  }

  // Generic capability route guard — reads the same MATRIX as the UI so a user
  // cannot bypass access by typing the URL directly.
  const requiredCap = capabilityForPath(pathname);
  const blocked = requiredCap ? !roleCan(role, requiredCap) : false;

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-10 flex shrink-0 items-center gap-3 border-b border-border/60 bg-background/80 px-4 py-2 backdrop-blur md:hidden">
            <SidebarTrigger className="-ml-1 shrink-0" />
          </header>


          <main className="flex-1 px-4 py-6 md:px-8 md:py-8">
            <div className="page-enter mx-auto w-full max-w-[1440px]">
              {blocked ? <AccessDenied /> : children ?? <Outlet />}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
