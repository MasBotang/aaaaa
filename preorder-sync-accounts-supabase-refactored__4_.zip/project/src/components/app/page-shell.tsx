import * as React from "react";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Sales Workspace — shared presentation primitives.
 *
 * These 3 components (`PageShell`, `PageHeader`, `StatCard`) unify the
 * page shell, header, and stat-card patterns across Sales workspace
 * pages so the module feels like one product, not a collection of pages.
 *
 * Presentation-only — no business logic, no data fetching, no side-effects.
 */

/* -------------------------------- PageShell ----------------------------- */

/**
 * Standard page shell: warm cream background + centered content column.
 *
 * `max-w-7xl` (1280px) was chosen as the single standard because it comfortably
 * fits the widest grids in the Sales module (Products' 4-col XL grid and
 * Pesanan's 5-col XL KPI grid) while staying tight enough that Home & Shift
 * — the narrower content-first pages — don't feel visually diluted.
 *
 * Override `maxWidth` only when a page genuinely needs a different width;
 * default should cover every workspace page in this module.
 */
export function PageShell({
  children,
  maxWidth = "7xl",
  className,
}: {
  children: React.ReactNode;
  maxWidth?: "5xl" | "6xl" | "7xl" | "screen-2xl";
  className?: string;
}) {
  const mw =
    maxWidth === "5xl"
      ? "max-w-5xl"
      : maxWidth === "6xl"
        ? "max-w-6xl"
        : maxWidth === "screen-2xl"
          ? "max-w-[1440px]"
          : "max-w-7xl";
  return (
    <div className={cn("min-h-screen bg-[oklch(0.975_0.012_75)]", className)}>
      <div className={cn("relative mx-auto flex w-full flex-col gap-8 px-4 py-8 md:px-6 lg:px-8 lg:py-10", mw)}>
        {children}
      </div>
    </div>
  );
}

/* -------------------------------- PageHeader ---------------------------- */

export function PageHeader({
  breadcrumb,
  title,
  description,
  actions,
  eyebrow,
}: {
  /** Ordered breadcrumb labels; last item is rendered as the current page. */
  breadcrumb?: string[];
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Right-side slot for buttons, tab toggles, status badges, etc. */
  actions?: React.ReactNode;
  /** Optional uppercase eyebrow ABOVE the title (used instead of breadcrumb). */
  eyebrow?: React.ReactNode;
}) {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-end sm:justify-between">
      <div className="flex min-w-0 flex-col gap-2">
        {breadcrumb && breadcrumb.length > 0 ? (
          <nav
            aria-label="Breadcrumb"
            className="flex flex-wrap items-center gap-1.5 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground"
          >
            {breadcrumb.map((label, i) => {
              const isLast = i === breadcrumb.length - 1;
              return (
                <span key={`${label}-${i}`} className="flex items-center gap-1.5">
                  <span className={isLast ? "text-foreground/80" : undefined}>{label}</span>
                  {!isLast && (
                    <ChevronRight className="h-3 w-3 text-muted-foreground/60" aria-hidden />
                  )}
                </span>
              );
            })}
          </nav>
        ) : eyebrow ? (
          <span className="inline-flex w-fit items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary/80">
            {eyebrow}
          </span>
        ) : null}
        <h1 className="font-display truncate text-[26px] font-semibold leading-tight tracking-tight text-foreground sm:text-[30px]">
          {title}
        </h1>
        {description ? (
          <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
            {description}
          </p>
        ) : null}
      </div>
      {actions ? (
        <div className="flex shrink-0 flex-wrap items-center gap-2 justify-end">
          {actions}
        </div>
      ) : null}
    </header>
  );
}

/* -------------------------------- StatCard ------------------------------ */

export type StatCardTone = "default" | "ok" | "warn" | "danger";
export type StatCardVariant = "default" | "inverse";

/**
 * Unified stat / KPI card.
 *
 * Merged from the three previous local variants across Sales pages:
 * - Home's `HeroStat` → variant="inverse" (translucent white on dark hero)
 * - Shift's `HeroStat` + `SummaryTile` → default + optional `accent`/`compact`
 * - Products' `MetricCard` → default with `icon` + `hint`
 *
 * Values are always rendered with `tabular-nums` for aligned digits.
 */
export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "default",
  variant = "default",
  compact = false,
  accent = false,
  className,
}: {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  icon?: React.ReactNode;
  tone?: StatCardTone;
  variant?: StatCardVariant;
  compact?: boolean;
  /** default-variant only — highlights the card with a subtle primary tint. */
  accent?: boolean;
  className?: string;
}) {
  if (variant === "inverse") {
    return (
      <div
        className={cn(
          "rounded-2xl bg-white/8 p-4 ring-1 ring-white/12 backdrop-blur-sm",
          className,
        )}
      >
        <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-primary-foreground/70">
          {icon ? <span className="text-primary-foreground/80">{icon}</span> : null}
          {label}
        </div>
        <div className="mt-1.5 font-display text-[20px] font-bold leading-none tabular-nums text-primary-foreground">
          {value}
        </div>
        {hint ? (
          <div className="mt-1 text-[11px] text-primary-foreground/65">{hint}</div>
        ) : null}
      </div>
    );
  }

  const toneClass =
    tone === "danger"
      ? "text-destructive"
      : tone === "warn"
        ? "text-amber-600"
        : tone === "ok"
          ? "text-emerald-600"
          : "text-foreground";

  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-2xl border bg-card shadow-[0_1px_2px_rgba(20,10,0,0.03),0_10px_28px_-18px_rgba(20,10,0,0.12)] transition-all duration-150 hover:-translate-y-0.5 hover:shadow-[0_2px_4px_rgba(20,10,0,0.04),0_18px_36px_-18px_rgba(20,10,0,0.18)]",
        compact ? "p-3.5" : "p-5",
        accent ? "border-primary/25 bg-primary/[0.04]" : "border-border/60",
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {icon ? <span className="text-muted-foreground/80">{icon}</span> : null}
          {label}
        </span>
      </div>
      <div
        className={cn(
          "mt-2 font-display font-semibold leading-none tabular-nums tracking-tight",
          compact ? "text-lg" : "text-[28px]",
          toneClass,
        )}
      >
        {value}
      </div>
      {hint ? (
        <div className={cn("mt-1.5 text-xs text-muted-foreground", compact && "text-[10px]")}>
          {hint}
        </div>
      ) : null}
    </div>
  );
}