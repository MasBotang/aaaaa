-- Extends `public.profiles` with the fields `accounts-page.tsx` (Pengaturan →
-- Manajemen Akun) needs but that the original auth migration deliberately
-- left out of scope (see docs/auth-migration.md §1 "di luar scope").
--
-- Deliberately NOT added here: password, email. Those stay owned by
-- `auth.users` (Supabase Auth) — duplicating them into `profiles` would
-- recreate the exact "two disconnected identity stores" bug the original
-- auth migration fixed.
--
-- `username` is deliberately NOT added: Supabase auth is fully email-based
-- for this project, and profiles should not carry a second, parallel
-- identity handle. (An earlier draft of this migration added `username`
-- with a case-insensitive unique index — removed before this ever shipped.
-- Do not reintroduce it here.)

ALTER TABLE public.profiles
  ADD COLUMN status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  ADD COLUMN employee_code text,
  ADD COLUMN phone text,
  ADD COLUMN notes text;

-- No RLS policy changes: profiles_select_own / profiles_update_own (from the
-- original migration) are unchanged and still correctly scope self-service
-- access. Admin-initiated reads/writes on OTHER users' rows continue to
-- require supabaseAdmin (service_role) server-side — never a broadened RLS
-- policy — same posture the original migration's §6 explicitly chose.
