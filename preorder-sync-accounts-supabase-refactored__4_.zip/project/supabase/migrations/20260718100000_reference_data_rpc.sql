-- ============================================================================
-- 20260718100000_reference_data_rpc.sql
--
-- Tahap "Migrasi Data Referensi" (Produk, Inventory Items, Recipes, Price
-- Groups, Settings) dari localStorage ke Supabase.
--
-- File ini HANYA menambah (additive) di atas skema yang sudah ada dari
-- 20260717080000_sales_pos_init.sql — tidak ada DROP/ALTER yang mengubah
-- data existing (skema itu sendiri belum pernah di-apply ke project
-- manapun, jadi tidak ada risiko data production).
--
-- Isi:
--   1. RPC deduct_product_stock / add_product_stock — atomic read-check-write
--      untuk Ready Stock produk (menggantikan pola "SELECT lalu UPDATE
--      terpisah" yang jadi sumber race condition di versi localStorage).
--   2. RPC adjust_inventory_stock — pola atomic yang SAMA, diterapkan ke
--      inventory_items.stock (dipakai stock-movement.service.ts, yang
--      sebelumnya juga melakukan read-then-write terpisah
--      (`Math.max(0, list[i].stock + delta)`) — bug class yang identik,
--      jadi diperbaiki dengan cara yang sama meski tidak diminta eksplisit).
--   3. ALTER recipes.output_ref_id → nullable. Skema asal mendefinisikannya
--      `not null`, tapi recipe.service.ts (kode aplikasi, TIDAK diubah di
--      migrasi ini) sengaja mengisi `outputRefId: ""` untuk resep bertipe
--      "panir" (lihat resolveOutput() — "Panir recipes are pure
--      compositions ... Skip auto-creating an inventory item"). String
--      kosong bukan uuid yang valid, jadi kolom ini dilonggarkan jadi
--      nullable; recipe.service.ts (sisi TypeScript) yang menerjemahkan
--      "" ↔ NULL di batas Supabase supaya kontrak `Recipe.outputRefId:
--      string` di kode aplikasi tidak perlu berubah sama sekali.
-- ============================================================================

alter table public.recipes
  alter column output_ref_id drop not null;

-- ----------------------------------------------------------------------------
-- deduct_product_stock — dipakai productService.deduct() (checkout POS,
-- fail-loud bila stok kurang).
--
-- security invoker (default) SENGAJA dipertahankan, BUKAN security definer:
-- RPC ini harus tetap tunduk pada RLS products_write_upd (admin/cashier/
-- production) persis seperti UPDATE biasa — permissions.ts tetap jadi
-- source of truth untuk siapa yang boleh checkout; RLS di sini murni
-- defense-in-depth, konsisten dengan prinsip yang sudah dipakai di seluruh
-- skema Prompt 0.
-- ----------------------------------------------------------------------------
create or replace function public.deduct_product_stock(
  p_product_id uuid,
  p_qty numeric
)
returns public.products
language plpgsql
as $$
declare
  v_row public.products;
  v_current numeric;
  v_name text;
begin
  if p_qty is null or p_qty <= 0 then
    raise exception 'Qty deduksi harus > 0';
  end if;

  -- Satu statement atomic: baca + validasi + tulis sekaligus. Tidak ada
  -- celah antara "cek stok cukup" dan "kurangi stok" seperti pada pola
  -- localStorage lama — dua device/tab yang checkout produk yang sama
  -- nyaris bersamaan tidak bisa lagi sama-sama lolos validasi lalu
  -- sama-sama menulis, karena baris terkunci oleh UPDATE pertama yang
  -- benar-benar jalan; UPDATE kedua mengevaluasi ulang `stock >= p_qty`
  -- terhadap nilai yang SUDAH diperbarui oleh yang pertama.
  update public.products
  set stock = stock - p_qty,
      updated_at = now()
  where id = p_product_id
    and stock >= p_qty
  returning * into v_row;

  if found then
    return v_row;
  end if;

  -- Tidak ada row ter-update — cari tahu alasannya (hanya untuk pesan
  -- error yang informatif; tidak mempengaruhi atomicity di atas, karena
  -- ini murni SELECT read-only setelah keputusan sudah final).
  select stock, name into v_current, v_name
  from public.products
  where id = p_product_id;

  if not found then
    raise exception 'Produk % tidak ditemukan', p_product_id;
  end if;

  raise exception 'Ready stock % tidak mencukupi (tersedia %, butuh %)',
    v_name, v_current, p_qty;
end;
$$;

comment on function public.deduct_product_stock(uuid, numeric) is
  'Atomic: UPDATE ... WHERE stock >= qty RETURNING *. Throw jika qty<=0, produk tidak ada, atau stok kurang. Dipanggil dari productService.deduct().';

-- ----------------------------------------------------------------------------
-- add_product_stock — dipakai productService.addStock() (refund rollback,
-- production release, dsb). Tidak throw untuk kasus qty<=0 / produk tidak
-- ditemukan — mengembalikan NULL, persis perilaku versi localStorage
-- (addStock() lama: `if (qty <= 0) return null;` / `if (i < 0) return
-- null;`).
-- ----------------------------------------------------------------------------
create or replace function public.add_product_stock(
  p_product_id uuid,
  p_qty numeric
)
returns public.products
language plpgsql
as $$
declare
  v_row public.products;
begin
  if p_qty is null or p_qty <= 0 then
    return null;
  end if;

  update public.products
  set stock = stock + p_qty,
      updated_at = now()
  where id = p_product_id
  returning * into v_row;

  return v_row; -- NULL otomatis bila product_id tidak ditemukan.
end;
$$;

comment on function public.add_product_stock(uuid, numeric) is
  'Atomic: UPDATE stock = stock + qty RETURNING *. NULL bila qty<=0 atau produk tidak ada (tidak throw). Dipanggil dari productService.addStock().';

-- ----------------------------------------------------------------------------
-- adjust_inventory_stock — dipakai inventoryService.adjustStock(), sumber
-- tunggal penulisan stok inventory (dipanggil stock-movement.service.ts).
-- Sama seperti product: pola lama-nya read-then-write
-- (`Math.max(0, stock + delta)`) di client, sekarang satu statement
-- atomic yang meng-clamp ke 0 di sisi database.
-- ----------------------------------------------------------------------------
create or replace function public.adjust_inventory_stock(
  p_item_id uuid,
  p_delta numeric
)
returns public.inventory_items
language plpgsql
as $$
declare
  v_row public.inventory_items;
begin
  update public.inventory_items
  set stock = greatest(0, stock + p_delta),
      updated_at = now()
  where id = p_item_id
  returning * into v_row;

  return v_row; -- NULL bila item_id tidak ditemukan.
end;
$$;

comment on function public.adjust_inventory_stock(uuid, numeric) is
  'Atomic: UPDATE stock = GREATEST(0, stock + delta) RETURNING *. NULL bila item tidak ada. Dipanggil dari inventoryService.adjustStock().';

-- ============================================================================
-- END 20260718100000_reference_data_rpc.sql
-- ============================================================================
