-- ============================================================================
-- 20260717090000_db_audit_hardening.sql
-- Senior DB Architect audit hasil review terhadap:
--   - 20260716164012_..._profiles.sql
--   - 20260716164034_..._revoke.sql
--   - 20260717080000_sales_pos_init.sql
--
-- ATURAN YANG DIPEGANG SAAT MENYUSUN FILE INI:
--   1) TIDAK mengubah/mengedit file migration yang sudah ada — semua
--      perubahan di sini bersifat ADDITIVE (ALTER TABLE / CREATE INDEX /
--      DROP INDEX) di atas skema yang sudah dibuat.
--   2) TIDAK mengubah behaviour aplikasi. Setiap CHECK constraint di bawah
--      HANYA ditambahkan setelah dikonfirmasi ke src/ bahwa constraint itu
--      SUDAH jadi invariant yang ditegakkan (atau diasumsikan) di level
--      aplikasi — lihat komentar "Bukti" di tiap section. DB di sini
--      berfungsi sebagai defense-in-depth kedua, persis prinsip yang sudah
--      dipakai untuk RLS di 20260717080000.
--   3) Belum pernah di-apply ke Supabase project manapun (skema Tahap 1 ini
--      sendiri, per catatan di file aslinya, juga belum pernah dijalankan).
--      Jadi tidak ada risiko data production yang gagal validasi.
--   4) Tidak melakukan perubahan yang butuh DROP+CREATE 30+ RLS policy atau
--      mengganti nama fungsi `current_role()` — lihat Temuan Major #1 di
--      laporan audit (docs/storage-migration/schema-mapping.md) untuk alasan
--      kenapa itu SENGAJA tidak dieksekusi di sini (risiko migrasi tidak
--      sepadan dengan manfaatnya saat ini).
-- ============================================================================


-- ============================================================================
-- SECTION A — CHECK constraints (numerik non-negatif / positif)
--
-- Setiap constraint di bawah dipetakan ke bukti konkret di src/ yang
-- menunjukkan aplikasi SUDAH mengasumsikan/menegakkan invariant yang sama,
-- supaya menambah constraint ini TIDAK mengubah behaviour yang valid — cuma
-- menutup celah di mana constraint itu bisa "bocor" (mis. lewat keyboard
-- input yang lolos validasi client, akses langsung ke API, dsb).
-- ============================================================================

-- ---- products --------------------------------------------------------
-- Bukti: products-page.tsx menolak simpan bila price<0 / cost<0 / stock<0
-- / minStock<0 ("Harga tidak boleh negatif" / "Stok tidak boleh negatif"),
-- dengan komentar eksplisit bahwa guard client-side ini perlu karena
-- `min={0}` di <input type="number"> tidak cukup mencegah nilai negatif.
-- wip_stock tidak disebut eksplisit di guard itu, tapi secara semantik
-- adalah stok juga (WIP) — disamakan.
alter table public.products
  add constraint products_price_nonnegative check (price >= 0),
  add constraint products_cost_nonnegative check (cost >= 0),
  add constraint products_stock_nonnegative check (stock >= 0),
  add constraint products_wip_stock_nonnegative check (wip_stock >= 0),
  add constraint products_min_stock_nonnegative check (min_stock is null or min_stock >= 0);

-- ---- inventory_items --------------------------------------------------------
-- Bukti: inventory.service.ts men-clamp stock dengan
-- `Math.max(0, list[i].stock + delta)` — aplikasi sudah mengasumsikan stok
-- inventory tidak pernah negatif.
alter table public.inventory_items
  add constraint inventory_items_stock_nonnegative check (stock >= 0),
  add constraint inventory_items_min_stock_nonnegative check (min_stock >= 0),
  add constraint inventory_items_purchase_price_nonnegative check (purchase_price >= 0),
  add constraint inventory_items_purchase_qty_nonnegative check (purchase_quantity >= 0),
  add constraint inventory_items_cost_per_unit_nonnegative check (cost_per_unit >= 0),
  add constraint inventory_items_safety_stock_nonnegative check (safety_stock is null or safety_stock >= 0),
  add constraint inventory_items_last_purchase_price_nonnegative check (last_purchase_price is null or last_purchase_price >= 0);

-- ---- stock_movements --------------------------------------------------------
-- Bukti: komentar SQL asli di kolom ini sendiri sudah menyatakan
-- "quantity selalu positif; arah dari `type`" — CHECK ini menegakkan
-- invariant yang sudah didokumentasikan tapi belum pernah ditegakkan.
alter table public.stock_movements
  add constraint stock_movements_quantity_positive check (quantity > 0);

-- ---- sales --------------------------------------------------------
-- Bukti: pos-page.tsx menghitung `changeDue = Math.max(0, paidTotal -
-- total)` — change tidak pernah negatif secara desain. subtotal/total/
-- tendered adalah nilai uang transaksi, tidak ada jalur bisnis yang sah
-- menghasilkan nilai negatif (refund/void dicatat lewat kolom `voided`,
-- bukan total negatif).
alter table public.sales
  add constraint sales_subtotal_nonnegative check (subtotal >= 0),
  add constraint sales_total_nonnegative check (total >= 0),
  add constraint sales_tendered_nonnegative check (tendered is null or tendered >= 0),
  add constraint sales_change_nonnegative check (change is null or change >= 0);

-- ---- hold_orders --------------------------------------------------------
alter table public.hold_orders
  add constraint hold_orders_total_nonnegative check (total >= 0);

-- ---- preorders --------------------------------------------------------
-- CATATAN: `remaining_balance` SENGAJA TIDAK diberi CHECK >= 0 di sini.
-- preorder.service.ts menghitung `remainingBalance = total - downPayment`
-- tanpa clamp — kalau ada skenario DP lebih besar dari total (koreksi
-- manual, dsb) nilainya bisa negatif secara sah di aplikasi saat ini.
-- Memaksakan >= 0 di DB berisiko menolak insert/update yang valid di app
-- — lihat "Suggestion" terkait di laporan audit.
alter table public.preorders
  add constraint preorders_total_nonnegative check (total >= 0),
  add constraint preorders_down_payment_nonnegative check (down_payment is null or down_payment >= 0);

-- ---- preorder_cancel_requests --------------------------------------------------------
alter table public.preorder_cancel_requests
  add constraint preorder_cancel_requests_dp_nonnegative check (down_payment_at_request >= 0);

-- ---- production_need_additions --------------------------------------------------------
alter table public.production_need_additions
  add constraint production_need_additions_qty_positive check (qty > 0);

-- ---- marketplace_settlements --------------------------------------------------------
alter table public.marketplace_settlements
  add constraint marketplace_settlements_order_count_nonnegative check (order_count >= 0),
  add constraint marketplace_settlements_gross_sales_nonnegative check (gross_sales >= 0),
  add constraint marketplace_settlements_fee_nonnegative check (marketplace_fee >= 0),
  add constraint marketplace_settlements_net_received_nonnegative check (net_received >= 0);

-- ---- sales_targets --------------------------------------------------------
alter table public.sales_targets
  add constraint sales_targets_target_nonnegative check (target >= 0);

-- ---- recipes / production_runs / finishing_validations ------------------
alter table public.recipes
  add constraint recipes_output_quantity_positive check (output_quantity > 0),
  add constraint recipes_yield_pct_nonnegative check (estimated_yield_pct >= 0),
  add constraint recipes_net_weight_nonnegative check (estimated_net_weight is null or estimated_net_weight >= 0);

alter table public.production_runs
  add constraint production_runs_batches_nonnegative check (batches >= 0),
  add constraint production_runs_produced_qty_nonnegative check (produced_quantity >= 0),
  add constraint production_runs_rejected_qty_nonnegative check (rejected_quantity is null or rejected_quantity >= 0),
  add constraint production_runs_loss_qty_nonnegative check (loss_quantity is null or loss_quantity >= 0),
  add constraint production_runs_actual_weight_nonnegative check (actual_weight is null or actual_weight >= 0),
  add constraint production_runs_actual_batches_nonnegative check (actual_batches is null or actual_batches >= 0),
  add constraint production_runs_waste_qty_nonnegative check (waste_quantity is null or waste_quantity >= 0);

alter table public.finishing_validations
  add constraint finishing_validations_validated_qty_nonnegative check (validated_qty >= 0),
  add constraint finishing_validations_rejected_qty_nonnegative check (rejected_qty >= 0);

-- ---- shifts --------------------------------------------------------
-- Kolom kas & rekap penjualan per shift: tidak ada jalur bisnis yang sah
-- menghasilkan nilai negatif (selisih kas dicatat via
-- `cash_difference_reason` bertipe text, bukan kolom numerik bertanda).
alter table public.shifts
  add constraint shifts_opening_cash_nonnegative check (opening_cash >= 0),
  add constraint shifts_closing_cash_nonnegative check (closing_cash is null or closing_cash >= 0),
  add constraint shifts_expected_cash_nonnegative check (expected_cash is null or expected_cash >= 0),
  add constraint shifts_total_orders_nonnegative check (total_orders is null or total_orders >= 0),
  add constraint shifts_total_revenue_nonnegative check (total_revenue is null or total_revenue >= 0),
  add constraint shifts_cash_sales_nonnegative check (cash_sales is null or cash_sales >= 0),
  add constraint shifts_qris_sales_nonnegative check (qris_sales is null or qris_sales >= 0),
  add constraint shifts_transfer_sales_nonnegative check (transfer_sales is null or transfer_sales >= 0),
  add constraint shifts_marketplace_sales_nonnegative check (marketplace_sales is null or marketplace_sales >= 0),
  add constraint shifts_total_opex_nonnegative check (total_operational_expense is null or total_operational_expense >= 0),
  add constraint shifts_total_packaging_qty_nonnegative check (total_packaging_qty is null or total_packaging_qty >= 0);

-- ---- finance_* --------------------------------------------------------
alter table public.finance_expenses
  add constraint finance_expenses_amount_positive check (amount > 0);

alter table public.finance_debts
  add constraint finance_debts_principal_positive check (principal > 0);

alter table public.finance_debt_payments
  add constraint finance_debt_payments_amount_positive check (amount > 0);

alter table public.finance_fund_withdraws
  add constraint finance_fund_withdraws_amount_positive check (amount > 0);

alter table public.finance_budgets
  add constraint finance_budgets_monthly_amount_nonnegative check (monthly_amount >= 0);

-- ---- business_settings / daily_counters --------------------------------
alter table public.business_settings
  add constraint business_settings_sales_target_daily_nonnegative check (sales_target_daily >= 0);

alter table public.daily_counters
  add constraint daily_counters_value_nonnegative check (value >= 0);


-- ============================================================================
-- SECTION B — Index: relasi/FK yang belum terindeks
--
-- Semua kolom di bawah adalah target FK (dipakai untuk JOIN dan untuk
-- lookup saat ON DELETE SET NULL/RESTRICT dieksekusi) tapi belum punya
-- index eksplisit di migration asal.
-- ============================================================================

create index if not exists preorders_price_group_id_idx on public.preorders (price_group_id);
create index if not exists sales_price_group_id_idx on public.sales (price_group_id);
create index if not exists hold_orders_price_group_id_idx on public.hold_orders (price_group_id);
create index if not exists preorders_sale_id_idx on public.preorders (sale_id);
create index if not exists preorders_queue_id_idx on public.preorders (queue_id);
create index if not exists order_queue_preorder_id_idx on public.order_queue (preorder_id);
create index if not exists production_need_additions_product_id_idx on public.production_need_additions (product_id);


-- ============================================================================
-- SECTION C — Index: mendukung query laporan/pencarian yang paling sering
-- dipakai (sales report, queue, preorder, finance) — lihat item 3 & 7 di
-- laporan audit untuk penjelasan tiap pilihan.
-- ============================================================================

-- Laporan sales: mayoritas query "sales report" mengecualikan transaksi
-- voided dan diurutkan/difilter per tanggal. Partial index ini jauh lebih
-- kecil & lebih relevan dibanding full index di semua baris.
create index if not exists sales_active_created_at_idx
  on public.sales (created_at desc) where voided = false;

-- Kebalikannya: mencari transaksi yang di-void (audit/investigasi) —
-- juga partial, karena voided=true diperkirakan minoritas baris.
create index if not exists sales_voided_created_at_idx
  on public.sales (created_at desc) where voided = true;

-- Queue: list per status diurutkan created_at (dashboard antrean).
create index if not exists order_queue_status_created_at_idx
  on public.order_queue (status, created_at desc);

-- Preorder: dashboard "preorder yang perlu diproses hari ini" biasanya
-- filter status + tanggal sekaligus.
create index if not exists preorders_status_date_idx
  on public.preorders (status, date);

-- Finance: laporan pengeluaran per pot dalam rentang tanggal.
create index if not exists finance_expenses_pot_at_idx
  on public.finance_expenses (pot, at desc);

-- Pencarian customer (lihat catatan di schema-mapping.md — tidak ada
-- tabel `customers` tersendiri; nama & telepon disimpan langsung di
-- sales/preorders). pg_trgm dipakai supaya pencarian nama customer bisa
-- pakai ILIKE '%teks%' (substring, bukan cuma prefix) secara efisien.
create extension if not exists pg_trgm;

create index if not exists sales_customer_name_trgm_idx
  on public.sales using gin (customer_name gin_trgm_ops)
  where customer_name is not null;
create index if not exists preorders_customer_name_trgm_idx
  on public.preorders using gin (customer_name gin_trgm_ops);

create index if not exists sales_customer_phone_idx
  on public.sales (customer_phone) where customer_phone is not null;
create index if not exists preorders_customer_phone_idx
  on public.preorders (customer_phone) where customer_phone is not null;


-- ============================================================================
-- SECTION D — Index yang dihapus (tidak berguna / digantikan index lain)
-- ============================================================================

-- `sales_voided_idx` (kolom boolean tunggal, mayoritas baris `false`) tidak
-- selektif dan jarang membantu planner. Digantikan oleh dua partial index
-- di atas (sales_active_created_at_idx / sales_voided_created_at_idx) yang
-- sekaligus sudah terurut sesuai pola query laporan yang sebenarnya dipakai
-- (selalu "per tanggal", bukan "cari voided" secara berdiri sendiri).
drop index if exists public.sales_voided_idx;

-- `finance_expenses_pot_idx` (kolom tunggal `pot`, kardinalitas rendah —
-- cuma 4 kemungkinan nilai: owner/development/operational/debt) digantikan
-- oleh composite `finance_expenses_pot_at_idx` di atas, yang mencakup semua
-- query yang sebelumnya memakai index ini (filter per pot) SEKALIGUS
-- mendukung urutan tanggal di dalamnya. `finance_expenses_at_idx` (index
-- tanggal berdiri sendiri, untuk laporan lintas-pot) TETAP dipertahankan
-- karena composite (pot, at) tidak bisa dipakai efisien untuk query yang
-- hanya filter/​order by `at` tanpa `pot`.
drop index if exists public.finance_expenses_pot_idx;

-- ============================================================================
-- END 20260717090000_db_audit_hardening.sql
-- ============================================================================
