-- ============================================================================
-- Migrasi Domain Sales — Tahap 3 (Order Queue)
--
-- Tambahan additive: kasir butuh DELETE ke `public.order_queue` supaya
-- `salesService.void()` bisa membersihkan entri queue saat pesanannya
-- sendiri di-refund. Policy generic `order_queue_delete_admin_only`
-- (dibuat dari loop di init migration) hanya mengizinkan admin — kalau
-- kasir yang men-trigger void, DELETE ke order_queue akan gagal RLS dan
-- rollback refund jadi tidak konsisten (Sale sudah voided tapi antrean
-- masih tampil di production).
--
-- Policy RLS bersifat OR (permissive) — menambahkan policy ini TIDAK
-- mengubah izin admin yang sudah ada, hanya menambah izin cashier.
-- Owner & production tetap dilarang DELETE dari tabel ini.
--
-- INSERT/UPDATE order_queue: TIDAK ada perubahan (sudah cukup di init
-- migration — admin/cashier bisa INSERT+UPDATE, production bisa UPDATE).
-- ============================================================================

create policy order_queue_delete_cashier on public.order_queue
  for delete to authenticated
  using (public.current_role() in ('admin','cashier'));
