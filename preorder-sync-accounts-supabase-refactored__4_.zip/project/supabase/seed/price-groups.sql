-- ============================================================================
-- price-groups.sql
--
-- Seed 5 Price Group default. Jalankan SEKALI lewat Supabase SQL Editor
-- (atau psql/service-role) setelah migration diterapkan.
--
-- KENAPA INI SQL TERPISAH, BUKAN SEED-ON-READ DI CLIENT (seperti versi
-- localStorage lama, price-group.service.ts → ensureSeed()):
-- RLS `price_groups_write_admin` hanya mengizinkan role admin melakukan
-- INSERT. Kasir/production yang membuka POS duluan (sebelum admin sempat
-- login sekalipun) TIDAK bisa memicu auto-seed lagi seperti dulu — RLS akan
-- menolak insert-nya. Karena itu seeding dipindah ke sini: dijalankan sekali
-- oleh admin/operator (lewat SQL Editor, kredensial service_role/postgres),
-- BUKAN oleh sembarang client di request pertama.
--
-- IDEMPOTENT lewat kondisi "hanya insert bila tabel masih kosong" — aman
-- dijalankan ulang tanpa membuat duplikat.
-- ============================================================================

insert into public.price_groups (name, sources, is_default)
select * from (values
  ('Outlet',      array['outlet','whatsapp']::text[], true),
  ('ShopeeFood',  array['shopeefood']::text[],         false),
  ('GoFood',      array['gofood']::text[],              false),
  ('GrabFood',    array['grabfood']::text[],            false),
  ('Reseller',    array['reseller']::text[],            false)
) as seed(name, sources, is_default)
where not exists (select 1 from public.price_groups);

-- ============================================================================
-- END price-groups.sql
-- ============================================================================
