-- ============================================================================
-- bootstrap-admin.sql
--
-- Bootstrap akun ADMIN PERTAMA untuk DeSalut Business OS.
--
-- PENTING — apa yang TIDAK dilakukan file ini:
--   - TIDAK membuat baris di auth.users.
--   - TIDAK menyimpan/menyentuh password sama sekali.
-- Postgres/SQL bukan tempat yang aman untuk membuat user Supabase Auth
-- (password harus lewat jalur ter-hash resmi Supabase, bukan lewat SQL
-- biasa) — karena itu pembuatan auth.users WAJIB dilakukan lebih dulu lewat
-- Supabase Dashboard atau Auth Admin API. Lihat langkah lengkap di
-- docs/auth-migration.md § "Bootstrap admin pertama".
--
-- Apa yang DILAKUKAN file ini:
--   Setelah baris auth.users untuk email di bawah ada (dan otomatis sudah
--   punya baris public.profiles berkat trigger on_auth_user_created —
--   lihat 20260716164012_..._profiles.sql), script ini memastikan profil
--   itu punya role='admin' dan full_name yang benar. Berguna karena kalau
--   admin dibuat TANPA menyertakan user_metadata.role='admin' saat create
--   user, trigger `handle_new_user()` akan default ke role='cashier' —
--   script ini yang mempromosikannya jadi admin.
--
-- IDEMPOTENT — aman dijalankan berkali-kali. Aman dijalankan lewat SQL
-- Editor di Supabase Dashboard, atau `supabase db execute` / psql dengan
-- kredensial yang punya akses ke skema public & auth (mis. service_role /
-- postgres) — bukan lewat client aplikasi dengan anon/authenticated key,
-- karena RLS `profiles_update_own` hanya izinkan user mengubah barisnya
-- sendiri (dan pengguna yang baru dibuat belum tentu sedang login saat
-- script ini dijalankan).
-- ============================================================================

do $$
declare
  target_email text := 'dariabang@desalut.id';
  target_full_name text := 'Daria Bang';
  target_user_id uuid;
begin
  select id into target_user_id
  from auth.users
  where email = target_email;

  if target_user_id is null then
    raise exception
      'Tidak ditemukan auth.users dengan email %. Buat user ini dulu lewat '
      'Supabase Dashboard (Authentication > Users > Add user) atau Auth '
      'Admin API sebelum menjalankan script ini — lihat docs/auth-migration.md.',
      target_email;
  end if;

  insert into public.profiles (id, full_name, role)
  values (target_user_id, target_full_name, 'admin')
  on conflict (id) do update
    set full_name = excluded.full_name,
        role = excluded.role,
        updated_at = now();

  raise notice 'profiles.% dipromosikan/diverifikasi sebagai admin (%).',
    target_user_id, target_email;
end $$;

-- ============================================================================
-- END bootstrap-admin.sql
-- ============================================================================
