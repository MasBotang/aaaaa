-- ============================================================================
-- products-and-inventory.sql
--
-- Seed katalog produk awal + item inventory awal. OPSIONAL — jalankan
-- SEKALI lewat Supabase SQL Editor (service_role/postgres) bila kamu ingin
-- data starter yang sama seperti versi localStorage lama (seed.ts →
-- seedProducts / seedInventory).
--
-- KENAPA SQL TERPISAH, BUKAN SEED-ON-BOOT DI CLIENT (seperti sebelumnya):
-- RLS `products_write_ins` mensyaratkan role admin untuk INSERT; RLS
-- `inventory_items_write_production_ins` mensyaratkan admin ATAU production.
-- Auto-seed lama di role-context.tsx berjalan untuk SIAPA SAJA yang login
-- (termasuk cashier/owner) — begitu login pertama sebagai cashier, RLS akan
-- menolak insert-nya. Karena itu seeding data referensi dipindah ke sini,
-- dijalankan sekali oleh operator dengan kredensial yang tepat. Lihat
-- src/services/seed.ts untuk catatan lengkap kenapa auto-seed di client
-- untuk domain ini dinonaktifkan pada migrasi ini.
--
-- `legacy_id` pada products diisi dari id localStorage lama (p1..p20) murni
-- untuk jejak/telusur — TIDAK dipakai sebagai primary key lagi (id sekarang
-- uuid, digenerate otomatis oleh DEFAULT gen_random_uuid()). inventory_items
-- tidak punya id localStorage yang stabil (di-generate dari timestamp saat
-- itu), jadi tidak ada legacy_id untuk baris-baris ini.
--
-- IDEMPOTENT lewat kondisi "hanya insert bila tabel masih kosong" — aman
-- dijalankan ulang tanpa duplikat, TAPI tidak akan menambah produk/item
-- baru yang kamu buat manual setelah seed pertama (itu memang behaviour
-- yang diinginkan — seed ini cuma untuk starting point kosong).
-- ============================================================================

-- ---- products ----------------------------------------------------------
insert into public.products
  (legacy_id, name, category, price, cost, stock, active, stock_source, image_url)
select * from (values
  ('p1', 'Original Mayo', 'Risol', 5000, 2000, 0, true, 'showcase', null),
  ('p2', 'Nori Spicy Mayo', 'Risol', 6000, 2500, 0, true, 'showcase', null),
  ('p3', 'Mayo Special', 'Risol', 6500, 2800, 0, true, 'showcase', null),
  ('p4', 'Ragout', 'Risol', 5500, 2300, 0, true, 'showcase', null),
  ('p5', 'Ayam Suwir Pedas', 'Risol', 5500, 2300, 0, true, 'showcase', null),
  ('p6', 'Choco Crunchy', 'Risol', 5000, 2000, 0, true, 'showcase', null),
  ('p7', 'Choco Cheese', 'Risol', 5500, 2200, 0, true, 'showcase', null),
  ('p8', 'Matcha', 'Risol', 5500, 2200, 0, true, 'showcase', null),
  ('p9', '1 Pack Original Mayo', 'Frozen', 45000, 20000, 0, true, 'freezer', null),
  ('p10', '1 Pack Nori Spicy Mayo', 'Frozen', 55000, 25000, 0, true, 'freezer', null),
  ('p11', '1 Pack Mayo Special', 'Frozen', 60000, 28000, 0, true, 'freezer', null),
  ('p12', '1 Pack Ragout', 'Frozen', 50000, 23000, 0, true, 'freezer', null),
  ('p13', '1 Pack Ayam Suwir', 'Frozen', 50000, 23000, 0, true, 'freezer', null),
  ('p14', '1 Pack Choco Crunchy', 'Frozen', 45000, 20000, 0, true, 'freezer', null),
  ('p15', '1 Pack Choco Cheese', 'Frozen', 50000, 22000, 0, true, 'freezer', null),
  ('p16', '1 Pack Matcha', 'Frozen', 50000, 22000, 0, true, 'freezer', null),
  ('p17', 'Paket Asin', 'Paket', 55000, 25000, 0, true, 'showcase', null),
  ('p18', 'Paket Manis', 'Paket', 50000, 22000, 0, true, 'showcase', null),
  ('p19', 'Paket Creamy Pedas', 'Paket', 60000, 28000, 0, true, 'showcase', null),
  ('p20', 'Paket Spesial Manis', 'Paket', 55000, 24000, 0, true, 'showcase', null)
) as seed(legacy_id, name, category, price, cost, stock, active, stock_source, image_url)
where not exists (select 1 from public.products);

-- ---- inventory_items ----------------------------------------------------
insert into public.inventory_items
  (name, category, unit, stock, min_stock, purchase_price, purchase_quantity, cost_per_unit, active)
select * from (values
  ('Air Mineral', 'operational', 'botol', 40, 20, 5000, 1, 5000.0, true),
  ('Gas LPG 3kg', 'operational', 'tabung', 6, 3, 20000, 1, 20000.0, true),
  ('Sabun Cuci', 'operational', 'pcs', 10, 3, 18000, 1, 18000.0, true),
  ('Sabun Tangan', 'operational', 'pcs', 5, 2, 15000, 1, 15000.0, true),
  ('Tisu', 'operational', 'pack', 20, 5, 12000, 1, 12000.0, true),
  ('Lakban', 'operational', 'roll', 10, 3, 15000, 1, 15000.0, true),
  ('Spidol', 'operational', 'pcs', 5, 2, 8000, 1, 8000.0, true),
  ('Masker', 'operational', 'box', 5, 1, 25000, 1, 25000.0, true),
  ('Sarung Tangan', 'operational', 'box', 5, 1, 30000, 1, 30000.0, true),
  ('Kantong Sampah', 'operational', 'pack', 8, 2, 18000, 1, 18000.0, true),
  ('Launch Box Xtra Kecil (Isi 2)', 'packaging', 'pcs', 200, 50, 800, 1, 800.0, true),
  ('Launch Box Kecil (Isi 3)', 'packaging', 'pcs', 200, 50, 1000, 1, 1000.0, true),
  ('Launch Box Sedang (Isi 4-5)', 'packaging', 'pcs', 200, 50, 1200, 1, 1200.0, true),
  ('Launch Box Sedang Xtra (Isi 6-8)', 'packaging', 'pcs', 200, 50, 1500, 1, 1500.0, true),
  ('Plastik Non PE Kecil', 'packaging', 'pcs', 300, 100, 200, 1, 200.0, true),
  ('Plastik Non PE Sedang', 'packaging', 'pcs', 300, 100, 300, 1, 300.0, true),
  ('Plastik Non PE Besar', 'packaging', 'pcs', 300, 100, 400, 1, 400.0, true),
  ('Plastik PE Kecil', 'packaging', 'pcs', 300, 100, 250, 1, 250.0, true),
  ('Plastik PE Sedang', 'packaging', 'pcs', 300, 100, 350, 1, 350.0, true),
  ('Plastik PE Besar', 'packaging', 'pcs', 300, 100, 500, 1, 500.0, true),
  ('Bawang Merah', 'raw', 'kg', 3, 1, 70000, 1, 70000.0, true),
  ('Bawang Putih', 'raw', 'kg', 3, 1, 70000, 1, 70000.0, true),
  ('Cabai Kriting', 'raw', 'kg', 2, 1, 70000, 1, 70000.0, true),
  ('Cabai Rawit', 'raw', 'kg', 2, 1, 70000, 1, 70000.0, true),
  ('Carnation 2kg', 'raw', 'kg', 8, 4, 477100, 8, 59637.5, true),
  ('Choco Crunchy 1kg', 'raw', 'kg', 6, 3, 611000, 12, 50916.67, true),
  ('Cidea Crabstick 1kg', 'raw', 'kg', 6, 3, 573900, 12, 47825.0, true),
  ('Dada Fillet', 'raw', 'kg', 5, 2, 55000, 1, 55000.0, true),
  ('Daun Salam & Jeruk', 'raw', 'ikat', 3, 1, 2000, 1, 2000.0, true),
  ('Delmonte Cabe 1kg', 'raw', 'kg', 5, 2, 220000, 10, 22000.0, true),
  ('Garam', 'raw', 'pcs', 3, 1, 6000, 1, 6000.0, true),
  ('Greentea Crunchy 1kg', 'raw', 'kg', 6, 3, 680000, 12, 56666.67, true),
  ('Gula', 'raw', 'kg', 5, 2, 20000, 1, 20000.0, true),
  ('Jagung', 'raw', 'kg', 3, 1, 12000, 1, 12000.0, true),
  ('Kentang', 'raw', 'kg', 5, 2, 18000, 1, 18000.0, true),
  ('Kewpie 1kg', 'raw', 'kg', 4, 2, 395000, 6, 65833.33, true),
  ('Ladaku', 'raw', 'sachet', 24, 12, 11500, 12, 958.33, true),
  ('Mamayo 1kg', 'raw', 'kg', 6, 3, 255000, 12, 21250.0, true),
  ('Mentega', 'raw', 'gram', 1000, 400, 5000, 200, 25.0, true),
  ('Minyak 1 KG Tropical', 'raw', 'liter', 10, 4, 20000, 1, 20000.0, true),
  ('Minyak Adonan Risol', 'raw', 'liter', 5, 2, 20000, 1, 20000.0, true),
  ('Nori MamaSuka', 'raw', 'pcs', 10, 4, 13800, 1, 13800.0, true),
  ('Panir Pita 10kg', 'raw', 'kg', 10, 5, 133000, 10, 13300.0, true),
  ('Prochiz Gold Cheddar 2kg', 'raw', 'kg', 4, 2, 815000, 8, 101875.0, true),
  ('Prochiz Quick Melt Slice', 'raw', 'pcs', 48, 24, 500000, 48, 10416.67, true),
  ('Rice Crispy 1kg', 'raw', 'kg', 3, 1, 50000, 1, 50000.0, true),
  ('Slice Beef 1kg', 'raw', 'kg', 5, 2, 950000, 10, 95000.0, true),
  ('Susu UHT Diamond', 'raw', 'kg', 10, 5, 190000, 10, 19000.0, true),
  ('Telur', 'raw', 'kg', 5, 2, 28000, 1, 28000.0, true),
  ('Tepung Tapioka Gunung', 'raw', 'pcs', 10, 5, 105000, 20, 5250.0, true),
  ('Tepung Terigu', 'raw', 'kg', 25, 10, 213000, 25, 8520.0, true),
  ('Totole Kaldu Jamur', 'raw', 'gram', 800, 400, 51000, 400, 127.5, true),
  ('Wortel', 'raw', 'kg', 4, 2, 15000, 1, 15000.0, true)) as seed(name, category, unit, stock, min_stock, purchase_price, purchase_quantity, cost_per_unit, active)
where not exists (select 1 from public.inventory_items);

-- ============================================================================
-- END products-and-inventory.sql
-- ============================================================================
