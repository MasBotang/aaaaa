# Auth Migration — localStorage → Supabase Auth

Scope tahap ini: **HANYA** Login, Logout, Session, `AuthContext`, Role,
Profile, dan Bootstrap akun pertama. Modul lain (Sales, Queue, PreOrder,
Shift, Refund, Product, Inventory, Recipe, Settings, Finance, Analytics)
**tidak disentuh**.

---

## 1. Audit — kondisi sebelum tahap ini

File yang diperiksa: `src/lib/role-context.tsx`, `src/lib/accounts.functions.ts`,
`src/lib/permissions.ts`, `src/services/types.ts`, plus seluruh pemanggil
`useAuth()` / `useRole()`.

### Temuan kunci

**`src/lib/role-context.tsx` SUDAH memakai Supabase Auth sepenuhnya** —
bukan hasil migrasi tahap ini, tapi kondisi awal yang sudah ada di project
saat prompt ini diterima (diverifikasi lewat diff terhadap arsip asli:
`src/` byte-for-byte identik dengan sebelum audit database di Prompt 0, dan
`role-context.tsx` di dalamnya sudah memanggil `supabase.auth.*`, bukan
`accounts.functions.ts`). Konkretnya, sebelum tahap ini:

- `signIn()` → `supabase.auth.signInWithPassword({ email, password })`.
- `signOut()` → `supabase.auth.signOut()`.
- Restore session saat reload → `supabase.auth.getSession()`.
- Sinkronisasi state → `supabase.auth.onAuthStateChange()` (menangani
  `SIGNED_IN`, `SIGNED_OUT`, `USER_UPDATED`, `TOKEN_REFRESHED`).
- Setelah dapat `User` dari Supabase, `loadProfile()` mengambil `full_name`
  dan `role` dari tabel `public.profiles` (`select id, full_name, role
  from profiles where id = auth.uid()`, dibatasi RLS `profiles_select_own`).
- Tidak ada pembacaan `localStorage`/`desalut_session` sama sekali di file
  ini. Grep `desalut_session` di seluruh `src/` = 0 hasil.
- `role-context.tsx` **tidak mengimpor** `accounts.functions.ts` sama
  sekali.

Jadi requirement inti Prompt 1 (§4, §5, §6.pertama, §7.role-context tidak
memanggil accounts.functions) **sudah terpenuhi sebelum tahap ini dimulai**.

### Yang MASIH bermasalah (dan diperbaiki di tahap ini)

**`src/routes/auth.tsx`** (halaman login) berisi panel "Buat Admin
Pertama" yang self-service: form ini memanggil `bootstrapAdmin()` /
`adminExists()` dari `accounts.functions.ts` — yaitu store **localStorage
lama** (`desalut:v1:accounts`) yang **sudah sama sekali tidak terhubung**
ke Supabase Auth. Efeknya: seorang admin baru yang dibuat lewat form ini
akan mendapat toast sukses ("Admin dibuat. Silakan masuk."), tapi
`signIn()` — yang memanggil `supabase.auth.signInWithPassword` — **tidak
akan pernah berhasil** untuk akun tersebut, karena tidak ada baris
`auth.users`/`profiles` yang terbentuk. Ini adalah:

1. **Self-registration UI** yang eksplisit dilarang di §8 prompt ini.
2. **Bug nyata** peninggalan migrasi sebagian (role-context.tsx sudah
   pindah ke Supabase, tapi panel bootstrap di halaman yang sama masih
   menulis ke sistem lama) — form ini memberi *false sense of success*.

**Perbaikan**: panel diganti jadi pesan statis "Akun baru dibuat oleh
Admin melalui menu Pengaturan → Manajemen Akun" (satu-satunya cabang yang
sebelumnya sudah ada untuk kasus "admin sudah ada" — sekarang jadi
satu-satunya tampilan, karena self-service bootstrap tidak lagi
ditawarkan). Detail lihat §4 di bawah dan diff di §7.

### Ringkasan: bagaimana login/session/role bekerja sekarang

```
User buka /auth
  → RoleProvider (root) sudah jalan duluan: getSession() + onAuthStateChange()
  → isi email/password → signIn(email, password)
      → supabase.auth.signInWithPassword()
      → sukses → onAuthStateChange('SIGNED_IN', session) trigger otomatis
      → applySession(session) → loadProfile(user) → profiles.select(id, full_name, role)
      → AuthContext.{user, session, profile, role} ter-update
  → auth.tsx punya efek: begitu {hydrated, user, role} lengkap → redirect ke ROLE_LANDING[role]
```

Reload browser: `getSession()` membaca token dari penyimpanan internal
Supabase SDK (localStorage, dikelola SDK sendiri — bukan dibaca manual
oleh kode aplikasi), lalu `applySession()` dipanggil sama seperti alur
login normal.

### File yang terdampak tahap ini

| File | Status |
|---|---|
| `src/lib/role-context.tsx` | Sudah sesuai target — **tidak diubah** |
| `src/lib/permissions.ts` | Sudah sesuai target (hanya konsumsi `useRole()`) — **tidak diubah** |
| `src/lib/accounts.functions.ts` | Dipertahankan sesuai instruksi (rollback sementara) — **tidak diubah** |
| `src/routes/auth.tsx` | **Diubah** — hapus form self-registration bootstrap admin, ganti pesan statis (lihat §1 di atas) |
| `src/lib/supabase-client.ts` + `src/integrations/supabase/client.ts` | Sudah ada & sudah pakai env var (`VITE_SUPABASE_URL` / `VITE_SUPABASE_PUBLISHABLE_KEY`), tidak hardcode — **tidak diubah** |
| `supabase/migrations/20260716164012_..._profiles.sql` | Tabel `profiles` + trigger sudah sesuai kebutuhan — **tidak diubah** |
| `supabase/seed/bootstrap-admin.sql` | **Baru** — lihat §5 |
| `docs/auth-migration.md` | **Baru** — dokumen ini |

### Catatan di luar scope (sengaja tidak disentuh)

- `src/features/accounts/accounts-page.tsx` ("Pengaturan → Manajemen
  Akun") **masih memakai `accounts.functions.ts` sepenuhnya** (CRUD akun
  di localStorage) — sekarang berjalan **paralel dan tidak sinkron**
  dengan sistem Supabase Auth yang sesungguhnya menentukan siapa yang bisa
  login. Ini adalah gap produk yang nyata, tapi **domain "Account
  Management CRUD" tidak ada di scope Prompt 1** (scope hanya Login/
  Logout/Session/AuthContext/Role/Profile/Bootstrap). Migrasi halaman ini
  ke Supabase (CRUD `profiles` + Auth Admin API untuk buat/nonaktifkan
  user) adalah kandidat tahap berikutnya — **tidak dikerjakan sekarang**,
  menunggu konfirmasi eksplisit sesuai instruksi "Setelah tahap ini
  selesai, BERHENTI."
- `RoleProvider` (`role-context.tsx`) juga memanggil `seedIfEmpty()`,
  `seedInventoryIfEmpty()`, `seedRecipesIfEmpty()` di `useEffect`-nya —
  ini seeding data Product/Inventory/Recipe (localStorage), tidak
  berhubungan dengan Auth sama sekali. Ini perilaku pre-existing yang
  berada di luar domain Product/Inventory/Recipe yang dilarang disentuh —
  **dibiarkan apa adanya**, tidak dipindah/dihapus, supaya tidak mengubah
  behaviour modul lain.
- `src/services/user.service.ts` (`StorageKeys.users`) — dead code
  peninggalan (dipakai ≤1 tempat, oleh `seed.ts`, tidak berhubungan
  dengan auth aktual). Sudah dicatat sebagai temuan di
  `docs/storage-migration/schema-mapping.md` (Prompt 0). **Tidak
  disentuh** di sini karena bukan bagian dari alur login/session.

---

## 2. Arsitektur Auth Baru

```
┌──────────────────┐      ┌─────────────────────┐      ┌────────────────────┐
│   auth.users      │ 1:1  │   public.profiles    │      │   permissions.ts    │
│  (Supabase Auth)  │─────▶│  id, full_name, role  │      │  (source of truth   │
│  email + password  │      │  role: admin|owner|   │      │   capability, TIDAK │
│  (hashed, dikelola │      │  cashier|production   │      │   berubah)          │
│  Supabase)          │      └───────────┬───────────┘      └─────────┬──────────┘
└─────────┬──────────┘                  │ dibaca via                  │ dikonsumsi
          │ trigger on_auth_user_created│ profiles_select_own (RLS)   │ via useRole()
          ▼                              ▼                              │
   (baris profiles dibuat        role-context.tsx (RoleProvider)  ◀────┘
    otomatis, role default        - supabase.auth.signInWithPassword()
    'cashier' kalau tidak          - supabase.auth.signOut()
    di-set eksplisit saat          - supabase.auth.getSession()
    create user)                   - supabase.auth.onAuthStateChange()
                                    - AuthContextValue: role, user, session,
                                      profile, hydrated, signIn(), signOut()
                                            │
                                            ▼
                                  useAuth() / useRole()  ◀── TIDAK BERUBAH
                                  (dipakai di seluruh halaman & permissions.ts)
```

Kolom `role` di `profiles` memakai `CHECK (role IN ('admin','owner',
'cashier','production'))` — persis sama dengan union type `Role` di
`src/services/types.ts` (`"admin" | "owner" | "cashier" | "production"`).
Kedua sumber ini dijaga manual supaya tetap identik (tidak ada mekanisme
generate otomatis di project ini) — kalau `Role` di TypeScript berubah,
`CHECK` constraint di migration `profiles` harus diikutkan berubah di PR
yang sama.

---

## 3. Flow

### Login

1. User isi email + password di `/auth`, submit.
2. `signIn(email, password)` → `supabase.auth.signInWithPassword()`.
3. Gagal → `error.message` dilempar sebagai `Error`, ditangkap di
   `auth.tsx` → ditampilkan di banner error + toast. Tidak ada perubahan
   pada pesan error dari Supabase (apa adanya, seperti "Invalid login
   credentials").
4. Sukses → `applySession(data.session)` langsung dipanggil (tidak
   menunggu event `onAuthStateChange`, supaya UI update instan) → set
   `user`, `session`, lalu `loadProfile()` mengambil `role` & `full_name`
   dari `profiles`.
5. `auth.tsx` punya `useEffect` yang redirect begitu `{hydrated, user,
   role}` lengkap, ke `ROLE_LANDING[role]` (atau `?redirect=` kalau ada).

### Logout

1. `signOut()` → `supabase.auth.signOut()` (menghapus token di sisi
   Supabase & local session storage SDK).
2. State direset eksplisit (`user/session/profile/role` → `null`) di
   dalam `signOut()` itu sendiri — tidak menunggu event
   `onAuthStateChange('SIGNED_OUT')` supaya UI langsung ter-update tanpa
   delay, meskipun event itu tetap akan datang dan no-op karena state
   sudah kosong.

### Restore session (reload browser)

1. Saat `RoleProvider` mount: `supabase.auth.getSession()` dipanggil.
   Ini membaca access/refresh token dari penyimpanan internal Supabase JS
   SDK (dikonfigurasi ke `localStorage` di
   `src/integrations/supabase/client.ts`, **dikelola SDK**, bukan dibaca
   manual oleh kode aplikasi) dan me-refresh token bila perlu.
2. Kalau ada session valid → `applySession()` → profile & role di-load.
3. `hydrated` diset `true` di blok `finally`, apa pun hasilnya (ada
   session atau tidak) — dipakai halaman lain untuk tahu kapan aman
   memeriksa `user`/`role` (mencegah flash-redirect ke `/auth` sebelum
   status login benar-benar diketahui).

### Auth state sinkron otomatis

`supabase.auth.onAuthStateChange()` menangani event `SIGNED_IN`,
`SIGNED_OUT`, `USER_UPDATED`, `TOKEN_REFRESHED` — semuanya memanggil
`applySession()` yang sama dengan alur login manual, jadi:
- Refresh token otomatis oleh SDK → `TOKEN_REFRESHED` → context tetap
  sinkron (tidak perlu reload).
- Login dari tab/device lain dengan akun yang sama **tidak** saling
  memaksa logout satu sama lain — setiap tab/device menyimpan sesinya
  sendiri (perilaku standar Supabase Auth: token per klien, bukan
  single-session-per-user).
- Session expired / refresh token invalid → SDK memicu `SIGNED_OUT` →
  context otomatis kembali ke `user: null, role: null`, halaman yang
  butuh auth akan redirect ke `/auth` (via cek `hydrated && !user` di
  route guard masing-masing halaman, tidak diubah di tahap ini).

Guard `activeUserId` (`useRef`) mencegah race condition kalau
`applySession` untuk user lama masih pending ketika user baru sudah
login (mis. logout cepat lalu login akun lain) — hasil `loadProfile()`
yang basi diabaikan kalau `activeUserId.current` sudah berubah.

---

## 4. Backward Compatibility

`AuthContextValue` **tidak berubah sama sekali** dari kondisi sebelum
tahap ini:

```ts
interface AuthContextValue {
  role: Role | null;
  user: LocalUser | null;        // { id, email }
  session: { userId: string } | null;
  profile: Profile | null;        // { id, full_name, email }
  hydrated: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}
```

`useAuth()` (alias `useRole()`), `ROLE_LABELS`, `ROLE_DESCRIPTIONS` — semua
export dari `role-context.tsx` tidak berubah nama, shape, maupun perilaku.
`permissions.ts` tidak disentuh sama sekali (hanya mengonsumsi `role` dari
`useRole()`, tidak tahu-menahu soal Supabase). Akibatnya seluruh halaman
pemanggil (`app-shell.tsx`, `app-sidebar.tsx`, `access-denied.tsx`,
`shifts-page.tsx`, `home-page.tsx`, `preorder-page.tsx`, `pesanan-page.tsx`,
`settings-page.tsx`, `pos-page.tsx`, `_app.finance.tsx`, `index.tsx`, dan
`auth.tsx` sendiri) **tetap compile tanpa perubahan** — sudah diverifikasi
lewat grep, tidak ada satu pun dari file-file ini yang disentuh di tahap
ini.

Satu-satunya perubahan kode adalah di dalam `auth.tsx` (self-registration
panel → pesan statis) — perubahan ini **tidak menyentuh** shape
`AuthContextValue`, tidak menambah/menghapus property, dan tidak mengubah
perilaku `signIn`/`signOut`/`useRole`.

---

## 5. Bootstrap Akun Administrator Pertama

Aplikasi ini **tidak punya fitur Register**, dan tahap ini **sengaja
tidak membuatnya** (tidak ada halaman Register, endpoint Register, atau
self-registration di UI — panel yang sebelumnya ada di `/auth` sudah
diganti pesan statis, lihat §1).

### Langkah bootstrap admin pertama

**Step 1 — Buat user di Supabase Auth** (password dibuat di sini, TIDAK
pernah di source code/migration/seed):

**Opsi A — Supabase Dashboard** (paling mudah untuk sekali pakai):
1. Buka **Authentication → Users → Add user → Create new user**.
2. Email: `dariabang@desalut.id`.
3. Set password (checklist "Auto Confirm User" supaya tidak perlu alur
   verifikasi email).
4. (Opsional tapi disarankan) Isi **User Metadata**:
   ```json
   { "role": "admin", "full_name": "Daria Bang" }
   ```
   Kalau field ini diisi saat create user, trigger `handle_new_user()`
   (sudah ada dari migration `profiles`) otomatis membuat baris
   `profiles` dengan `role='admin'` — **Step 2 di bawah jadi opsional**
   (tinggal untuk verifikasi).

**Opsi B — Supabase Auth Admin API** (untuk automation/CI), pakai
`service_role` key (server-side saja, JANGAN pernah expose ke client):
```ts
// dijalankan di server/CI, BUKAN di kode aplikasi client
const { data, error } = await supabaseAdmin.auth.admin.createUser({
  email: "dariabang@desalut.id",
  password: process.env.BOOTSTRAP_ADMIN_PASSWORD, // dari secret manager, bukan hardcode
  email_confirm: true,
  user_metadata: { role: "admin", full_name: "Daria Bang" },
});
```

**Step 2 — Pastikan profile ter-promote jadi admin**

Jalankan `supabase/seed/bootstrap-admin.sql` lewat SQL Editor di Supabase
Dashboard (atau `psql`/`supabase db execute` dengan kredensial
service_role/postgres). Script ini:
- Mencari `auth.users` dengan email `dariabang@desalut.id`.
- Meng-upsert baris `profiles` terkait supaya `role='admin'` dan
  `full_name='Daria Bang'` — idempotent, aman dijalankan berkali-kali,
  dan berguna terutama kalau Step 1 dilakukan **tanpa** mengisi
  `user_metadata` (trigger akan default ke `role='cashier'`, script ini
  yang mempromosikannya).
- **Tidak pernah menyentuh password** — kalau `auth.users` untuk email
  tersebut belum ada, script akan gagal dengan pesan error yang jelas
  (`RAISE EXCEPTION`), bukan diam-diam membuat user baru.

**Step 3 — Login**

Masuk ke `/auth` dengan email + password yang dibuat di Step 1.

### Akun berikutnya (bukan admin pertama)

Setelah admin pertama ada dan bisa login, pembuatan akun selanjutnya
untuk staf lain **di luar scope tahap ini** — saat ini masih lewat
`Pengaturan → Manajemen Akun` yang berjalan di sistem lama
(`accounts.functions.ts`, localStorage, **belum** terhubung ke Supabase
Auth). Migrasi halaman itu adalah kandidat tahap berikutnya (lihat
catatan "di luar scope" di §1).

---

## 6. RLS — audit & keputusan

Diperiksa: apakah policy `profiles` yang sudah ada (dari migration
`20260716164012_..._profiles.sql`) cukup untuk flow login/profile-load di
atas.

```sql
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (auth.uid() = id);

create policy "profiles_update_own" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
```

`role-context.tsx` hanya pernah melakukan **satu** query ke `profiles`:
`select id, full_name, role from profiles where id = <user yang sedang
login>` — persis dicakup `profiles_select_own`. Insert baris `profiles`
baru terjadi lewat trigger `handle_new_user()` yang `SECURITY DEFINER`
(bypass RLS by design, sudah ada dari migration sebelumnya).

**Keputusan: tidak ada migration RLS baru yang ditambahkan di tahap ini.**
Policy yang sudah ada sudah cukup untuk seluruh flow Login/Logout/Session/
Profile di scope ini. Menambah policy baru (mis. "authenticated boleh
lihat semua profiles") tidak diperlukan oleh flow saat ini dan berisiko
memperluas exposure data tanpa kebutuhan nyata — kalau nanti halaman
Account Management dimigrasikan ke Supabase (di luar scope tahap ini) dan
butuh admin bisa melihat semua `profiles`, itu keputusan RLS yang
sebaiknya dibuat bersamaan dengan migrasi halaman tersebut, bukan
diantisipasi sekarang.

---

## 7. Ringkasan Perubahan Kode

| File | Perubahan |
|---|---|
| `src/routes/auth.tsx` | Hapus import `adminExists`, `bootstrapAdmin` dari `accounts.functions.ts`. `BootstrapAdminPanel` disederhanakan jadi komponen statis (tanpa state/effect/form) yang selalu menampilkan pesan "akun baru dibuat oleh Admin lewat Pengaturan → Manajemen Akun" — menghilangkan form self-registration yang sebelumnya menulis ke store lama yang tidak lagi terhubung ke Supabase Auth. |
| `supabase/seed/bootstrap-admin.sql` | **Baru.** Script idempotent untuk mempromosikan profile admin pertama setelah `auth.users`-nya dibuat lewat Dashboard/Admin API. Tidak menyentuh password. |
| `docs/auth-migration.md` | **Baru.** Dokumen ini. |

Tidak ada file lain yang diubah. `src/lib/role-context.tsx`,
`src/lib/permissions.ts`, `src/lib/accounts.functions.ts`,
`src/lib/supabase-client.ts`, `src/integrations/supabase/*`, dan seluruh
migration di `supabase/migrations/` **tidak disentuh** di tahap ini.

---

## 8. Acceptance Test — checklist

| # | Skenario | Hasil |
|---|---|---|
| 1 | Login berhasil | ✅ `signIn()` → `supabase.auth.signInWithPassword()`, tidak berubah dari kondisi awal |
| 2 | Logout berhasil | ✅ `signOut()` → `supabase.auth.signOut()` + reset state eksplisit, tidak berubah |
| 3 | Browser reload tetap login | ✅ `getSession()` di mount `RoleProvider`, tidak berubah |
| 4 | Refresh token tetap bekerja | ✅ `autoRefreshToken: true` di `src/integrations/supabase/client.ts` (sudah ada) + event `TOKEN_REFRESHED` ditangani di `onAuthStateChange`, tidak berubah |
| 5 | Session restore berhasil | ✅ Sama seperti #3 — `applySession(data.session)` dari `getSession()` |
| 6 | Dua browser/device bisa login akun yang sama | ✅ Perilaku default Supabase Auth (token per klien, tidak ada single-session enforcement) — tidak ada kode di project ini yang membatasinya |
| 7 | Role tetap sesuai profile | ✅ `loadProfile()` selalu baca ulang dari `profiles` tiap `applySession()` |
| 8 | Permission tetap sama seperti sebelum migrasi | ✅ `permissions.ts` tidak diubah sama sekali |
| 9 | Tidak ada lagi pembacaan `localStorage`/`desalut_session` untuk auth | ✅ Diverifikasi via grep — 0 hasil untuk `desalut_session` di seluruh `src/`; satu-satunya pemakaian `localStorage` yang tersisa terkait auth adalah internal Supabase JS SDK sendiri (dikonfigurasi, bukan dibaca manual oleh kode aplikasi) |
| 10 | `role-context.tsx` tidak lagi memanggil `accounts.functions.ts` | ✅ Diverifikasi via grep — 0 import `accounts.functions` di `role-context.tsx` |
| 11 | Tidak ada perubahan behaviour UI | ⚠️ **Satu pengecualian yang disengaja**: panel bootstrap admin di `/auth` diubah dari form aktif (tapi rusak/menyesatkan) menjadi pesan statis. Ini bukan regresi — form lama tidak pernah benar-benar berfungsi untuk membuat akun yang bisa login (lihat §1). Semua UI lain tidak berubah. |
| 12 | Seluruh project tetap compile | ✅ `AuthContextValue`, `useAuth`, `useRole`, `permissions.ts` tidak berubah; `auth.tsx` tetap valid TypeScript (import yang tidak dipakai lagi sudah dihapus, tidak ada referensi menggantung ke `adminExists`/`bootstrapAdmin`) |

### Definition of Done — lintas cek

- ✅ Tidak ada lagi penggunaan `localStorage` untuk session/login di kode
  aplikasi (SDK Supabase mengelola token-nya sendiri secara internal).
- ✅ `role-context.tsx` hanya menggunakan Supabase Auth.
- ✅ `permissions.ts` tidak mengalami perubahan behaviour (file tidak
  disentuh).
- ✅ Semua halaman pemakai `useAuth()`/`useRole()` tetap compile tanpa
  perubahan (tidak ada satu pun yang disentuh di tahap ini).
- ✅ Tidak ada perubahan pada domain selain Authentication (`auth.tsx`
  adalah satu-satunya file domain Auth yang diubah; `accounts-page.tsx`
  dan modul lain tidak disentuh).
- ⏳ Migration SQL berhasil dijalankan pada database kosong — **perlu
  dijalankan & diverifikasi manual oleh kamu** di Supabase project yang
  sesungguhnya (semua migration di `supabase/migrations/` dari Prompt 0 +
  0.1 belum pernah di-apply ke project manapun, sesuai catatan di
  `schema-mapping.md`). Tidak ada migration SQL baru di tahap ini —
  `profiles` sudah cukup.
- ⏳ Bootstrap akun administrator pertama — **perlu dieksekusi manual**
  mengikuti §5 di atas (butuh akses ke Supabase Dashboard/Admin API,
  tidak bisa dilakukan dari repository).
- ✅ Dokumentasi `auth-migration.md` lengkap dan sesuai implementasi
  (dokumen ini).

---

**Tahap ini berhenti di sini.** Migrasi domain lain (Product, Inventory,
Sales, Account Management, dst.) menunggu pengujian manual & konfirmasi
eksplisit sesuai instruksi.
