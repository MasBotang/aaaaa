# Audit Database — Senior DB Architect Review

Scope: `supabase/migrations/` + `docs/storage-migration/`.
Tidak ada perubahan di `src/`, tidak ada perubahan behaviour aplikasi, dan
**tidak ada migration lama yang diedit** — semua improvement ada di migration
baru: `supabase/migrations/20260717090000_db_audit_hardening.sql`.

Legend severity:
- **Critical** — celah integritas data nyata, sebaiknya ditutup sebelum apply ke production.
- **Major** — desain punya risiko/inkonsistensi, layak ditangani tapi tidak mendesak.
- **Minor** — perbaikan kecil, dampak terbatas.
- **Suggestion** — untuk dipertimbangkan, sengaja TIDAK diimplementasikan sekarang (butuh keputusan bisnis, atau risikonya belum sepadan dengan manfaatnya).

---

## 1. Audit Relasi (FK)

Semua FK di `20260717080000_sales_pos_init.sql` diperiksa satu per satu
(arah, nullability, `ON DELETE`).

**Hasil: tidak ditemukan FK yang hilang atau `ON DELETE` yang salah.**
Pola yang dipakai sudah konsisten dan tepat secara semantik:

| Pola | Contoh | Kenapa tepat |
|---|---|---|
| `ON DELETE RESTRICT` | `stock_movements.item_id`, `refund_requests.sale_id`, `finance_debt_payments.debt_id`, `finishing_validations.product_id`, `production_need_additions.{preorder_id,product_id}`, `preorder_cancel_requests.preorder_id` | Semua ini baris **riwayat/audit finansial** — menghapus parent-nya tidak boleh diam-diam menghapus jejak riwayat. RESTRICT memaksa penanganan eksplisit (arsip/soft-delete) sebelum parent bisa dihapus. |
| `ON DELETE SET NULL` | `sales.shift_id/price_group_id/preorder_id`, `preorders.price_group_id/sale_id/queue_id`, `order_queue.preorder_id`, `production_runs.recipe_id`, `hold_orders.price_group_id` | Referensi "konteks tambahan", bukan bagian identitas baris. Menghapus parent-nya wajar membuat referensi jadi kosong, tidak perlu memblokir maupun ikut menghapus child. |
| Tanpa FK (disengaja & didokumentasikan) | `order_queue.sale_id`, `recipes.output_ref_id`, `production_runs.output_ref_id` | Lihat **Major #2** dan **Major #3** di bawah — sudah didokumentasikan dengan baik di komentar SQL asli, keputusannya tepat, hanya perlu sedikit penguatan dokumentasi (sudah dilakukan di `schema-mapping.md`). |

Tidak ada kolom yang seharusnya `NOT NULL` tapi dibuat nullable, atau
sebaliknya — pola nullable-nya konsisten dengan sifat data (mis. `closed_at`
pada `shifts` nullable karena shift yang masih berjalan memang belum punya
waktu tutup).

### Major #1 — `public.current_role()` berpotensi bentrok dengan keyword SQL `CURRENT_ROLE`

`CURRENT_ROLE` adalah keyword bawaan SQL standard (setara `CURRENT_USER`,
mengembalikan role sesi Postgres saat ini). Migration
`20260717080000_sales_pos_init.sql` membuat fungsi aplikasi dengan nama
persis sama: `public.current_role()`, dipakai di 30+ RLS policy.

Selama dipanggil **schema-qualified** (`public.current_role()`, seperti
semua pemakaian saat ini di RLS policy) tidak ada bug aktif. Risikonya
muncul di masa depan: developer yang menulis query/migration baru dan
memanggil `current_role` tanpa qualifier, mengira akan dapat role sesi
Postgres, bisa diam-diam mendapat hasil dari fungsi aplikasi ini (tanpa
error) kalau `public` ada lebih dulu di `search_path` — sumber bug yang
sulit dilacak karena tidak ada exception yang muncul.

**Tidak diperbaiki di migration baru ini** — rename butuh `DROP FUNCTION`
+ `CREATE OR REPLACE` ulang untuk 30+ RLS policy yang memakainya, yaitu
mengedit ulang isi migration yang sudah ada (dilarang oleh instruksi audit
ini) atau mengulang seluruh section RLS di migration baru (risiko migrasi
tidak sepadan untuk masalah yang saat ini masih laten). **Rekomendasi:**
saat migration RLS berikutnya memang perlu disentuh untuk alasan lain,
sekalian rename ke `public.current_app_role()`.

### Major #2 — Relasi `sales.preorder_id` ↔ `preorders.sale_id` bidirectional tanpa penjaga konsistensi

Dua FK independen menunjuk arah berlawanan untuk hubungan yang sama:
`sales.preorder_id → preorders.id` dan `preorders.sale_id → sales.id`.
Tidak ada constraint/trigger yang menjamin keduanya selalu konsisten
(mis. secara teori `sales.preorder_id = X` tapi `preorders(X).sale_id`
menunjuk ke sale lain, atau `NULL`).

Ini bukan bug — komentar di migration asli sudah menjelaskan alasan
teknisnya (dibuat di dua tahap karena `preorders` dibuat sebelum `sales`
untuk menghindari circular reference). Tapi desain "sumber kebenaran ganda"
begini rawan drift kalau kode aplikasi di masa depan hanya meng-update
salah satu sisi.

**Tidak diperbaiki di migration baru ini** — trigger sinkronisasi
otomatis termasuk over-engineering untuk masalah yang belum terbukti
terjadi (`preorders.status` sudah jadi source of truth alur bisnisnya).
**Rekomendasi:** kalau nanti ada laporan data preorder/sale yang "nyasar",
pertimbangkan trigger `AFTER UPDATE` kecil yang menjaga dua kolom ini tetap
sinkron, atau — lebih sederhana — jadikan hanya SATU sisi sumber kebenaran
dan hitung sisi lain via query/view.

### Major #3 — Kolom polymorphic reference tanpa FK (`recipes.output_ref_id`, `production_runs.output_ref_id`)

Kedua kolom ini bisa menunjuk ke `inventory_items.id` ATAU `products.id`
tergantung `output_target_type`, sehingga tidak bisa diberi FK tunggal.
Sudah didokumentasikan dengan baik di komentar SQL asli, termasuk alternatif
yang dipertimbangkan (dua kolom nullable + `CHECK` "exactly one").

**Tidak diperbaiki sekarang** — mengubah pola ini jadi dua kolom akan
mengubah bentuk tabel secara signifikan (bukan sekadar tambahan index/
constraint), dan alternatif itu sendiri sudah dicatat di komentar asli
sebagai opsional. **Suggestion untuk migration terpisah nanti:** dua kolom
nullable (`output_inventory_item_id`, `output_product_id`) + `CHECK
(num_nonnulls(output_inventory_item_id, output_product_id) = 1)` kalau
integritas referensial di level DB untuk kolom ini jadi prioritas.

---

## 2. Audit Normalisasi (JSONB)

Semua kolom JSONB di skema sudah diberi komentar rasional di SQL asli.
Ditinjau ulang satu per satu — kesimpulan: **desainnya sudah tepat, tidak
ada yang perlu dipecah sekarang.**

| Kolom | Tetap JSONB? | Alasan | Kandidat dipecah nanti? |
|---|---|---|---|
| `products.prices` | Ya | Shape sederhana (map id→angka), selalu dibaca/ditulis bersama produknya | Tidak — shape terlalu sederhana untuk butuh tabel sendiri |
| `sales.items`, `preorders.items`, `hold_orders.items` | Ya | Array-of-object, dibaca/ditulis sebagai satu unit per transaksi | **Ya, kandidat kuat** — kalau laporan "penjualan per produk" / "produk terlaris" makin sering dibutuhkan, normalisasi ke `sale_items` akan jauh lebih efisien daripada `jsonb_array_elements` di setiap query laporan. Belum genting karena belum ada bukti query semacam itu dipakai berat saat ini. |
| `sales.payment` | Ya | Split payment, array kecil (biasanya 1-3 elemen) | Tidak — volume kecil, query agregat per metode pembayaran masih murah lewat `jsonb_array_elements` sesekali |
| `shifts.operational_expenses`, `.packaging_usage`, `.marketplace_reconciliations`, `.payment_reconciliations` | Ya | Ditulis/dibaca sebagai snapshot 1x per shift (saat tutup shift) | Tidak — ini snapshot historis, bukan data operasional yang di-query granular |
| `order_queue.timeline` | Ya | Log kecil per baris queue, append-only sepanjang siklus hidup 1 order | Tidak |
| `recipes.ingredients` | Ya | Selalu dibaca/ditulis bersama resepnya, tiap resep punya <20 ingredient | Kandidat lemah — hanya kalau butuh "cari resep yang pakai bahan X" secara SQL-native |
| `production_runs.consumed` | Ya | Sama polanya dengan `recipes.ingredients` | Sama seperti di atas |
| `finance_settings.allocation`, `.opening_balance`, `business_settings.production` | Ya | Objek kecil, singleton, bentuk tetap (tidak berulang per baris) | Tidak — ini secara semantik lebih dekat ke "struct" daripada "banyak baris data" |

**Tidak ada perubahan di migration baru untuk section ini** sesuai instruksi
("JANGAN langsung memecah semuanya... hanya beri rekomendasi bila memang
layak"). Satu-satunya kandidat yang tercatat layak dipertimbangkan adalah
`sale_items`, dan itu pun disyaratkan bukti kebutuhan (laporan per-item)
lebih dulu.

---

## 3 & 7. Audit Index & Performance

### Ditambahkan (di `20260717090000_db_audit_hardening.sql`)

**Index FK yang belum ada** (dibutuhkan untuk performa JOIN dan untuk
lookup saat `ON DELETE SET NULL/RESTRICT` dieksekusi Postgres):
`preorders.price_group_id`, `sales.price_group_id`,
`hold_orders.price_group_id`, `preorders.sale_id`, `preorders.queue_id`,
`order_queue.preorder_id`, `production_need_additions.product_id`.

**Index laporan/pencarian** (langsung menjawab item 7 — sales, queue,
preorder, finance):
- `sales_active_created_at_idx` / `sales_voided_created_at_idx` — partial
  index, menggantikan `sales_voided_idx` yang lama (lihat bagian "Index
  dihapus" di bawah). Cocok dengan pola nyata: laporan sales HAMPIR SELALU
  filter per rentang tanggal + exclude voided.
- `order_queue_status_created_at_idx` — composite, untuk dashboard antrean
  per status terurut waktu (query yang sebelumnya butuh 2 index terpisah
  sekarang cukup 1 index).
- `preorders_status_date_idx` — composite, untuk "preorder due hari ini
  dengan status tertentu".
- `finance_expenses_pot_at_idx` — composite, untuk laporan pengeluaran per
  pot dalam rentang tanggal.
- `sales_customer_phone_idx`, `preorders_customer_phone_idx` — pencarian
  customer via nomor HP (exact/prefix match).
- `sales_customer_name_trgm_idx`, `preorders_customer_name_trgm_idx` (GIN,
  `pg_trgm`) — pencarian customer via nama (substring, bukan cuma prefix),
  karena `preorder-page.tsx` saat ini melakukan filter nama customer secara
  client-side; index ini menyiapkan jalan kalau pencarian dipindah ke
  server-side query.

### Dihapus

- `sales_voided_idx` — index boolean tunggal, mayoritas baris bernilai
  `false` sehingga selektivitasnya rendah dan jarang dipakai planner.
  Digantikan oleh dua partial index di atas yang sekaligus mengikuti pola
  query nyata (selalu "per tanggal").
- `finance_expenses_pot_idx` — kardinalitas rendah (4 kemungkinan nilai),
  fungsinya sudah tercakup penuh oleh composite `finance_expenses_pot_at_idx`.
  `finance_expenses_at_idx` (index tanggal berdiri sendiri) **tetap
  dipertahankan** untuk laporan lintas-pot.

### Dipertimbangkan tapi TIDAK ditambahkan (Suggestion)

- Composite `inventory_items (category, active)` — index tunggal
  `category_idx` dan `active_idx` yang ada saat ini kemungkinan sudah
  cukup untuk volume data inventory yang biasanya kecil (puluhan–ratusan
  baris). Menambah index composite di sini nilai tambahnya tipis
  dibanding cost write — didokumentasikan sebagai catatan, tidak
  diimplementasikan.
- Menulis ulang policy RLS memakai `(select public.current_role())`
  (bentuk yang di Postgres versi lebih baru bisa di-cache planner per
  statement, bukan per baris) — perbaikan performa mikro yang valid,
  tapi mengubah 30+ policy yang sudah berjalan baik; di luar scope audit
  ini yang fokus ke desain skema.

---

## 4. Audit Constraint

Lihat **Section A** di `20260717090000_db_audit_hardening.sql` — daftar
lengkap `CHECK` constraint yang ditambahkan (harga, biaya, qty, jumlah uang
→ non-negatif/positif). **Setiap constraint dipetakan ke bukti konkret di
`src/`** (dicantumkan sebagai komentar di migration) yang menunjukkan
aplikasi SUDAH mengasumsikan invariant yang sama, supaya penambahan ini
tidak berisiko menolak data valid:

- `products-page.tsx` menolak simpan produk dengan `price/cost/stock/minStock`
  negatif secara eksplisit (dengan catatan bahwa `min={0}` di `<input>` saja
  tidak cukup) → jadi CHECK di DB menutup celah yang app sendiri sudah akui
  sebagai bug class.
- `inventory.service.ts` men-clamp `Math.max(0, stock + delta)`.
- `pos-page.tsx` men-clamp `changeDue = Math.max(0, paidTotal - total)`.
- Komentar SQL asli di `stock_movements.quantity` sudah menyatakan
  "selalu positif" tapi belum pernah ditegakkan sebagai CHECK.

**Sengaja TIDAK ditambahkan** (kolom yang secara desain bisa sah bernilai
negatif atau di mana bukti di `src/` tidak cukup kuat):
- `preorders.remaining_balance` — dihitung `total - downPayment` tanpa
  clamp di `preorder.service.ts`; ada jalur (koreksi manual DP) yang bisa
  membuatnya negatif secara sah saat ini.
- `stock_movements.balance_after` — konsekuensi logis dari keputusan
  membiarkan `products.stock`/`inventory_items.stock` boleh 0 sebagai batas
  bawah tapi TIDAK ada constraint eksplisit untuk `balance_after` itu
  sendiri, karena kolom ini murni hasil kalkulasi (snapshot), bukan input.

Tidak ada `UNIQUE` yang hilang — constraint `UNIQUE` yang relevan (mis.
`legacy_id`, `finance_budgets.category`) sudah ada di migration asli. Tidak
ada `DEFAULT` yang hilang untuk kolom yang butuh default. Enum via `CHECK
(... IN (...))` sudah dipakai konsisten dan sengaja dipilih di atas native
Postgres `ENUM` type — pola ini tepat untuk kolom seperti `audit_log.action`
yang nilainya terus bertambah (menambah value ke `CHECK` semudah `ALTER
TABLE`, sedangkan `ALTER TYPE ... ADD VALUE` pada enum native punya
keterbatasan transaksi). **Tidak ada perubahan direkomendasikan** untuk pola
ini.

---

## 5. Audit Naming

Diperiksa: nama tabel, kolom, constraint, index, function, dan policy.

**Hasil: konsisten, semuanya `snake_case`, tidak ada yang perlu diubah.**
Pola penamaan index (`{table}_{kolom}_idx`), constraint (implicit dari
Postgres untuk FK/PK, eksplisit `{table}_{kolom}_{jenis}` untuk yang baru
ditambahkan di audit ini), dan policy (`{table}_{aksi}_{scope}`, mis.
`sales_write_cashier_ins`) sudah dipakai secara konsisten dari migration
`profiles` sampai `sales_pos_init`. Migration baru di audit ini mengikuti
pola yang sama persis.

---

## 6. Audit RLS

Ditinjau seluruh policy di `20260717080000_sales_pos_init.sql`.

**Hasil: sudah sesuai prinsip yang digariskan** — `authenticated` read-all,
write dibatasi per kelompok role secara luas (bukan granular), dan
`permissions.ts` tetap jadi sumber kebenaran utama (database hanya defense
in depth). Tidak ditemukan policy yang terlalu kompleks atau berlebihan.
Pemetaan role → tabel di komentar SQL asli konsisten dengan policy yang
benar-benar dibuat (diverifikasi baris per baris).

Satu-satunya catatan sudah tercantum sebagai **asumsi eksplisit yang perlu
dikonfirmasi pemilik produk** (bukan bug): apakah "Finance & Settings =
admin-only write" benar, karena tidak ada capability eksplisit untuk ini di
`permissions.ts`. Ini bukan tanggung jawab audit database untuk diputuskan
— sudah dibawa apa adanya ke `schema-mapping.md` yang diperbarui.

**Tidak ada perubahan RLS di migration baru ini** — sesuai instruksi
("JANGAN membuat policy terlalu kompleks") dan karena tidak ditemukan
kekurangan yang perlu ditambal.

---

## 8. Audit Migration Quality

- **Urutan CREATE TABLE / FK**: benar — `preorders` dibuat sebelum `sales`
  lalu `sales.id` di-back-fill ke `preorders.sale_id` via `ALTER TABLE`
  terpisah untuk menghindari circular dependency; `order_queue` dibuat
  setelah, dengan pola back-fill FK yang sama untuk `preorders.queue_id`.
  Pola ini benar dan sudah didokumentasikan dengan jelas di komentar.
- **Idempotency**: migration asli TIDAK memakai `IF NOT EXISTS` di
  `CREATE TABLE`/`CREATE INDEX` (mengandalkan Supabase migration runner
  yang men-track migration mana yang sudah jalan, bukan idempotency
  manual) — ini pola yang wajar untuk migration yang belum pernah di-apply,
  jadi tidak masalah. Migration audit baru ini (`20260717090000`) sengaja
  memakai `CREATE INDEX IF NOT EXISTS` / `DROP INDEX IF EXISTS` supaya
  aman di-replay kalau perlu tanpa mengandalkan state migration runner.
- **DROP IF EXISTS**: tidak relevan untuk migration awal (belum ada objek
  untuk di-drop selain 2 index yang memang sengaja dihapus di audit ini).
- **Komentar & readability**: sangat baik — setiap keputusan desain
  non-obvious (JSONB, FK yang sengaja tidak dibuat, singleton pattern,
  race condition counter) didokumentasikan langsung di SQL-nya. Ini
  praktik yang baik dan dipertahankan pola yang sama di migration audit.

**Tidak ada perbaikan migration quality yang perlu diterapkan** — kualitas
migration asli sudah baik.

---

## 9. Audit Dokumentasi

`docs/storage-migration/schema-mapping.md` diperbarui:
- Tabel pemetaan StorageKey → Table dilengkapi kolom Primary Key, Foreign
  Key, Status, dan Catatan Migrasi sesuai format yang diminta.
- Daftar StorageKey yang **belum** dimigrasikan dipisah jadi section
  tersendiri yang eksplisit (sebelumnya bercampur di dalam tabel utama).
- Referensi ke migration audit baru (`20260717090000`) dan laporan ini
  ditambahkan.

Isi teknis (alasan JSONB, alasan tanpa-FK, dsb.) yang sudah ada di versi
lama dipertahankan — hanya disusun ulang ke format tabel yang diminta,
tidak ada informasi yang dihapus.

---

## Ringkasan Temuan

| # | Severity | Temuan | Status |
|---|---|---|---|
| 1 | Major | `public.current_role()` berpotensi bentrok dengan keyword `CURRENT_ROLE` | Didokumentasikan, tidak diperbaiki sekarang (butuh migrasi RLS terpisah) |
| 2 | Major | `sales.preorder_id` ↔ `preorders.sale_id` bidirectional tanpa penjaga konsistensi | Didokumentasikan, tidak diperbaiki sekarang (butuh keputusan desain) |
| 3 | Major | `recipes.output_ref_id` / `production_runs.output_ref_id` polymorphic tanpa FK | Sudah tepat untuk saat ini, alternatif dicatat untuk masa depan |
| 4 | Major | `stock_movements.quantity` didokumentasikan "selalu positif" tapi tidak ditegakkan | **Diperbaiki** — CHECK ditambahkan |
| 5 | Major | Kolom uang/qty di 15+ tabel tanpa CHECK non-negatif, padahal app sudah mengasumsikan invariant ini | **Diperbaiki** — CHECK ditambahkan (lihat Section A) |
| 6 | Minor | 7 kolom FK tanpa index (price_group_id, sale_id, queue_id, dst.) | **Diperbaiki** — index ditambahkan |
| 7 | Minor | `sales_voided_idx` & `finance_expenses_pot_idx` selektivitas rendah | **Diperbaiki** — diganti composite/partial index |
| 8 | Suggestion | `sales.items`/`preorders.items` JSONB — kandidat normalisasi ke `sale_items` kalau laporan per-item makin dibutuhkan | Tidak diimplementasikan — belum ada bukti kebutuhan |
| 9 | Suggestion | `preorders.remaining_balance` tidak di-clamp non-negatif | Tidak diimplementasikan — app sendiri belum meng-clamp nilai ini |
| 10 | Suggestion | Pencarian customer masih client-side filter di `preorder-page.tsx` | Index pendukung (trigram + phone) sudah disiapkan di DB, migrasi query ke server-side di luar scope audit database |

Tidak ditemukan temuan **Critical** — tidak ada risiko kehilangan data,
korupsi relasi, atau celah keamanan RLS yang mendesak.
