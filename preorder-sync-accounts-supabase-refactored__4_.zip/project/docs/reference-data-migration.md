# Reference Data Migration — Product, Inventory, Recipe, Price Group, Settings

Scope tahap ini: **HANYA** 5 domain data referensi — Produk, Inventory Items,
Recipes, Price Groups, Settings. Sales, Queue, Preorder, Shift, Refund
**tidak dimigrasikan** — service-service mereka tetap localStorage, hanya
disentuh secara mekanis (tambah `async`/`await`) di titik-titik yang
memanggil salah satu dari 5 service yang sekarang Supabase.

---

## 1. Tabel yang dipakai (dari Prompt 0)

| Service | Tabel Supabase | PK |
|---|---|---|
| `product.service.ts` | `products` | `id` (uuid) |
| `inventory.service.ts` | `inventory_items` | `id` (uuid) |
| `recipe.service.ts` | `recipes` | `id` (uuid) |
| `price-group.service.ts` | `price_groups` | `id` (uuid) |
| `settings.service.ts` | `business_settings` | `id` (smallint, singleton = 1) |

**`id` sekarang selalu uuid** — bukan lagi string custom seperti `"p1"`,
`"inv_1699999999999"`, atau `"pg_outlet"` dari versi localStorage. Kolom
`legacy_id` di `products`/`inventory_items`/`price_groups` (dari skema
Prompt 0) menyimpan id lama HANYA untuk baris yang diimpor lewat seed SQL
(lihat §4) — kode aplikasi tidak pernah membaca/menulis `legacy_id`.

Konsekuensi konkret: `products-page.tsx`'s `emptyProduct()` dan
`settings-page.tsx`'s tambah-Price-Group sekarang memakai
`crypto.randomUUID()` untuk id produk/grup baru, bukan format lama
(`p_${Date.now()}` / `pg_${Date.now()}`) — `upsert()` ke Supabase butuh
uuid valid.

---

## 2. Kenapa perlu SQL migration tambahan

`supabase/migrations/20260718100000_reference_data_rpc.sql` (additive,
tidak mengubah migration Prompt 0/0.1):

1. **RPC `deduct_product_stock(product_id, qty)`** dan
   **`add_product_stock(product_id, qty)`** — sesuai instruksi eksplisit
   Prompt 2 §3: satu statement atomic
   (`UPDATE ... WHERE stock >= qty RETURNING *`), menggantikan pola "SELECT
   lalu UPDATE terpisah" yang jadi sumber race condition di versi
   localStorage. `deduct` throw dengan pesan informatif kalau stok kurang
   atau produk tidak ada; `add` mengembalikan `NULL` untuk qty≤0/produk
   tidak ada (tidak throw) — persis perilaku lama.
2. **RPC `adjust_inventory_stock(item_id, delta)`** — **tidak diminta
   eksplisit**, tapi ditambahkan karena `inventoryService.adjustStock()`
   (dipanggil `stock-movement.service.ts`) punya bug class yang **identik**
   dengan produk: read-then-write (`Math.max(0, stock + delta)`) di
   client. Pola atomic yang sama diterapkan di sini juga.
3. **`ALTER TABLE recipes ALTER COLUMN output_ref_id DROP NOT NULL`** —
   skema Prompt 0 mendefinisikan kolom ini `not null`, tapi
   `recipe.service.ts` (tidak diubah logikanya) sengaja mengisi
   `outputRefId: ""` untuk resep tipe "panir" (yang tidak menghasilkan
   output stockable). String kosong bukan uuid valid, jadi kolom
   dilonggarkan; recipe.service.ts menerjemahkan `"" ↔ NULL` di boundary
   Supabase supaya kontrak `Recipe.outputRefId: string` di TypeScript tidak
   berubah.

Semua RPC di atas **`security invoker`** (default) — tetap tunduk RLS
`products_write_upd` / `inventory_items_write_*` yang sudah ada dari
Prompt 0, jadi cashier/production tetap hanya bisa mengubah stok (bukan
insert/delete), persis prinsip defense-in-depth yang sudah ditetapkan.

---

## 3. Kenapa auto-seed client-side dimatikan

Versi localStorage: `role-context.tsx` memanggil `seedIfEmpty()` /
`seedInventoryIfEmpty()` / `seedRecipesIfEmpty()` untuk **siapa saja** yang
login, setiap kali "tabel" localStorage kosong.

Ini **tidak bisa dipertahankan** begitu data pindah ke Supabase, karena dua
alasan:

1. **RLS.** `products_write_ins` mensyaratkan role **admin** untuk INSERT;
   `inventory_items_write_production_ins` admin **atau** production;
   `price_groups_write_admin` admin-only. Begitu yang login pertama adalah
   cashier/owner, auto-seed akan **gagal dengan error** (bukan diam-diam
   no-op seperti localStorage).
2. **API bulk-replace hilang.** `productService.save(list)` /
   `inventoryService.save(list)` (ganti seluruh tabel sekaligus) tidak ada
   padanan aman di Supabase yang bisa dipanggil client — dan kalaupun ada,
   dua device yang sama-sama mendapati tabel kosong bisa balapan
   menduplikasi data.

**Perbaikan:** `seedIfEmpty()`, `seedInventoryIfEmpty()`,
`seedRecipesIfEmpty()` di `src/services/seed.ts` sekarang **no-op**
(dipertahankan sebagai fungsi kosong, bukan dihapus, supaya
`role-context.tsx` — di luar scope tahap ini — tidak perlu ikut diubah).
Array `seedProducts`/`seedInventory`/`seedRecipes` tetap ada di file yang
sama sebagai **sumber data** yang dipakai men-generate seed SQL (lihat di
bawah) — bukan lagi dieksekusi langsung dari client.

`seedIfEmpty()` masih menjalankan seeding **`userService`** (localStorage,
tidak terkait Supabase — sudah dead code sejak audit Prompt 0, dibiarkan
apa adanya, di luar scope).

---

## 4. Seed data — sekarang lewat SQL, bukan client

| File | Isi | Wajib dijalankan? |
|---|---|---|
| `supabase/seed/price-groups.sql` | 5 Price Group default (Outlet, ShopeeFood, GoFood, GrabFood, Reseller) | **Ya** — tanpa ini, dropdown Price Group di POS/Settings kosong (aplikasi tetap jalan, cuma tidak ada grup untuk dipilih) |
| `supabase/seed/products-and-inventory.sql` | 20 produk starter + 53 item inventory starter (persis data `seedProducts`/`seedInventory` versi localStorage lama) | Opsional — hanya kalau kamu mau data starter yang sama seperti sebelumnya |

Keduanya **idempotent** (`WHERE NOT EXISTS (SELECT 1 FROM ...)`) — aman
dijalankan ulang, tidak akan menduplikasi. Jalankan lewat Supabase SQL
Editor (kredensial admin/service_role), **setelah** kedua migration
(`20260717080000` dan `20260718100000`) diterapkan.

Resep (recipes) **tidak** punya seed SQL — `recipeService` belum
dikonsumsi UI manapun (belum ada halaman Recipe), jadi belum mendesak.

---

## 5. File yang diubah

### 5 service inti (ditulis ulang penuh, async, Supabase)
- `src/services/product.service.ts`
- `src/services/inventory.service.ts`
- `src/services/recipe.service.ts`
- `src/services/price-group.service.ts`
- `src/services/settings.service.ts`

Nama & parameter fungsi dipertahankan sepersis mungkin, **kecuali** yang
sebelumnya murni sinkron atas data yang sudah ter-load (`categories()`,
`isSkuTaken()`, `generateSku()`, `forSource()`, `byId()`) — ini diubah
menerima list yang sudah di-fetch (`list: Product[]` dst.) sebagai
parameter, bukan fetch sendiri, supaya tetap sinkron dan tidak perlu
round-trip Supabase tambahan untuk komputasi murni. `priceFor()` tidak
berubah sama sekali (murni operasi atas objek yang sudah ada).

`settingsService.getCached()` (baru): cache in-memory sinkron, dipakai
`whatsapp.service.ts` dan `pos/invoice-receipt.ts` — dua file lintas-domain
yang formatting-nya dipanggil sinkron dari halaman Queue/Preorder/Pesanan
(di luar scope). Lihat komentar di `settings.service.ts` untuk detail.

### Halaman yang dikonversi penuh ke react-query
- `src/features/products/products-page.tsx`
- `src/features/pos/pos-page.tsx`
- `src/features/settings/settings-page.tsx` (Business/Sales/Production —
  **Finance section TIDAK disentuh**, `financeSettings` bukan salah satu
  dari 5 service yang dimigrasikan)

Pola yang dipakai konsisten dengan `accounts-page.tsx` yang sudah ada:
`useQuery` untuk baca, `useMutation` + `qc.invalidateQueries` untuk tulis,
toast.success/error. **Tidak ada realtime** — setelah mutasi sukses, cache
di-invalidate dan react-query refetch; device LAIN baru melihat perubahan
setelah refresh manual (realtime menyusul Prompt 5, sesuai catatan kamu).

### Analytics (baca produk/inventory, tapi bukan salah satu dari 5 service)
- `src/features/analytics/sales/data.ts` — `productPerformance`,
  `topProducts`, `worstProducts`, `categoryBreakdown`,
  `computeSalesAnalytics` diubah menerima `products: Product[]` sebagai
  parameter (bukan fetch sendiri) — fungsi-fungsi ini murni komputasi
  sinkron, jadi lebih tepat menerima data yang sudah di-fetch daripada
  ikut jadi async.
- `src/features/analytics/sales/operational-data.ts` — sama, `products`/
  `inventoryItems` di-thread lewat `kpiPanel`, `packagingAnalytics`,
  `computeOperationalAnalytics`.
- `src/features/analytics/sales/sales-analytics-page.tsx` — satu-satunya
  titik yang benar-benar `useQuery` products & inventory items, diteruskan
  ke seluruh call chain di atas.

### Ripple minimal ke domain yang TIDAK dimigrasikan (mekanis, ada TODO)

Domain Sales/Queue/Preorder/Shift/Refund **sengaja tidak dimigrasikan**
tahap ini, TAPI beberapa file di dalamnya memanggil salah satu dari 5
service yang sekarang async — terutama `productService.deduct()`/
`addStock()`, yang **harus** async karena sekarang RPC (panggilan
jaringan). Perubahan di file-file berikut **murni mekanis**
(`async`/`await`, tanpa mengubah logic/storage/behaviour) — masing-masing
diberi komentar `TODO(prompt berikutnya)`:

| File | Kenapa tersentuh |
|---|---|
| `src/services/stock-movement.service.ts` | `record()` memanggil `inventoryService.get()`/`adjustStock()` |
| `src/services/sales.service.ts` | `create()`/`void()` memanggil `productService.deduct/addStock`, `inventoryService.get`, `stockMovementService.record` |
| `src/services/shift.service.ts` | `moveStock()` + 4 fungsi mutasi (expense/packaging) memanggil `inventoryService`/`stockMovementService` |
| `src/services/refund.service.ts` | `approve()` memanggil `salesService.void()` (yang sekarang async) |
| `src/features/sales/preorder-page.tsx` | `finalizeComplete`/`requestComplete`/`confirmSettle` memanggil `salesService.create()` |
| `src/features/sales/pesanan-page.tsx` | `approveRefund()` memanggil `refundService.approve()` |
| `src/features/sales/shifts-page.tsx` | 2 pembacaan `inventoryService.list()` (react-query) + 4 titik mutasi (await + invalidate) — TIDAK ada perubahan pada logic Shift itu sendiri |

**Tidak ada perubahan** pada `queue.service.ts` atau `preorder.service.ts`
— dikonfirmasi lewat grep, keduanya nol dependency ke 5 service yang
dimigrasikan.

`src/services/production-planning.service.ts` — dikonversi async penuh
untuk konsistensi (memanggil productService/inventoryService/
settingsService), meski **belum dikonsumsi UI manapun** saat ini
(dikonfirmasi lewat grep) — forward-compat murni, tidak ada risiko regresi
karena tidak ada pemanggil.

---

## 6. Yang SENGAJA tidak diikutkan tahap ini

- **Realtime.** Perubahan dari device lain baru terlihat setelah refresh
  manual / refetch react-query (mis. reopen halaman, atau invalidate dari
  mutasi sendiri). Sesuai instruksi kamu — "realtime otomatis menyusul di
  Prompt 5".
- **`inventoryService.adjustStock()` shortage validation** di
  `stock-movement.service.ts` masih check-then-act (baca stok dulu,
  baru panggil RPC) — bukan penuh atomic seperti `productService.deduct()`.
  RPC `adjust_inventory_stock` sendiri tetap atomic (clamp ke 0 di DB), tapi
  validasi "throw kalau kurang" di level `stockMovementService.record()`
  bisa false-negative dalam window race yang sempit. Diterima sebagai
  keterbatasan sementara karena `stock_movements` bukan salah satu dari 5
  tabel yang dimigrasikan tahap ini.
- **Migrasi Sales/Queue/Preorder/Shift/Refund itu sendiri** (tabel
  `sales`, `order_queue`, `preorders`, `shifts`, `refund_requests`) — tetap
  localStorage penuh, hanya titik panggil ke 5 service yang disentuh (lihat
  §5 di atas).
- **Halaman Recipe** — belum ada, `recipeService` sudah dimigrasikan penuh
  tapi menunggu UI-nya dibuat.

---

## 7. Acceptance Test — checklist

| # | Skenario | Cara verifikasi |
|---|---|---|
| 1 | Tambah/edit/hapus produk tersimpan di Supabase | Cek tabel `products` di Supabase Dashboard setelah aksi di `/produk` |
| 2 | Perubahan produk terlihat di device lain setelah refresh manual | Buka `/produk` di 2 browser/device, ubah di salah satu, refresh yang lain |
| 3 | Checkout POS mengurangi stok secara atomic | Checkout dua transaksi produk yang sama nyaris bersamaan dari 2 tab — stok akhir harus konsisten (tidak overselling) |
| 4 | Void/refund mengembalikan stok | Void sale dari `/pesanan`, cek `products.stock` bertambah kembali |
| 5 | Price Group CRUD + Set Default | `/pengaturan` → Sales — tambah, ubah sources, set default, hapus (kecuali default) |
| 6 | Business/Production settings tersimpan | `/pengaturan` → Business & Production — ubah, simpan, refresh, nilai tetap |
| 7 | POS tetap menampilkan Price Group & Settings yang benar | Buka `/pos`, cek nama customer default & source order price group sesuai `/pengaturan` |
| 8 | Shift Closing (expense/packaging) tetap berfungsi | `/shift` — tambah/edit/hapus pengeluaran operasional, simpan pemakaian packaging — stok inventory ikut berubah |
| 9 | Preorder → Complete tetap membuat Sale & mengurangi stok | `/preorder` — selesaikan sebuah PO, cek Sale baru muncul & stok produk berkurang |
| 10 | Analytics tidak error | `/analytics/sales` — semua tab (Top/Worst Products, Category Breakdown, Packaging, KPI Panel) tampil tanpa error |
| 11 | Tidak ada pemanggilan sinkron ke 5 service yang sekarang async | Sudah diverifikasi lewat grep menyeluruh — 0 hasil un-awaited di luar file service itu sendiri |

**Belum diverifikasi otomatis** (perlu `npm install` + `npm run build`,
tidak bisa dijalankan di lingkungan pembuatan migrasi ini — jaringan
nonaktif): full TypeScript compile check. Semua perubahan sudah ditinjau
manual baris-per-baris dan disilangkan lewat grep menyeluruh, tapi
**jalankan `npm run build` sebelum deploy** untuk menangkap kesalahan tipe
yang mungkin terlewat.

---

## 8. Setelah tahap ini

1. Jalankan kedua migration (`20260717080000` lalu `20260718100000`) ke
   Supabase project kamu (kalau belum).
2. Jalankan `supabase/seed/price-groups.sql` (wajib).
3. (Opsional) jalankan `supabase/seed/products-and-inventory.sql` kalau
   mau data starter.
4. `npm install && npm run build` — pastikan tidak ada TypeScript error.
5. Test manual sesuai checklist §7, termasuk skenario 2 device kamu
   sebutkan di instruksi.
6. Setelah kamu konfirmasi lolos test manual, lanjut ke migrasi domain
   berikutnya (Sales/Queue/Preorder/Shift/Refund) — **belum dikerjakan di
   tahap ini**.
