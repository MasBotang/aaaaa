# Deploy to Vercel

## 1. Install & verify locally
```bash
npm install
npm run dev      # sanity check dev server
npm run build    # produces .vercel/output/
```

## 2. Set env vars in Vercel (Project Settings → Environment Variables)
- VITE_SUPABASE_URL              (Production, Preview, Development)
- VITE_SUPABASE_ANON_KEY         (Production, Preview, Development)
- SUPABASE_SERVICE_ROLE_KEY      (Production, Preview) — NO VITE_ prefix

⚠️ Rotate SUPABASE_SERVICE_ROLE_KEY before first deploy — the previous value was committed.

## 3. Deploy
### Option A — Git
Push repo → import at https://vercel.com/new → deploy.
Framework Preset: Other. Leave Build Command / Output Directory at defaults.

### Option B — CLI
```bash
npm i -g vercel
vercel        # preview
vercel --prod # production
```

## Removed (Cloudflare-specific)
- wrangler.toml
- devDependency: wrangler
- script: "deploy": "wrangler deploy"
