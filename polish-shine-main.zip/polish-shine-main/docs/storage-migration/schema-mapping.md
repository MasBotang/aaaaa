# Schema Mapping — localStorage (StorageKeys) → Supabase Postgres

Status: **Tahap 1 — Sales/POS-first**. Belum dijalankan ke Supabase manapun.
SQL: `supabase/migrations/20260717080000_sales_pos_init.sql`
+ `supabase/migrations/20260717090000_db_audit_hardening.sql` (audit &
hardening — index dan CHECK constraint tambahan, additive, tidak mengubah
`20260717080000`)
+ `supabase/migrations/20260718100000_reference_data_rpc.sql` (RPC atomic
untuk stock produk/inventory + `recipes.output_ref_id` nullable — lihat
[`reference-data-migration.md`](../reference-data-migration.md)).

> 📋 Laporan audit database lengkap (relasi, normalisasi, index, constraint,
> naming, RLS, migration quality): lihat
> [`db-audit-report.md`](./db-audit-report.md).

> 📋 Migrasi app-level (product/inventory/recipe/price-group/settings
> service dari localStorage ke Supabase, termasuk RPC & seed SQL): lihat
> [`reference-data-migration.md`](../reference-data-migration.md).

> ℹ️ File ini awalnya diminta bernama `0001_init.sql`, tapi sudah di-rename
> ke format timestamp di atas supaya terurut **setelah** migration `profiles`
> yang sudah ada (`20260716164012_..._profiles.sql`,
> `20260716164034_..._revoke.sql`) — konsisten dengan konvensi penamaan
> Supabase CLI di project ini. Isi SQL tidak berubah, cuma nama file.

## Temuan penting sebelum baca tabel di bawah

1. **Project ini SUDAH punya sistem auth Supabase** (`supabase/migrations/2026...profiles.sql`)
   — tabel `public.profiles` (id → `auth.users.id`, `role` check admin/owner/cashier/production)
   sudah ada & sudah pernah dijalankan. Migration di atas **memakai** tabel
   ini (lewat fungsi `public.current_role()` untuk RLS) tapi **tidak
   mengubahnya**.
2. **Ada 2 sistem "user" yang berbeda di kode, dan keduanya BUKAN yang di atas:**
   - `StorageKeys.users` (`User[]` — `{id, name, role}`) di `user.service.ts`:
     dipakai di ≤1 tempat, tampak seperti sisa versi lama. **Tidak dibuatkan
     tabel** — sudah digantikan `profiles` yang sudah ada.
   - `src/lib/accounts.functions.ts` — sistem akun **login sungguhan** yang
     dipakai app sekarang (`Account` dengan **password plaintext**,
     tersimpan di key `desalut:v1:accounts`). Key ini **BUKAN** bagian dari
     `StorageKeys` (di-hardcode terpisah), jadi **secara ketat di luar scope**
     prompt ini. Tapi ini layak kamu tahu: kalau `profiles`/Supabase Auth
     sudah ada, kemungkinan besar langkah migrasi berikutnya (di luar
     dokumen ini) adalah pindahkan login dari `accounts.functions.ts` ke
     Supabase Auth sungguhan (email+password via `auth.users`), bukan cuma
     migrasi datanya ke tabel Postgres biasa — karena password plaintext di
     localStorage adalah risiko keamanan nyata, terlepas dari soal
     localStorage→Supabase. Saya tidak mengubah apa pun di sini; hanya
     menandai supaya tidak diabaikan tanpa sadar.
3. **Race condition Sales/POS yang disebutkan di konteks migrasi** kemungkinan
   besar bersumber dari `StorageKeys.salesSequence` /
   `StorageKeys.orderNumberSequence` — pola read-increment-write pada satu
   objek counter (`{day, n}`). Lihat tabel `daily_counters` di bawah: dirancang
   supaya prompt migrasi kode nanti bisa pakai `INSERT ... ON CONFLICT ...
   DO UPDATE SET value = value + 1 RETURNING value` (atomik di Postgres),
   yang menutup race condition ini — **dengan syarat** kode nanti benar-benar
   memakai pola upsert-atomik ini, bukan select-lalu-update terpisah.

## Tabel pemetaan

| StorageKey Lama | Table Baru | Primary Key | Foreign Key | Status | Catatan Migrasi |
|---|---|---|---|---|---|
| `products` | `products` | `id` (uuid) | — | Migrated | `prices` (Record<priceGroupId, number>) → JSONB, FK ke `price_groups` tidak bisa dipaksa di dalam JSONB (app-level only) |
| `sales` | `sales` | `id` (uuid) | `shift_id→shifts.id`, `price_group_id→price_groups.id`, `preorder_id→preorders.id` | Migrated | `items`, `payment`, `packings`, `plastic`, `extraPackaging` → JSONB (lihat alasan di SQL) |
| `shifts` | `shifts` | `id` (uuid) | — | Migrated | `operationalExpenses`, `packagingUsage`, `marketplaceReconciliations`, `paymentReconciliations` → JSONB |
| `currentShift` | *(tidak ada tabel — derived)* | — | — | Derived | Baris `shifts` dengan `closed_at IS NULL`. Unique partial index `shifts_only_one_open_idx` menegakkan "hanya 1 shift terbuka" — aturan ini disimpulkan dari `currentShift` yang berbentuk objek tunggal (bukan array) di kode lama |
| `users` | *(tidak ada tabel)* | — | — | Superseded | Digantikan oleh `profiles` (Supabase Auth) yang sudah ada. Lihat temuan #2 |
| `settings` | `business_settings` | `id` (smallint, singleton = 1) | — | Migrated | `production` (ProductionSettings) → JSONB |
| `salesSequence`, `orderNumberSequence` | `daily_counters` | `(counter_name, day)` (composite) | — | Migrated | Digabung jadi 1 tabel dengan kolom `counter_name` ('sales_sequence' \| 'order_number_sequence'). Lihat temuan #3 soal race condition |
| `holdOrders` | `hold_orders` | `id` (uuid) | `price_group_id→price_groups.id` | Migrated | — |
| `inventoryItems` | `inventory_items` | `id` (uuid) | — | Migrated | — |
| `stockMovements` | `stock_movements` | `id` (uuid) | `item_id→inventory_items.id` (restrict) | Migrated | — |
| `recipes` | `recipes` | `id` (uuid) | — (`output_ref_id` polymorphic tanpa FK) | Migrated | `ingredients` (RecipeIngredient[]) → JSONB; `outputRefId` polymorphic (inventory ATAU product) → uuid tanpa FK, divalidasi app |
| `productionRuns` | `production_runs` | `id` (uuid) | `recipe_id→recipes.id` (set null) | Migrated | `recipeId` kosong (activity=`finishing_validation`) → **NULL**, bukan string kosong, saat load data |
| `finishingValidations` | `finishing_validations` | `id` (uuid) | `product_id→products.id` (restrict) | Migrated | — |
| `orderQueue` | `order_queue` | `id` (uuid) | `preorder_id→preorders.id` (set null); `sale_id` **SENGAJA TANPA FK** | Migrated | Lihat "Catatan khusus: `order_queue.sale_id` tanpa FK" di bawah |
| `auditLog` | `audit_log` | `id` (uuid) | — | Migrated | Append-only: tidak ada policy UPDATE/DELETE sama sekali. `action` disimpan `text` tanpa CHECK enum (30+ nilai & terus bertambah — union TypeScript tetap sumber kebenaran) |
| `priceGroups` | `price_groups` | `id` (uuid) | — | Migrated | — |
| `marketplaceSettlements` | `marketplace_settlements` | `id` (uuid) | — | Migrated | — |
| `preorders` | `preorders` | `id` (uuid) | `price_group_id→price_groups.id` (set null), `sale_id→sales.id` (set null), `queue_id→order_queue.id` (set null) | Migrated | `items`, `packings` → JSONB |
| `productionNeedAdditions` | `production_need_additions` | `id` (uuid) | `preorder_id→preorders.id` (restrict, not null), `product_id→products.id` (restrict, not null) | Migrated | — |
| `financeExpenses` | `finance_expenses` | `id` (uuid) | — | Migrated | — |
| `financeDebts` | `finance_debts` | `id` (uuid) | — | Migrated | — |
| `financeDebtPayments` | `finance_debt_payments` | `id` (uuid) | `debt_id→finance_debts.id` (restrict, not null) | Migrated | — |
| `financeFundWithdraws` | `finance_fund_withdraws` | `id` (uuid) | — | Migrated | — |
| `financeSettings` | `finance_settings` | `id` (smallint, singleton = 1) | — | Migrated | `allocation`, `openingBalance` → JSONB |
| `financeBudgets` | `finance_budgets` | `id` (uuid) | — | Migrated | Sumber asli tidak punya `id` — key alami `category` (`UNIQUE`). `created_at` sintetis (tidak ada di data asli) |
| `refundRequests` | `refund_requests` | `id` (uuid) | `sale_id→sales.id` (restrict, not null) | Migrated | — |
| `preorderCancelRequests` | `preorder_cancel_requests` | `id` (uuid) | `preorder_id→preorders.id` (restrict, not null) | Migrated | — |
| `salesTargets` | `sales_targets` | `date_key` (text) | — | Migrated | `Record<dateKey, number>` → 1 baris per `date_key` (termasuk baris literal `'__default'`) |

### StorageKey yang BELUM dimigrasikan

| StorageKey Lama | Status | Catatan Migrasi |
|---|---|---|
| `sidebarState` | Not migrated (by design) | UI state murni per-device/per-browser, tidak relevan sebagai data server-side |
| `seeded`, `inventorySeeded`, `recipesSeeded`, `priceGroupsSeeded` | Not migrated (by design) | Flag onboarding lokal. Begitu Supabase jadi sumber kebenaran bersama, "seeding" jadi one-time script/SQL, bukan flag per klien |
| `stockAdjustments` | Not migrated (unused key) | Grep di seluruh `src/` tidak menemukan pemakaian. Penyesuaian stok nyatanya lewat `stock_movements` dengan `type = 'adjustment'`. Kandidat untuk dihapus dari `keys.ts` di kemudian hari (di luar scope prompt ini) |
| `purchases` | Not migrated (no real feature yet) | Hanya dirujuk generik di `accounts.functions.ts` (cek `createdBy` untuk larangan hapus akun) — tidak ada service/type/komponen Purchase apa pun di kode. Tidak dibuatkan tabel supaya tidak menebak struktur fitur yang belum ada; rancang saat fiturnya benar-benar dibangun |
| `stockOpnames` | Not migrated (no feature yet) | Tidak ditemukan pemakaian di `src/` sama sekali |
| `attendance` | Not migrated (no feature yet) | Tidak ditemukan pemakaian di `src/` |
| `salaryRules`, `salaryBonuses`, `salaryAdditionals` | Not migrated (reserved) | Tidak ditemukan pemakaian; komentar di `keys.ts` menyebutnya "data source, di luar Payroll" — reserved untuk fitur masa depan |
| `payrolls`, `payrollDeductions`, `payrollSettlements` | Not migrated (reserved) | Sama seperti di atas — reserved, tidak ada service/type nyata untuk dijadikan acuan schema saat ini |
| `role` | Not migrated (dead code candidate) | Tidak ditemukan dipakai di `src/` selain deklarasi di `keys.ts`. Role sesi sekarang datang dari `role-context.tsx` (terhubung ke sistem auth). Kandidat dead code |


### Catatan khusus: `order_queue.sale_id` tanpa FK

`queue.service.ts` → `relinkSale()` punya komentar eksplisit yang menjelaskan
bahwa saat Pre Order di-promote ke antrean, `sale_id` **sementara diisi
`preorder.id`** (placeholder) sebelum Sale sungguhan terbentuk, baru
kemudian di-relink ke `sales.id` asli. Kalau kolom ini diberi FK ke
`sales.id`, insert placeholder awal itu akan **gagal** (karena `preorder.id`
bukan baris yang ada di `sales`). Jadi kolom ini sengaja dibiarkan `uuid not
null` **tanpa** FK constraint — integritas referensialnya tetap tanggung
jawab aplikasi, persis seperti sekarang di localStorage.

### Tabel opsional future-proof (TIDAK diimplementasikan sekarang)

Sesuai arahan, tidak perlu skema multi-tenant. Satu catatan opsional untuk
nanti: kalau suatu saat butuh multi-outlet, banyak type sudah punya field
`outletId?` optional (`PriceGroup`, `MarketplaceSettlement`, `PreOrder`,
`Sale`) — menambah kolom `outlet_id uuid nullable` (tanpa FK dulu) ke
tabel-tabel itu murah dilakukan belakangan, tidak perlu disiapkan sekarang.

## RLS — ringkasan

Semua tabel: `authenticated` boleh `SELECT` semua baris. Write dibatasi per
kelompok role secara luas (bukan granular seperti `permissions.ts`):

| Kelompok tabel | Role yang boleh write |
|---|---|
| `sales`, `shifts`, `hold_orders`, `preorders`, `order_queue`, `production_need_additions`, `marketplace_settlements`, `daily_counters` | admin, cashier |
| `order_queue` (update tambahan) | admin, production (perlu update status masak/packing) |
| `products` | admin (insert/delete), admin+cashier+production (update — stock berubah dari POS & produksi) |
| `price_groups`, `sales_targets`, semua tabel `finance_*`, `business_settings` | admin saja (**asumsi**, lihat catatan di SQL — tidak ada capability eksplisit untuk ini di `permissions.ts`, tolong dikonfirmasi) |
| `refund_requests`, `preorder_cancel_requests` | insert: admin+cashier; approve/reject (update): admin saja |
| `inventory_items`, `recipes`, `production_runs`, `finishing_validations` | admin, production |
| `stock_movements` | insert: admin, cashier, production (cashier ditambahkan di `20260722000000_stock_movements_cashier_insert.sql` — dibutuhkan untuk movement `sales_packaging_usage` saat checkout POS, lihat migration file untuk detail); update/delete: admin, production |
| `audit_log` | insert: siapa saja yang authenticated; update/delete: **tidak ada policy sama sekali** (append-only, konsisten dengan komentar di `audit.service.ts`) |

**Catatan terkait yang belum diperbaiki:** `inventory_items` UPDATE (dipakai oleh RPC `adjust_inventory_stock`, dipanggil dari `stock-movement.service.ts`) masih admin+production saja. Untuk role cashier, ini berarti baris `stock_movements` untuk `sales_packaging_usage` kini berhasil tercatat, tapi nilai `inventory_items.stock` itu sendiri belum tentu benar-benar berkurang (RPC diam-diam tidak meng-update baris yang tidak lolos RLS). Perlu keputusan produk terpisah sebelum diubah.

RLS ini adalah lapisan pertahanan kedua — `src/lib/permissions.ts` di
aplikasi tetap sumber kebenaran untuk detail granular (mis. hanya admin yang
boleh edit harga produk, hanya admin yang boleh approve refund).

## Migration audit (Tahap 1.1)

`supabase/migrations/20260717090000_db_audit_hardening.sql` menambahkan
(additive, tidak mengubah `20260717080000`):
- `CHECK` constraint non-negatif/positif untuk kolom harga/biaya/qty/uang
  yang aplikasinya sudah mengasumsikan invariant ini (bukti per-kolom ada
  di komentar migration).
- Index untuk kolom FK yang belum terindeks, dan index laporan/pencarian
  (sales report, queue, preorder due date, finance per pot, pencarian
  customer via nama/telepon).
- Menghapus 2 index dengan selektivitas rendah, digantikan index yang
  lebih sesuai pola query nyata.

Detail lengkap tiap keputusan (termasuk yang SENGAJA tidak diubah) ada di
[`db-audit-report.md`](./db-audit-report.md).

## Yang PERLU kamu putuskan/konfirmasi sebelum apply

1. Asumsi "Finance & Settings = admin-only write" di atas — benar?
2. ~~Rename file migration ke format timestamp~~ — sudah dilakukan (lihat catatan di atas).
3. Field `cashier`, `createdBy`, `actor`, `operator`, dll di semua tabel
   sengaja **tetap `text` bebas** (bukan FK ke `profiles.id`) karena sistem
   identitas aktor aplikasi saat ini masih `accounts.functions.ts`
   (localStorage, bukan Supabase Auth) — lihat temuan #2. Menyambungkan
   kolom-kolom ini ke `profiles.id` baru masuk akal setelah login
   sungguhan-sungguhan pindah ke Supabase Auth.
