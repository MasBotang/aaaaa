import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { nitro } from "nitro/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Deployment target: Vercel (Build Output API v3).
// Nitro's "vercel" preset emits .vercel/output/ which Vercel auto-detects
// with no vercel.json needed. SSR runs as a Vercel Function (Node runtime);
// static assets are served from .vercel/output/static.
export default defineConfig({
  plugins: [
    tanstackStart({
      server: { entry: "server" },
    }),
    nitro({ preset: "vercel" }),
    viteReact(),
    tailwindcss(),
    tsConfigPaths(),
  ],
});
