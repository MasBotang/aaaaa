/**
 * Translate raw Supabase / Postgres / network errors into short, friendly
 * Indonesian messages suitable for toasts and inline error states.
 *
 * Kept intentionally conservative: we recognise well-known codes / patterns
 * and fall back to a generic message rather than leaking implementation
 * details ("duplicate key value violates unique constraint …").
 */

export function friendlyError(err: unknown, fallback = "Terjadi kesalahan. Coba lagi."): string {
  if (!err) return fallback;

  // Supabase PostgrestError shape: { message, code, details, hint }
  const anyErr = err as {
    code?: string;
    message?: string;
    hint?: string;
    details?: string;
    status?: number;
    name?: string;
  };

  const code = anyErr.code;
  const raw = (anyErr.message ?? "").toString();
  const lower = raw.toLowerCase();

  // Network / offline
  if (anyErr.name === "TypeError" && lower.includes("fetch")) {
    return "Tidak bisa terhubung. Periksa koneksi internet lalu coba lagi.";
  }
  if (lower.includes("failed to fetch") || lower.includes("networkerror")) {
    return "Tidak bisa terhubung. Periksa koneksi internet lalu coba lagi.";
  }

  // Auth
  if (anyErr.status === 401 || lower.includes("jwt") || lower.includes("unauthorized")) {
    return "Sesi Anda berakhir. Silakan masuk kembali.";
  }
  if (anyErr.status === 403 || lower.includes("permission denied") || code === "42501") {
    return "Anda tidak memiliki akses untuk aksi ini.";
  }

  // Postgres codes
  switch (code) {
    case "23505":
      return "Data serupa sudah ada. Periksa kembali sebelum menyimpan.";
    case "23503":
      return "Data ini masih terhubung dengan catatan lain dan tidak bisa diubah/dihapus.";
    case "23502":
      return "Ada isian wajib yang belum diisi.";
    case "23514":
      return "Nilai yang dimasukkan tidak valid.";
    case "22P02":
      return "Format data tidak valid.";
    case "P0001":
      // RAISE from function — often already a human message.
      return raw || fallback;
    case "PGRST116":
      return "Data tidak ditemukan.";
  }

  // Common Supabase auth messages
  if (lower.includes("invalid login credentials")) {
    return "Email atau kata sandi salah.";
  }
  if (lower.includes("email not confirmed")) {
    return "Email belum dikonfirmasi. Periksa kotak masuk Anda.";
  }
  if (lower.includes("rate limit")) {
    return "Terlalu banyak percobaan. Coba lagi beberapa saat.";
  }

  // Fallback: if the raw message is short and looks human, use it.
  if (raw && raw.length <= 140 && !raw.includes("::") && !raw.startsWith("{")) {
    return raw;
  }
  return fallback;
}
