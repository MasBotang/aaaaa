// Reports client-side errors caught by the root error boundary.
//
// This used to forward errors to Lovable's in-editor preview bridge via
// `window.__lovableEvents`, which only exists inside Lovable's own preview
// iframe. Now that the app runs standalone, we just log to the console.
// Wire this up to whatever error-monitoring service you use (Sentry, etc.)
// if you want these captured somewhere durable.
export function reportError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  console.error(error, {
    source: "react_error_boundary",
    route: window.location.pathname,
    ...context,
  });
}
