import type { RefObject } from "react";
import { Search, X, ShoppingBasket } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/common/empty-state";
import type { CustomerType, Product } from "@/services/types";
import { formatIDR } from "@/lib/format";
import { priceFor, iconForCategory } from "./pos-helpers";
import type { CartLine } from "./pos-helpers";

/**
 * Panel "pilih produk" (search + kategori + grid kartu) dari POSPage.
 *
 * Langkah kedua pemecahan `pos-page.tsx` (lihat pos-helpers.ts untuk langkah
 * pertama). Ini murni presentational — SEMUA state & handler tetap tinggal
 * di POSPage, dikirim ke sini sebagai props. JSX-nya dipindah verbatim
 * (copy-paste, tanpa modifikasi logika), jadi perilaku harus identik
 * dengan sebelum dipisah.
 *
 * SENGAJA belum ditest dengan `npm run build` di sandbox ini (tidak ada
 * akses network buat install dependencies) — sudah diverifikasi manual:
 * setiap identifier bebas di JSX di bawah ditelusuri satu-satu balik ke
 * prop di interface ini. Tetap disarankan jalankan `npm run build`/
 * `npm run dev` sebelum deploy ke production.
 */
export interface ProductGridProps {
  searchRef: RefObject<HTMLInputElement | null>;
  query: string;
  setQuery: (v: string) => void;
  categories: string[];
  category: string;
  setCategory: (v: string) => void;
  visible: Product[];
  cart: CartLine[];
  isPreorder: boolean;
  activePriceGroupId: string | undefined;
  customerType: CustomerType;
  addToCart: (p: Product) => void;
}

export function ProductGrid({
  searchRef,
  query,
  setQuery,
  categories,
  category,
  setCategory,
  visible,
  cart,
  isPreorder,
  activePriceGroupId,
  customerType,
  addToCart,
}: ProductGridProps) {
  return (
    <>
      {/* Premium search — tall, elegant, keyboard-first. */}
      <div className="group relative">
        <Search
          className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-primary"
          strokeWidth={1.75}
        />
        <Input
          ref={searchRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Cari nama produk, SKU, barcode..."
          aria-label="Cari produk"
          className="h-[54px] rounded-[18px] border-border/50 bg-card pl-14 pr-24 text-[15px] font-medium shadow-[0_1px_0_oklch(1_0_0_/_0.9)_inset,0_8px_24px_-16px_oklch(0.22_0.025_40_/_0.15)] transition placeholder:font-normal placeholder:text-muted-foreground/70 focus-visible:border-primary/40 focus-visible:ring-2 focus-visible:ring-primary/15"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label="Bersihkan pencarian"
            className="absolute right-16 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground"
          >
            <X className="h-4 w-4" strokeWidth={1.75} />
          </button>
        ) : null}
        <kbd
          title="Tekan F2 untuk fokus pencarian"
          className="pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 items-center gap-1 rounded-lg border border-border/60 bg-muted/60 px-2 py-1 text-[11px] font-semibold tracking-wide text-muted-foreground sm:inline-flex"
        >
          F2
        </kbd>
      </div>

      {/* Premium category pills — rounded, gradient-active, elegant. */}
      <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
        {categories.map((c) => {
          const Icon = iconForCategory(c);
          const isActive = category === c;
          return (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              aria-pressed={isActive}
              className={`group inline-flex shrink-0 items-center gap-2 rounded-full px-5 py-2.5 text-[13px] font-semibold transition active:scale-[0.98] ${
                isActive
                  ? "brand-gradient text-primary-foreground shadow-brand"
                  : "border border-border/50 bg-card text-foreground/80 shadow-[0_1px_2px_oklch(0.22_0.025_40_/_0.04)] hover:-translate-y-0.5 hover:border-primary/30 hover:text-foreground"
              }`}
            >
              <Icon
                className={`h-4 w-4 ${isActive ? "text-primary-foreground" : "text-primary/70 group-hover:text-primary"}`}
                strokeWidth={1.75}
              />
              <span className="whitespace-nowrap">{c}</span>
            </button>
          );
        })}
      </div>

      <div className="grid min-h-0 flex-1 auto-rows-max grid-cols-2 gap-4 overflow-y-auto pb-6 pt-2 pr-1 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
        {visible.map((p) => {
          const stock = p.stock;
          const outOfStock = typeof stock === "number" && stock <= 0;
          // PO tidak menyentuh ready stock saat dibuat — semua produk boleh
          // dipilih meski Habis. Kartu tetap menampilkan badge "Habis" agar
          // kasir sadar, tapi tidak di-disable.
          const blockSelect = outOfStock && !isPreorder;
          const lowStock =
            typeof stock === "number" && stock > 0 && (p.minStock ?? 0) > 0 && stock <= (p.minStock ?? 0);
          const price = priceFor(p, activePriceGroupId, customerType);
          const inCartQty = cart.find((x) => x.productId === p.id)?.qty ?? 0;
          return (
            <button
              key={p.id}
              onClick={() => addToCart(p)}
              disabled={blockSelect}
              aria-label={`${p.name}${outOfStock ? " · stok habis" : ""}${isPreorder && outOfStock ? " (tersedia untuk Pre Order)" : ""}`}
              className={`group relative flex flex-col overflow-visible rounded-[18px] pos-card text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 ${
                blockSelect
                  ? "cursor-not-allowed opacity-60"
                  : "pos-card-hover active:translate-y-0 active:scale-[0.98]"
              }`}
            >
              {/* Image hero — ~68% of card, PNG-friendly, generous breathing room. */}
              <div
                className="relative flex h-[158px] w-full items-center justify-center overflow-hidden rounded-t-[17px] px-5 pt-6 pb-3"
                style={{
                  background:
                    "radial-gradient(85% 95% at 50% 30%, #FFFFFF 0%, #FBF7F1 100%)",
                }}
              >
                {/* Subtle botanical wash */}
                <svg
                  aria-hidden
                  viewBox="0 0 100 100"
                  className="pointer-events-none absolute -bottom-3 -right-3 h-20 w-20 opacity-[0.10] text-primary"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="0.8"
                >
                  <path d="M50 10 C 48 40 48 70 50 95" />
                  <path d="M50 30 C 38 34 30 44 28 56" />
                  <path d="M50 30 C 62 34 70 44 72 56" />
                  <path d="M50 55 C 40 58 32 68 30 78" />
                  <path d="M50 55 C 60 58 68 68 70 78" />
                </svg>
                {p.imageUrl ? (
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    loading="lazy"
                    className={`relative h-full w-full object-contain drop-shadow-[0_10px_18px_oklch(0.22_0.025_40_/_0.18)] transition duration-300 ${
                      blockSelect ? "grayscale" : "group-hover:-translate-y-1 group-hover:scale-[1.04]"
                    }`}
                  />
                ) : (
                  <ShoppingBasket
                    className="h-12 w-12 text-primary/30"
                    strokeWidth={1.25}
                  />
                )}

                {/* Selected quantity badge — subtle, replaces heavy border. */}
                {inCartQty > 0 && (
                  <span className="absolute right-2.5 top-2.5 inline-flex h-6 min-w-6 items-center justify-center rounded-full brand-gradient px-1.5 text-[11px] font-bold tabular-nums text-primary-foreground shadow-brand">
                    {inCartQty}
                  </span>
                )}

                {/* Stock badges — muted, only when meaningful. */}
                {outOfStock ? (
                  <span
                    className={`absolute left-2.5 top-2.5 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider shadow-sm ${
                      isPreorder
                        ? "bg-amber-500/95 text-white"
                        : "bg-destructive/95 text-destructive-foreground"
                    }`}
                  >
                    {isPreorder ? "Habis · PO OK" : "Habis"}
                  </span>
                ) : lowStock ? (
                  <span className="absolute left-2.5 top-2.5 rounded-full bg-gold px-2 py-0.5 text-[10px] font-semibold tracking-wider text-foreground/80 shadow-sm">
                    Sisa {stock}
                  </span>
                ) : null}
              </div>

              {/* Info — minimal: name + price only. */}
              <div className="flex flex-1 flex-col gap-1.5 px-4 py-3.5">
                <span className="line-clamp-2 min-h-[2.5rem] text-[13.5px] font-semibold leading-snug text-foreground">
                  {p.name}
                </span>
                <span className="mt-auto text-[16px] font-bold tabular-nums text-primary">
                  {formatIDR(price)}
                </span>
              </div>
            </button>
          );
        })}

        {visible.length === 0 && (
          <div className="col-span-full">
            <EmptyState
              icon={<Search className="h-8 w-8" strokeWidth={1.6} />}
              title="Produk tidak ditemukan"
              description={
                query ? `Tidak ada hasil untuk "${query}".` : "Coba pilih kategori lain."
              }
              action={
                query ? (
                  <Button size="sm" variant="outline" onClick={() => setQuery("")}>
                    Bersihkan pencarian
                  </Button>
                ) : null
              }
            />
          </div>
        )}
      </div>
    </>
  );
}
