import { supabase } from "@/lib/supabase-client";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (lanjutan): auditService sekarang menulis & membaca
// tabel `public.audit_log` di Supabase (bukan localStorage lagi).
//
// RLS (lihat 20260717080000_sales_pos_init.sql):
//   - INSERT: SIAPA SAJA yang authenticated boleh menulis (log ditulis oleh
//     berbagai role saat mereka melakukan aksi) — tidak ada gap izin di
//     sini, tidak perlu migration tambahan.
//   - SELECT: authenticated boleh baca semua baris (`audit_log_read_all`).
//   - Tidak ada policy UPDATE/DELETE sama sekali -> default deny, menegakkan
//     sifat append-only (sama seperti versi localStorage yang sengaja tidak
//     menyediakan `remove`/`update`).
//
// `log()` SENGAJA dipertahankan sebagai fire-and-forget (bukan async/await
// di call site) — diverifikasi ke seluruh 29 pemanggilan di src/: tidak ada
// satu pun yang meng-await atau memakai return value-nya, konsisten dengan
// perilaku lama (audit gagal TIDAK BOLEH membatalkan aksi bisnis yang
// memicunya, lihat komentar "kegagalan di langkah ini TIDAK membatalkan
// Sale" di sales.service.ts). Insert dikirim di background; error ditangkap
// & di-console.error, TIDAK dilempar sebagai unhandled promise rejection.
// ---------------------------------------------------------------------------

export type AuditAction =
  | "sale_created"
  | "sale_voided"
  | "stock_adjustment"
  | "packaging_rule_upsert"
  | "packaging_rule_delete"
  | "product_price_edit"
  | "product_upsert"
  | "settings_update"
  | "shift_open"
  | "shift_close"
  | "queue_status_change"
  | "operational_expense_added"
  | "operational_expense_updated"
  | "operational_expense_deleted"
  | "packaging_usage_saved"
  | "packaging_usage_updated"
  | "sales_packaging_used"
  | "sales_extra_packaging_added"
  | "packaging_name_mismatch"
  | "packaging_movement_partial_failure"
  | "sales_rollback_partial_failure"
  | "production_record_created"
  | "production_release"
  | "production_planning_saved"
  | "refund_requested"
  | "refund_approved"
  | "refund_rejected"
  | "refund_approve_blocked"
  | "preorder_cancel_requested"
  | "preorder_cancel_approved"
  | "preorder_cancel_rejected"
  | "preorder_mark_ready_undo"
  | "product_stock_write"
  | "whatsapp_notification_sent"
  | "preorder_dp_paid"
  | "settlement_posted";

export interface AuditEntry {
  id: string;
  createdAt: string;
  actor: string;
  actorRole?: string;
  action: AuditAction;
  entity?: string;
  entityId?: string;
  reason?: string;
  metadata?: Record<string, unknown>;
}

interface AuditRow {
  id: string;
  legacy_id: string | null;
  created_at: string;
  actor: string;
  actor_role: string | null;
  action: string;
  entity: string | null;
  entity_id: string | null;
  reason: string | null;
  metadata: Record<string, unknown> | null;
}

function fromRow(row: AuditRow): AuditEntry {
  return {
    id: row.id,
    createdAt: row.created_at,
    actor: row.actor,
    actorRole: row.actor_role ?? undefined,
    action: row.action as AuditAction,
    entity: row.entity ?? undefined,
    entityId: row.entity_id ?? undefined,
    reason: row.reason ?? undefined,
    metadata: row.metadata ?? undefined,
  };
}

/**
 * Append-only audit log. Tidak menyediakan `remove` / `update` secara sengaja —
 * jejak audit tidak boleh dihapus dari kode aplikasi (dan memang tidak ada
 * policy UPDATE/DELETE di database untuk role manapun).
 */
export const auditService = {
  /**
   * Terurut terbaru dulu, dibatasi `limit` baris (default 500) supaya tidak
   * menarik seluruh histori sekaligus — sebelumnya versi localStorage
   * mengambil semua baris dari cap 10.000 entry di client; Supabase tidak
   * butuh cap tulis semacam itu lagi (paginasi dilakukan lewat query, bukan
   * dengan memotong array setelah insert).
   */
  async list(limit = 500): Promise<AuditEntry[]> {
    const { data, error } = await supabase
      .from("audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(limit);
    if (error) throw error;
    return (data as AuditRow[]).map(fromRow);
  },

  log(entry: Omit<AuditEntry, "id" | "createdAt">): void {
    const insertRow = {
      actor: entry.actor,
      actor_role: entry.actorRole ?? null,
      action: entry.action,
      entity: entry.entity ?? null,
      entity_id: entry.entityId ?? null,
      reason: entry.reason ?? null,
      metadata: entry.metadata ?? null,
    };
    void supabase
      .from("audit_log")
      .insert(insertRow)
      .then(({ error }) => {
        if (error) {
          // Best-effort by design: audit gagal tidak boleh mengganggu alur
          // bisnis yang memicunya. Dicatat ke console supaya tetap terlihat
          // saat development/debugging.
          console.error("[auditService.log] gagal menulis audit log:", error, entry);
        }
      });
  },

  async byAction(action: AuditAction, limit = 500): Promise<AuditEntry[]> {
    const { data, error } = await supabase
      .from("audit_log")
      .select("*")
      .eq("action", action)
      .order("created_at", { ascending: false })
      .limit(limit);
    if (error) throw error;
    return (data as AuditRow[]).map(fromRow);
  },
};

export const AUDIT_ACTION_LABEL: Record<AuditAction, string> = {
  sale_created: "Transaksi Dibuat",
  sale_voided: "Void Transaksi",
  stock_adjustment: "Penyesuaian Stok",
  packaging_rule_upsert: "Ubah Aturan Kemasan",
  packaging_rule_delete: "Hapus Aturan Kemasan",
  product_price_edit: "Ubah Harga Produk",
  product_upsert: "Ubah Produk",
  settings_update: "Ubah Pengaturan",
  shift_open: "Buka Shift",
  shift_close: "Tutup Shift",
  queue_status_change: "Ubah Status Antrean",
  operational_expense_added: "Tambah Pengeluaran Operasional",
  operational_expense_updated: "Ubah Pengeluaran Operasional",
  operational_expense_deleted: "Hapus Pengeluaran Operasional",
  packaging_usage_saved: "Simpan Pemakaian Packaging",
  packaging_usage_updated: "Ubah Pemakaian Packaging",
  sales_packaging_used: "Pemakaian Packaging Penjualan",
  sales_extra_packaging_added: "Packaging Tambahan Penjualan",
  packaging_name_mismatch: "Nama Packaging Tidak Cocok Dengan Inventory",
  packaging_movement_partial_failure: "Pencatatan Pergerakan Packaging Gagal Sebagian",
  sales_rollback_partial_failure: "Rollback Checkout Gagal Sebagian",
  production_record_created: "Pencatatan Produksi",
  production_release: "Release Produksi ke Sales",
  production_planning_saved: "Simpan Planning Produksi",
  refund_requested: "Pengajuan Refund",
  refund_approved: "Refund Disetujui",
  refund_rejected: "Refund Ditolak",
  refund_approve_blocked: "Refund Ditolak Otomatis (sudah produksi)",
  preorder_cancel_requested: "Pengajuan Pembatalan Pre Order",
  preorder_cancel_approved: "Pembatalan Pre Order Disetujui (DP Hangus)",
  preorder_cancel_rejected: "Pengajuan Pembatalan Pre Order Ditolak",
  preorder_mark_ready_undo: "Urungkan Tandai Siap Diproses (Pre Order)",
  product_stock_write: "Tulis Ready Stock Produk",
  whatsapp_notification_sent: "Kirim Notifikasi WhatsApp",
  preorder_dp_paid: "Pembayaran DP Pre Order",
  settlement_posted: "Posting Settlement Marketplace",
};
