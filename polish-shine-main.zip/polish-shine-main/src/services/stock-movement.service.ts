import { supabase } from "@/lib/supabase-client";
import { inventoryService } from "./inventory.service";
import type { StockMovement, StockMovementType } from "./types";

// ---------------------------------------------------------------------------
// Migrasi Domain Sales (lanjutan): stockMovementService sekarang membaca &
// menulis tabel `public.stock_movements` di Supabase (bukan localStorage
// lagi). Public API dipertahankan sepersis mungkin — list()/byItem()/
// recent() jadi async; record() sudah async sejak sebelumnya (karena
// memanggil inventoryService yang sudah Supabase lebih dulu).
//
// `save()` DIHAPUS — pada versi localStorage fungsinya menimpa seluruh
// array sekaligus; dengan Supabase, `record()` langsung INSERT satu baris,
// jadi tidak ada lagi kebutuhan "simpan ulang seluruh list". Diverifikasi
// tidak ada caller `save()`/`list()`/`byItem()`/`recent()` di luar file ini
// sebelum migrasi (grep di seluruh src/) — aman diubah jadi async tanpa
// menyentuh pemanggil lain.
//
// RLS & fix terkait (lihat supabase/migrations/
// 20260722000000_stock_movements_cashier_insert.sql): kebijakan INSERT
// semula pada stock_movements hanya mengizinkan role admin/production.
// Padahal movement bertipe 'sales_packaging_usage' ditulis SAAT CHECKOUT
// oleh CASHIER (sales.service.ts / shift.service.ts) — migrasi tambahan
// itu menambah policy INSERT untuk cashier, persis alasan yang sama dengan
// policy `products_write_cashier` yang sudah ada ("stock berkurang saat
// checkout"). UPDATE/DELETE tetap admin+production only.
//
// CATATAN TERKAIT YANG BELUM DIPERBAIKI (di luar scope migrasi ini):
// RPC `adjust_inventory_stock` yang dipanggil oleh `inventoryService.
// adjustStock()` di bawah adalah security invoker, dan UPDATE-nya masih
// tunduk pada policy inventory_items yang JUGA admin+production only.
// Artinya untuk role cashier, baris audit stock_movements di bawah akan
// berhasil tercatat, TAPI nilai stok inventory_items itu sendiri belum
// tentu benar-benar berkurang (RPC mengembalikan NULL secara diam-diam
// bila baris tidak match RLS, lalu balanceAfter jatuh ke fallback
// perhitungan lokal di bawah). ini keputusan permission yang lebih besar
// (siapa boleh mengubah stok inventory secara langsung) yang perlu
// dikonfirmasi terpisah ke pemilik produk — TIDAK diubah di sini.
// ---------------------------------------------------------------------------

interface StockMovementRow {
  id: string;
  legacy_id: string | null;
  created_at: string;
  item_id: string;
  item_name: string;
  unit: string;
  type: StockMovementType;
  quantity: number | string;
  delta: number | string;
  reason: string | null;
  notes: string | null;
  balance_after: number | string;
}

function toNumber(v: number | string): number {
  const n = typeof v === "string" ? Number(v) : v;
  return Number.isFinite(n) ? n : 0;
}

function fromRow(row: StockMovementRow): StockMovement {
  return {
    id: row.id,
    createdAt: row.created_at,
    itemId: row.item_id,
    itemName: row.item_name,
    unit: row.unit,
    type: row.type,
    quantity: toNumber(row.quantity),
    delta: toNumber(row.delta),
    reason: row.reason ?? undefined,
    notes: row.notes ?? undefined,
    balanceAfter: toNumber(row.balance_after),
  };
}

/** Stock In types add to balance; everything else subtracts. */
const STOCK_IN_TYPES: StockMovementType[] = ["restock", "production_output"];

export function isStockIn(t: StockMovementType): boolean {
  return STOCK_IN_TYPES.includes(t);
}

export interface NewStockMovementInput {
  itemId: string;
  type: StockMovementType;
  /** Positive number entered by user; sign is determined by type. */
  quantity: number;
  reason?: string;
  notes?: string;
  /**
   * For "adjustment": when true, this represents an absolute target stock
   * level and `quantity` is interpreted as the new balance.
   */
  adjustmentAbsolute?: boolean;
}

export const stockMovementService = {
  async list(): Promise<StockMovement[]> {
    const { data, error } = await supabase
      .from("stock_movements")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data as StockMovementRow[]).map(fromRow);
  },

  async byItem(itemId: string): Promise<StockMovement[]> {
    const { data, error } = await supabase
      .from("stock_movements")
      .select("*")
      .eq("item_id", itemId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data as StockMovementRow[]).map(fromRow);
  },

  async recent(limit = 10): Promise<StockMovement[]> {
    const { data, error } = await supabase
      .from("stock_movements")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(limit);
    if (error) throw error;
    return (data as StockMovementRow[]).map(fromRow);
  },

  /**
   * Source of truth: every stock change goes through here.
   * Applies the delta to the item and persists the movement.
   */
  async record(input: NewStockMovementInput): Promise<StockMovement> {
    const item = await inventoryService.get(input.itemId);
    if (!item) throw new Error("Item tidak ditemukan");
    const qty = Math.max(0, input.quantity);

    let requestedDelta = 0;
    if (input.type === "adjustment" && input.adjustmentAbsolute) {
      requestedDelta = qty - item.stock;
    } else if (isStockIn(input.type)) {
      requestedDelta = qty;
    } else if (input.type === "adjustment") {
      requestedDelta = -qty;
    } else {
      requestedDelta = -qty;
    }

    // FIX (Sprint 1.5, dipertahankan dari versi localStorage): fail-loud
    // pada shortage untuk semua tipe stock-out (kecuali `adjustment`
    // absolut, yang memang bisa menargetkan 0).
    if (
      requestedDelta < 0 &&
      !(input.type === "adjustment" && input.adjustmentAbsolute) &&
      item.stock + requestedDelta < 0
    ) {
      throw new Error(
        `Stok ${item.name} tidak mencukupi (tersedia ${item.stock}, butuh ${Math.abs(requestedDelta)})`,
      );
    }
    // Untuk adjustment absolut, tetap clamp ke 0 supaya stok tidak negatif.
    const minDelta = -item.stock;
    const delta = requestedDelta < minDelta ? minDelta : requestedDelta;

    // Delta nol (mis. adjustment absolut ke nilai yang sama dengan stok
    // saat ini) berarti tidak ada perubahan nyata untuk dicatat. DB
    // menegakkan `stock_movements_quantity_positive` (quantity > 0), jadi
    // baris dengan quantity=0 akan ditolak — di versi localStorage lama
    // baris semacam ini tetap tersimpan tapi tidak pernah benar-benar
    // dibaca/dipakai di mana pun (diverifikasi: tidak ada caller list()/
    // byItem() eksternal). Di sini kita skip INSERT-nya dan kembalikan
    // representasi "tidak ada perubahan" tanpa menyentuh DB — perilaku
    // yang terlihat sama dari sisi caller (tetap resolve dengan
    // balanceAfter yang benar), hanya tidak menambah baris kosong.
    if (delta === 0) {
      return {
        id: `noop_${item.id}_${Date.now()}`,
        createdAt: new Date().toISOString(),
        itemId: item.id,
        itemName: item.name,
        unit: item.unit,
        type: input.type,
        quantity: 0,
        delta: 0,
        reason: input.reason?.trim() || undefined,
        notes: input.notes?.trim() || undefined,
        balanceAfter: item.stock,
      };
    }

    const updated = await inventoryService.adjustStock(item.id, delta);
    const balanceAfter = updated?.stock ?? Math.max(0, item.stock + delta);

    const insertRow = {
      item_id: item.id,
      item_name: item.name,
      unit: item.unit,
      type: input.type,
      quantity: Math.abs(delta),
      delta,
      reason: input.reason?.trim() || null,
      notes: input.notes?.trim() || null,
      balance_after: balanceAfter,
    };
    const { data, error } = await supabase
      .from("stock_movements")
      .insert(insertRow)
      .select()
      .single();
    if (error) throw error;
    return fromRow(data as StockMovementRow);
  },
};
