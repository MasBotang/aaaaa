export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          actor: string
          actor_role: string | null
          created_at: string
          entity: string | null
          entity_id: string | null
          id: string
          legacy_id: string | null
          metadata: Json | null
          reason: string | null
        }
        Insert: {
          action: string
          actor: string
          actor_role?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          legacy_id?: string | null
          metadata?: Json | null
          reason?: string | null
        }
        Update: {
          action?: string
          actor?: string
          actor_role?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          legacy_id?: string | null
          metadata?: Json | null
          reason?: string | null
        }
        Relationships: []
      }
      business_settings: {
        Row: {
          business_logo: string | null
          business_name: string
          default_customer_name: string
          id: number
          production: Json | null
          sales_target_daily: number
          updated_at: string
        }
        Insert: {
          business_logo?: string | null
          business_name?: string
          default_customer_name?: string
          id?: number
          production?: Json | null
          sales_target_daily?: number
          updated_at?: string
        }
        Update: {
          business_logo?: string | null
          business_name?: string
          default_customer_name?: string
          id?: number
          production?: Json | null
          sales_target_daily?: number
          updated_at?: string
        }
        Relationships: []
      }
      daily_counters: {
        Row: {
          counter_name: string
          day: string
          value: number
        }
        Insert: {
          counter_name: string
          day: string
          value?: number
        }
        Update: {
          counter_name?: string
          day?: string
          value?: number
        }
        Relationships: []
      }
      finance_budgets: {
        Row: {
          category: string
          created_at: string
          id: string
          monthly_amount: number
          note: string | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          monthly_amount?: number
          note?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          monthly_amount?: number
          note?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      finance_debt_payments: {
        Row: {
          amount: number
          at: string
          debt_id: string
          id: string
          legacy_id: string | null
          notes: string | null
          payment: string
        }
        Insert: {
          amount: number
          at: string
          debt_id: string
          id?: string
          legacy_id?: string | null
          notes?: string | null
          payment: string
        }
        Update: {
          amount?: number
          at?: string
          debt_id?: string
          id?: string
          legacy_id?: string | null
          notes?: string | null
          payment?: string
        }
        Relationships: [
          {
            foreignKeyName: "finance_debt_payments_debt_id_fkey"
            columns: ["debt_id"]
            isOneToOne: false
            referencedRelation: "finance_debts"
            referencedColumns: ["id"]
          },
        ]
      }
      finance_debts: {
        Row: {
          active: boolean
          created_at: string
          id: string
          legacy_id: string | null
          name: string
          notes: string | null
          principal: number
          target_date: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          legacy_id?: string | null
          name: string
          notes?: string | null
          principal: number
          target_date?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          legacy_id?: string | null
          name?: string
          notes?: string | null
          principal?: number
          target_date?: string | null
        }
        Relationships: []
      }
      finance_expenses: {
        Row: {
          amount: number
          at: string
          category: string
          created_by: string | null
          description: string
          id: string
          legacy_id: string | null
          payment: string
          pot: string
        }
        Insert: {
          amount: number
          at: string
          category: string
          created_by?: string | null
          description: string
          id?: string
          legacy_id?: string | null
          payment: string
          pot: string
        }
        Update: {
          amount?: number
          at?: string
          category?: string
          created_by?: string | null
          description?: string
          id?: string
          legacy_id?: string | null
          payment?: string
          pot?: string
        }
        Relationships: []
      }
      finance_fund_withdraws: {
        Row: {
          amount: number
          at: string
          description: string
          id: string
          legacy_id: string | null
          payment: string
          pot: string
        }
        Insert: {
          amount: number
          at: string
          description: string
          id?: string
          legacy_id?: string | null
          payment: string
          pot: string
        }
        Update: {
          amount?: number
          at?: string
          description?: string
          id?: string
          legacy_id?: string | null
          payment?: string
          pot?: string
        }
        Relationships: []
      }
      finance_settings: {
        Row: {
          allocation: Json
          development_target: number
          id: number
          opening_balance: Json
          updated_at: string
        }
        Insert: {
          allocation?: Json
          development_target?: number
          id?: number
          opening_balance?: Json
          updated_at?: string
        }
        Update: {
          allocation?: Json
          development_target?: number
          id?: number
          opening_balance?: Json
          updated_at?: string
        }
        Relationships: []
      }
      finishing_validations: {
        Row: {
          created_at: string
          id: string
          legacy_id: string | null
          notes: string | null
          operator: string
          product_id: string
          product_name: string
          rejected_qty: number
          validated_qty: number
        }
        Insert: {
          created_at?: string
          id?: string
          legacy_id?: string | null
          notes?: string | null
          operator: string
          product_id: string
          product_name: string
          rejected_qty?: number
          validated_qty?: number
        }
        Update: {
          created_at?: string
          id?: string
          legacy_id?: string | null
          notes?: string | null
          operator?: string
          product_id?: string
          product_name?: string
          rejected_qty?: number
          validated_qty?: number
        }
        Relationships: [
          {
            foreignKeyName: "finishing_validations_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      hold_orders: {
        Row: {
          created_at: string
          customer_name: string
          id: string
          items: Json
          legacy_id: string | null
          price_group_id: string | null
          source_order: string | null
          total: number
        }
        Insert: {
          created_at?: string
          customer_name: string
          id?: string
          items?: Json
          legacy_id?: string | null
          price_group_id?: string | null
          source_order?: string | null
          total?: number
        }
        Update: {
          created_at?: string
          customer_name?: string
          id?: string
          items?: Json
          legacy_id?: string | null
          price_group_id?: string | null
          source_order?: string | null
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "hold_orders_price_group_id_fkey"
            columns: ["price_group_id"]
            isOneToOne: false
            referencedRelation: "price_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory_items: {
        Row: {
          active: boolean
          category: string
          cost_per_unit: number
          created_at: string
          id: string
          last_purchase_at: string | null
          last_purchase_price: number | null
          last_supplier: string | null
          legacy_id: string | null
          min_stock: number
          name: string
          purchase_price: number
          purchase_quantity: number
          purchase_type: string | null
          safety_stock: number | null
          stock: number
          unit: string
          units_per_carton: number | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          category: string
          cost_per_unit?: number
          created_at?: string
          id?: string
          last_purchase_at?: string | null
          last_purchase_price?: number | null
          last_supplier?: string | null
          legacy_id?: string | null
          min_stock?: number
          name: string
          purchase_price?: number
          purchase_quantity?: number
          purchase_type?: string | null
          safety_stock?: number | null
          stock?: number
          unit: string
          units_per_carton?: number | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          category?: string
          cost_per_unit?: number
          created_at?: string
          id?: string
          last_purchase_at?: string | null
          last_purchase_price?: number | null
          last_supplier?: string | null
          legacy_id?: string | null
          min_stock?: number
          name?: string
          purchase_price?: number
          purchase_quantity?: number
          purchase_type?: string | null
          safety_stock?: number | null
          stock?: number
          unit?: string
          units_per_carton?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      marketplace_settlements: {
        Row: {
          created_at: string
          created_by: string
          date: string
          gross_sales: number
          id: string
          legacy_id: string | null
          marketplace: string
          marketplace_fee: number
          net_received: number
          notes: string | null
          order_count: number
        }
        Insert: {
          created_at?: string
          created_by: string
          date: string
          gross_sales?: number
          id?: string
          legacy_id?: string | null
          marketplace: string
          marketplace_fee?: number
          net_received?: number
          notes?: string | null
          order_count?: number
        }
        Update: {
          created_at?: string
          created_by?: string
          date?: string
          gross_sales?: number
          id?: string
          legacy_id?: string | null
          marketplace?: string
          marketplace_fee?: number
          net_received?: number
          notes?: string | null
          order_count?: number
        }
        Relationships: []
      }
      order_queue: {
        Row: {
          created_at: string
          customer_name: string
          customer_phone: string | null
          id: string
          is_preorder: boolean
          item_count: number
          items_summary: string | null
          last_actor: string | null
          legacy_id: string | null
          order_number: string | null
          packings: Json
          pickup_at: string | null
          preorder_id: string | null
          sale_code: string
          sale_id: string
          sale_type: string
          source_order: string | null
          status: string
          timeline: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_name: string
          customer_phone?: string | null
          id?: string
          is_preorder?: boolean
          item_count?: number
          items_summary?: string | null
          last_actor?: string | null
          legacy_id?: string | null
          order_number?: string | null
          packings?: Json
          pickup_at?: string | null
          preorder_id?: string | null
          sale_code: string
          sale_id: string
          sale_type: string
          source_order?: string | null
          status: string
          timeline?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_name?: string
          customer_phone?: string | null
          id?: string
          is_preorder?: boolean
          item_count?: number
          items_summary?: string | null
          last_actor?: string | null
          legacy_id?: string | null
          order_number?: string | null
          packings?: Json
          pickup_at?: string | null
          preorder_id?: string | null
          sale_code?: string
          sale_id?: string
          sale_type?: string
          source_order?: string | null
          status?: string
          timeline?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_queue_preorder_id_fkey"
            columns: ["preorder_id"]
            isOneToOne: false
            referencedRelation: "preorders"
            referencedColumns: ["id"]
          },
        ]
      }
      preorder_cancel_requests: {
        Row: {
          decided_at: string | null
          decided_by: string | null
          decided_by_role: string | null
          decision_note: string | null
          down_payment_at_request: number
          id: string
          legacy_id: string | null
          preorder_id: string
          reason: string
          requested_at: string
          requested_by: string
          requested_by_role: string | null
          status: string
        }
        Insert: {
          decided_at?: string | null
          decided_by?: string | null
          decided_by_role?: string | null
          decision_note?: string | null
          down_payment_at_request: number
          id?: string
          legacy_id?: string | null
          preorder_id: string
          reason: string
          requested_at?: string
          requested_by: string
          requested_by_role?: string | null
          status: string
        }
        Update: {
          decided_at?: string | null
          decided_by?: string | null
          decided_by_role?: string | null
          decision_note?: string | null
          down_payment_at_request?: number
          id?: string
          legacy_id?: string | null
          preorder_id?: string
          reason?: string
          requested_at?: string
          requested_by?: string
          requested_by_role?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "preorder_cancel_requests_preorder_id_fkey"
            columns: ["preorder_id"]
            isOneToOne: false
            referencedRelation: "preorders"
            referencedColumns: ["id"]
          },
        ]
      }
      preorders: {
        Row: {
          created_at: string
          created_by: string
          customer_name: string
          customer_phone: string | null
          date: string
          down_payment: number | null
          dp_method: string | null
          dp_paid_at: string | null
          id: string
          items: Json
          legacy_id: string | null
          notes: string | null
          packings: Json
          price_group_id: string | null
          queue_id: string | null
          remaining_balance: number | null
          sale_id: string | null
          sale_type: string | null
          source_order: string
          status: string
          time: string
          total: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          customer_name: string
          customer_phone?: string | null
          date: string
          down_payment?: number | null
          dp_method?: string | null
          dp_paid_at?: string | null
          id?: string
          items?: Json
          legacy_id?: string | null
          notes?: string | null
          packings?: Json
          price_group_id?: string | null
          queue_id?: string | null
          remaining_balance?: number | null
          sale_id?: string | null
          sale_type?: string | null
          source_order: string
          status: string
          time: string
          total?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          customer_name?: string
          customer_phone?: string | null
          date?: string
          down_payment?: number | null
          dp_method?: string | null
          dp_paid_at?: string | null
          id?: string
          items?: Json
          legacy_id?: string | null
          notes?: string | null
          packings?: Json
          price_group_id?: string | null
          queue_id?: string | null
          remaining_balance?: number | null
          sale_id?: string | null
          sale_type?: string | null
          source_order?: string
          status?: string
          time?: string
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "preorders_price_group_id_fkey"
            columns: ["price_group_id"]
            isOneToOne: false
            referencedRelation: "price_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "preorders_queue_id_fkey"
            columns: ["queue_id"]
            isOneToOne: false
            referencedRelation: "order_queue"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "preorders_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      price_groups: {
        Row: {
          created_at: string
          id: string
          is_default: boolean
          legacy_id: string | null
          name: string
          sources: string[]
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_default?: boolean
          legacy_id?: string | null
          name: string
          sources?: string[]
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_default?: boolean
          legacy_id?: string | null
          name?: string
          sources?: string[]
          updated_at?: string
        }
        Relationships: []
      }
      production_need_additions: {
        Row: {
          created_at: string
          date: string
          id: string
          legacy_id: string | null
          preorder_id: string
          product_id: string
          product_name: string
          qty: number
          release_reason: string | null
          released_at: string | null
          status: string
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          legacy_id?: string | null
          preorder_id: string
          product_id: string
          product_name: string
          qty: number
          release_reason?: string | null
          released_at?: string | null
          status: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          legacy_id?: string | null
          preorder_id?: string
          product_id?: string
          product_name?: string
          qty?: number
          release_reason?: string | null
          released_at?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "production_need_additions_preorder_id_fkey"
            columns: ["preorder_id"]
            isOneToOne: false
            referencedRelation: "preorders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "production_need_additions_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      production_runs: {
        Row: {
          activity: string | null
          actual_batches: number | null
          actual_weight: number | null
          actual_weight_unit: string | null
          batches: number
          consumed: Json
          created_at: string
          folder_label: string | null
          id: string
          legacy_id: string | null
          loss_quantity: number | null
          notes: string | null
          operator: string
          output_name: string
          output_ref_id: string
          output_target_type: string
          output_unit: string
          produced_quantity: number
          recipe_id: string | null
          recipe_name: string | null
          rejected_quantity: number | null
          waste_quantity: number | null
        }
        Insert: {
          activity?: string | null
          actual_batches?: number | null
          actual_weight?: number | null
          actual_weight_unit?: string | null
          batches?: number
          consumed?: Json
          created_at?: string
          folder_label?: string | null
          id?: string
          legacy_id?: string | null
          loss_quantity?: number | null
          notes?: string | null
          operator: string
          output_name: string
          output_ref_id: string
          output_target_type: string
          output_unit: string
          produced_quantity?: number
          recipe_id?: string | null
          recipe_name?: string | null
          rejected_quantity?: number | null
          waste_quantity?: number | null
        }
        Update: {
          activity?: string | null
          actual_batches?: number | null
          actual_weight?: number | null
          actual_weight_unit?: string | null
          batches?: number
          consumed?: Json
          created_at?: string
          folder_label?: string | null
          id?: string
          legacy_id?: string | null
          loss_quantity?: number | null
          notes?: string | null
          operator?: string
          output_name?: string
          output_ref_id?: string
          output_target_type?: string
          output_unit?: string
          produced_quantity?: number
          recipe_id?: string | null
          recipe_name?: string | null
          rejected_quantity?: number | null
          waste_quantity?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "production_runs_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          active: boolean
          category: string
          cost: number
          created_at: string
          id: string
          image_url: string | null
          legacy_id: string | null
          min_stock: number | null
          name: string
          price: number
          prices: Json
          sku: string | null
          stock: number
          stock_source: string | null
          updated_at: string
          wip_stock: number
        }
        Insert: {
          active?: boolean
          category: string
          cost?: number
          created_at?: string
          id?: string
          image_url?: string | null
          legacy_id?: string | null
          min_stock?: number | null
          name: string
          price?: number
          prices?: Json
          sku?: string | null
          stock?: number
          stock_source?: string | null
          updated_at?: string
          wip_stock?: number
        }
        Update: {
          active?: boolean
          category?: string
          cost?: number
          created_at?: string
          id?: string
          image_url?: string | null
          legacy_id?: string | null
          min_stock?: number | null
          name?: string
          price?: number
          prices?: Json
          sku?: string | null
          stock?: number
          stock_source?: string | null
          updated_at?: string
          wip_stock?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          employee_code: string | null
          full_name: string | null
          id: string
          notes: string | null
          phone: string | null
          role: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          employee_code?: string | null
          full_name?: string | null
          id: string
          notes?: string | null
          phone?: string | null
          role?: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          employee_code?: string | null
          full_name?: string | null
          id?: string
          notes?: string | null
          phone?: string | null
          role?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      recipes: {
        Row: {
          active: boolean
          created_at: string
          estimated_net_weight: number | null
          estimated_net_weight_unit: string | null
          estimated_yield_pct: number
          id: string
          ingredients: Json
          legacy_id: string | null
          name: string
          notes: string | null
          output_name: string
          output_quantity: number
          output_ref_id: string | null
          output_target_type: string
          output_unit: string
          type: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          estimated_net_weight?: number | null
          estimated_net_weight_unit?: string | null
          estimated_yield_pct?: number
          id?: string
          ingredients?: Json
          legacy_id?: string | null
          name: string
          notes?: string | null
          output_name: string
          output_quantity: number
          output_ref_id?: string | null
          output_target_type: string
          output_unit: string
          type: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          estimated_net_weight?: number | null
          estimated_net_weight_unit?: string | null
          estimated_yield_pct?: number
          id?: string
          ingredients?: Json
          legacy_id?: string | null
          name?: string
          notes?: string | null
          output_name?: string
          output_quantity?: number
          output_ref_id?: string | null
          output_target_type?: string
          output_unit?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      refund_requests: {
        Row: {
          decided_at: string | null
          decided_by: string | null
          decided_by_role: string | null
          decision_note: string | null
          id: string
          legacy_id: string | null
          reason: string
          requested_at: string
          requested_by: string
          requested_by_role: string | null
          sale_id: string
          status: string
        }
        Insert: {
          decided_at?: string | null
          decided_by?: string | null
          decided_by_role?: string | null
          decision_note?: string | null
          id?: string
          legacy_id?: string | null
          reason: string
          requested_at?: string
          requested_by: string
          requested_by_role?: string | null
          sale_id: string
          status: string
        }
        Update: {
          decided_at?: string | null
          decided_by?: string | null
          decided_by_role?: string | null
          decision_note?: string | null
          id?: string
          legacy_id?: string | null
          reason?: string
          requested_at?: string
          requested_by?: string
          requested_by_role?: string | null
          sale_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "refund_requests_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      sales: {
        Row: {
          cashier: string
          change: number | null
          created_at: string
          customer_name: string | null
          customer_notes: string | null
          customer_phone: string | null
          customer_type: string | null
          extra_packaging: Json
          id: string
          is_preorder: boolean
          items: Json
          legacy_id: string | null
          order_number: string | null
          packings: Json
          payment: Json
          pickup_at: string | null
          plastic: Json | null
          preorder_id: string | null
          price_group_id: string | null
          sale_type: string | null
          shift_id: string | null
          source_order: string | null
          subtotal: number
          tendered: number | null
          total: number
          void_reason: string | null
          voided: boolean
          voided_at: string | null
          voided_by: string | null
        }
        Insert: {
          cashier: string
          change?: number | null
          created_at?: string
          customer_name?: string | null
          customer_notes?: string | null
          customer_phone?: string | null
          customer_type?: string | null
          extra_packaging?: Json
          id?: string
          is_preorder?: boolean
          items?: Json
          legacy_id?: string | null
          order_number?: string | null
          packings?: Json
          payment?: Json
          pickup_at?: string | null
          plastic?: Json | null
          preorder_id?: string | null
          price_group_id?: string | null
          sale_type?: string | null
          shift_id?: string | null
          source_order?: string | null
          subtotal?: number
          tendered?: number | null
          total?: number
          void_reason?: string | null
          voided?: boolean
          voided_at?: string | null
          voided_by?: string | null
        }
        Update: {
          cashier?: string
          change?: number | null
          created_at?: string
          customer_name?: string | null
          customer_notes?: string | null
          customer_phone?: string | null
          customer_type?: string | null
          extra_packaging?: Json
          id?: string
          is_preorder?: boolean
          items?: Json
          legacy_id?: string | null
          order_number?: string | null
          packings?: Json
          payment?: Json
          pickup_at?: string | null
          plastic?: Json | null
          preorder_id?: string | null
          price_group_id?: string | null
          sale_type?: string | null
          shift_id?: string | null
          source_order?: string | null
          subtotal?: number
          tendered?: number | null
          total?: number
          void_reason?: string | null
          voided?: boolean
          voided_at?: string | null
          voided_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sales_preorder_id_fkey"
            columns: ["preorder_id"]
            isOneToOne: false
            referencedRelation: "preorders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_price_group_id_fkey"
            columns: ["price_group_id"]
            isOneToOne: false
            referencedRelation: "price_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_shift_id_fkey"
            columns: ["shift_id"]
            isOneToOne: false
            referencedRelation: "shifts"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_targets: {
        Row: {
          date_key: string
          target: number
          updated_at: string
        }
        Insert: {
          date_key: string
          target?: number
          updated_at?: string
        }
        Update: {
          date_key?: string
          target?: number
          updated_at?: string
        }
        Relationships: []
      }
      shifts: {
        Row: {
          cash_difference_reason: string | null
          cash_sales: number | null
          cashier: string
          closed_at: string | null
          closing_cash: number | null
          created_at: string
          expected_cash: number | null
          id: string
          legacy_id: string | null
          marketplace_reconciliations: Json
          marketplace_sales: number | null
          opened_at: string
          opening_cash: number
          operational_expenses: Json
          packaging_usage: Json
          packaging_usage_saved_at: string | null
          packaging_usage_saved_by: string | null
          payment_reconciliations: Json
          qris_sales: number | null
          total_operational_expense: number | null
          total_orders: number | null
          total_packaging_qty: number | null
          total_revenue: number | null
          transfer_sales: number | null
          updated_at: string
        }
        Insert: {
          cash_difference_reason?: string | null
          cash_sales?: number | null
          cashier: string
          closed_at?: string | null
          closing_cash?: number | null
          created_at?: string
          expected_cash?: number | null
          id?: string
          legacy_id?: string | null
          marketplace_reconciliations?: Json
          marketplace_sales?: number | null
          opened_at: string
          opening_cash?: number
          operational_expenses?: Json
          packaging_usage?: Json
          packaging_usage_saved_at?: string | null
          packaging_usage_saved_by?: string | null
          payment_reconciliations?: Json
          qris_sales?: number | null
          total_operational_expense?: number | null
          total_orders?: number | null
          total_packaging_qty?: number | null
          total_revenue?: number | null
          transfer_sales?: number | null
          updated_at?: string
        }
        Update: {
          cash_difference_reason?: string | null
          cash_sales?: number | null
          cashier?: string
          closed_at?: string | null
          closing_cash?: number | null
          created_at?: string
          expected_cash?: number | null
          id?: string
          legacy_id?: string | null
          marketplace_reconciliations?: Json
          marketplace_sales?: number | null
          opened_at?: string
          opening_cash?: number
          operational_expenses?: Json
          packaging_usage?: Json
          packaging_usage_saved_at?: string | null
          packaging_usage_saved_by?: string | null
          payment_reconciliations?: Json
          qris_sales?: number | null
          total_operational_expense?: number | null
          total_orders?: number | null
          total_packaging_qty?: number | null
          total_revenue?: number | null
          transfer_sales?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      stock_movements: {
        Row: {
          balance_after: number
          created_at: string
          delta: number
          id: string
          item_id: string
          item_name: string
          legacy_id: string | null
          notes: string | null
          quantity: number
          reason: string | null
          type: string
          unit: string
        }
        Insert: {
          balance_after: number
          created_at?: string
          delta: number
          id?: string
          item_id: string
          item_name: string
          legacy_id?: string | null
          notes?: string | null
          quantity: number
          reason?: string | null
          type: string
          unit: string
        }
        Update: {
          balance_after?: number
          created_at?: string
          delta?: number
          id?: string
          item_id?: string
          item_name?: string
          legacy_id?: string | null
          notes?: string | null
          quantity?: number
          reason?: string | null
          type?: string
          unit?: string
        }
        Relationships: [
          {
            foreignKeyName: "stock_movements_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_product_stock: {
        Args: { p_product_id: string; p_qty: number }
        Returns: {
          active: boolean
          category: string
          cost: number
          created_at: string
          id: string
          image_url: string | null
          legacy_id: string | null
          min_stock: number | null
          name: string
          price: number
          prices: Json
          sku: string | null
          stock: number
          stock_source: string | null
          updated_at: string
          wip_stock: number
        }
        SetofOptions: {
          from: "*"
          to: "products"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      adjust_inventory_stock: {
        Args: { p_delta: number; p_item_id: string }
        Returns: {
          active: boolean
          category: string
          cost_per_unit: number
          created_at: string
          id: string
          last_purchase_at: string | null
          last_purchase_price: number | null
          last_supplier: string | null
          legacy_id: string | null
          min_stock: number
          name: string
          purchase_price: number
          purchase_quantity: number
          purchase_type: string | null
          safety_stock: number | null
          stock: number
          unit: string
          units_per_carton: number | null
          updated_at: string
        }
        SetofOptions: {
          from: "*"
          to: "inventory_items"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      current_role: { Args: never; Returns: string }
      deduct_product_stock: {
        Args: { p_product_id: string; p_qty: number }
        Returns: {
          active: boolean
          category: string
          cost: number
          created_at: string
          id: string
          image_url: string | null
          legacy_id: string | null
          min_stock: number | null
          name: string
          price: number
          prices: Json
          sku: string | null
          stock: number
          stock_source: string | null
          updated_at: string
          wip_stock: number
        }
        SetofOptions: {
          from: "*"
          to: "products"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
