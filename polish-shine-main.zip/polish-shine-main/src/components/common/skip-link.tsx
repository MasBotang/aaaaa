/**
 * Keyboard-only "skip to content" link. Hidden until it receives focus,
 * then jumps focus straight to the main content region — so keyboard
 * users don't have to tab through the entire sidebar on every page.
 *
 * Must render before the sidebar in the DOM. The target element must
 * have id="main-content" and be focusable (tabIndex={-1}).
 */
export function SkipToContent() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-primary-foreground focus:shadow-lg focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
    >
      Lewati ke konten utama
    </a>
  );
}
