import { useState, type ReactNode } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  loading?: boolean;
  onConfirm: () => void | Promise<void>;
}

/**
 * Standard confirm dialog for destructive / irreversible actions
 * (delete product, void transaction, remove cart item, etc.).
 *
 * Radix AlertDialog already handles focus trap + Escape close.
 */
export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Konfirmasi",
  cancelLabel = "Batal",
  destructive = false,
  loading = false,
  onConfirm,
}: ConfirmDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={loading ? undefined : onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          {description ? (
            <AlertDialogDescription>{description}</AlertDialogDescription>
          ) : null}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>{cancelLabel}</AlertDialogCancel>
          <AlertDialogAction
            disabled={loading}
            aria-busy={loading || undefined}
            onClick={(e) => {
              e.preventDefault();
              void onConfirm();
            }}
            className={cn(
              destructive &&
                "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            )}
          >
            {loading ? "Memproses…" : confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

/**
 * Hook-based convenience for inline destructive actions.
 *
 * Usage:
 *   const confirm = useConfirm();
 *   ...
 *   <Button onClick={() => confirm.ask({
 *     title: "Hapus produk?",
 *     description: "Aksi ini tidak bisa dibatalkan.",
 *     destructive: true,
 *     onConfirm: () => deleteMutation.mutateAsync(id),
 *   })}>Hapus</Button>
 *   {confirm.dialog}
 */
export function useConfirm() {
  const [state, setState] = useState<
    | (Omit<ConfirmDialogProps, "open" | "onOpenChange" | "loading"> & {
        loading?: boolean;
      })
    | null
  >(null);
  const [loading, setLoading] = useState(false);

  const ask = (opts: Omit<ConfirmDialogProps, "open" | "onOpenChange" | "loading">) => {
    setState(opts);
  };

  const dialog = state ? (
    <ConfirmDialog
      {...state}
      open
      loading={loading}
      onOpenChange={(o) => {
        if (!o) setState(null);
      }}
      onConfirm={async () => {
        try {
          setLoading(true);
          await state.onConfirm();
          setState(null);
        } finally {
          setLoading(false);
        }
      }}
    />
  ) : null;

  return { ask, dialog };
}
