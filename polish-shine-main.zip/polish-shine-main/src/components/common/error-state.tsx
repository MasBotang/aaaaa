import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { friendlyError } from "@/lib/friendly-error";
import { cn } from "@/lib/utils";

/**
 * Inline error state for a failed useQuery — placed where the data was
 * supposed to be, with a retry button that re-runs refetch().
 */
export function ErrorState({
  error,
  onRetry,
  title = "Gagal memuat data",
  className,
}: {
  error: unknown;
  onRetry?: () => void;
  title?: string;
  className?: string;
}) {
  const message = friendlyError(error);
  return (
    <div
      role="alert"
      className={cn(
        "flex flex-col items-center justify-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-6 py-8 text-center",
        className,
      )}
    >
      <AlertTriangle
        className="h-7 w-7 text-destructive"
        strokeWidth={1.6}
        aria-hidden="true"
      />
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      <p className="max-w-sm text-xs text-muted-foreground">{message}</p>
      {onRetry ? (
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={onRetry}
          className="mt-1"
        >
          Coba lagi
        </Button>
      ) : null}
    </div>
  );
}
