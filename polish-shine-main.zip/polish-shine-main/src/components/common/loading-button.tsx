import { forwardRef } from "react";
import { Loader2 } from "lucide-react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface LoadingButtonProps extends ButtonProps {
  /** When true, the button is disabled and shows a spinner. */
  loading?: boolean;
  /** Optional loading-state label announced to assistive tech. */
  loadingText?: string;
}

/**
 * Button wrapper for mutation submits. While `loading` is true the button
 * is disabled, shows an inline spinner, and exposes `aria-busy` so screen
 * reader users are told the action is in progress. Prevents double-submit.
 */
export const LoadingButton = forwardRef<HTMLButtonElement, LoadingButtonProps>(
  ({ loading, loadingText, disabled, children, className, ...props }, ref) => {
    return (
      <Button
        ref={ref}
        {...props}
        aria-busy={loading || undefined}
        aria-live={loading ? "polite" : undefined}
        disabled={disabled || loading}
        className={cn(className)}
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            <span>{loadingText ?? children}</span>
          </>
        ) : (
          children
        )}
      </Button>
    );
  },
);
LoadingButton.displayName = "LoadingButton";
