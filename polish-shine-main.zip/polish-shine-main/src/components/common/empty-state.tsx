import type { ReactNode } from "react";
import { Inbox } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Standard empty-state card used across every list/table/grid so the pattern
 * (icon + title + description + optional CTA) is consistent app-wide.
 *
 * Uses the shared `.empty-state` utility from styles.css.
 */
export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("empty-state", className)}>
      <div className="mb-1 text-muted-foreground/70" aria-hidden="true">
        {icon ?? <Inbox className="h-8 w-8" strokeWidth={1.6} />}
      </div>
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      {description ? (
        <p className="max-w-sm text-xs text-muted-foreground">{description}</p>
      ) : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}
