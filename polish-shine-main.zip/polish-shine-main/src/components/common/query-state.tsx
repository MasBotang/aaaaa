import type { ReactNode } from "react";
import { ErrorState } from "./error-state";

/**
 * Composable wrapper that standardises the loading / error / empty triad
 * for a useQuery result. Pass the query's flags in and the correct branch
 * renders — including a smooth fade-in of real content via `page-enter`.
 *
 * Background refetches (`isFetching` while data is already present) do NOT
 * re-show the skeleton; render a <RefetchingBadge> near the section title
 * instead.
 */
export function QueryState<T>({
  data,
  isLoading,
  isError,
  error,
  onRetry,
  skeleton,
  empty,
  isEmpty,
  children,
}: {
  data: T | undefined;
  isLoading: boolean;
  isError: boolean;
  error?: unknown;
  onRetry?: () => void;
  skeleton: ReactNode;
  empty?: ReactNode;
  isEmpty?: (data: T) => boolean;
  children: (data: T) => ReactNode;
}) {
  if (isLoading && data === undefined) {
    return <>{skeleton}</>;
  }
  if (isError && data === undefined) {
    return <ErrorState error={error} onRetry={onRetry} />;
  }
  if (data === undefined) {
    return <>{skeleton}</>;
  }
  if (empty && isEmpty && isEmpty(data)) {
    return <>{empty}</>;
  }
  return <div className="page-enter">{children(data)}</div>;
}
