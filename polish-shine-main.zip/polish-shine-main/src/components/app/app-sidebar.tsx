import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronRight, LogOut } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { navForRole, ROLE_LANDING, type NavItem } from "@/lib/navigation";
import { useRole, ROLE_LABELS } from "@/lib/role-context";
import { storage, StorageKeys } from "@/services/storage";
import { toast } from "sonner";

function isItemActive(pathname: string, item: NavItem): boolean {
  if (item.to) return pathname === item.to || pathname.startsWith(item.to + "/");
  if (item.children)
    return item.children.some((c) => pathname === c.to || pathname.startsWith(c.to + "/"));
  return false;
}

function readExpanded(): Record<string, boolean> {
  return storage.get<Record<string, boolean>>(StorageKeys.sidebarState) ?? {};
}

/** Subtle botanical/risol decoration; anchored to sidebar bottom, low opacity. */
function BotanicalDecoration() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-x-0 bottom-16 -z-0 flex justify-center opacity-[0.09]"
    >
      <svg
        width="240"
        height="180"
        viewBox="0 0 240 180"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* stem */}
        <path
          d="M120 180 C 120 140, 130 110, 120 70 S 90 30, 120 10"
          stroke="currentColor"
          strokeWidth="1.2"
          strokeLinecap="round"
        />
        {/* leaves */}
        <path
          d="M120 130 Q 90 118 78 96 Q 108 100 120 130 Z"
          fill="currentColor"
          opacity="0.9"
        />
        <path
          d="M120 100 Q 150 88 162 66 Q 132 70 120 100 Z"
          fill="currentColor"
          opacity="0.9"
        />
        <path
          d="M120 70 Q 96 60 88 40 Q 114 44 120 70 Z"
          fill="currentColor"
          opacity="0.9"
        />
        {/* risol (triangular fritter) */}
        <g transform="translate(60 150) rotate(-14)">
          <path
            d="M0 20 L 40 0 L 44 24 Z"
            fill="currentColor"
            opacity="0.85"
          />
          <path d="M6 18 L 38 4" stroke="currentColor" strokeWidth="0.8" opacity="0.6" />
          <path d="M10 20 L 40 6" stroke="currentColor" strokeWidth="0.8" opacity="0.6" />
        </g>
        <g transform="translate(160 148) rotate(18)">
          <path
            d="M0 22 L 44 0 L 46 26 Z"
            fill="currentColor"
            opacity="0.85"
          />
          <path d="M8 20 L 40 4" stroke="currentColor" strokeWidth="0.8" opacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

export function AppSidebar() {
  const { role, profile, user, signOut } = useRole();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  useEffect(() => {
    setExpanded(readExpanded());
  }, []);

  if (!role) return null;
  const items = navForRole(role);

  const badgeFor = (_item: NavItem): number => 0;

  async function handleSignOut() {
    await signOut();
    toast.success("Berhasil keluar");
    router.navigate({ to: "/auth", replace: true });
  }

  const displayName = profile?.full_name ?? user?.email ?? "User";
  const initials = (profile?.full_name || user?.email || "U")
    .split(/[ @]/)[0]
    .slice(0, 2)
    .toUpperCase();

  function toggle(id: string, next: boolean) {
    setExpanded((prev) => {
      const updated = { ...prev, [id]: next };
      storage.set(StorageKeys.sidebarState, updated);
      return updated;
    });
  }

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="border-b border-sidebar-border/60 pb-3">
        <Link
          to={ROLE_LANDING[role]}
          className="flex items-center gap-3 px-1.5 py-2 text-sm"
        >
          <div className="relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-2xl bg-[oklch(0.98_0.012_85)] shadow-[0_10px_24px_-10px_rgba(0,0,0,0.5)]">
            <img
              src="/apple-touch-icon.png"
              alt=""
              aria-hidden
              className="h-full w-full object-cover"
              draggable={false}
            />
          </div>
          {!collapsed && (
            <div className="flex min-w-0 flex-col leading-tight">
              <span className="truncate font-display text-[18px] font-bold text-sidebar-foreground">
                de Salut
              </span>
              <span className="truncate text-[10px] font-semibold uppercase tracking-[0.14em] text-sidebar-foreground/60">
                handcrafted comfort food
              </span>
            </div>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent className="relative overflow-hidden">
        {!collapsed && <BotanicalDecoration />}
        <SidebarGroup className="relative z-10 pt-2">
          <SidebarGroupContent>
            <SidebarMenu className="gap-1">
              {items.map((item) => {
                const active = isItemActive(pathname, item);
                if (!item.children) {
                  return (
                    <SidebarMenuItem key={item.id}>
                      <SidebarMenuButton
                        asChild
                        isActive={active}
                        tooltip={item.title}
                        className="h-10 rounded-xl px-3 font-medium data-[active=true]:bg-primary data-[active=true]:text-primary-foreground data-[active=true]:shadow-[0_8px_20px_-10px_rgba(0,0,0,0.55)]"
                      >
                        <Link to={item.to!} className="flex items-center gap-2.5">
                          <item.icon className="h-[18px] w-[18px]" strokeWidth={1.85} />
                          <span className="truncate">{item.title}</span>
                          {badgeFor(item) > 0 && !collapsed && (
                            <Badge className="ml-auto h-5 px-1.5 text-[10px] tabular-nums">
                              {badgeFor(item)}
                            </Badge>
                          )}
                          {item.comingVersion && !collapsed && (
                            <Badge
                              variant="outline"
                              className="ml-auto h-5 border-sidebar-foreground/25 bg-transparent px-1.5 text-[10px] text-sidebar-foreground/60"
                            >
                              V{item.comingVersion}
                            </Badge>
                          )}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                }

                const isOpen = expanded[item.id] ?? active;
                return (
                  <Collapsible
                    key={item.id}
                    asChild
                    open={isOpen}
                    onOpenChange={(o) => toggle(item.id, o)}
                  >
                    <SidebarMenuItem>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton
                          isActive={active}
                          tooltip={item.title}
                          className="h-10 rounded-xl px-3 font-medium data-[active=true]:bg-primary data-[active=true]:text-primary-foreground data-[active=true]:shadow-[0_8px_20px_-10px_rgba(0,0,0,0.55)]"
                        >
                          <item.icon className="h-[18px] w-[18px]" strokeWidth={1.85} />
                          <span className="truncate">{item.title}</span>
                          {item.comingVersion && !collapsed && (
                            <Badge
                              variant="outline"
                              className="ml-auto h-5 border-sidebar-foreground/25 bg-transparent px-1.5 text-[10px] text-sidebar-foreground/60"
                            >
                              V{item.comingVersion}
                            </Badge>
                          )}
                          {!item.comingVersion && (
                            <ChevronRight
                              className="ml-auto h-4 w-4 shrink-0 transition-transform duration-200 data-[state=open]:rotate-90"
                              data-state={isOpen ? "open" : "closed"}
                              strokeWidth={1.9}
                            />
                          )}
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub className="ml-4 mt-1 gap-0.5 border-l-sidebar-border/40">
                          {item.children.map((c) => {
                            const childActive =
                              pathname === c.to || pathname.startsWith(c.to + "/");
                            return (
                              <SidebarMenuSubItem key={c.to}>
                                <SidebarMenuSubButton
                                  asChild
                                  isActive={childActive}
                                  className="h-8 rounded-lg data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-foreground"
                                >
                                  <Link to={c.to} className="flex items-center">
                                    <span className="truncate">{c.title}</span>
                                    {c.comingVersion && (
                                      <Badge
                                        variant="outline"
                                        className="ml-auto h-5 border-sidebar-foreground/25 bg-transparent px-1.5 text-[10px] text-sidebar-foreground/60"
                                      >
                                        V{c.comingVersion}
                                      </Badge>
                                    )}
                                  </Link>
                                </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            );
                          })}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </SidebarMenuItem>
                  </Collapsible>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border/60">
        {collapsed ? (
          <Button
            variant="ghost"
            size="icon"
            onClick={handleSignOut}
            className="mx-auto text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
            aria-label="Keluar"
          >
            <LogOut className="h-4 w-4" strokeWidth={1.9} />
          </Button>
        ) : (
          <div className="flex flex-col gap-2 rounded-xl border border-sidebar-border/40 bg-[oklch(1_0_0/0.04)] p-2.5">
            <div className="flex items-center gap-2.5">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[oklch(0.88_0.14_86)] to-[oklch(0.72_0.14_78)] text-[11px] font-bold uppercase text-[oklch(0.32_0.12_28)]">
                {initials}
              </div>
              <div className="flex min-w-0 flex-col leading-tight">
                <span className="truncate text-[13px] font-semibold text-sidebar-foreground">
                  {displayName}
                </span>
                <span className="truncate text-[10.5px] text-sidebar-foreground/60">
                  {ROLE_LABELS[role]}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSignOut}
                className="ml-auto h-8 w-8 shrink-0 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                aria-label="Keluar"
              >
                <LogOut className="h-4 w-4" strokeWidth={1.9} />
              </Button>
            </div>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
