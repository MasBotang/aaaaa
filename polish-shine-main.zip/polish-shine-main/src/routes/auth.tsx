import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { useRole } from "@/lib/role-context";
import { ROLE_LANDING } from "@/lib/navigation";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  validateSearch: (s) =>
    z.object({ redirect: z.string().optional() }).parse(s),
  head: () => ({
    meta: [
      { title: "Masuk — de Salut" },
      { name: "description", content: "Masuk ke akun tim de Salut." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { user, role, hydrated, signIn } = useRole();
  const navigate = useNavigate();
  const search = Route.useSearch();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (hydrated && user && role) {
      const target = search.redirect || ROLE_LANDING[role];
      navigate({ to: target, replace: true });
    }
  }, [hydrated, user, role, search.redirect, navigate]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    try {
      await signIn(email.trim(), password);
      toast.success("Berhasil masuk");
    } catch (error) {
      const msg = (error as Error).message;
      setErr(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-background px-6 py-10">
      {/* warm decorative blobs */}
      <div
        className="pointer-events-none absolute -top-56 -right-56 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, oklch(0.85 0.12 80 / 0.24), transparent 70%)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-56 -left-56 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, oklch(0.45 0.16 26 / 0.10), transparent 70%)" }}
      />
      {/* subtle risol/botanical doodles scattered around the card */}
      <RisolDoodle className="pointer-events-none absolute left-[8%] top-[14%] h-24 w-24 -rotate-12 text-primary/10 md:h-32 md:w-32" />
      <RisolDoodle className="pointer-events-none absolute bottom-[10%] right-[10%] h-28 w-28 rotate-[18deg] text-primary/10 md:h-36 md:w-36" />

      <div className="relative z-10 w-full max-w-[420px]">
        <div className="overflow-hidden rounded-[28px] border border-white/60 bg-surface shadow-elevated">
          <div className="flex flex-col items-center px-8 pb-8 pt-10 text-center">
            <img
              src="/logo-desalut.png"
              alt="de Salut — handcrafted comfort food"
              className="h-auto w-[220px] max-w-full select-none"
              draggable={false}
            />
            <div className="mt-5 h-[3px] w-11 rounded-full gold-gradient" />
            <p className="mt-4 text-[13.5px] leading-relaxed text-muted-foreground">
              Masuk untuk lanjut kelola pesanan, dapur, dan penjualan hari ini.
            </p>
          </div>

          <div className="px-8 pb-10">
            {err && (
              <div className="mb-4 rounded-xl bg-destructive-soft px-3 py-2.5 text-[12.5px] font-medium text-destructive">
                {err}
              </div>
            )}

            <form className="space-y-4" onSubmit={handleLogin}>
              <div>
                <label
                  className="mb-2 block text-[10.5px] font-bold uppercase tracking-[0.09em]"
                  style={{ color: "var(--primary-deep)" }}
                >
                  Email
                </label>
                <input
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nama@desalut.id"
                  className="w-full rounded-2xl border border-border bg-surface px-4 py-3.5 text-sm text-foreground outline-none transition focus:border-primary focus:shadow-[0_0_0_4px_oklch(0.48_0.16_26_/_0.10)]"
                />
              </div>
              <div>
                <label
                  className="mb-2 block text-[10.5px] font-bold uppercase tracking-[0.09em]"
                  style={{ color: "var(--primary-deep)" }}
                >
                  Kata Sandi
                </label>
                <input
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-2xl border border-border bg-surface px-4 py-3.5 text-sm text-foreground outline-none transition focus:border-primary focus:shadow-[0_0_0_4px_oklch(0.48_0.16_26_/_0.10)]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="mt-2 w-full rounded-2xl py-3.5 text-sm font-bold text-primary-foreground transition hover:-translate-y-0.5 active:translate-y-0 shadow-brand disabled:opacity-60 disabled:hover:translate-y-0"
                style={{ background: "var(--primary-deep)" }}
              >
                {loading ? "Memproses…" : "Masuk"}
              </button>
            </form>

            <BootstrapAdminPanel />
          </div>
        </div>

        <p className="mt-6 text-center text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70">
          de Salut · handcrafted comfort food
        </p>
      </div>
    </div>
  );
}

/**
 * Auth migration note: sebelumnya panel ini punya form "Buat Admin
 * Pertama" yang self-service — tapi form itu menulis ke
 * `accounts.functions.ts` (store localStorage lama) yang sudah TIDAK
 * terhubung ke Supabase Auth sama sekali (signIn() di atas memakai
 * supabase.auth.signInWithPassword). Akun yang dibuat lewat form lama itu
 * tidak akan pernah bisa dipakai login. Sesuai kebijakan bootstrap akun
 * pertama yang baru (lihat docs/auth-migration.md), TIDAK ada self
 * registration di UI — admin pertama dibuat lewat Supabase Dashboard atau
 * Auth Admin API, lalu profil admin-nya di-set lewat
 * supabase/seed/bootstrap-admin.sql.
 */
function BootstrapAdminPanel() {
  return (
    <div
      className="mt-7 rounded-2xl border p-4"
      style={{ background: "var(--gold-soft)", borderColor: "oklch(0.88 0.10 88)" }}
    >
      <div
        className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em]"
        style={{ color: "oklch(0.45 0.10 70)" }}
      >
        Belum Punya Akun?
      </div>
      <p className="text-[12px] leading-relaxed" style={{ color: "oklch(0.40 0.08 60)" }}>
        Akun tim baru dibuat oleh Admin lewat menu{" "}
        <span className="font-semibold">Pengaturan → Manajemen Akun</span>. Hubungi admin kamu
        kalau butuh akses.
      </p>
    </div>
  );
}

/** Coretan risol tipis — dekorasi latar, senada dengan yang ada di sidebar. */
function RisolDoodle({ className }: { className?: string }) {
  return (
    <svg
      aria-hidden
      viewBox="0 0 240 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        d="M120 180 C 120 140, 130 110, 120 70 S 90 30, 120 10"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <path d="M120 130 Q 90 118 78 96 Q 108 100 120 130 Z" fill="currentColor" opacity="0.9" />
      <path d="M120 100 Q 150 88 162 66 Q 132 70 120 100 Z" fill="currentColor" opacity="0.9" />
      <path d="M120 70 Q 96 60 88 40 Q 114 44 120 70 Z" fill="currentColor" opacity="0.9" />
      <g transform="translate(60 150) rotate(-14)">
        <path d="M0 20 L 40 0 L 44 24 Z" fill="currentColor" opacity="0.85" />
        <path d="M6 18 L 38 4" stroke="currentColor" strokeWidth="0.9" opacity="0.6" />
        <path d="M10 20 L 40 6" stroke="currentColor" strokeWidth="0.9" opacity="0.6" />
      </g>
      <g transform="translate(160 148) rotate(18)">
        <path d="M0 22 L 44 0 L 46 26 Z" fill="currentColor" opacity="0.85" />
        <path d="M8 20 L 40 4" stroke="currentColor" strokeWidth="0.9" opacity="0.6" />
      </g>
    </svg>
  );
}
