import { createFileRoute } from "@tanstack/react-router";
import { PackageOpen } from "lucide-react";

export const Route = createFileRoute("/_app/unavailable")({
  head: () => ({
    meta: [
      { title: "Modul belum tersedia — de Salut" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: UnavailablePage,
});

function UnavailablePage() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="w-full max-w-md rounded-[22px] border border-border/60 bg-card p-8 text-center shadow-card">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
          <PackageOpen className="h-7 w-7" />
        </div>
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Modul belum tersedia
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Peran Anda dikonfigurasi untuk modul yang belum diaktifkan pada build
          ini. Silakan hubungi admin untuk diarahkan ke workspace yang sesuai.
        </p>
      </div>
    </div>
  );
}
