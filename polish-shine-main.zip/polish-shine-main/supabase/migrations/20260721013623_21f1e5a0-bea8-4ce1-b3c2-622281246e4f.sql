create extension if not exists pgcrypto;

create or replace function public.current_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

revoke execute on function public.current_role() from public, anon;
grant execute on function public.current_role() to authenticated;

create table public.price_groups (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  sources text[] not null default '{}',
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index price_groups_is_default_idx on public.price_groups (is_default);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  category text not null,
  price numeric(14,2) not null default 0,
  cost numeric(14,2) not null default 0,
  sku text,
  stock numeric(12,3) not null default 0,
  wip_stock numeric(12,3) not null default 0,
  min_stock numeric(12,3),
  image_url text,
  active boolean not null default true,
  stock_source text check (stock_source in ('freezer','showcase')),
  prices jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_category_idx on public.products (category);
create index products_active_idx on public.products (active);

create table public.shifts (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  cashier text not null,
  opened_at timestamptz not null,
  closed_at timestamptz,
  opening_cash numeric(14,2) not null default 0,
  closing_cash numeric(14,2),
  expected_cash numeric(14,2),
  cash_difference_reason text,
  total_orders integer,
  total_revenue numeric(14,2),
  cash_sales numeric(14,2),
  qris_sales numeric(14,2),
  transfer_sales numeric(14,2),
  marketplace_sales numeric(14,2),
  operational_expenses jsonb not null default '[]'::jsonb,
  total_operational_expense numeric(14,2),
  packaging_usage jsonb not null default '[]'::jsonb,
  total_packaging_qty numeric(12,3),
  packaging_usage_saved_at timestamptz,
  packaging_usage_saved_by text,
  marketplace_reconciliations jsonb not null default '[]'::jsonb,
  payment_reconciliations jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index shifts_cashier_idx on public.shifts (cashier);
create index shifts_opened_at_idx on public.shifts (opened_at desc);
create unique index shifts_only_one_open_idx on public.shifts ((true)) where closed_at is null;

create table public.preorders (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  customer_name text not null,
  customer_phone text,
  date date not null,
  time text not null,
  items jsonb not null default '[]'::jsonb,
  total numeric(14,2) not null default 0,
  notes text,
  status text not null check (status in ('scheduled','ready_to_process','completed','cancelled')),
  source_order text not null check (source_order in ('outlet','shopeefood','gofood','grabfood','whatsapp','reseller')),
  price_group_id uuid references public.price_groups(id) on delete set null,
  sale_type text check (sale_type in ('frozen','matang')),
  sale_id uuid,
  queue_id uuid,
  down_payment numeric(14,2),
  remaining_balance numeric(14,2),
  dp_paid_at timestamptz,
  dp_method text check (dp_method in ('cash','qris','card','transfer')),
  packings jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now()
);
create index preorders_status_idx on public.preorders (status);
create index preorders_date_idx on public.preorders (date);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  cashier text not null,
  customer_name text,
  shift_id uuid references public.shifts(id) on delete set null,
  items jsonb not null default '[]'::jsonb,
  subtotal numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  payment jsonb not null default '[]'::jsonb,
  tendered numeric(14,2),
  change numeric(14,2),
  voided boolean not null default false,
  void_reason text,
  voided_by text,
  voided_at timestamptz,
  sale_type text check (sale_type in ('frozen','matang')),
  customer_type text check (customer_type in ('end_user','reseller')),
  is_preorder boolean not null default false,
  customer_phone text,
  pickup_at timestamptz,
  source_order text check (source_order in ('outlet','shopeefood','gofood','grabfood','whatsapp','reseller')),
  price_group_id uuid references public.price_groups(id) on delete set null,
  preorder_id uuid references public.preorders(id) on delete set null,
  order_number text,
  packings jsonb not null default '[]'::jsonb,
  plastic jsonb,
  extra_packaging jsonb not null default '[]'::jsonb,
  customer_notes text
);
create index sales_created_at_idx on public.sales (created_at desc);
create index sales_shift_id_idx on public.sales (shift_id);
create index sales_preorder_id_idx on public.sales (preorder_id);
create index sales_source_order_idx on public.sales (source_order);
create index sales_voided_idx on public.sales (voided);

alter table public.preorders
  add constraint preorders_sale_id_fkey foreign key (sale_id)
  references public.sales(id) on delete set null;

create table public.hold_orders (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  customer_name text not null,
  items jsonb not null default '[]'::jsonb,
  total numeric(14,2) not null default 0,
  source_order text check (source_order in ('outlet','shopeefood','gofood','grabfood','whatsapp','reseller')),
  price_group_id uuid references public.price_groups(id) on delete set null
);

create table public.order_queue (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  sale_id uuid not null,
  sale_code text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  status text not null check (status in ('waiting','cooking','packing','ready','completed')),
  sale_type text not null check (sale_type in ('frozen','matang')),
  customer_name text not null,
  customer_phone text,
  pickup_at timestamptz,
  is_preorder boolean not null default false,
  item_count integer not null default 0,
  items_summary text,
  timeline jsonb not null default '[]'::jsonb,
  last_actor text,
  source_order text check (source_order in ('outlet','shopeefood','gofood','grabfood','whatsapp','reseller')),
  preorder_id uuid references public.preorders(id) on delete set null,
  order_number text,
  packings jsonb not null default '[]'::jsonb
);
create index order_queue_status_idx on public.order_queue (status);
create index order_queue_sale_id_idx on public.order_queue (sale_id);

alter table public.preorders
  add constraint preorders_queue_id_fkey foreign key (queue_id)
  references public.order_queue(id) on delete set null;

create table public.production_need_additions (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  preorder_id uuid not null references public.preorders(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  product_name text not null,
  qty numeric(12,3) not null,
  date date not null,
  status text not null check (status in ('active','released')),
  created_at timestamptz not null default now(),
  released_at timestamptz,
  release_reason text check (release_reason in ('cancelled','completed','expired','manual'))
);
create index production_need_additions_preorder_idx on public.production_need_additions (preorder_id);
create index production_need_additions_status_idx on public.production_need_additions (status);

create table public.refund_requests (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  sale_id uuid not null references public.sales(id) on delete restrict,
  requested_by text not null,
  requested_by_role text check (requested_by_role in ('admin','owner','cashier','production')),
  requested_at timestamptz not null default now(),
  reason text not null,
  status text not null check (status in ('pending','approved','rejected')),
  decided_by text,
  decided_by_role text check (decided_by_role in ('admin','owner','cashier','production')),
  decided_at timestamptz,
  decision_note text
);
create index refund_requests_sale_idx on public.refund_requests (sale_id);
create index refund_requests_status_idx on public.refund_requests (status);

create table public.preorder_cancel_requests (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  preorder_id uuid not null references public.preorders(id) on delete restrict,
  requested_by text not null,
  requested_by_role text check (requested_by_role in ('admin','owner','cashier','production')),
  requested_at timestamptz not null default now(),
  reason text not null,
  status text not null check (status in ('pending','approved','rejected')),
  decided_by text,
  decided_by_role text check (decided_by_role in ('admin','owner','cashier','production')),
  decided_at timestamptz,
  decision_note text,
  down_payment_at_request numeric(14,2) not null
);
create index preorder_cancel_requests_preorder_idx on public.preorder_cancel_requests (preorder_id);
create index preorder_cancel_requests_status_idx on public.preorder_cancel_requests (status);

create table public.marketplace_settlements (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  date date not null,
  marketplace text not null check (marketplace in ('shopeefood','gofood','grabfood')),
  order_count integer not null default 0,
  gross_sales numeric(14,2) not null default 0,
  marketplace_fee numeric(14,2) not null default 0,
  net_received numeric(14,2) not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  created_by text not null
);
create index marketplace_settlements_date_idx on public.marketplace_settlements (date);
create index marketplace_settlements_marketplace_idx on public.marketplace_settlements (marketplace);

create table public.sales_targets (
  date_key text primary key,
  target numeric(14,2) not null default 0,
  updated_at timestamptz not null default now()
);

create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  actor text not null,
  actor_role text,
  action text not null,
  entity text,
  entity_id text,
  reason text,
  metadata jsonb
);
create index audit_log_created_at_idx on public.audit_log (created_at desc);
create index audit_log_action_idx on public.audit_log (action);
create index audit_log_entity_idx on public.audit_log (entity, entity_id);

create table public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  category text not null check (category in ('raw','packaging','operational','production_item')),
  unit text not null,
  stock numeric(12,3) not null default 0,
  min_stock numeric(12,3) not null default 0,
  purchase_price numeric(14,2) not null default 0,
  purchase_quantity numeric(12,3) not null default 0,
  cost_per_unit numeric(14,4) not null default 0,
  active boolean not null default true,
  safety_stock numeric(12,3),
  purchase_type text check (purchase_type in ('satuan','karton')),
  units_per_carton numeric(12,3),
  last_purchase_price numeric(14,2),
  last_purchase_at timestamptz,
  last_supplier text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index inventory_items_category_idx on public.inventory_items (category);
create index inventory_items_active_idx on public.inventory_items (active);

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  item_id uuid not null references public.inventory_items(id) on delete restrict,
  item_name text not null,
  unit text not null,
  type text not null check (type in (
    'restock','operational_usage','adjustment',
    'production_consumption','production_output','sales_packaging_usage'
  )),
  quantity numeric(12,3) not null,
  delta numeric(12,3) not null,
  reason text,
  notes text,
  balance_after numeric(12,3) not null
);
create index stock_movements_item_idx on public.stock_movements (item_id, created_at desc);
create index stock_movements_type_idx on public.stock_movements (type);

create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  type text not null check (type in ('semi_finished','finished','panir')),
  output_target_type text not null check (output_target_type in ('inventory','product')),
  output_ref_id uuid,
  output_name text not null,
  output_quantity numeric(12,3) not null,
  output_unit text not null,
  estimated_yield_pct numeric(5,2) not null default 0,
  estimated_net_weight numeric(12,3),
  estimated_net_weight_unit text check (estimated_net_weight_unit in ('g','kg')),
  notes text,
  ingredients jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index recipes_type_idx on public.recipes (type);
create index recipes_active_idx on public.recipes (active);

create table public.production_runs (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  activity text check (activity in ('create_adonan','produce_finished','panir','finishing_validation')),
  recipe_id uuid references public.recipes(id) on delete set null,
  recipe_name text,
  batches numeric(12,3) not null default 0,
  produced_quantity numeric(12,3) not null default 0,
  output_unit text not null,
  output_target_type text not null check (output_target_type in ('inventory','product')),
  output_ref_id uuid not null,
  output_name text not null,
  operator text not null,
  notes text,
  consumed jsonb not null default '[]'::jsonb,
  rejected_quantity numeric(12,3),
  folder_label text,
  loss_quantity numeric(12,3),
  actual_weight numeric(12,3),
  actual_weight_unit text check (actual_weight_unit in ('g','kg')),
  actual_batches numeric(12,3),
  waste_quantity numeric(12,3)
);
create index production_runs_created_at_idx on public.production_runs (created_at desc);
create index production_runs_recipe_idx on public.production_runs (recipe_id);
create index production_runs_activity_idx on public.production_runs (activity);

create table public.finishing_validations (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  created_at timestamptz not null default now(),
  product_id uuid not null references public.products(id) on delete restrict,
  product_name text not null,
  validated_qty numeric(12,3) not null default 0,
  rejected_qty numeric(12,3) not null default 0,
  operator text not null,
  notes text
);
create index finishing_validations_product_idx on public.finishing_validations (product_id, created_at desc);

create table public.finance_expenses (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  at timestamptz not null,
  description text not null,
  category text not null check (category in ('operational','utilities','equipment','marketing','maintenance','payroll','other')),
  pot text not null check (pot in ('owner','development','operational','debt')),
  payment text not null check (payment in ('cash','qris','bank','dompet')),
  amount numeric(14,2) not null,
  created_by text
);
create index finance_expenses_at_idx on public.finance_expenses (at desc);
create index finance_expenses_pot_idx on public.finance_expenses (pot);

create table public.finance_debts (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  name text not null,
  principal numeric(14,2) not null,
  created_at timestamptz not null default now(),
  target_date date,
  notes text,
  active boolean not null default true
);
create index finance_debts_active_idx on public.finance_debts (active);

create table public.finance_debt_payments (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  debt_id uuid not null references public.finance_debts(id) on delete restrict,
  at timestamptz not null,
  amount numeric(14,2) not null,
  payment text not null check (payment in ('cash','qris','bank','dompet')),
  notes text
);
create index finance_debt_payments_debt_idx on public.finance_debt_payments (debt_id);

create table public.finance_fund_withdraws (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  at timestamptz not null,
  pot text not null check (pot in ('owner','development','operational','debt')),
  amount numeric(14,2) not null,
  description text not null,
  payment text not null check (payment in ('cash','qris','bank','dompet'))
);
create index finance_fund_withdraws_at_idx on public.finance_fund_withdraws (at desc);
create index finance_fund_withdraws_pot_idx on public.finance_fund_withdraws (pot);

create table public.finance_budgets (
  id uuid primary key default gen_random_uuid(),
  category text not null unique check (category in ('operational','development','marketing','owner_salary','debt')),
  monthly_amount numeric(14,2) not null default 0,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.finance_settings (
  id smallint primary key default 1 check (id = 1),
  allocation jsonb not null default '{"owner":0,"development":0,"operational":0,"debt":0}'::jsonb,
  development_target numeric(14,2) not null default 0,
  opening_balance jsonb not null default '{"cash":0,"qris":0,"bank":0,"dompet":0}'::jsonb,
  updated_at timestamptz not null default now()
);

create table public.business_settings (
  id smallint primary key default 1 check (id = 1),
  business_name text not null default '',
  business_logo text,
  sales_target_daily numeric(14,2) not null default 0,
  default_customer_name text not null default '',
  production jsonb,
  updated_at timestamptz not null default now()
);

create table public.daily_counters (
  counter_name text not null check (counter_name in ('sales_sequence','order_number_sequence')),
  day date not null,
  value integer not null default 0,
  primary key (counter_name, day)
);

-- GRANTs for Data API access
GRANT SELECT, INSERT, UPDATE, DELETE ON public.price_groups, public.products, public.shifts, public.preorders, public.sales, public.hold_orders, public.order_queue, public.production_need_additions, public.refund_requests, public.preorder_cancel_requests, public.marketplace_settlements, public.sales_targets, public.audit_log, public.inventory_items, public.stock_movements, public.recipes, public.production_runs, public.finishing_validations, public.finance_expenses, public.finance_debts, public.finance_debt_payments, public.finance_fund_withdraws, public.finance_settings, public.finance_budgets, public.business_settings, public.daily_counters TO authenticated;
GRANT ALL ON public.price_groups, public.products, public.shifts, public.preorders, public.sales, public.hold_orders, public.order_queue, public.production_need_additions, public.refund_requests, public.preorder_cancel_requests, public.marketplace_settlements, public.sales_targets, public.audit_log, public.inventory_items, public.stock_movements, public.recipes, public.production_runs, public.finishing_validations, public.finance_expenses, public.finance_debts, public.finance_debt_payments, public.finance_fund_withdraws, public.finance_settings, public.finance_budgets, public.business_settings, public.daily_counters TO service_role;

-- updated_at triggers
create trigger price_groups_set_updated_at before update on public.price_groups for each row execute function public.tg_set_updated_at();
create trigger products_set_updated_at before update on public.products for each row execute function public.tg_set_updated_at();
create trigger shifts_set_updated_at before update on public.shifts for each row execute function public.tg_set_updated_at();
create trigger preorders_set_updated_at before update on public.preorders for each row execute function public.tg_set_updated_at();
create trigger order_queue_set_updated_at before update on public.order_queue for each row execute function public.tg_set_updated_at();
create trigger sales_targets_set_updated_at before update on public.sales_targets for each row execute function public.tg_set_updated_at();
create trigger inventory_items_set_updated_at before update on public.inventory_items for each row execute function public.tg_set_updated_at();
create trigger recipes_set_updated_at before update on public.recipes for each row execute function public.tg_set_updated_at();
create trigger finance_budgets_set_updated_at before update on public.finance_budgets for each row execute function public.tg_set_updated_at();
create trigger finance_settings_set_updated_at before update on public.finance_settings for each row execute function public.tg_set_updated_at();
create trigger business_settings_set_updated_at before update on public.business_settings for each row execute function public.tg_set_updated_at();

-- Enable RLS
alter table public.price_groups enable row level security;
alter table public.products enable row level security;
alter table public.shifts enable row level security;
alter table public.preorders enable row level security;
alter table public.sales enable row level security;
alter table public.hold_orders enable row level security;
alter table public.order_queue enable row level security;
alter table public.production_need_additions enable row level security;
alter table public.refund_requests enable row level security;
alter table public.preorder_cancel_requests enable row level security;
alter table public.marketplace_settlements enable row level security;
alter table public.sales_targets enable row level security;
alter table public.audit_log enable row level security;
alter table public.inventory_items enable row level security;
alter table public.stock_movements enable row level security;
alter table public.recipes enable row level security;
alter table public.production_runs enable row level security;
alter table public.finishing_validations enable row level security;
alter table public.finance_expenses enable row level security;
alter table public.finance_debts enable row level security;
alter table public.finance_debt_payments enable row level security;
alter table public.finance_fund_withdraws enable row level security;
alter table public.finance_settings enable row level security;
alter table public.finance_budgets enable row level security;
alter table public.business_settings enable row level security;
alter table public.daily_counters enable row level security;

-- Generic read policy for all authenticated users
do $$
declare
  t text;
  tables text[] := array[
    'price_groups','products','shifts','preorders','sales','hold_orders',
    'order_queue','production_need_additions','refund_requests',
    'preorder_cancel_requests','marketplace_settlements','sales_targets',
    'audit_log','inventory_items','stock_movements','recipes',
    'production_runs','finishing_validations','finance_expenses',
    'finance_debts','finance_debt_payments','finance_fund_withdraws',
    'finance_settings','finance_budgets','business_settings','daily_counters'
  ];
begin
  foreach t in array tables loop
    execute format(
      'create policy %I on public.%I for select to authenticated using (true);',
      t || '_read_all', t
    );
  end loop;
end $$;

-- Sales/POS: admin + cashier
do $$
declare
  t text;
  tables text[] := array[
    'sales','shifts','hold_orders','preorders','order_queue',
    'production_need_additions','marketplace_settlements'
  ];
begin
  foreach t in array tables loop
    execute format('create policy %I on public.%I for insert to authenticated with check (public.current_role() in (''admin'',''cashier''));', t || '_write_cashier_ins', t);
    execute format('create policy %I on public.%I for update to authenticated using (public.current_role() in (''admin'',''cashier'')) with check (public.current_role() in (''admin'',''cashier''));', t || '_write_cashier_upd', t);
    execute format('create policy %I on public.%I for delete to authenticated using (public.current_role() = ''admin'');', t || '_delete_admin_only', t);
  end loop;
end $$;

create policy order_queue_write_production_upd on public.order_queue
  for update to authenticated
  using (public.current_role() in ('admin','production'))
  with check (public.current_role() in ('admin','production'));

create policy products_write_ins on public.products
  for insert to authenticated with check (public.current_role() = 'admin');
create policy products_write_upd on public.products
  for update to authenticated
  using (public.current_role() in ('admin','cashier','production'))
  with check (public.current_role() in ('admin','cashier','production'));
create policy products_delete_admin_only on public.products
  for delete to authenticated using (public.current_role() = 'admin');

create policy price_groups_write_admin on public.price_groups
  for all to authenticated
  using (public.current_role() = 'admin')
  with check (public.current_role() = 'admin');

create policy refund_requests_insert on public.refund_requests
  for insert to authenticated with check (public.current_role() in ('admin','cashier'));
create policy refund_requests_decide on public.refund_requests
  for update to authenticated
  using (public.current_role() = 'admin')
  with check (public.current_role() = 'admin');

create policy preorder_cancel_requests_insert on public.preorder_cancel_requests
  for insert to authenticated with check (public.current_role() in ('admin','cashier'));
create policy preorder_cancel_requests_decide on public.preorder_cancel_requests
  for update to authenticated
  using (public.current_role() = 'admin')
  with check (public.current_role() = 'admin');

create policy sales_targets_write_admin on public.sales_targets
  for all to authenticated
  using (public.current_role() = 'admin')
  with check (public.current_role() = 'admin');

create policy audit_log_insert_any_authenticated on public.audit_log
  for insert to authenticated with check (true);

do $$
declare
  t text;
  tables text[] := array[
    'inventory_items','stock_movements','recipes','production_runs',
    'finishing_validations'
  ];
begin
  foreach t in array tables loop
    execute format('create policy %I on public.%I for insert to authenticated with check (public.current_role() in (''admin'',''production''));', t || '_write_production_ins', t);
    execute format('create policy %I on public.%I for update to authenticated using (public.current_role() in (''admin'',''production'')) with check (public.current_role() in (''admin'',''production''));', t || '_write_production_upd', t);
    execute format('create policy %I on public.%I for delete to authenticated using (public.current_role() = ''admin'');', t || '_delete_admin_only', t);
  end loop;
end $$;

do $$
declare
  t text;
  tables text[] := array[
    'finance_expenses','finance_debts','finance_debt_payments',
    'finance_fund_withdraws','finance_settings','finance_budgets',
    'business_settings'
  ];
begin
  foreach t in array tables loop
    execute format('create policy %I on public.%I for all to authenticated using (public.current_role() = ''admin'') with check (public.current_role() = ''admin'');', t || '_write_admin_only', t);
  end loop;
end $$;

create policy daily_counters_write on public.daily_counters
  for all to authenticated
  using (public.current_role() in ('admin','cashier'))
  with check (public.current_role() in ('admin','cashier'));