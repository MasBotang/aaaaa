alter table public.products
  add constraint products_price_nonnegative check (price >= 0),
  add constraint products_cost_nonnegative check (cost >= 0),
  add constraint products_stock_nonnegative check (stock >= 0),
  add constraint products_wip_stock_nonnegative check (wip_stock >= 0),
  add constraint products_min_stock_nonnegative check (min_stock is null or min_stock >= 0);

alter table public.inventory_items
  add constraint inventory_items_stock_nonnegative check (stock >= 0),
  add constraint inventory_items_min_stock_nonnegative check (min_stock >= 0),
  add constraint inventory_items_purchase_price_nonnegative check (purchase_price >= 0),
  add constraint inventory_items_purchase_qty_nonnegative check (purchase_quantity >= 0),
  add constraint inventory_items_cost_per_unit_nonnegative check (cost_per_unit >= 0),
  add constraint inventory_items_safety_stock_nonnegative check (safety_stock is null or safety_stock >= 0),
  add constraint inventory_items_last_purchase_price_nonnegative check (last_purchase_price is null or last_purchase_price >= 0);

alter table public.stock_movements
  add constraint stock_movements_quantity_positive check (quantity > 0);

alter table public.sales
  add constraint sales_subtotal_nonnegative check (subtotal >= 0),
  add constraint sales_total_nonnegative check (total >= 0),
  add constraint sales_tendered_nonnegative check (tendered is null or tendered >= 0),
  add constraint sales_change_nonnegative check (change is null or change >= 0);

alter table public.hold_orders add constraint hold_orders_total_nonnegative check (total >= 0);

alter table public.preorders
  add constraint preorders_total_nonnegative check (total >= 0),
  add constraint preorders_down_payment_nonnegative check (down_payment is null or down_payment >= 0);

alter table public.preorder_cancel_requests
  add constraint preorder_cancel_requests_dp_nonnegative check (down_payment_at_request >= 0);

alter table public.production_need_additions
  add constraint production_need_additions_qty_positive check (qty > 0);

alter table public.marketplace_settlements
  add constraint marketplace_settlements_order_count_nonnegative check (order_count >= 0),
  add constraint marketplace_settlements_gross_sales_nonnegative check (gross_sales >= 0),
  add constraint marketplace_settlements_fee_nonnegative check (marketplace_fee >= 0),
  add constraint marketplace_settlements_net_received_nonnegative check (net_received >= 0);

alter table public.sales_targets add constraint sales_targets_target_nonnegative check (target >= 0);

alter table public.recipes
  add constraint recipes_output_quantity_positive check (output_quantity > 0),
  add constraint recipes_yield_pct_nonnegative check (estimated_yield_pct >= 0),
  add constraint recipes_net_weight_nonnegative check (estimated_net_weight is null or estimated_net_weight >= 0);

alter table public.production_runs
  add constraint production_runs_batches_nonnegative check (batches >= 0),
  add constraint production_runs_produced_qty_nonnegative check (produced_quantity >= 0),
  add constraint production_runs_rejected_qty_nonnegative check (rejected_quantity is null or rejected_quantity >= 0),
  add constraint production_runs_loss_qty_nonnegative check (loss_quantity is null or loss_quantity >= 0),
  add constraint production_runs_actual_weight_nonnegative check (actual_weight is null or actual_weight >= 0),
  add constraint production_runs_actual_batches_nonnegative check (actual_batches is null or actual_batches >= 0),
  add constraint production_runs_waste_qty_nonnegative check (waste_quantity is null or waste_quantity >= 0);

alter table public.finishing_validations
  add constraint finishing_validations_validated_qty_nonnegative check (validated_qty >= 0),
  add constraint finishing_validations_rejected_qty_nonnegative check (rejected_qty >= 0);

alter table public.shifts
  add constraint shifts_opening_cash_nonnegative check (opening_cash >= 0),
  add constraint shifts_closing_cash_nonnegative check (closing_cash is null or closing_cash >= 0),
  add constraint shifts_expected_cash_nonnegative check (expected_cash is null or expected_cash >= 0),
  add constraint shifts_total_orders_nonnegative check (total_orders is null or total_orders >= 0),
  add constraint shifts_total_revenue_nonnegative check (total_revenue is null or total_revenue >= 0),
  add constraint shifts_cash_sales_nonnegative check (cash_sales is null or cash_sales >= 0),
  add constraint shifts_qris_sales_nonnegative check (qris_sales is null or qris_sales >= 0),
  add constraint shifts_transfer_sales_nonnegative check (transfer_sales is null or transfer_sales >= 0),
  add constraint shifts_marketplace_sales_nonnegative check (marketplace_sales is null or marketplace_sales >= 0),
  add constraint shifts_total_opex_nonnegative check (total_operational_expense is null or total_operational_expense >= 0),
  add constraint shifts_total_packaging_qty_nonnegative check (total_packaging_qty is null or total_packaging_qty >= 0);

alter table public.finance_expenses add constraint finance_expenses_amount_positive check (amount > 0);
alter table public.finance_debts add constraint finance_debts_principal_positive check (principal > 0);
alter table public.finance_debt_payments add constraint finance_debt_payments_amount_positive check (amount > 0);
alter table public.finance_fund_withdraws add constraint finance_fund_withdraws_amount_positive check (amount > 0);
alter table public.finance_budgets add constraint finance_budgets_monthly_amount_nonnegative check (monthly_amount >= 0);
alter table public.finance_settings add constraint finance_settings_development_target_nonnegative check (development_target >= 0);
alter table public.business_settings add constraint business_settings_sales_target_daily_nonnegative check (sales_target_daily >= 0);
alter table public.daily_counters add constraint daily_counters_value_nonnegative check (value >= 0);

-- Additional indexes
create index if not exists sales_shift_created_at_idx on public.sales (shift_id, created_at desc);
create index if not exists finance_expenses_pot_at_idx on public.finance_expenses (pot, at desc);
create extension if not exists pg_trgm;
create index if not exists sales_customer_name_trgm_idx on public.sales using gin (customer_name gin_trgm_ops) where customer_name is not null;
create index if not exists preorders_customer_name_trgm_idx on public.preorders using gin (customer_name gin_trgm_ops);
create index if not exists sales_customer_phone_idx on public.sales (customer_phone) where customer_phone is not null;
create index if not exists preorders_customer_phone_idx on public.preorders (customer_phone) where customer_phone is not null;
drop index if exists public.sales_voided_idx;
drop index if exists public.finance_expenses_pot_idx;

-- ==== RPCs ====
alter table public.recipes alter column output_ref_id drop not null;

create or replace function public.deduct_product_stock(p_product_id uuid, p_qty numeric)
returns public.products language plpgsql as $$
declare v_row public.products; v_current numeric; v_name text;
begin
  if p_qty is null or p_qty <= 0 then raise exception 'Qty deduksi harus > 0'; end if;
  update public.products set stock = stock - p_qty, updated_at = now()
    where id = p_product_id and stock >= p_qty returning * into v_row;
  if found then return v_row; end if;
  select stock, name into v_current, v_name from public.products where id = p_product_id;
  if not found then raise exception 'Produk % tidak ditemukan', p_product_id; end if;
  raise exception 'Ready stock % tidak mencukupi (tersedia %, butuh %)', v_name, v_current, p_qty;
end; $$;

create or replace function public.add_product_stock(p_product_id uuid, p_qty numeric)
returns public.products language plpgsql as $$
declare v_row public.products;
begin
  if p_qty is null or p_qty <= 0 then return null; end if;
  update public.products set stock = stock + p_qty, updated_at = now() where id = p_product_id returning * into v_row;
  return v_row;
end; $$;

create or replace function public.adjust_inventory_stock(p_item_id uuid, p_delta numeric)
returns public.inventory_items language plpgsql as $$
declare v_row public.inventory_items;
begin
  update public.inventory_items set stock = greatest(0, stock + p_delta), updated_at = now()
    where id = p_item_id returning * into v_row;
  return v_row;
end; $$;

-- ==== order_queue cashier delete ====
create policy order_queue_delete_cashier on public.order_queue
  for delete to authenticated using (public.current_role() in ('admin','cashier'));

-- ==== profiles account fields ====
alter table public.profiles
  add column status text not null default 'active' check (status in ('active','inactive')),
  add column employee_code text,
  add column phone text,
  add column notes text;

-- ==== stock_movements cashier insert (packaging usage) ====
create policy stock_movements_insert_cashier on public.stock_movements
  for insert to authenticated with check (public.current_role() in ('admin','cashier') and type = 'sales_packaging_usage');