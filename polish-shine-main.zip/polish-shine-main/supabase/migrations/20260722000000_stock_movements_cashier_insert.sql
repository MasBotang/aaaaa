-- ============================================================================
-- 20260722000000_stock_movements_cashier_insert.sql
--
-- Konteks: stockMovementService (src/services/stock-movement.service.ts)
-- baru saja dimigrasikan dari localStorage ke tabel public.stock_movements
-- di Supabase.
--
-- Temuan saat migrasi: policy INSERT semula pada stock_movements (dibuat di
-- 20260717080000_sales_pos_init.sql, grup "Inventory / Production: admin +
-- production") HANYA mengizinkan role admin/production menulis baris.
-- Padahal movement bertipe 'sales_packaging_usage' DITULIS SAAT CHECKOUT
-- oleh CASHIER (lihat sales.service.ts `create()` dan shift.service.ts) —
-- alur paling sering terjadi di operasional harian.
--
-- Selama data ini masih di localStorage gap ini tidak pernah kelihatan
-- (localStorage tidak tunduk RLS). Begitu dipindah ke Supabase, INSERT ini
-- akan ditolak untuk role cashier tanpa policy tambahan di bawah — checkout
-- tetap akan berhasil (packaging movement recording dibungkus try/catch dan
-- tidak membatalkan Sale, sesuai desain existing), tapi jejak
-- stock_movements untuk packaging usage tidak akan pernah tercatat.
--
-- Fix: tambahkan SATU policy INSERT baru untuk cashier, PERSIS pola & alasan
-- yang sudah dipakai untuk tabel `products` ("products: write oleh admin,
-- cashier (stock berkurang saat checkout), production" — lihat baris ~761
-- di 20260717080000_sales_pos_init.sql). UPDATE/DELETE stock_movements
-- TETAP admin+production only — movement history tidak pernah
-- diedit/dihapus oleh cashier di UI mana pun. Murni tambahan INSERT,
-- policy admin/production yang sudah ada TIDAK diubah/dihapus (additive,
-- konsisten dengan prinsip di 20260717090000_db_audit_hardening.sql).
--
-- CATATAN TERKAIT YANG SENGAJA TIDAK DIPERBAIKI DI SINI: RPC
-- `adjust_inventory_stock` (dipanggil sebelum INSERT stock_movements) masih
-- security invoker dan UPDATE-nya di dalam tetap tunduk pada policy
-- inventory_items yang JUGA admin+production only. Artinya nilai stok
-- inventory_items itu sendiri belum tentu benar-benar berkurang saat
-- cashier checkout packaging, walau baris audit stock_movements-nya kini
-- berhasil tercatat berkat policy ini. Ini keputusan permission yang lebih
-- besar (siapa boleh mengubah stok inventory secara langsung) dan perlu
-- dikonfirmasi terpisah ke pemilik produk sebelum diubah.
-- ============================================================================

create policy stock_movements_write_cashier_ins on public.stock_movements
  for insert to authenticated
  with check (public.current_role() in ('admin', 'cashier', 'production'));

comment on policy stock_movements_write_cashier_ins on public.stock_movements is
  'Tambahan additive: cashier butuh INSERT karena sales_packaging_usage movement ditulis saat checkout POS. Lihat komentar migration file untuk detail & catatan terkait inventory_items yang belum diperbaiki.';

-- ============================================================================
-- END 20260722000000_stock_movements_cashier_insert.sql
-- ============================================================================
