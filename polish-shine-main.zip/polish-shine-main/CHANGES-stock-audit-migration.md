# Perbaikan: Migrasi `stock-movement.service.ts` & `audit.service.ts` ke Supabase

Konteks: hasil audit go-live sebelumnya menemukan modul Sales 100% sudah
pindah ke Supabase KECUALI dua side-effect yang dipanggil dari alur
checkout — pencatatan pergerakan stok (`stock_movements`) dan audit log
(`audit_log`) — yang masih baca/tulis `localStorage` browser. Ini bikin dua
jejak itu tidak sinkron antar device/kasir. Perbaikan ini menutup gap
tersebut.

## File yang diubah

1. **`src/services/audit.service.ts`** — ditulis ulang penuh.
   - `list()` dan `byAction()` sekarang `async`, query ke tabel
     `public.audit_log` (default limit 500 baris terbaru).
   - `log()` tetap dipanggil tanpa `await` di semua 29 call site yang
     sudah ada (diverifikasi tidak ada satu pun yang memakai return
     value/meng-await sebelumnya) — insert dikirim di background, error
     ditangkap & di-`console.error`, tidak pernah melempar unhandled
     promise rejection atau membatalkan aksi bisnis yang memicunya.
   - Tidak perlu perubahan RLS — `audit_log` sudah mengizinkan INSERT dari
     semua role authenticated dan SELECT untuk semua row sejak awal.

2. **`src/services/stock-movement.service.ts`** — ditulis ulang penuh.
   - `list()`, `byItem()`, `recent()` sekarang `async`, query ke tabel
     `public.stock_movements`. `record()` tetap `async` (sudah async
     sebelumnya).
   - `save()` dihapus (tidak ada caller eksternal — fungsinya "timpa
     seluruh array" sudah tidak relevan karena `record()` langsung INSERT
     satu baris).
   - Kasus `delta === 0` (mis. adjustment absolut ke nilai stok yang sama)
     di-skip dari INSERT — DB punya CHECK `quantity > 0` yang akan
     menolak baris semacam itu.

3. **`supabase/migrations/20260722000000_stock_movements_cashier_insert.sql`**
   (baru) — menambah policy INSERT untuk role **cashier** pada
   `stock_movements`. Ini wajib dijalankan sebelum deploy: movement
   `sales_packaging_usage` ditulis saat checkout oleh cashier; tanpa
   policy ini, insert akan ditolak RLS untuk role tersebut begitu data
   pindah dari localStorage (yang tidak tunduk RLS) ke Supabase.
   Additive — policy admin/production yang sudah ada tidak diubah.

4. **`DEPLOY.md`** — menambah migration #8 di atas ke urutan eksekusi.

5. **`docs/storage-migration/schema-mapping.md`** — memperbarui ringkasan
   tabel RLS untuk `stock_movements` (cashier sekarang boleh insert) dan
   menambah catatan terkait gap yang belum diperbaiki (lihat di bawah).

## ⚠️ Belum diperbaiki — perlu keputusan produk sebelum go-live penuh

RPC `adjust_inventory_stock` (dipanggil dari `stockMovementService.record()`
untuk benar-benar mengurangi/menambah `inventory_items.stock`) adalah
*security invoker* — UPDATE di dalamnya tetap tunduk pada policy
`inventory_items` yang **masih admin+production only** (tidak disentuh di
migrasi ini). Konsekuensinya: untuk role **cashier**, baris audit
`stock_movements` untuk `sales_packaging_usage` sekarang berhasil tercatat
(berkat fix di atas), **tapi** nilai `inventory_items.stock` itu sendiri
belum tentu benar-benar berkurang saat checkout — RPC diam-diam tidak
meng-update baris yang tidak lolos RLS, lalu `balanceAfter` jatuh ke
fallback perhitungan lokal yang tidak merefleksikan nilai DB sebenarnya.

Ini keputusan permission yang lebih besar (siapa boleh mengubah stok
inventory secara langsung) — mirip dengan ambiguitas "Finance & Settings =
admin-only write" yang sudah dicatat di audit sebelumnya. Perlu dikonfirmasi
ke pemilik produk: apakah cashier memang boleh mengurangi stok
`inventory_items` (mis. bahan baku/packaging) langsung saat checkout, atau
alur ini harus direvisi (mis. lewat RPC `security definer` terpisah yang
tetap dibatasi ke jenis movement tertentu).

## Cara apply

```bash
supabase link --project-ref <project-id>
supabase db push   # akan menjalankan migration #8 di atas otomatis
npm run build && npm run deploy
```

Tidak ada perubahan skema data lain, tidak ada seed baru yang perlu
dijalankan ulang.
